﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// for vibration feedback
const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
let timer_StopVibrate = null;

function makeVibrate(level = 1) {
  let stopDelay = 50;
  stopVibrate();
  
  // after oct 23 update im gonna use increasing levels, where 1 is the lowest (for buttons),
  // 2 is mid level (for open settings) and 3 is the highest (for closing settings).
  const levelToScene = {
    1: 26,
    2: 27,
    3: 29
  };

  let scene = levelToScene[level] || 25;
  vibrate.scene = scene;
  if (scene > 25) stopDelay = 1300;
  vibrate.start();
  timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibrate, {});
}

function stopVibrate() {
  vibrate.stop();
  if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
}

//////Watchface Language Sets (Uppercase)
const watchfaceLangs = {
  EN:{
    WEEKDAYS_SHORT: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
  },

  ES:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MIÉ", "JUE", "VIE", "SÁB", "DOM"],
  },

  IT:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MER", "GIO", "VEN", "SAB", "DOM"],
  },

  PT:{
    WEEKDAYS_SHORT: ["SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM"],
  },

  FR:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MER", "JEU", "VEN", "SAM", "DIM"],
  },

  DE:{
    WEEKDAYS_SHORT: ["MON", "DIE", "MIT", "DON", "FRE", "SAM", "SON"],

  },
};
let currWatchfaceLang;
let currLangCode;

const colorsSet = [
    "BLUE",
    "CYAN",
    "TURQUOISE",
    "LIME",
    "GREEN",
    "YELLOW",
    "ORANGE",
    "RED",
    "PINK",
    "VIOLET",
    "GRAY",
];

const colorHEXset = [
    0xFF74C0FC, // Blue
    0xFF66E6FF, // Cyan
    0xFF63E6BE, // Turquoise
    0xFFAEE66D, // Lime
    0xFF8BE78B, // Green
    0xFFFFEB66, // Yellow
    0xFFFFA94D, // Orange
    0xFFFF6B6B, // Red
    0xFFF58AB5, // Pink
    0xFFA68AD9, // Violet
    0xFFC1C9E5  // Gray
];

let colorsIndex = 0;
let currColor = colorsSet[colorsIndex];
let currColorHEX = colorHEXset[colorsIndex];

let bgAlphaLevels = [
  { TEXT: "Level 1", LEVEL: 128 },  // 50%
  { TEXT: "Level 2", LEVEL: 153 },  // 60%
  { TEXT: "Level 3", LEVEL: 179 },  // 70%
  { TEXT: "Level 4", LEVEL: 204 }   // 80%
];
let bgAlphaIndex = 3;
let currBgAlpha = bgAlphaLevels[bgAlphaIndex];
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_background_bg = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SF-Compact-Rounded-Semibold.ttf; FontSize: 32
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 416,
              h: 45,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Semibold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF-Compact-Rounded-Semibold.ttf; FontSize: 32; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 38,
              h: 38,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Semibold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

//////Function to detect current language from system
function detectLanguage() {
    const zeppAvailableLangs = [
        "ZH", // 0  Chinese (Simplified)
        "ZH", // 1  Chinese (Traditional)
        "EN", // 2  English
        "ES", // 3  Spanish
        "RU", // 4  Russian
        "KO", // 5  Korean
        "FR", // 6  French
        "DE", // 7  German
        "ID", // 8  Indonesian
        "PL", // 9  Polish
        "IT", // 10 Italian
        "JA", // 11 Japanese
        "TH", // 12 Thai
        "AR", // 13 Arabic
        "VI", // 14 Vietnamese
        "PT", // 15 Portuguese (Portugal)
        "NL", // 16 Dutch
        "TR", // 17 Turkish
        "UK", // 18 Ukrainian
        "HE", // 19 Hebrew
        "PT", // 20 Portuguese (Brazil)
        "RO", // 21 Romanian
        "CS", // 22 Czech
        "EL", // 23 Greek
        "SR", // 24 Serbian
        "CA", // 25 Catalan
        "FI", // 26 Finnish
        "NO", // 27 Norwegian
        "DA", // 28 Danish
        "SV", // 29 Swedish
        "HU", // 30 Hungarian
        "MS", // 31 Malay
        "SK", // 32 Slovak
        "HI"  // 33 Hindi
    ];
    let langCode = zeppAvailableLangs[hmSetting.getLanguage()]; //Get current language on watch

    currLangCode = watchfaceLangs[langCode] ? langCode : "EN";
    currWatchfaceLang = watchfaceLangs[currLangCode];
}
detectLanguage();

let bgColor = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 0,
    y: 0,
    w: 390,
    h: 450,
    color: 0xFF74C0FC,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let bgAlphaOverlay = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 0,
    y: 0,
    w: 390,
    h: 450,
    color: 0xFF000000,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
bgAlphaOverlay.setAlpha(currBgAlpha.LEVEL);

let bgOverlay = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: 'WATCHFACE_OVERLAY.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
})
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'TRANSPARENT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 95,
              y: 60,
              w: 200,
              h: 60,
              text_size: 32,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Semibold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 95,
              y: 340,
              w: 200,
              h: 60,
              text_size: 32,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Semibold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_HR.png',
              // center_x: 195,
              // center_y: 225,
              // x: 20,
              // y: 99,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 20,
              pos_y: 225 - 99,
              center_x: 195,
              center_y: 225,
              src: 'HAND_HR.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_MIN.png',
              // center_x: 195,
              // center_y: 225,
              // x: 20,
              // y: 172,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 20,
              pos_y: 225 - 172,
              center_x: 195,
              center_y: 225,
              src: 'HAND_MIN.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_SEC_BLUE.png',
              // center_x: 195,
              // center_y: 225,
              // x: 12,
              // y: 187,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'HAND_SEC_BLUE.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 12,
              second_posY: 187,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_HR.png',
              // center_x: 195,
              // center_y: 225,
              // x: 20,
              // y: 99,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 20,
              pos_y: 225 - 99,
              center_x: 195,
              center_y: 225,
              src: 'HAND_HR.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_MIN.png',
              // center_x: 195,
              // center_y: 225,
              // x: 20,
              // y: 172,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 20,
              pos_y: 225 - 172,
              center_x: 195,
              center_y: 225,
              src: 'HAND_MIN.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 390,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              longpress_func: (button_widget) => {
                settingsMenu(true)
makeVibrate(2)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 145,
              y: 50,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 145,
              y: 175,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 145,
              y: 320,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let watchfaceButtons = [ Button_1, Button_2, Button_3, Button_4 ];

//////Watchface menu
let prevColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 0,
    y: 0,
    w: 100,
    h: 450,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTNPREV_PRESSED.png',
    normal_src: 'settings/BTNPREV_NORMAL.png',
    click_func: (button_widget) => {
    prevColor()
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let nextColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 290,
    y: 0,
    w: 100,
    h: 450,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTNNEXT_PRESSED.png',
    normal_src: 'settings/BTNNEXT_NORMAL.png',
    click_func: (button_widget) => {
    nextColor()
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let bgAlphabtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 145,
    y: 175,
    w: 100,
    h: 100,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BGALPHABTN_PRESSED.png',
    normal_src: 'settings/BGALPHABTN_NORMAL.png',
    click_func: (button_widget) => {
    changeBgAlpha()
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let Confirmbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 135,
    y: 321,
    w: 120,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_CONFIRM_PRESSED.png',
    normal_src: 'settings/BTN_CONFIRM_NORMAL.png',
    click_func: (button_widget) => {
    settingsMenu(false)
    makeVibrate(3)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

//Functions for watchface menu
let toastWatchfaceMenu;

function prevColor(){
    colorsIndex = (colorsIndex - 1 + colorHEXset.length) % colorHEXset.length;
    currColor = colorsSet[colorsIndex];
    currColorHEX = colorHEXset[colorsIndex];
    updateWatchface();
}

function nextColor(){
    colorsIndex = (colorsIndex + 1) % colorHEXset.length;
    currColor = colorsSet[colorsIndex];
    currColorHEX = colorHEXset[colorsIndex];
    updateWatchface();
}

function changeBgAlpha(){
    bgAlphaIndex = (bgAlphaIndex + 1) % bgAlphaLevels.length;
    currBgAlpha = bgAlphaLevels[bgAlphaIndex];
    toastWatchfaceMenu = "Background: " + currBgAlpha.TEXT;
    hmUI.showToast({text: toastWatchfaceMenu})
    updateWatchface();
}

function updateWatchface(){
    //Set background color
    bgColor.setProperty(hmUI.prop.COLOR, currColorHEX);

    //Set background overlay alpha
    bgAlphaOverlay.setAlpha(currBgAlpha.LEVEL);

    //Set clock gradients alpha
    let currHandSecIMG = "HAND_SEC_" + currColor + ".png";
    normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.MORE, {
        second_path: currHandSecIMG,
        second_centerX: 195,
        second_centerY: 225,
        second_posX: 12,
        second_posY: 187,
        fresh_frequency: 15,
        fresh_freqency: 15,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
}

let settingMenuLayout = [ prevColorbtn, nextColorbtn, bgAlphabtn, Confirmbtn ];

function settingsMenu(isMenuVisible){
    watchfaceButtons.forEach(element => element.setProperty(hmUI.prop.VISIBLE, !isMenuVisible));
    settingMenuLayout.forEach(element => element.setProperty(hmUI.prop.VISIBLE, isMenuVisible));
};

settingsMenu(false);
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0');
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                let normal_DOW_Str = currWatchfaceLang.WEEKDAYS_SHORT[timeSensor.week-1];
                let fullDate_Str = normal_DOW_Str + " " + normal_dayStr;

                normal_dow_text_font.setProperty(hmUI.prop.TEXT, fullDate_Str );
              };

              if (updateMinute) { // Hour Pointer
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              if (updateMinute) { // Hour Pointer
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) { // Minute Pointer
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };
            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

                console.log('pause_call.js');
                // start pause_call.js

settingsMenu(false)
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}