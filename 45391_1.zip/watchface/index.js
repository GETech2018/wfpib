﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_compass_icon_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_stress_text_text_img = ''
        let normal_stress_text_separator_img = ''
        let normal_bio_charge_text_text_img = ''
        let normal_bio_charge_text_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_speed_text_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_image_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Play-Regular.ttf; FontSize: 25; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 430,
              y: 512,
              w: 30,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Play-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'background_fd10a9ae.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 320,
              y: 7,
              src: 'Compass_Pointer.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 59,
              y: 0,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 390,
              font_array: ["chars_2B766396_000.png","chars_2B766396_001.png","chars_2B766396_002.png","chars_2B766396_003.png","chars_2B766396_004.png","chars_2B766396_005.png","chars_2B766396_006.png","chars_2B766396_007.png","chars_2B766396_008.png","chars_2B766396_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 337,
              font_array: ["chars_2B766396_000.png","chars_2B766396_001.png","chars_2B766396_002.png","chars_2B766396_003.png","chars_2B766396_004.png","chars_2B766396_005.png","chars_2B766396_006.png","chars_2B766396_007.png","chars_2B766396_008.png","chars_2B766396_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 328,
              src: 'kal_0084.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 445,
              font_array: ["chars_2B766396_000.png","chars_2B766396_001.png","chars_2B766396_002.png","chars_2B766396_003.png","chars_2B766396_004.png","chars_2B766396_005.png","chars_2B766396_006.png","chars_2B766396_007.png","chars_2B766396_008.png","chars_2B766396_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 309,
              y: 446,
              font_array: ["chars_2B766396_000.png","chars_2B766396_001.png","chars_2B766396_002.png","chars_2B766396_003.png","chars_2B766396_004.png","chars_2B766396_005.png","chars_2B766396_006.png","chars_2B766396_007.png","chars_2B766396_008.png","chars_2B766396_009.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 227,
              y: 445,
              src: 'bg_en.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 390,
              font_array: ["chars_2B766396_000.png","chars_2B766396_001.png","chars_2B766396_002.png","chars_2B766396_003.png","chars_2B766396_004.png","chars_2B766396_005.png","chars_2B766396_006.png","chars_2B766396_007.png","chars_2B766396_008.png","chars_2B766396_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 25,
              y: 382,
              src: 'biocharge3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 336,
              font_array: ["chars_CC0A366E_000.png","chars_CC0A366E_001.png","chars_CC0A366E_002.png","chars_CC0A366E_003.png","chars_CC0A366E_004.png","chars_CC0A366E_005.png","chars_CC0A366E_006.png","chars_CC0A366E_007.png","chars_CC0A366E_008.png","chars_CC0A366E_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 63,
              y: 264,
              image_array: ["Wind_D_1.png","Wind_D_2.png","Wind_D_3.png","Wind_D_4.png","Wind_D_5.png","Wind_D_6.png","Wind_D_7.png","Wind_D_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_speed_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 10,
              y: 259,
              font_array: ["chars_2B766396_000.png","chars_2B766396_001.png","chars_2B766396_002.png","chars_2B766396_003.png","chars_2B766396_004.png","chars_2B766396_005.png","chars_2B766396_006.png","chars_2B766396_007.png","chars_2B766396_008.png","chars_2B766396_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND_SPEED,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 170,
              y: 22,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Play-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 22,
              y: 92,
              image_array: ["set_18_70x70_meteo_1.png","set_18_70x70_meteo_2.png","set_18_70x70_meteo_3.png","set_18_70x70_meteo_4.png","set_18_70x70_meteo_5.png","set_18_70x70_meteo_6.png","set_18_70x70_meteo_7.png","set_18_70x70_meteo_8.png","set_18_70x70_meteo_9.png","set_18_70x70_meteo_10.png","set_18_70x70_meteo_11.png","set_18_70x70_meteo_12.png","set_18_70x70_meteo_13.png","set_18_70x70_meteo_14.png","set_18_70x70_meteo_15.png","set_18_70x70_meteo_16.png","set_18_70x70_meteo_17.png","set_18_70x70_meteo_18.png","set_18_70x70_meteo_19.png","set_18_70x70_meteo_20.png","set_18_70x70_meteo_21.png","set_18_70x70_meteo_22.png","set_18_70x70_meteo_23.png","set_18_70x70_meteo_24.png","set_18_70x70_meteo_25.png","set_18_70x70_meteo_26.png","set_18_70x70_meteo_27.png","set_18_70x70_meteo_28.png","set_18_70x70_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 22,
              y: 194,
              font_array: ["chars_CC0A366E_000.png","chars_CC0A366E_001.png","chars_CC0A366E_002.png","chars_CC0A366E_003.png","chars_CC0A366E_004.png","chars_CC0A366E_005.png","chars_CC0A366E_006.png","chars_CC0A366E_007.png","chars_CC0A366E_008.png","chars_CC0A366E_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_1C07B55F_011.png',
              unit_tc: 'chars_1C07B55F_011.png',
              unit_en: 'chars_1C07B55F_011.png',
              negative_image: 'chars_1C07B55F_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 266,
              y: 258,
              src: '113.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 292,
              month_startY: 253,
              month_sc_array: ["chars_CC0A366E_000.png","chars_CC0A366E_001.png","chars_CC0A366E_002.png","chars_CC0A366E_003.png","chars_CC0A366E_004.png","chars_CC0A366E_005.png","chars_CC0A366E_006.png","chars_CC0A366E_007.png","chars_CC0A366E_008.png","chars_CC0A366E_009.png"],
              month_tc_array: ["chars_CC0A366E_000.png","chars_CC0A366E_001.png","chars_CC0A366E_002.png","chars_CC0A366E_003.png","chars_CC0A366E_004.png","chars_CC0A366E_005.png","chars_CC0A366E_006.png","chars_CC0A366E_007.png","chars_CC0A366E_008.png","chars_CC0A366E_009.png"],
              month_en_array: ["chars_CC0A366E_000.png","chars_CC0A366E_001.png","chars_CC0A366E_002.png","chars_CC0A366E_003.png","chars_CC0A366E_004.png","chars_CC0A366E_005.png","chars_CC0A366E_006.png","chars_CC0A366E_007.png","chars_CC0A366E_008.png","chars_CC0A366E_009.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 206,
              day_startY: 254,
              day_sc_array: ["chars_DF6299E2_000.png","chars_DF6299E2_001.png","chars_DF6299E2_002.png","chars_DF6299E2_003.png","chars_DF6299E2_004.png","chars_DF6299E2_005.png","chars_DF6299E2_006.png","chars_DF6299E2_007.png","chars_DF6299E2_008.png","chars_DF6299E2_009.png"],
              day_tc_array: ["chars_DF6299E2_000.png","chars_DF6299E2_001.png","chars_DF6299E2_002.png","chars_DF6299E2_003.png","chars_DF6299E2_004.png","chars_DF6299E2_005.png","chars_DF6299E2_006.png","chars_DF6299E2_007.png","chars_DF6299E2_008.png","chars_DF6299E2_009.png"],
              day_en_array: ["chars_DF6299E2_000.png","chars_DF6299E2_001.png","chars_DF6299E2_002.png","chars_DF6299E2_003.png","chars_DF6299E2_004.png","chars_DF6299E2_005.png","chars_DF6299E2_006.png","chars_DF6299E2_007.png","chars_DF6299E2_008.png","chars_DF6299E2_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 130,
              y: 196,
              week_en: ["chars_A8A932E0_000.png","chars_A8A932E0_001.png","chars_A8A932E0_002.png","chars_A8A932E0_003.png","chars_A8A932E0_004.png","chars_A8A932E0_005.png","chars_A8A932E0_006.png"],
              week_tc: ["chars_A8A932E0_000.png","chars_A8A932E0_001.png","chars_A8A932E0_002.png","chars_A8A932E0_003.png","chars_A8A932E0_004.png","chars_A8A932E0_005.png","chars_A8A932E0_006.png"],
              week_sc: ["chars_A8A932E0_000.png","chars_A8A932E0_001.png","chars_A8A932E0_002.png","chars_A8A932E0_003.png","chars_A8A932E0_004.png","chars_A8A932E0_005.png","chars_A8A932E0_006.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 135,
              hour_startY: 94,
              hour_array: ["chars_FC870475_000.png","chars_FC870475_001.png","chars_FC870475_002.png","chars_FC870475_003.png","chars_FC870475_004.png","chars_FC870475_005.png","chars_FC870475_006.png","chars_FC870475_007.png","chars_FC870475_008.png","chars_FC870475_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 291,
              minute_startY: 94,
              minute_array: ["chars_FC870475_000.png","chars_FC870475_001.png","chars_FC870475_002.png","chars_FC870475_003.png","chars_FC870475_004.png","chars_FC870475_005.png","chars_FC870475_006.png","chars_FC870475_007.png","chars_FC870475_008.png","chars_FC870475_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 263,
              y: 51,
              src: 'chars_AF19D79E_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 208,
              y: 380,
              w: 188,
              h: 55,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 215,
              y: 324,
              w: 170,
              h: 51,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 30,
              y: 443,
              w: 100,
              h: 42,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 30,
              y: 322,
              w: 100,
              h: 56,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 57,
              y: -19,
              w: 91,
              h: 100,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 7,
              y: 85,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 231,
              y: 440,
              w: 136,
              h: 47,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 230,
              y: 250,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 41,
              y: 384,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 303,
              y: 15,
              w: 89,
              h: 46,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}