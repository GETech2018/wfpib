function isHmUIDefined() {
  return typeof hmUI !== "undefined";
}
function isHmBleDefined() {
  return typeof hmBle !== "undefined";
}
function isHmTimerDefined() {
  return typeof timer !== "undefined";
}
function isHmFsDefined() {
  return typeof hmFS !== "undefined";
}
function isHmAppDefined() {
  return typeof hmApp !== "undefined";
}
function isHmSensorDefined() {
  return typeof hmSensor !== "undefined";
}
function isHmSettingDefined() {
  return typeof hmSetting !== "undefined";
}

export { isHmAppDefined, isHmBleDefined, isHmFsDefined, isHmSensorDefined, isHmSettingDefined, isHmTimerDefined, isHmUIDefined };
