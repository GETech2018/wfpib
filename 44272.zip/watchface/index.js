﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_hrv_text_text_img = ''
        let normal_hrv_text_separator_img = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_image_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 367,
              font_array: ["cal_0.png","cal_00.png","cal_1.png","cal_2.png","cal_3.png","cal_4.png","cal_5.png","cal_6.png","cal_7.png","cal_8.png"],
              padding: true,
              h_space: 7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 225,
              y: 420,
              src: 'cal_Text.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 40,
              y: 368,
              font_array: ["stps_0.png","stps_00.png","stps_1.png","stps_2.png","stps_3.png","stps_4.png","stps_5.png","stps_6.png","stps_7.png","stps_8.png"],
              padding: true,
              h_space: 7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 70,
              y: 420,
              src: 'stps_Text.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 30,
              y: 290,
              font_array: ["bpm_0.png","bpm_00.png","bpm_1.png","bpm_2.png","bpm_3.png","bpm_4.png","bpm_5.png","bpm_6.png","bpm_7.png","bpm_8.png"],
              padding: false,
              h_space: 7,
              invalid_image: 'bpm_--.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 137,
              y: 315,
              src: 'bpm_Text.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 70,
              src: 'tmp_Text.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 155,
              y: 90,
              font_array: ["temp_0.png","temp_00.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'temp_C.png',
              unit_tc: 'temp_C.png',
              unit_en: 'temp_C.png',
              imperial_unit_sc: 'temp_C.png',
              imperial_unit_tc: 'temp_C.png',
              imperial_unit_en: 'temp_C.png',
              negative_image: 'temp_-.png',
              invalid_image: 'temp_--.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 155,
                y: 90,
                font_array: ["temp_0.png","temp_00.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png"],
                padding: false,
                h_space: 4,
                unit_sc: 'temp_C.png',
                unit_tc: 'temp_C.png',
                unit_en: 'temp_C.png',
                imperial_unit_sc: 'temp_C.png',
                imperial_unit_tc: 'temp_C.png',
                imperial_unit_en: 'temp_C.png',
                negative_image: 'temp_-.png',
                invalid_image: 'temp_--.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 33,
              y: 36,
              src: 'bttry_Empty.png',
              // alpha: 120,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img.setAlpha(120);

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 85,
              // center_y: 88,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 52,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF26261E,
              // mirror: False,
              // inversion: False,
              // alpha: 190,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 85,
              center_y: 88,
              start_angle: 0,
              end_angle: 360,
              radius: 47,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF26261E,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale.setAlpha(190);
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 75,
              font_array: ["bttry_0.png","bttry_00.png","bttry_1.png","bttry_2.png","bttry_3.png","bttry_4.png","bttry_5.png","bttry_6.png","bttry_7.png","bttry_8.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 13,
              y: 50,
              src: 'bttry_Text.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 252,
              y: 36,
              src: 'mes_Empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 280,
              day_startY: 90,
              day_sc_array: ["bttry_0.png","bttry_00.png","bttry_1.png","bttry_2.png","bttry_3.png","bttry_4.png","bttry_5.png","bttry_6.png","bttry_7.png","bttry_8.png"],
              day_tc_array: ["bttry_0.png","bttry_00.png","bttry_1.png","bttry_2.png","bttry_3.png","bttry_4.png","bttry_5.png","bttry_6.png","bttry_7.png","bttry_8.png"],
              day_en_array: ["bttry_0.png","bttry_00.png","bttry_1.png","bttry_2.png","bttry_3.png","bttry_4.png","bttry_5.png","bttry_6.png","bttry_7.png","bttry_8.png"],
              day_zero: 1,
              day_space: 7,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 252,
              month_startY: 36,
              month_sc_array: ["mes_01.png","mes_02.png","mes_03.png","mes_04.png","mes_05.png","mes_06.png","mes_07.png","mes_08.png","mes_09.png","mes_10.png","mes_11.png","mes_12.png"],
              month_tc_array: ["mes_01.png","mes_02.png","mes_03.png","mes_04.png","mes_05.png","mes_06.png","mes_07.png","mes_08.png","mes_09.png","mes_10.png","mes_11.png","mes_12.png"],
              month_en_array: ["mes_01.png","mes_02.png","mes_03.png","mes_04.png","mes_05.png","mes_06.png","mes_07.png","mes_08.png","mes_09.png","mes_10.png","mes_11.png","mes_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 170,
              hour_array: ["hra_0.png","hra_00.png","hra_1.png","hra_2.png","hra_3.png","hra_4.png","hra_5.png","hra_6.png","hra_7.png","hra_8.png"],
              hour_zero: 1,
              hour_space: 14,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 220,
              minute_startY: 170,
              minute_array: ["min_0.png","min_00.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png"],
              minute_zero: 1,
              minute_space: 14,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 270,
              second_startY: 270,
              second_array: ["seg_0.png","seg_00.png","seg_1.png","seg_2.png","seg_3.png","seg_4.png","seg_5.png","seg_6.png","seg_7.png","seg_8.png"],
              second_zero: 1,
              second_space: 7,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 195,
              y: 170,
              src: 'hra_Sep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 85,
                      center_y: 88,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 47,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF26261E,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}