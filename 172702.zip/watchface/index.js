﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sleep_score_font = ''
        let normal_sleep_time_font = ''
        let normal_sleep_end_font = ''
        let normal_sleep_start_font = ''
        let normal_humidity_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_city_name_text = ''
        let normal_stress_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER', ];
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_battery_text_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_text_text_img = ''
        let normal_stand_circle_scale = ''
        let normal_stand_target_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_month_name_font = ''
        let idle_Month_Array = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER', ];
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_linear_scale = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let Button_14 = ''
        let timeSensor = '';
        let sleepSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 498,
              src: '001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 369,
              y: 203,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_score_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 133,
              y: 375,
              w: 166,
              h: 53,
              text_size: 33,
              char_space: 0,
              color: 0xFF95CDEE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 130,
              y: 453,
              w: 166,
              h: 37,
              text_size: 28,
              char_space: 0,
              color: 0xFFE8B917,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_end_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 135,
              y: 433,
              w: 166,
              h: 33,
              text_size: 26,
              char_space: 0,
              color: 0xFF17B566,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              // padding: true,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            normal_sleep_start_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 128,
              y: 430,
              w: 166,
              h: 33,
              text_size: 26,
              char_space: 0,
              color: 0xFF17B566,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 391,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'z_empty.png',
              unit_tc: 'z_empty.png',
              unit_en: 'z_empty.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 253,
              y: 343,
              image_array: ["w00.png","w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 376,
              y: 391,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              unit_sc: '050.png',
              unit_tc: '050.png',
              unit_en: '050.png',
              imperial_unit_sc: '049.png',
              imperial_unit_tc: '049.png',
              imperial_unit_en: '049.png',
              negative_image: '047.png',
              invalid_image: '048.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 376,
                y: 391,
                font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
                padding: false,
                h_space: 1,
                unit_sc: '049.png',
                unit_tc: '049.png',
                unit_en: '049.png',
                imperial_unit_sc: '050.png',
                imperial_unit_tc: '050.png',
                imperial_unit_en: '050.png',
                negative_image: '047.png',
                invalid_image: '048.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 376,
              y: 353,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              unit_sc: '050.png',
              unit_tc: '050.png',
              unit_en: '050.png',
              imperial_unit_sc: '049.png',
              imperial_unit_tc: '049.png',
              imperial_unit_en: '049.png',
              negative_image: '047.png',
              invalid_image: '048.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 376,
                y: 353,
                font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
                padding: false,
                h_space: 1,
                unit_sc: '049.png',
                unit_tc: '049.png',
                unit_en: '049.png',
                imperial_unit_sc: '050.png',
                imperial_unit_tc: '050.png',
                imperial_unit_en: '050.png',
                negative_image: '047.png',
                invalid_image: '048.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 391,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              unit_sc: '050.png',
              unit_tc: '050.png',
              unit_en: '050.png',
              imperial_unit_sc: '049.png',
              imperial_unit_tc: '049.png',
              imperial_unit_en: '049.png',
              negative_image: '047.png',
              invalid_image: '048.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 249,
                y: 391,
                font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
                padding: false,
                h_space: 1,
                unit_sc: '049.png',
                unit_tc: '049.png',
                unit_en: '049.png',
                imperial_unit_sc: '050.png',
                imperial_unit_tc: '050.png',
                imperial_unit_en: '050.png',
                negative_image: '047.png',
                invalid_image: '048.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 260,
              y: 78,
              w: 166,
              h: 33,
              text_size: 23,
              char_space: 2,
              color: 0xFFDFE405,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 128,
              y: 391,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 391,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'z_empty.png',
              unit_tc: 'z_empty.png',
              unit_en: 'z_empty.png',
              invalid_image: '048.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 354,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              invalid_image: '048.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 4,
              y: 304,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 3,
              dot_image: '046.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 304,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 3,
              dot_image: '046.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 245,
              year_startY: 288,
              year_sc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              year_tc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              year_en_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 195,
              month_startY: 288,
              month_sc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              month_tc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              month_en_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '034.png',
              month_unit_tc: '034.png',
              month_unit_en: '034.png',
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 132,
              y: 317,
              w: 166,
              h: 33,
              text_size: 22,
              char_space: 4,
              color: 0xFF95CDEE,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: JANUARY, FEBRUARY, MARCH, APRIL, MAY, JUNE, JULY, AUGUST, SEPTEMBER, OCTOBER, NOVEMBER, DECEMBER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 146,
              day_startY: 288,
              day_sc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              day_tc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              day_en_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '034.png',
              day_unit_tc: '034.png',
              day_unit_en: '034.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 249,
              week_en: ["053.png","054.png","055.png","056.png","057.png","058.png","059.png"],
              week_tc: ["053.png","054.png","055.png","056.png","057.png","058.png","059.png"],
              week_sc: ["053.png","054.png","055.png","056.png","057.png","058.png","059.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 8,
              hour_startY: 127,
              hour_array: ["014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 198,
              minute_startY: 127,
              minute_array: ["014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 358,
              second_startY: 142,
              second_array: ["004.png","005.png","006.png","007.png","008.png","009.png","010.png","011.png","012.png","013.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 354,
              y: 53,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 0,
              unit_sc: '051.png',
              unit_tc: '051.png',
              unit_en: '051.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 264,
              // start_y: 60,
              // color: 0xFF95CDEE,
              // lenght: 88,
              // line_width: 8,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 289,
              y: 14,
              src: 'z2.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 347,
              y: 17,
              src: 'z4.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 260,
              y: 16,
              src: 'z1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 317,
              y: 17,
              src: 'z3.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 80,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'z_empty.png',
              unit_tc: 'z_empty.png',
              unit_en: 'z_empty.png',
              dot_image: '045.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 89,
              // center_y: 88,
              // start_angle: -95,
              // end_angle: 2,
              // radius: 28,
              // line_width: 14,
              // line_cap: Flat,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 89,
              center_y: 88,
              start_angle: -95,
              end_angle: 2,
              radius: 21,
              line_width: 14,
              corner_flag: 3,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_stand_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 58,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 58,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: true,
              h_space: 1,
              unit_sc: '052.png',
              unit_tc: '052.png',
              unit_en: '052.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 88,
              // center_y: 89,
              // start_angle: -91,
              // end_angle: 2,
              // radius: 48,
              // line_width: 14,
              // line_cap: Flat,
              // color: 0xFFFF8C00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 88,
              center_y: 89,
              start_angle: -91,
              end_angle: 2,
              radius: 41,
              line_width: 14,
              corner_flag: 3,
              color: 0xFFFF8C00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 35,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 85,
              // center_y: 86,
              // start_angle: -93,
              // end_angle: 4,
              // radius: 66,
              // line_width: 16,
              // line_cap: Flat,
              // color: 0xFF75BAFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 85,
              center_y: 86,
              start_angle: -93,
              end_angle: 4,
              radius: 58,
              line_width: 16,
              corner_flag: 3,
              color: 0xFF75BAFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 13,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 245,
              year_startY: 339,
              year_sc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              year_tc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              year_en_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 195,
              month_startY: 339,
              month_sc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              month_tc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              month_en_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '034.png',
              month_unit_tc: '034.png',
              month_unit_en: '034.png',
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 132,
              y: 368,
              w: 166,
              h: 33,
              text_size: 22,
              char_space: 4,
              color: 0xFF95CDEE,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: JANUARY, FEBRUARY, MARCH, APRIL, MAY, JUNE, JULY, AUGUST, SEPTEMBER, OCTOBER, NOVEMBER, DECEMBER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 146,
              day_startY: 339,
              day_sc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              day_tc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              day_en_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '034.png',
              day_unit_tc: '034.png',
              day_unit_en: '034.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 188,
              src: '060.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 294,
              week_en: ["053.png","054.png","055.png","056.png","057.png","058.png","059.png"],
              week_tc: ["053.png","054.png","055.png","056.png","057.png","058.png","059.png"],
              week_sc: ["053.png","054.png","055.png","056.png","057.png","058.png","059.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 112,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              unit_sc: '051.png',
              unit_tc: '051.png',
              unit_en: '051.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 163,
              // start_y: 144,
              // color: 0xFF95CDEE,
              // lenght: 111,
              // line_width: 8,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 34,
              hour_startY: 166,
              hour_array: ["014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 245,
              minute_startY: 166,
              minute_array: ["014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 21,
              y: 0,
              src: 'z_empty.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 198,
              y: 126,
              w: 146,
              h: 120,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 9,
              y: 126,
              w: 146,
              h: 120,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 191,
              y: 344,
              w: 51,
              h: 82,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 344,
              w: 110,
              h: 42,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 257,
              y: 50,
              w: 160,
              h: 29,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 292,
              w: 133,
              h: 41,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 92,
              y: 56,
              w: 103,
              h: 22,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 385,
              w: 110,
              h: 41,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 114,
              y: 344,
              w: 72,
              h: 82,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 343,
              y: 126,
              w: 89,
              h: 75,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 92,
              y: 34,
              w: 103,
              h: 23,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 246,
              y: 344,
              w: 186,
              h: 82,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 92,
              y: 13,
              w: 103,
              h: 22,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 132,
              y: 249,
              w: 166,
              h: 96,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: 'z_empty.png',
              normal_src: 'z_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 297,
              y: 249,
              w: 135,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: 'z_empty.png',
              normal_src: 'z_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 249,
              w: 133,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: 'z_empty.png',
              normal_src: 'z_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 297,
              y: 292,
              w: 135,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: 'z_empty.png',
              normal_src: 'z_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: -10,
              y: 435,
              w: 160,
              h: 28,
              text: 'DropOFF:',
              color: 0xFFC0C0C0,
              text_size: 26,
              press_src: 'z_empty.png',
              normal_src: 'z_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: -10,
              y: 462,
              w: 160,
              h: 60,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 26,
              press_src: 'z_empty.png',
              normal_src: 'z_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 276,
              y: 435,
              w: 164,
              h: 28,
              text: ':WakeUP',
              color: 0xFFC0C0C0,
              text_size: 26,
              press_src: 'z_empty.png',
              normal_src: 'z_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 276,
              y: 462,
              w: 160,
              h: 60,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 26,
              press_src: 'z_empty.png',
              normal_src: 'z_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 109,
              y: 433,
              w: 213,
              h: 130,
              text: 'DURATION',
              color: 0xFFC0C0C0,
              text_size: 26,
              press_src: 'z_empty.png',
              normal_src: 'z_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 257,
              y: 82,
              w: 174,
              h: 25,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 22,
              press_src: 'z_empty.png',
              normal_src: 'z_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'OfflineMapScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 56,
              w: 51,
              h: 51,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 22,
              press_src: 'z_empty.png',
              normal_src: 'z_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ClubCardsScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 6,
              w: 51,
              h: 51,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 22,
              press_src: 'z_empty.png',
              normal_src: 'z_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 343,
              y: 200,
              w: 89,
              h: 46,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 22,
              press_src: 'z_empty.png',
              normal_src: 'z_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1049670, url: 'page/wclk_showLayer' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_14 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 92,
              y: 78,
              w: 103,
              h: 29,
              text: '',
              color: 0xFFC0C0C0,
              text_size: 22,
              press_src: 'z_empty.png',
              normal_src: 'z_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportRecordListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('month font');
              if (updateHour) {
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str );
              };

            };

            //#endregion
            if (!sleepSensor) sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
            //#region sleep_update
            function sleep_update() {
              console.log('sleep_update()');
              let sleepInfo = sleepSensor.getBasicInfo();

              console.log('sleep score');
              let sleepScore = sleepInfo.score;
              if (normal_sleep_score_font) normal_sleep_score_font.setProperty(hmUI.prop.TEXT, String(sleepScore));

              console.log('sleep duration time');
              let sleepTime = sleepSensor.getTotalTime();
              const modelData = sleepSensor.getSleepStageModel();
              let sleepStageArray = sleepSensor.getSleepStageData();
              let wakeupTime = 0;
              let wakeupCount = 0;

              for (let i = 0; i < sleepStageArray.length; i++) {
                let data = sleepStageArray[i];
                if (data.model == modelData.WAKE_STAGE) {
                  wakeupTime += data.stop + 1 - data.start;
                  wakeupCount++;
                };
              };
              sleepTime -= wakeupTime;
              let sleepTimeHour = Math.floor(sleepTime / 60);
              let sleepTimeMin = sleepTime % 60;

              let normal_sleepTimeHourStr = sleepTimeHour.toString();
              normal_sleepTimeHourStr = normal_sleepTimeHourStr.padStart(2, '0');
              let normal_sleepTimeMinStr = sleepTimeMin.toString().padStart(2, '0');
              let normal_sleepTimeStr = normal_sleepTimeHourStr + ':' + normal_sleepTimeMinStr;
              if (normal_sleep_time_font) normal_sleep_time_font.setProperty(hmUI.prop.TEXT, normal_sleepTimeStr);

              console.log('sleep end time');
              let sleepEndTime = sleepInfo.endTime;
              if (sleepEndTime >= 24*60) sleepEndTime -= 24*60;
              let sleepEndHour = Math.floor(sleepEndTime / 60);
              if (!timeSensor.is24Hour) {
                if (sleepEndHour >= 12) sleepEndHour -= 12;
                if (sleepEndHour == 0) sleepEndHour = 12;
              };
              let sleepEndMin = sleepEndTime % 60;

              let normal_sleepEndHourStr = sleepEndHour.toString();
              normal_sleepEndHourStr = normal_sleepEndHourStr.padStart(2, '0');
              let normal_SleepEndMinStr = sleepEndMin.toString().padStart(2, '0');
              let normal_SleepEndStr = normal_sleepEndHourStr + ':' + normal_SleepEndMinStr;
              if (normal_sleep_end_font) normal_sleep_end_font.setProperty(hmUI.prop.TEXT, normal_SleepEndStr);

              console.log('sleep start time');
              let sleepStartTime = sleepInfo.startTime;
              if (sleepStartTime >= 24*60) sleepStartTime -= 24*60;
              let sleepStartHour = Math.floor(sleepStartTime / 60);
              if (!timeSensor.is24Hour) {
                if (sleepStartHour >= 12) sleepStartHour -= 12;
                if (sleepStartHour == 0) sleepStartHour = 12;
              };
              let sleepStartMin = sleepStartTime % 60;

              let normal_SleepStartHourStr = sleepStartHour.toString();
              normal_SleepStartHourStr = normal_SleepStartHourStr.padStart(2, '0');
              let normal_SleepStartMinStr = sleepStartMin.toString().padStart(2, '0');
              let normal_SleepStartStr = normal_SleepStartHourStr + ':' + normal_SleepStartMinStr;
              if (normal_sleep_start_font) normal_sleep_start_font.setProperty(hmUI.prop.TEXT, normal_SleepStartStr);

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_cityNameStr = normal_cityNameStr.toUpperCase();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 264;
                  let start_y_normal_battery = 60;
                  let lenght_ls_normal_battery = 88;
                  let line_width_ls_normal_battery = 8;
                  let color_ls_normal_battery = 0xFF95CDEE;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    radius: 4,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 89,
                      center_y: 88,
                      start_angle: -95,
                      end_angle: 2,
                      radius: 21,
                      line_width: 14,
                      corner_flag: 3,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 88,
                      center_y: 89,
                      start_angle: -91,
                      end_angle: 2,
                      radius: 41,
                      line_width: 14,
                      corner_flag: 3,
                      color: 0xFFFF8C00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 85,
                      center_y: 86,
                      start_angle: -93,
                      end_angle: 4,
                      radius: 58,
                      line_width: 16,
                      corner_flag: 3,
                      color: 0xFF75BAFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 163;
                  let start_y_idle_battery = 144;
                  let lenght_ls_idle_battery = 111;
                  let line_width_ls_idle_battery = 8;
                  let color_ls_idle_battery = 0xFF95CDEE;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    radius: 4,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                sleep_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}