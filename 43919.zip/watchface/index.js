﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// for vibration feedback
const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
let timer_StopVibrate = null;

function makeVibrate(level = 2) {
  let stopDelay = 50;
  stopVibrate();
  vibrate.stop();

  const levelToScene = {
    1: 25,
    2: 23,
    3: 28
  };

  let scene = levelToScene[level] || 25;
  vibrate.scene = scene;
  if (scene > 25) stopDelay = 1300;
  vibrate.start();
  timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibrate, {});
}

function stopVibrate() {
  vibrate.stop();
  if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
}

//variables for settings
let bgColorSet = 7;
let bgColorIndex = 1;
let bgStylesSet = [ "MAIN", "ALT" ];
let bgStylesIndex = 0;
let currBgStyle = bgStylesSet[bgStylesIndex];
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_step_current_text_font = ''
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let normal_battery_circle_scale = ''
        let normal_battery_current_text_font = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SFUIDisplay-Medium.ttf; FontSize: 32
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 446,
              h: 46,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SFUIDisplay-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SFUIDisplay-Medium.ttf; FontSize: 50
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 675,
              h: 72,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SFUIDisplay-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SFUIDisplay-Medium.ttf; FontSize: 34; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 40,
              h: 40,
              text_size: 34,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SFUIDisplay-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SFUIDisplay-Medium.ttf; FontSize: 22
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 308,
              h: 33,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SFUIDisplay-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

let bgColor = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    w: 390,
    h: 450,
    src: "colors/COLOR_1.png",
});
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'MAIN.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 388,
              image_array: ["WEATHERICON_1.png","WEATHERICON_2.png","WEATHERICON_3.png","WEATHERICON_4.png","WEATHERICON_5.png","WEATHERICON_6.png","WEATHERICON_7.png","WEATHERICON_8.png","WEATHERICON_9.png","WEATHERICON_10.png","WEATHERICON_11.png","WEATHERICON_12.png","WEATHERICON_13.png","WEATHERICON_14.png","WEATHERICON_15.png","WEATHERICON_16.png","WEATHERICON_17.png","WEATHERICON_18.png","WEATHERICON_19.png","WEATHERICON_20.png","WEATHERICON_21.png","WEATHERICON_22.png","WEATHERICON_23.png","WEATHERICON_24.png","WEATHERICON_25.png","WEATHERICON_26.png","WEATHERICON_27.png","WEATHERICON_28.png","WEATHERICON_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 258,
              y: 384,
              w: 100,
              h: 45,
              text_size: 32,
              char_space: 0,
              font: 'fonts/SFUIDisplay-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 84,
              y: 384,
              w: 100,
              h: 45,
              text_size: 32,
              char_space: 0,
              font: 'fonts/SFUIDisplay-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 258,
              y: 304,
              w: 80,
              h: 45,
              text_size: 32,
              char_space: 0,
              font: 'fonts/SFUIDisplay-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 84,
              y: 304,
              w: 115,
              h: 45,
              text_size: 32,
              char_space: 0,
              font: 'fonts/SFUIDisplay-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 32,
              y: 172,
              w: 150,
              h: 56,
              text_size: 50,
              char_space: 0,
              font: 'fonts/SFUIDisplay-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 32,
              y: 140,
              w: 150,
              h: 40,
              text_size: 34,
              char_space: 0,
              font: 'fonts/SFUIDisplay-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: ПНД, ВТР, СРД, ЧТВ,ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 64,
              // center_y: 73,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 40,
              // line_width: 6,
              // line_cap: Rounded,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 64,
              center_y: 73,
              start_angle: 0,
              end_angle: 360,
              radius: 37,
              line_width: 6,
              corner_flag: 0,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 35,
              y: 58,
              w: 60,
              h: 30,
              text_size: 22,
              char_space: 0,
              font: 'fonts/SFUIDisplay-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_HR.png',
              // center_x: 255,
              // center_y: 129,
              // x: 10,
              // y: 67,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 255 - 10,
              pos_y: 129 - 67,
              center_x: 255,
              center_y: 129,
              src: 'HAND_HR.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_MIN.png',
              // center_x: 255,
              // center_y: 129,
              // x: 10,
              // y: 103,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 255 - 10,
              pos_y: 129 - 103,
              center_x: 255,
              center_y: 129,
              src: 'HAND_MIN.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_SEC.png',
              // center_x: 255,
              // center_y: 129,
              // x: 8,
              // y: 112,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'HAND_SEC.png',
              second_centerX: 255,
              second_centerY: 129,
              second_posX: 8,
              second_posY: 112,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_HR.png',
              // center_x: 255,
              // center_y: 129,
              // x: 10,
              // y: 67,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 255 - 10,
              pos_y: 129 - 67,
              center_x: 255,
              center_y: 129,
              src: 'HAND_HR.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_MIN.png',
              // center_x: 255,
              // center_y: 129,
              // x: 10,
              // y: 103,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 255 - 10,
              pos_y: 129 - 103,
              center_x: 255,
              center_y: 129,
              src: 'HAND_MIN.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                showSettings()
                makeVibrate(2)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 32,
              y: 130,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 80,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 85,
              y: 294,
              w: 100,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 85,
              y: 376,
              w: 100,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportRecordListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 260,
              y: 294,
              w: 100,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 260,
              y: 376,
              w: 100,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let settingsBG = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    w: 390,
    h: 450,
    src: "settings/SETTINGS_BG.png",
});

let prevColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: -16,
    y: 255,
    w: 90,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_SELECTOR_PREV_PRESSED.png',
    normal_src: 'settings/BTN_SELECTOR_PREV_NORMAL.png',
    click_func: (button_widget) => {
    prevColor()
    makeVibrate(1)
    }, // end func
}); // end button

let nextColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 108,
    y: 255,
    w: 90,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_SELECTOR_NEXT_PRESSED.png',
    normal_src: 'settings/BTN_SELECTOR_NEXT_NORMAL.png',
    click_func: (button_widget) => {
    nextColor()
    makeVibrate(1)
    }, // end func
}); // end button

let changeStyleBtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 181,
    y: 255,
    w: 195,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BACKGROUND_STYLE_PRESSED.png',
    normal_src: 'settings/BACKGROUND_STYLE_NORMAL.png',
    click_func: (button_widget) => {
    changeStyleClock()
    makeVibrate(1)
    }, // end func
}); // end button

let Confirmbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 135,
    y: 348,
    w: 120,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_CONFIRM_PRESSED.png',
    normal_src: 'settings/BTN_CONFIRM_NORMAL.png',
    click_func: (button_widget) => {
    hideSettings()
    makeVibrate(3)
    }, // end func
}); // end button

// functions to change colors
function prevColor(){
    bgColorIndex = bgColorIndex - 1;
    if (bgColorIndex < 1) bgColorIndex = bgColorSet;
    updateWatchface();
}

function nextColor(){
    bgColorIndex = bgColorIndex + 1;
    if (bgColorIndex > bgColorSet) bgColorIndex = 1;
    updateWatchface();
}

function changeStyleClock(){
    bgStylesIndex = (bgStylesIndex + 1) % bgStylesSet.length;
    currBgStyle = bgStylesSet[bgStylesIndex]
    updateWatchface();
}

function updateWatchface(){
    let bgColorSRC = "colors/COLOR_" + bgColorIndex + ".png";
    bgColor.setProperty(hmUI.prop.SRC, bgColorSRC); // BG Color

    let bgStyleSRC = currBgStyle + ".png";
    normal_background_bg_img.setProperty(hmUI.prop.SRC, bgStyleSRC); // BG Style
}

function hideSettings(){
    // normal buttons
    Button_1.setProperty(hmUI.prop.VISIBLE, true); //open settings
    Button_2.setProperty(hmUI.prop.VISIBLE, true);
    Button_3.setProperty(hmUI.prop.VISIBLE, true);
    Button_4.setProperty(hmUI.prop.VISIBLE, true);
    Button_5.setProperty(hmUI.prop.VISIBLE, true);
    Button_6.setProperty(hmUI.prop.VISIBLE, true);
    Button_7.setProperty(hmUI.prop.VISIBLE, true);
    
    // settings layout
    settingsBG.setProperty(hmUI.prop.VISIBLE, false);
    prevColorbtn.setProperty(hmUI.prop.VISIBLE, false);
    nextColorbtn.setProperty(hmUI.prop.VISIBLE, false);
    changeStyleBtn.setProperty(hmUI.prop.VISIBLE, false);
    Confirmbtn.setProperty(hmUI.prop.VISIBLE, false);
}
hideSettings();

function showSettings(){
    // normal buttons
    Button_1.setProperty(hmUI.prop.VISIBLE, false); //open settings
    Button_2.setProperty(hmUI.prop.VISIBLE, false);
    Button_3.setProperty(hmUI.prop.VISIBLE, false);
    Button_4.setProperty(hmUI.prop.VISIBLE, false);
    Button_5.setProperty(hmUI.prop.VISIBLE, false);
    Button_6.setProperty(hmUI.prop.VISIBLE, false);
    Button_7.setProperty(hmUI.prop.VISIBLE, false);
    
    // settings layout
    settingsBG.setProperty(hmUI.prop.VISIBLE, true);
    prevColorbtn.setProperty(hmUI.prop.VISIBLE, true);
    nextColorbtn.setProperty(hmUI.prop.VISIBLE, true);
    changeStyleBtn.setProperty(hmUI.prop.VISIBLE, true);
    Confirmbtn.setProperty(hmUI.prop.VISIBLE, true);
}
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              if (updateMinute) { // Hour Pointer
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              if (updateMinute) { // Hour Pointer
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) { // Minute Pointer
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 64,
                      center_y: 73,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 37,
                      line_width: 6,
                      corner_flag: 0,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}