﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js


let time24 = hmSensor.createSensor(hmSensor.id.TIME);
let normal_24Hcheck =''

function check24h(){
if(elementnumber_1==1){
if (time24.is24Hour){
normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, true);
}

if (!time24.is24Hour){
normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, false);
}
}
};

// change color
         let colornumber = 1
        let totalcolors = 6
        let namecolor = ''
        let Folder =''

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "YELLOW"
Folder = "Yellow/"
}
if ( colornumber == 2) { namecolor = "RED"
Folder = "Red/"
}
if ( colornumber == 3) { namecolor = "GREEN"
Folder = "Green/"
}
if ( colornumber == 4) { namecolor = "BLUE"
Folder = "Blue/"
}
if ( colornumber == 5) { namecolor = "ORANGE"
Folder = "Orange/"
}
if ( colornumber == 6) { namecolor = "GRAY"
Folder = "Gray/"
}
hmUI.showToast({text: namecolor });

             //hmUI.showToast({text: "color " + parseInt(colornumber) });
             normal_year_icon_img.setProperty(hmUI.prop.SRC, Folder+"Bg_1.png");
             normal_step_icon_img.setProperty(hmUI.prop.SRC, Folder+"Bg_2.png");
             normal_temperature_icon_img.setProperty(hmUI.prop.SRC, Folder+"Bg_3.png");
             normal_pai_icon_img.setProperty(hmUI.prop.SRC, Folder+"Bg_4.png");
            
                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////




        // Switch Tab
        let cc = 0
        let elementnumber_1 = 1
        let total_elemente = 4

        function click_tab() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }
                if(elementnumber_1==3) {
                  UpdateElementeThree();
                }
                if(elementnumber_1==4) {
                  UpdateElementeFour();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'TIME & DATE'});
            if(elementnumber_1==2) hmUI.showToast({text: 'ACTIVITY'});
            if(elementnumber_1==3) hmUI.showToast({text: 'WEATHER'});
            if(elementnumber_1==4) hmUI.showToast({text: 'OTHER'});
        }

        //TIME AND DATE
        function UpdateElementeOne(){

         normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         Button_3.setProperty(hmUI.prop.VISIBLE, false);  //SPORT LIST



         normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
         normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
         normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_moon_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
          normal_wind_speed_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

         normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_pai_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
         normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);

         normal_year_icon_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, true);
         normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
         normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
        // normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, true);
         check24h()
         normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, true);
         normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, true);
         normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
         Button_2.setProperty(hmUI.prop.VISIBLE, true);// CALENDAR
         normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
         normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
         normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);


            Button_5.setProperty(hmUI.prop.MORE, {
              x: 167,
              y: 31,
              w: 55,
              h: 25,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //
UpdateElementeTwo()
elementnumber_1=2
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6.setProperty(hmUI.prop.MORE, {
              x: 236,
              y: 32,
              w: 55,
              h: 25,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //
UpdateElementeThree()
elementnumber_1=3
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7.setProperty(hmUI.prop.MORE, {
              x: 306,
              y: 32,
              w: 55,
              h: 25,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
UpdateElementeFour()
elementnumber_1=4
                //
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button



        }

        //ACTIVITY
        function UpdateElementeTwo(){
         normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
         normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
         normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
         normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
         Button_3.setProperty(hmUI.prop.VISIBLE, true); //SPORT LIST



         normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
         normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
         normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_moon_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
          normal_wind_speed_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

         normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_pai_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
         normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);

         normal_year_icon_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
         normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
         normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
         normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, false);
         normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
         normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
         normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
         Button_2.setProperty(hmUI.prop.VISIBLE, false);    // CALENDAR
         normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            Button_5.setProperty(hmUI.prop.MORE, {
              x: 167,
              y: 31,
              w: 55,
              h: 25,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //
UpdateElementeThree()
elementnumber_1=3
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6.setProperty(hmUI.prop.MORE, {
              x: 236,
              y: 32,
              w: 55,
              h: 25,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //
UpdateElementeFour()
elementnumber_1=4
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7.setProperty(hmUI.prop.MORE, {
              x: 306,
              y: 32,
              w: 55,
              h: 25,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
UpdateElementeOne()
elementnumber_1=1
                //
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button



        }

        //Weather
        function UpdateElementeThree(){
         normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         Button_3.setProperty(hmUI.prop.VISIBLE, false);  //SPORT LIST



         normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
         normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
         normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
         normal_moon_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
         normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
         normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
          normal_wind_speed_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, true);


         normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_pai_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
         normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);

         normal_year_icon_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
         normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
         normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
         normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, false);
         normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
         normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
         normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
         Button_2.setProperty(hmUI.prop.VISIBLE, false);    // CALENDAR
         normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            Button_5.setProperty(hmUI.prop.MORE, {
              x: 167,
              y: 31,
              w: 55,
              h: 25,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //
UpdateElementeFour()
elementnumber_1=4
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6.setProperty(hmUI.prop.MORE, {
              x: 236,
              y: 32,
              w: 55,
              h: 25,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //
UpdateElementeOne()
elementnumber_1=1
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7.setProperty(hmUI.prop.MORE, {
              x: 306,
              y: 32,
              w: 55,
              h: 25,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
UpdateElementeTwo()
elementnumber_1=2
                //
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

        }

        //OTHER
        function UpdateElementeFour(){
         normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         Button_3.setProperty(hmUI.prop.VISIBLE, false);  //SPORT LIST



         normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
         normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
         normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_moon_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
          normal_wind_speed_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);


         normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_pai_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
         normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
         normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, true);

         normal_year_icon_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
         normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
         normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
         normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, false);
         normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
         normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
         normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
         Button_2.setProperty(hmUI.prop.VISIBLE, false);    // CALENDAR
         normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            Button_5.setProperty(hmUI.prop.MORE, {
              x: 167,
              y: 31,
              w: 55,
              h: 25,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //
UpdateElementeOne()
elementnumber_1=1
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6.setProperty(hmUI.prop.MORE, {
              x: 236,
              y: 32,
              w: 55,
              h: 25,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //
UpdateElementeTwo()
elementnumber_1=2
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7.setProperty(hmUI.prop.MORE, {
              x: 306,
              y: 32,
              w: 55,
              h: 25,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
UpdateElementeThree()
elementnumber_1=3
                //
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
        }

///////////////////////////////
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_pai_icon_img = ''
        let normal_pai_circle_scale = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_compass_text_img = ''
        let normal_compass_direction_img_level = ''
        let normal_compass_direction_arr = ["Wind_D1.png", "Wind_D2.png", "Wind_D3.png", "Wind_D4.png", "Wind_D5.png", "Wind_D6.png", "Wind_D7.png", "Wind_D8.png"];
        let normal_stress_text_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_speed_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_sun_current_text_img = ''
        let normal_year_icon_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_linear_scale = ''
        let idle_background_bg_img = ''
        let idle_year_icon_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_battery_linear_scale = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'Bg_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Bg_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 337,
              // center_y: 152,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 40,
              // line_width: 6,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 337,
              center_y: 152,
              start_angle: 0,
              end_angle: 360,
              radius: 37,
              line_width: 6,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 158,
              font_array: ["SS_0.png","SS_1.png","SS_2.png","SS_3.png","SS_4.png","SS_5.png","SS_6.png","SS_7.png","SS_8.png","SS_9.png"],
              padding: true,
              h_space: -8,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 117,
              font_array: ["SS_0.png","SS_1.png","SS_2.png","SS_3.png","SS_4.png","SS_5.png","SS_6.png","SS_7.png","SS_8.png","SS_9.png"],
              padding: true,
              h_space: -8,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 217,
              font_array: ["SS_0.png","SS_1.png","SS_2.png","SS_3.png","SS_4.png","SS_5.png","SS_6.png","SS_7.png","SS_8.png","SS_9.png"],
              padding: true,
              h_space: -6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'Pointer_compass.png',
              // center_x: 99,
              // center_y: 397,
              // x: 53,
              // y: 52,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //#region Compass_Pointer
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 99 - 53,
              pos_y: 397 - 52,
              center_x: 99,
              center_y: 397,
              src: 'Pointer_compass.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //#endregion

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 373,
              font_array: ["Cal_0.png","Cal_1.png","Cal_2.png","Cal_3.png","Cal_4.png","Cal_5.png","Cal_6.png","Cal_7.png","Cal_8.png","Cal_9.png"],
              padding: false,
              h_space: -7,
              unit_sc: 'TempMaxmin_unit.png',
              unit_tc: 'TempMaxmin_unit.png',
              unit_en: 'TempMaxmin_unit.png',
              negative_image: 'Temp_Error.png',
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_direction_img_level = hmUI.createWidget(hmUI.widget.IMG, {
              x: 313,
              y: 380,
              src: 'Wind_D1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
              // type: hmUI.data_type.COMPASS,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 267,
              font_array: ["SS_0.png","SS_1.png","SS_2.png","SS_3.png","SS_4.png","SS_5.png","SS_6.png","SS_7.png","SS_8.png","SS_9.png"],
              padding: true,
              h_space: -6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 267,
              font_array: ["SS_0.png","SS_1.png","SS_2.png","SS_3.png","SS_4.png","SS_5.png","SS_6.png","SS_7.png","SS_8.png","SS_9.png"],
              padding: true,
              h_space: -6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Bg_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 344,
              // center_y: 153,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 45,
              // line_width: 6,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 344,
              center_y: 153,
              start_angle: 0,
              end_angle: 360,
              radius: 42,
              line_width: 6,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 51,
              y: 140,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: true,
              h_space: -3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 272,
              font_array: ["Cal_0.png","Cal_1.png","Cal_2.png","Cal_3.png","Cal_4.png","Cal_5.png","Cal_6.png","Cal_7.png","Cal_8.png","Cal_9.png"],
              padding: true,
              h_space: -3,
              unit_sc: 'KCAL_8.png',
              unit_tc: 'KCAL_8.png',
              unit_en: 'KCAL_8.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 214,
              font_array: ["Cal_0.png","Cal_1.png","Cal_2.png","Cal_3.png","Cal_4.png","Cal_5.png","Cal_6.png","Cal_7.png","Cal_8.png","Cal_9.png"],
              padding: true,
              h_space: -3,
              unit_sc: 'KM_1.png',
              unit_tc: 'KM_1.png',
              unit_en: 'KM_1.png',
              imperial_unit_sc: 'MI_2.png',
              imperial_unit_tc: 'MI_2.png',
              imperial_unit_en: 'MI_2.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 389,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: -10,
              unit_sc: 'UNIT_P.png',
              unit_tc: 'UNIT_P.png',
              unit_en: 'UNIT_P.png',
              invalid_image: 'Day_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 391,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Bg_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 55,
              y: 107,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 272,
              font_array: ["Cal_0.png","Cal_1.png","Cal_2.png","Cal_3.png","Cal_4.png","Cal_5.png","Cal_6.png","Cal_7.png","Cal_8.png","Cal_9.png"],
              padding: false,
              h_space: -9,
              unit_sc: 'TempMaxmin_unit.png',
              unit_tc: 'TempMaxmin_unit.png',
              unit_en: 'TempMaxmin_unit.png',
              imperial_unit_sc: 'TempMaxmin_unit.png',
              imperial_unit_tc: 'TempMaxmin_unit.png',
              imperial_unit_en: 'TempMaxmin_unit.png',
              negative_image: 'TempMaxMin_error.png',
              invalid_image: 'TempMaxMin_error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 247,
                y: 272,
                font_array: ["Cal_0.png","Cal_1.png","Cal_2.png","Cal_3.png","Cal_4.png","Cal_5.png","Cal_6.png","Cal_7.png","Cal_8.png","Cal_9.png"],
                padding: false,
                h_space: -9,
                unit_sc: 'TempMaxmin_unit.png',
                unit_tc: 'TempMaxmin_unit.png',
                unit_en: 'TempMaxmin_unit.png',
                imperial_unit_sc: 'TempMaxmin_unit.png',
                imperial_unit_tc: 'TempMaxmin_unit.png',
                imperial_unit_en: 'TempMaxmin_unit.png',
                negative_image: 'TempMaxMin_error.png',
                invalid_image: 'TempMaxMin_error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 272,
              font_array: ["Cal_0.png","Cal_1.png","Cal_2.png","Cal_3.png","Cal_4.png","Cal_5.png","Cal_6.png","Cal_7.png","Cal_8.png","Cal_9.png"],
              padding: false,
              h_space: -9,
              unit_sc: 'TempMaxmin_unit.png',
              unit_tc: 'TempMaxmin_unit.png',
              unit_en: 'TempMaxmin_unit.png',
              imperial_unit_sc: 'TempMaxmin_unit.png',
              imperial_unit_tc: 'TempMaxmin_unit.png',
              imperial_unit_en: 'TempMaxmin_unit.png',
              negative_image: 'TempMaxMin_error.png',
              invalid_image: 'TempMaxMin_error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 63,
                y: 272,
                font_array: ["Cal_0.png","Cal_1.png","Cal_2.png","Cal_3.png","Cal_4.png","Cal_5.png","Cal_6.png","Cal_7.png","Cal_8.png","Cal_9.png"],
                padding: false,
                h_space: -9,
                unit_sc: 'TempMaxmin_unit.png',
                unit_tc: 'TempMaxmin_unit.png',
                unit_en: 'TempMaxmin_unit.png',
                imperial_unit_sc: 'TempMaxmin_unit.png',
                imperial_unit_tc: 'TempMaxmin_unit.png',
                imperial_unit_en: 'TempMaxmin_unit.png',
                negative_image: 'TempMaxMin_error.png',
                invalid_image: 'TempMaxMin_error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 167,
              y: 111,
              font_array: ["Temp_0.png","Temp_1.png","Temp_2.png","Temp_3.png","Temp_4.png","Temp_5.png","Temp_6.png","Temp_7.png","Temp_8.png","Temp_9.png"],
              padding: false,
              h_space: -27,
              unit_sc: 'Temp_Unit.png',
              unit_tc: 'Temp_Unit.png',
              unit_en: 'Temp_Unit.png',
              imperial_unit_sc: 'Temp_Unit.png',
              imperial_unit_tc: 'Temp_Unit.png',
              imperial_unit_en: 'Temp_Unit.png',
              negative_image: 'Temp_Error.png',
              invalid_image: 'Temp_Error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 167,
                y: 111,
                font_array: ["Temp_0.png","Temp_1.png","Temp_2.png","Temp_3.png","Temp_4.png","Temp_5.png","Temp_6.png","Temp_7.png","Temp_8.png","Temp_9.png"],
                padding: false,
                h_space: -27,
                unit_sc: 'Temp_Unit.png',
                unit_tc: 'Temp_Unit.png',
                unit_en: 'Temp_Unit.png',
                imperial_unit_sc: 'Temp_Unit.png',
                imperial_unit_tc: 'Temp_Unit.png',
                imperial_unit_en: 'Temp_Unit.png',
                negative_image: 'Temp_Error.png',
                invalid_image: 'Temp_Error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 186,
              y: 215,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 340,
              y: 392,
              image_array: ["Wind_D1.png","Wind_D2.png","Wind_D3.png","Wind_D4.png","Wind_D5.png","Wind_D6.png","Wind_D7.png","Wind_D8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_speed_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 421,
              font_array: ["SS_0.png","SS_1.png","SS_2.png","SS_3.png","SS_4.png","SS_5.png","SS_6.png","SS_7.png","SS_8.png","SS_9.png"],
              padding: false,
              h_space: -7,
              unit_sc: 'KM_H.png',
              unit_tc: 'KM_H.png',
              unit_en: 'KM_H.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND_SPEED,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 422,
              font_array: ["SS_0.png","SS_1.png","SS_2.png","SS_3.png","SS_4.png","SS_5.png","SS_6.png","SS_7.png","SS_8.png","SS_9.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 381,
              font_array: ["SS_0.png","SS_1.png","SS_2.png","SS_3.png","SS_4.png","SS_5.png","SS_6.png","SS_7.png","SS_8.png","SS_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'Unit_hum.png',
              unit_tc: 'Unit_hum.png',
              unit_en: 'Unit_hum.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 258,
              y: 343,
              font_array: ["SS_0.png","SS_1.png","SS_2.png","SS_3.png","SS_4.png","SS_5.png","SS_6.png","SS_7.png","SS_8.png","SS_9.png"],
              padding: false,
              h_space: -3,
              invalid_image: 'SS_Dot.png',
              dot_image: 'SS_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_year_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 234,
              year_startY: 397,
              year_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              year_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              year_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              year_zero: 1,
              year_space: -10,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 116,
              y: 395,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 34,
              day_startY: 397,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: -13,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 75,
              month_startY: 336,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 88,
              y: 472,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 183,
              y: 247,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
            normal_24Hcheck = hmUI.createWidget(hmUI.widget.IMG, {
              x: 49,
              y: 242,
              src: 'Clock_24H.png',
            show_level: hmUI.show_level.ALL,

            });
check24h()
            // end user_script.js

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 49,
              am_y: 242,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 49,
              pm_y: 242,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 253,
              second_startY: 233,
              second_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              second_zero: 1,
              second_space: -13,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 222,
              minute_startY: 107,
              minute_array: ["TimeHM_0.png","TimeHM_1.png","TimeHM_2.png","TimeHM_3.png","TimeHM_4.png","TimeHM_5.png","TimeHM_6.png","TimeHM_7.png","TimeHM_8.png","TimeHM_9.png"],
              minute_zero: 1,
              minute_space: -24,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 29,
              hour_startY: 107,
              hour_array: ["TimeHM_0.png","TimeHM_1.png","TimeHM_2.png","TimeHM_3.png","TimeHM_4.png","TimeHM_5.png","TimeHM_6.png","TimeHM_7.png","TimeHM_8.png","TimeHM_9.png"],
              hour_zero: 1,
              hour_space: -24,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 471,
              font_array: ["SS_0.png","SS_1.png","SS_2.png","SS_3.png","SS_4.png","SS_5.png","SS_6.png","SS_7.png","SS_8.png","SS_9.png"],
              padding: false,
              h_space: -8,
              unit_sc: 'Unit_hum.png',
              unit_tc: 'Unit_hum.png',
              unit_en: 'Unit_hum.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 153,
              y: 478,
              src: 'Batt_icon1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 157,
              // start_y: 482,
              // color: 0xFFFFFFFF,
              // lenght: 35,
              // line_width: 11,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'Bg_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_year_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AODBg_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 234,
              year_startY: 397,
              year_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              year_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              year_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              year_zero: 1,
              year_space: -10,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 116,
              y: 395,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 34,
              day_startY: 397,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: -13,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 75,
              month_startY: 336,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 88,
              y: 472,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 183,
              y: 247,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 49,
              am_y: 242,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 49,
              pm_y: 242,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 222,
              minute_startY: 107,
              minute_array: ["TimeHM_0.png","TimeHM_1.png","TimeHM_2.png","TimeHM_3.png","TimeHM_4.png","TimeHM_5.png","TimeHM_6.png","TimeHM_7.png","TimeHM_8.png","TimeHM_9.png"],
              minute_zero: 1,
              minute_space: -24,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 264,
              y: 244,
              src: 'AOD_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 29,
              hour_startY: 107,
              hour_array: ["TimeHM_0.png","TimeHM_1.png","TimeHM_2.png","TimeHM_3.png","TimeHM_4.png","TimeHM_5.png","TimeHM_6.png","TimeHM_7.png","TimeHM_8.png","TimeHM_9.png"],
              hour_zero: 1,
              hour_space: -24,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 471,
              font_array: ["SS_0.png","SS_1.png","SS_2.png","SS_3.png","SS_4.png","SS_5.png","SS_6.png","SS_7.png","SS_8.png","SS_9.png"],
              padding: false,
              h_space: -8,
              unit_sc: 'Unit_hum.png',
              unit_tc: 'Unit_hum.png',
              unit_en: 'Unit_hum.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 153,
              y: 478,
              src: 'Batt_icon1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 157,
              // start_y: 482,
              // color: 0xFFFFFFFF,
              // lenght: 35,
              // line_width: 11,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 42,
              y: 104,
              w: 198,
              h: 35,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 39,
              y: 351,
              w: 177,
              h: 56,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 309,
              y: 126,
              w: 59,
              h: 52,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 343,
              w: 321,
              h: 33,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 185,
              y: 213,
              w: 61,
              h: 59,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 232,
              y: 113,
              w: 103,
              h: 81,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 256,
              y: 351,
              w: 119,
              h: 65,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 269,
              y: 240,
              w: 104,
              h: 66,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 267,
              y: 120,
              w: 91,
              h: 88,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 185,
              y: 243,
              w: 58,
              h: 58,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 148,
              y: 464,
              w: 168,
              h: 33,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 84,
              y: 342,
              w: 265,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 317,
              y: 119,
              w: 61,
              h: 69,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 48,
              y: 38,
              w: 113,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // switch tab
click_tab()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 167,
              y: 31,
              w: 55,
              h: 25,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 236,
              y: 32,
              w: 55,
              h: 25,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 306,
              y: 32,
              w: 55,
              h: 25,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 6,
              y: 171,
              w: 53,
              h: 115,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //change color
click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if ( cc == 0 ){
UpdateElementeOne()
cc =1
}
            // end user_script_end.js

            //#region compass_update
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                // Compass Number
                let normal_compass_direction_angle_text = compass_direction_angle.toString();
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);
                // Compass Images
                let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                let compass_direction_index = parseInt(compass_direction_angle_img/45);
                if (compass_direction_index > 7) compass_direction_index = 0;
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[0]);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                  // Compass Number
                  let normal_compass_direction_angle_text = compass_direction_angle.toString();
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);
                  // Compass Images
                  let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                  let compass_direction_index = parseInt(compass_direction_angle_img/45);
                  if (compass_direction_index > 7) compass_direction_index = 0;
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[0]);

                }

              }); // Listener end

            };
            //#endregion

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_cs_normal_pai = progressPAI;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_pai_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_pai * 100);
                  if (normal_pai_circle_scale) {
                    normal_pai_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 337,
                      center_y: 152,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 37,
                      line_width: 6,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 344,
                      center_y: 153,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 42,
                      line_width: 6,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 157;
                  let start_y_normal_battery = 482;
                  let lenght_ls_normal_battery = 35;
                  let line_width_ls_normal_battery = 11;
                  let color_ls_normal_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 157;
                  let start_y_idle_battery = 482;
                  let lenght_ls_idle_battery = 35;
                  let line_width_ls_idle_battery = 11;
                  let color_ls_idle_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

                console.log('resume_call.js');
                // start resume_call.js

 check24h()
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}