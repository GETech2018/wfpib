try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_75c409f92d3f4ad3b6d92006d387ab1a = '';
        let normal$_$text_444ad8447581407c9c3bcc4508bdf177 = '';
        let normal$_$text_cea2a7f600944760b29b638993ebdc5c = '';
        let normal$_$text_03df237cc21a47e5adc01698ebd5331b = '';
        let normal$_$text_308dbae9f8d84bf1a50207bede4d5ca6 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_2a9f55b96db545188f903bc2b568c4ce = '';
        const WEEK_EN_F = function (val) {
            const valueMap = {
                '1': 'Monday',
                '2': 'Tuesday',
                '3': 'Wednesday',
                '4': 'Thursday',
                '5': 'Friday',
                '6': 'Saturday',
                '7': 'Sunday'
            };
            return valueMap[val];
        };
        let stepSensor = '';
        let calorieSensor = '';
        let timeSensor = '';
        let batterySensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 432,
                    h: 514,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_75c409f92d3f4ad3b6d92006d387ab1a = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 112,
                    y: 226,
                    w: 100,
                    h: 40,
                    text: '[SC]',
                    color: '0xFF5a0909',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_444ad8447581407c9c3bcc4508bdf177 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 219,
                    y: 226,
                    w: 100,
                    h: 40,
                    text: '[CAL]',
                    color: '0xFF5a0909',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_cea2a7f600944760b29b638993ebdc5c = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 154,
                    y: 183,
                    w: 124,
                    h: 40,
                    text: '[HOUR_24_Z]:[MIN_Z]',
                    color: '0xFF5a0909',
                    text_size: 25,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_03df237cc21a47e5adc01698ebd5331b = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 185,
                    y: 356,
                    w: 69,
                    h: 34,
                    text: '[BATT_PER]%',
                    color: '0xFF5a0909',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_308dbae9f8d84bf1a50207bede4d5ca6 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 166,
                    y: 285,
                    w: 100,
                    h: 40,
                    text: '[DAY_Z]/[MON_Z]',
                    color: '0xFF5a0909',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_2a9f55b96db545188f903bc2b568c4ce = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 170,
                    y: 304,
                    w: 100,
                    h: 40,
                    text: '[WEEK_EN_F]',
                    color: '0xFF5a0909',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 218,
                    hour_centerY: 259,
                    hour_posX: 32,
                    hour_posY: 208,
                    hour_path: '3.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 218,
                    minute_centerY: 259,
                    minute_posX: 32,
                    minute_posY: 208,
                    minute_path: '4.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 218,
                    second_centerY: 259,
                    second_posX: 32,
                    second_posY: 208,
                    second_path: '5.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!calorieSensor) {
                    calorieSensor = hmSensor.createSensor(hmSensor.id.CALORIE);
                }
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_75c409f92d3f4ad3b6d92006d387ab1a.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), calorieSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_444ad8447581407c9c3bcc4508bdf177.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current }` });
                }), timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
                    normal$_$text_cea2a7f600944760b29b638993ebdc5c.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_03df237cc21a47e5adc01698ebd5331b.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                }), timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_308dbae9f8d84bf1a50207bede4d5ca6.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_308dbae9f8d84bf1a50207bede4d5ca6.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_308dbae9f8d84bf1a50207bede4d5ca6.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    normal$_$text_2a9f55b96db545188f903bc2b568c4ce.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                });
                normal$_$text_cea2a7f600944760b29b638993ebdc5c.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                timer.createTimer(0, 1000, function (timeSensor2) {
                    normal$_$text_cea2a7f600944760b29b638993ebdc5c.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor2.hour).padStart(2, '0') }:${ String(timeSensor2.minute).padStart(2, '0') }` });
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_75c409f92d3f4ad3b6d92006d387ab1a.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        normal$_$text_444ad8447581407c9c3bcc4508bdf177.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current }` });
                        normal$_$text_cea2a7f600944760b29b638993ebdc5c.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                        normal$_$text_03df237cc21a47e5adc01698ebd5331b.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_308dbae9f8d84bf1a50207bede4d5ca6.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_308dbae9f8d84bf1a50207bede4d5ca6.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_308dbae9f8d84bf1a50207bede4d5ca6.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_2a9f55b96db545188f903bc2b568c4ce.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}