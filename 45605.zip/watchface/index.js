﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_pai_day_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_pai_day_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 284,
              // start_y: 21,
              // color: 0xFFADB2C7,
              // lenght: 20,
              // line_width: 9,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 17,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 156,
              month_startY: 17,
              month_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_zero: 1,
              month_space: 1,
              month_unit_sc: 'pointer_0.png',
              month_unit_tc: 'pointer_0.png',
              month_unit_en: 'pointer_0.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 122,
              day_startY: 17,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 0,
              day_space: 1,
              day_unit_sc: 'pointer_0.png',
              day_unit_tc: 'pointer_0.png',
              day_unit_en: 'pointer_0.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 59,
              y: 9,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 319,
              y: 419,
              font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 419,
              font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 162,
              y: 419,
              font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 151,
              y: 453,
              image_array: ["img_step_1.png","img_step_2.png","img_step_3.png","img_step_4.png","img_step_5.png","img_step_6.png","img_step_7.png","img_step_8.png","img_step_9.png","img_step_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 162,
              y: 168,
              font_array: ["num_bpm_0.png","num_bpm_1.png","num_bpm_2.png","num_bpm_3.png","num_bpm_4.png","num_bpm_5.png","num_bpm_6.png","num_bpm_7.png","num_bpm_8.png","num_bpm_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'unit_bpm.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: 63,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 238,
              minute_startY: 63,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              // alpha: 180,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 63,
              src: 'pointer_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 284,
              // start_y: 21,
              // color: 0xFFADB2C7,
              // lenght: 20,
              // line_width: 9,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 17,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 156,
              month_startY: 17,
              month_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_zero: 1,
              month_space: 1,
              month_unit_sc: 'pointer_0.png',
              month_unit_tc: 'pointer_0.png',
              month_unit_en: 'pointer_0.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 122,
              day_startY: 17,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 0,
              day_space: 1,
              day_unit_sc: 'pointer_0.png',
              day_unit_tc: 'pointer_0.png',
              day_unit_en: 'pointer_0.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 59,
              y: 9,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 319,
              y: 419,
              font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 419,
              font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 162,
              y: 419,
              font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 151,
              y: 453,
              image_array: ["img_step_1.png","img_step_2.png","img_step_3.png","img_step_4.png","img_step_5.png","img_step_6.png","img_step_7.png","img_step_8.png","img_step_9.png","img_step_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 162,
              y: 168,
              font_array: ["num_bpm_0.png","num_bpm_1.png","num_bpm_2.png","num_bpm_3.png","num_bpm_4.png","num_bpm_5.png","num_bpm_6.png","num_bpm_7.png","num_bpm_8.png","num_bpm_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'unit_bpm.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: 63,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 238,
              minute_startY: 63,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              // alpha: 180,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 63,
              src: 'pointer_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_end.js');
            // start user_script_end.js

// start user_script_end.js

if (normal_heart_rate_linear_scale) {
  normal_heart_rate_linear_scale.setProperty(
    hmUI.prop.VISIBLE,
    false
  );
}

if (idle_heart_rate_linear_scale) {
  idle_heart_rate_linear_scale.setProperty(
    hmUI.prop.VISIBLE,
    false
  );
}

const customHeartRate =
  hmSensor.createSensor(hmSensor.id.HEART);


// =========================
// COLORS
// =========================

const heartCurveColor = 0xFFFE575E;

// tmavší průsvitná výplň
const heartFillColor = 0x652225;         


// =========================
// GRAPH POSITION
// =========================

const heartCurveX = 59;
const heartCurveY = 231;

const heartCurveWidth = 304;
const heartCurveHeight = 120;


// =========================
// GRAPH SETTINGS
// =========================

const heartCurveCount = 32;
const heartCurveStep = 10;

const heartCurvePointSize = 6;
const heartLineWidth = 4;


// =========================
// HISTORY
// =========================

let heartCurveHistory = [];


// =========================
// POINTS
// =========================

let heartCurvePoints = [];

for (
  let i = 0;
  i < heartCurveCount;
  i++
) {

  const point =
    hmUI.createWidget(
      hmUI.widget.FILL_RECT,
      {
        x:
          heartCurveX +
          i * heartCurveStep,

        y:
          heartCurveY +
          heartCurveHeight,

        w:
          heartCurvePointSize,

        h:
          heartCurvePointSize,

        color:
          heartCurveColor
      }
    );

  point.setProperty(
    hmUI.prop.VISIBLE,
    false
  );

  heartCurvePoints.push(point);
}


// =========================
// LINE SEGMENTS
// =========================
//
// Každý úsek je vytvořen
// z malých vertikálních
// obdélníků.
// Díky tomu nevznikají
// velké čtverce.
//

const lineSlicesPerSegment = 5;

let heartCurveLines = [];

for (
  let i = 0;
  i < heartCurveCount - 1;
  i++
) {

  let segment = [];

  for (
    let s = 0;
    s < lineSlicesPerSegment;
    s++
  ) {

    const line =
      hmUI.createWidget(
        hmUI.widget.FILL_RECT,
        {
          x:
            heartCurveX +
            i * heartCurveStep,

          y:
            heartCurveY +
            heartCurveHeight,

          w: 3,

          h:
            heartLineWidth,

          color:
            heartCurveColor
        }
      );

    line.setProperty(
      hmUI.prop.VISIBLE,
      false
    );

    segment.push(line);
  }

  heartCurveLines.push(segment);
}


// =========================
// FILL
// =========================
//
// Jemné úzké sloupky.
// Nejsou to velké čtverce.
//

const fillSlicesPerSegment = 5;

let heartCurveFills = [];

for (
  let i = 0;
  i < heartCurveCount - 1;
  i++
) {

  let segment = [];

  for (
    let s = 0;
    s < fillSlicesPerSegment;
    s++
  ) {

    const fill =
      hmUI.createWidget(
        hmUI.widget.FILL_RECT,
        {
          x:
            heartCurveX +
            i * heartCurveStep,

          y:
            heartCurveY +
            heartCurveHeight,

          w: 3,

          h: 1,

          color:
            heartFillColor
        }
      );

    fill.setProperty(
      hmUI.prop.VISIBLE,
      false
    );

    segment.push(fill);
  }

  heartCurveFills.push(segment);
}


// =========================
// MARKER
// =========================

const heartCurveMarker =
  hmUI.createWidget(
    hmUI.widget.IMG,
    {
      x:
        heartCurveX +
        heartCurveWidth -
        24,

      y:
        heartCurveY +
        heartCurveHeight -
        8,

      src:
        'heart_marker.png'
    }
  );


// =========================
// HEART -> Y
// =========================

function getHeartY(
  heartRate
) {

  const normalizedValue =
    Math.max(
      0,
      Math.min(
        1,
        heartRate / 180
      )
    );

  return (
    heartCurveY +
    heartCurveHeight -
    Math.round(
      normalizedValue *
      heartCurveHeight
    )
  );
}


// =========================
// UPDATE GRAPH
// =========================

function updateHeartCurve() {

  const currentHeartRate =
    customHeartRate.current ||
    customHeartRate.last;

  console.log(
    'DRAW HEART:',
    currentHeartRate
  );

  if (
    currentHeartRate === undefined ||
    currentHeartRate === null
  ) {
    return;
  }


  // =========================
  // ADD HISTORY
  // =========================

  heartCurveHistory.push(
    currentHeartRate
  );

  if (
    heartCurveHistory.length >
    heartCurveCount
  ) {

    heartCurveHistory.shift();
  }


  // =========================
  // POINTS
  // =========================

  for (
    let i = 0;
    i < heartCurveCount;
    i++
  ) {

    const point =
      heartCurvePoints[i];

    if (
      i >=
      heartCurveHistory.length
    ) {

      point.setProperty(
        hmUI.prop.VISIBLE,
        false
      );

      continue;
    }


    const heartRate =
      heartCurveHistory[i];

    const pointY =
      getHeartY(
        heartRate
      );


    point.setProperty(
      hmUI.prop.MORE,
      {
        x:
          heartCurveX +
          i * heartCurveStep,

        y:
          pointY,

        w:
          heartCurvePointSize,

        h:
          heartCurvePointSize,

        color:
          heartCurveColor
      }
    );

    point.setProperty(
      hmUI.prop.VISIBLE,
      true
    );
  }


  // =========================
  // DRAW LINE
  // =========================

  for (
    let i = 0;
    i < heartCurveCount - 1;
    i++
  ) {

    const segment =
      heartCurveLines[i];

    if (
      i + 1 >=
      heartCurveHistory.length
    ) {

      for (
        let s = 0;
        s < segment.length;
        s++
      ) {

        segment[s].setProperty(
          hmUI.prop.VISIBLE,
          false
        );
      }

      continue;
    }


    const y1 =
      getHeartY(
        heartCurveHistory[i]
      );

    const y2 =
      getHeartY(
        heartCurveHistory[i + 1]
      );


    const x1 =
      heartCurveX +
      i * heartCurveStep;


    const dy =
      y2 - y1;


    // malé kroky mezi body
    for (
      let s = 0;
      s < lineSlicesPerSegment;
      s++
    ) {

      const progress =
        s /
        (lineSlicesPerSegment - 1);


      const x =
        x1 +
        Math.round(
          progress *
          heartCurveStep
        );


      const y =
        y1 +
        Math.round(
          progress *
          dy
        );


      const line =
        segment[s];


      line.setProperty(
        hmUI.prop.MORE,
        {
          x:
            x,

          y:
            y -
            Math.floor(
              heartLineWidth / 2
            ),

          w: 3,

          h:
            heartLineWidth,

          color:
            heartCurveColor
        }
      );


      line.setProperty(
        hmUI.prop.VISIBLE,
        true
      );
    }
  }


  // =========================
  // DRAW FILL
  // =========================

  for (
    let i = 0;
    i < heartCurveCount - 1;
    i++
  ) {

    const segment =
      heartCurveFills[i];


    if (
      i + 1 >=
      heartCurveHistory.length
    ) {

      for (
        let s = 0;
        s < segment.length;
        s++
      ) {

        segment[s].setProperty(
          hmUI.prop.VISIBLE,
          false
        );
      }

      continue;
    }


    const y1 =
      getHeartY(
        heartCurveHistory[i]
      );

    const y2 =
      getHeartY(
        heartCurveHistory[i + 1]
      );


    const x1 =
      heartCurveX +
      i * heartCurveStep;


    const bottom =
      heartCurveY +
      heartCurveHeight;


    const dy =
      y2 - y1;


    // =========================
    // FILL EACH SMALL SLICE
    // =========================

    for (
      let s = 0;
      s < fillSlicesPerSegment;
      s++
    ) {

      const progress =
        s /
        (fillSlicesPerSegment - 1);


      const x =
        x1 +
        Math.round(
          progress *
          heartCurveStep
        );


      const curveY =
        y1 +
        Math.round(
          progress *
          dy
        );


      const fill =
        segment[s];


      const fillY =
        curveY;


      const fillHeight =
        bottom -
        fillY;


      if (
        fillHeight > 0
      ) {

        fill.setProperty(
          hmUI.prop.MORE,
          {
            x:
              x,

            y:
              fillY,

            w: 3,

            h:
              fillHeight,

            color:
              heartFillColor
          }
        );

        fill.setProperty(
          hmUI.prop.VISIBLE,
          true
        );

      } else {

        fill.setProperty(
          hmUI.prop.VISIBLE,
          false
        );
      }
    }
  }


  // =========================
  // MARKER
  // =========================

  const lastIndex =
    heartCurveHistory.length - 1;


  if (
    lastIndex >= 0
  ) {

    const lastHeartRate =
      heartCurveHistory[lastIndex];


    const markerY =
      getHeartY(
        lastHeartRate
      );


    heartCurveMarker.setProperty(
      hmUI.prop.MORE,
      {
        x:
          heartCurveX +
          lastIndex *
          heartCurveStep -
          8,

        y:
          markerY -
          8
      }
    );


    heartCurveMarker.setProperty(
      hmUI.prop.VISIBLE,
      true
    );
  }
}


// =========================
// HEART SENSOR
// =========================

customHeartRate.addEventListener(
  hmSensor.event.CHANGE,
  function () {

    console.log(
      'CUSTOM HEART EVENT'
    );

    updateHeartCurve();
  }
);


// =========================
// INITIAL DRAW
// =========================

updateHeartCurve();


// end user_script_end.js
            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 284;
                  let start_y_normal_battery = 21;
                  let lenght_ls_normal_battery = 20;
                  let line_width_ls_normal_battery = 9;
                  let color_ls_normal_battery = 0xFFADB2C7;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 284;
                  let start_y_idle_battery = 21;
                  let lenght_ls_idle_battery = 20;
                  let line_width_ls_idle_battery = 9;
                  let color_ls_idle_battery = 0xFFADB2C7;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
              pause_call: (function () {
                console.log('pause_call()');

                console.log('pause_call.js');
                // start pause_call.js

console.log('pause_call.js');
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}