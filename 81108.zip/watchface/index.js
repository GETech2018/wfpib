﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_fat_burning_circle_scale = ''
        let normal_fat_burning_TextCircle = new Array(3);
        let normal_fat_burning_TextCircle_ASCIIARRAY = new Array(10);
        let normal_fat_burning_TextCircle_img_width = 8;
        let normal_fat_burning_TextCircle_img_height = 12;
        let normal_stand_circle_scale = ''
        let normal_stand_TextCircle = new Array(2);
        let normal_stand_TextCircle_ASCIIARRAY = new Array(10);
        let normal_stand_TextCircle_img_width = 8;
        let normal_stand_TextCircle_img_height = 12;
        let normal_battery_circle_scale = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 8;
        let normal_battery_TextCircle_img_height = 12;
        let normal_calorie_circle_scale = ''
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 8;
        let normal_calorie_TextCircle_img_height = 12;
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_stress_pointer_progress_img_pointer = ''
        let normal_stress_text_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 320,
              h: 380,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 62,
              y: 309,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 225,
              y: 309,
              image_array: ["c044.png","c045.png","c046.png","c047.png","c048.png","c049.png","c050.png","c051.png","c052.png","c053.png","c054.png","c055.png","c056.png","c057.png","c058.png","c059.png","c060.png","c061.png","c062.png","c063.png","c064.png","c065.png","c066.png","c067.png","c068.png","c069.png","c070.png","c071.png","c072.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 328,
              font_array: ["f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png","f_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Grados.png',
              unit_tc: 'Grados.png',
              unit_en: 'Grados.png',
              negative_image: 'nega1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 86,
              y: 244,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 87,
              y: 204,
              src: '47.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 87,
              y: 97,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 90,
              day_startY: 70,
              day_sc_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              day_tc_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              day_en_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 160,
              // center_y: 160,
              // start_angle: -63,
              // end_angle: -14,
              // radius: 150,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFF006FDD,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 160,
              center_y: 160,
              start_angle: -63,
              end_angle: -14,
              radius: 146,
              line_width: 9,
              corner_flag: 0,
              color: 0xFF006FDD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_fat_burning_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 160,
              // circle_center_Y: 160,
              // font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              // radius: 140,
              // angle: -69,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_fat_burning_TextCircle_ASCIIARRAY[0] = 'nm_0.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[1] = 'nm_1.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[2] = 'nm_2.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[3] = 'nm_3.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[4] = 'nm_4.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[5] = 'nm_5.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[6] = 'nm_6.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[7] = 'nm_7.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[8] = 'nm_8.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[9] = 'nm_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_fat_burning_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 320,
                h: 380,
                center_x: 160,
                center_y: 160,
                pos_x: 160 - normal_fat_burning_TextCircle_img_width / 2,
                pos_y: 160 - 152,
                src: 'nm_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_fat_burning_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 160,
              // center_y: 160,
              // start_angle: 115,
              // end_angle: 174,
              // radius: 150,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFF0080C0,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 160,
              center_y: 160,
              start_angle: 115,
              end_angle: 174,
              radius: 145,
              line_width: 10,
              corner_flag: 0,
              color: 0xFF0080C0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_stand_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 160,
              // circle_center_Y: 160,
              // font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              // radius: 152,
              // angle: 111,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_TextCircle_ASCIIARRAY[0] = 'nm_0.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[1] = 'nm_1.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[2] = 'nm_2.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[3] = 'nm_3.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[4] = 'nm_4.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[5] = 'nm_5.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[6] = 'nm_6.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[7] = 'nm_7.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[8] = 'nm_8.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[9] = 'nm_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_stand_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 320,
                h: 380,
                center_x: 160,
                center_y: 160,
                pos_x: 160 - normal_stand_TextCircle_img_width / 2,
                pos_y: 160 + 140,
                src: 'nm_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_stand_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 160,
              // center_y: 160,
              // start_angle: 215,
              // end_angle: 257,
              // radius: 152,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFF009900,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 160,
              center_y: 160,
              start_angle: 215,
              end_angle: 257,
              radius: 148,
              line_width: 9,
              corner_flag: 0,
              color: 0xFF009900,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 160,
              // circle_center_Y: 160,
              // font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              // radius: 151,
              // angle: -153,
              // char_space_angle: 1,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'nm_0.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'nm_1.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'nm_2.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'nm_3.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'nm_4.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'nm_5.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'nm_6.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'nm_7.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'nm_8.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'nm_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 320,
                h: 380,
                center_x: 160,
                center_y: 160,
                pos_x: 160 - normal_battery_TextCircle_img_width / 2,
                pos_y: 160 + 139,
                src: 'nm_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 160,
              // center_y: 160,
              // start_angle: 34,
              // end_angle: 76,
              // radius: 152,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFFFF8C00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 160,
              center_y: 160,
              start_angle: 34,
              end_angle: 76,
              radius: 148,
              line_width: 9,
              corner_flag: 0,
              color: 0xFFFF8C00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 160,
              // circle_center_Y: 160,
              // font_array: ["nm_0.png","nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png"],
              // radius: 140,
              // angle: 26,
              // char_space_angle: 1,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = 'nm_0.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = 'nm_1.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = 'nm_2.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = 'nm_3.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = 'nm_4.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = 'nm_5.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = 'nm_6.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = 'nm_7.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = 'nm_8.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = 'nm_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 320,
                h: 380,
                center_x: 160,
                center_y: 160,
                pos_x: 160 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 160 - 152,
                src: 'nm_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 189,
              center_y: 73,
              x: 8,
              y: 42,
              start_angle: -135,
              end_angle: 140,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 65,
              font_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 188,
              center_y: 250,
              x: 8,
              y: 42,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 239,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point1.png',
              center_x: 246,
              center_y: 159,
              x: 10,
              y: 50,
              start_angle: -135,
              end_angle: 136,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 223,
              y: 147,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 22,
              hour_startY: 135,
              hour_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'se.png',
              hour_unit_tc: 'se.png',
              hour_unit_en: 'se.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 114,
              minute_startY: 135,
              minute_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 77,
              hour_startY: 126,
              hour_array: ["b_0.png","b_1.png","b_2.png","b_3.png","b_4.png","b_5.png","b_6.png","b_7.png","b_8.png","b_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_unit_sc: 'colonb_2.png',
              hour_unit_tc: 'colonb_2.png',
              hour_unit_en: 'colonb_2.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 166,
              minute_startY: 126,
              minute_array: ["b_0.png","b_1.png","b_2.png","b_3.png","b_4.png","b_5.png","b_6.png","b_7.png","b_8.png","b_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 164,
              y: 54,
              w: 54,
              h: 54,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 220,
              y: 135,
              w: 54,
              h: 54,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 280,
              y: 199,
              w: 34,
              h: 34,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 164,
              y: 227,
              w: 50,
              h: 50,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 62,
              y: 137,
              w: 87,
              h: 47,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 17,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                vibro();
                				click_zona1();
                             },
                              show_level: hmUI.show_level.ONLY_NORMAL,
                            });
                            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
                			normal_digital_clock_img_time_1.setProperty(hmUI.prop.VISIBLE, false);
                			normal_digital_clock_img_time_2.setProperty(hmUI.prop.VISIBLE, false);
                			normal_digital_clock_img_time_3.setProperty(hmUI.prop.VISIBLE, false);
                			normal_digital_clock_img_time_4.setProperty(hmUI.prop.VISIBLE, false);
                            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                              x: 15,
                              y: 131,
                              w: 49,
                              h: 49,
                              type: hmUI.data_type.FAT_BURNING,
                              show_level: hmUI.show_level.ONLY_NORMAL,
                            });
                            console.log('Watch_Face.Buttons');
                            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
                              x: 112,
                              y: 92,
                              w: 73,
                              h: 73,
                              text: '',
                              color: 0xFFFF8C00,
                              text_size: 24,
                              press_src: 'Empty.png',
                              normal_src: 'Empty.png',
                              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle fat_burning_FAT_BURRING');
              let valueFatBurning = fat_burning.current;
              let normal_fat_burning_circle_string = parseInt(valueFatBurning).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_fat_burning_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -69;
                if (valueFatBurning != null && valueFatBurning != undefined && isFinite(valueFatBurning) && normal_fat_burning_circle_string.length > 0 && normal_fat_burning_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_fat_burning_TextCircle_img_angle = 0;
                  let normal_fat_burning_TextCircle_dot_img_angle = 0;
                  normal_fat_burning_TextCircle_img_angle = toDegree(Math.atan2(normal_fat_burning_TextCircle_img_width/2, 140));
                  // alignment = CENTER_H
                  let normal_fat_burning_TextCircle_angleOffset = normal_fat_burning_TextCircle_img_angle * (normal_fat_burning_circle_string.length - 1);
                  char_Angle -= normal_fat_burning_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_fat_burning_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_fat_burning_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.POS_X, 160 - normal_fat_burning_TextCircle_img_width / 2);
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.SRC, normal_fat_burning_TextCircle_ASCIIARRAY[charCode]);
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_fat_burning_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle stand_STAND');
              let valueStand = stand.current;
              let normal_stand_circle_string = parseInt(valueStand).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_stand_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 291;
                if (valueStand != null && valueStand != undefined && isFinite(valueStand) && normal_stand_circle_string.length > 0 && normal_stand_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_stand_TextCircle_img_angle = 0;
                  let normal_stand_TextCircle_dot_img_angle = 0;
                  normal_stand_TextCircle_img_angle = toDegree(Math.atan2(normal_stand_TextCircle_img_width/2, 152));
                  // alignment = CENTER_H
                  let normal_stand_TextCircle_angleOffset = normal_stand_TextCircle_img_angle * (normal_stand_circle_string.length - 1);
                  normal_stand_TextCircle_angleOffset = -normal_stand_TextCircle_angleOffset;
                  char_Angle -= normal_stand_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_stand_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_stand_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_stand_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_stand_TextCircle[index].setProperty(hmUI.prop.POS_X, 160 - normal_stand_TextCircle_img_width / 2);
                      normal_stand_TextCircle[index].setProperty(hmUI.prop.SRC, normal_stand_TextCircle_ASCIIARRAY[charCode]);
                      normal_stand_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_stand_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 27;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 151));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + 1 * (normal_battery_circle_string.length - 1) / 2;
                  normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 160 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 26;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 140));
                  // alignment = CENTER_H
                  let normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_img_angle * (normal_calorie_circle_string.length - 1);
                  normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_angleOffset + 1 * (normal_calorie_circle_string.length - 1) / 2;
                  char_Angle -= normal_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 160 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_calorie_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales FAT_BURNING');
                
                let valueFatBurning = fat_burning.current;
                let targetFatBurning = fat_burning.target;
                let progressFatBurning = valueFatBurning/targetFatBurning;
                if (progressFatBurning > 1) progressFatBurning = 1;
                let progress_cs_normal_fat_burning = progressFatBurning;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_fat_burning_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_fat_burning * 100);
                  if (normal_fat_burning_circle_scale) {
                    normal_fat_burning_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 160,
                      center_y: 160,
                      start_angle: -63,
                      end_angle: -14,
                      radius: 146,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF006FDD,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 160,
                      center_y: 160,
                      start_angle: 115,
                      end_angle: 174,
                      radius: 145,
                      line_width: 10,
                      corner_flag: 0,
                      color: 0xFF0080C0,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 160,
                      center_y: 160,
                      start_angle: 215,
                      end_angle: 257,
                      radius: 148,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF009900,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 160,
                      center_y: 160,
                      start_angle: 34,
                      end_angle: 76,
                      radius: 148,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFFFF8C00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}