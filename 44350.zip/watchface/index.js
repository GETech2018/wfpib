﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_readiness_current_text_font = ''
        let normal_readiness_circle_scale = ''
        let normal_vo2max_current_text_font = ''
        let normal_vo2max_circle_scale = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_font = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_font = ''
        let normal_step_current_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_distance_current_text_font = ''
        let normal_day_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_date_img_date_week_img = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['Gennnaio', 'Febbbraio', 'Marzo', 'Aprile', 'Magggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre', ];
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_readiness_current_text_font = ''
        let idle_readiness_circle_scale = ''
        let idle_vo2max_current_text_font = ''
        let idle_vo2max_circle_scale = ''
        let idle_alarm_clock_current_text_font = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_temperature_current_text_font = ''
        let idle_temperature_high_text_font = ''
        let idle_temperature_low_text_font = ''
        let idle_weather_image_progress_img_level = ''
        let idle_heart_rate_text_font = ''
        let idle_step_current_text_font = ''
        let idle_calorie_current_text_font = ''
        let idle_distance_current_text_font = ''
        let idle_day_text_font = ''
        let idle_battery_current_text_font = ''
        let idle_date_img_date_week_img = ''
        let idle_month_name_font = ''
        let idle_Month_Array = ['Gennnaio', 'Febbbraio', 'Marzo', 'Aprile', 'Magggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre', ];
        let idle_digital_clock_img_time = ''
        let normal_vo2max_jumpable_img_click = ''
        let normal_recoveryTime_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_Switch_BG_Color = ''

        let bgColorIndex = 0;
        let bgColorList = [0xFFFF8000, 0xFF00FF00, 0xFFFFFF00, 0xFFFF0000, 0xFF0080FF, 0xFF6C828B, 0xFF408080, 0xFFFFFFFF, 0xFF808080];
        let bgColorToastList = ['Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBG_Color
            console.log('SwitchBG_Color');
            function switchBG_Color() {
              bgColorIndex++;
              if (bgColorIndex >= bgColorList.length) bgColorIndex = 0;
              hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
              let toastText = bgColorToastList[bgColorIndex].replace('%s', `${bgColorIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFFFF8000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sfondo2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 103,
              y: 54,
              w: 122,
              h: 40,
              text_size: 32,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 219,
              center_y: 253,
              start_angle: -57,
              end_angle: -10,
              radius: 250,
              line_width: 12,
              corner_flag: 3,
              type: hmUI.data_type.READINESS,
              color: 0xFF000000,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_circle_scale.setAlpha(150);

            normal_vo2max_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 210,
              y: 54,
              w: 122,
              h: 40,
              text_size: 32,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 197,
              center_y: 224,
              start_angle: 59,
              end_angle: 5,
              radius: 212,
              line_width: 12,
              corner_flag: 3,
              type: hmUI.data_type.VO2MAX,
              color: 0xFF000000,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_circle_scale.setAlpha(150);

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 101,
              y: 394,
              w: 122,
              h: 33,
              text_size: 26,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 184,
              y: 415,
              src: 'st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 54,
              y: 404,
              src: 'AlarmRond.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 61,
              y: 133,
              w: 122,
              h: 40,
              text_size: 30,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 290,
              y: 136,
              w: 122,
              h: 31,
              text_size: 25,
              char_space: 0,
              color: 0xFFFF0000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 249,
              y: 136,
              w: 122,
              h: 36,
              text_size: 25,
              char_space: 0,
              color: 0xFF0080FF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 161,
              y: 132,
              image_array: ["0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 177,
              y: 390,
              w: 122,
              h: 41,
              text_size: 32,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 208,
              y: 353,
              w: 125,
              h: 40,
              text_size: 32,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 133,
              y: 353,
              w: 122,
              h: 42,
              text_size: 32,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 68,
              y: 319,
              w: 122,
              h: 41,
              text_size: 32,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 134,
              y: 279,
              w: 122,
              h: 44,
              text_size: 31,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 208,
              y: 319,
              w: 122,
              h: 42,
              text_size: 32,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 23,
              y: 292,
              week_en: ["chars_A924873A_000.png","chars_A924873A_001.png","chars_A924873A_002.png","chars_A924873A_003.png","chars_A924873A_004.png","chars_A924873A_005.png","chars_A924873A_006.png"],
              week_tc: ["chars_A924873A_000.png","chars_A924873A_001.png","chars_A924873A_002.png","chars_A924873A_003.png","chars_A924873A_004.png","chars_A924873A_005.png","chars_A924873A_006.png"],
              week_sc: ["chars_A924873A_000.png","chars_A924873A_001.png","chars_A924873A_002.png","chars_A924873A_003.png","chars_A924873A_004.png","chars_A924873A_005.png","chars_A924873A_006.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 226,
              y: 281,
              w: 140,
              h: 44,
              text_size: 30,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: Gennnaio,Febbbraio,Marzo,Aprile,Magggio,Giugno,Luglio,Agosto,Settembre,Ottobre,Novembre,Dicembre,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 4,
              hour_startY: 178,
              hour_array: ["chars_BFE4B96D_000.png","chars_BFE4B96D_001.png","chars_BFE4B96D_002.png","chars_BFE4B96D_003.png","chars_BFE4B96D_004.png","chars_BFE4B96D_005.png","chars_BFE4B96D_006.png","chars_BFE4B96D_007.png","chars_BFE4B96D_008.png","chars_BFE4B96D_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 205,
              minute_startY: 178,
              minute_array: ["chars_3CA7EA88_000.png","chars_3CA7EA88_001.png","chars_3CA7EA88_002.png","chars_3CA7EA88_003.png","chars_3CA7EA88_004.png","chars_3CA7EA88_005.png","chars_3CA7EA88_006.png","chars_3CA7EA88_007.png","chars_3CA7EA88_008.png","chars_3CA7EA88_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFFFF8000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sfondo2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_readiness_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 103,
              y: 54,
              w: 122,
              h: 40,
              text_size: 32,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_readiness_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 219,
              center_y: 253,
              start_angle: -57,
              end_angle: -10,
              radius: 250,
              line_width: 12,
              corner_flag: 3,
              type: hmUI.data_type.READINESS,
              color: 0xFF000000,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_readiness_circle_scale.setAlpha(150);

            idle_vo2max_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 210,
              y: 54,
              w: 122,
              h: 40,
              text_size: 32,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_vo2max_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 197,
              center_y: 224,
              start_angle: 59,
              end_angle: 5,
              radius: 212,
              line_width: 12,
              corner_flag: 3,
              type: hmUI.data_type.VO2MAX,
              color: 0xFF000000,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_vo2max_circle_scale.setAlpha(150);

            idle_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 101,
              y: 394,
              w: 122,
              h: 33,
              text_size: 26,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 184,
              y: 415,
              src: 'st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 54,
              y: 404,
              src: 'AlarmRond.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 61,
              y: 133,
              w: 122,
              h: 40,
              text_size: 30,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 290,
              y: 136,
              w: 122,
              h: 31,
              text_size: 25,
              char_space: 0,
              color: 0xFFFF0000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 249,
              y: 136,
              w: 122,
              h: 36,
              text_size: 25,
              char_space: 0,
              color: 0xFF0080FF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 161,
              y: 132,
              image_array: ["0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 177,
              y: 390,
              w: 122,
              h: 41,
              text_size: 32,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 208,
              y: 353,
              w: 125,
              h: 40,
              text_size: 32,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 133,
              y: 353,
              w: 122,
              h: 42,
              text_size: 32,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 68,
              y: 319,
              w: 122,
              h: 41,
              text_size: 32,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 134,
              y: 279,
              w: 122,
              h: 44,
              text_size: 31,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 208,
              y: 319,
              w: 122,
              h: 42,
              text_size: 32,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 23,
              y: 292,
              week_en: ["chars_A924873A_000.png","chars_A924873A_001.png","chars_A924873A_002.png","chars_A924873A_003.png","chars_A924873A_004.png","chars_A924873A_005.png","chars_A924873A_006.png"],
              week_tc: ["chars_A924873A_000.png","chars_A924873A_001.png","chars_A924873A_002.png","chars_A924873A_003.png","chars_A924873A_004.png","chars_A924873A_005.png","chars_A924873A_006.png"],
              week_sc: ["chars_A924873A_000.png","chars_A924873A_001.png","chars_A924873A_002.png","chars_A924873A_003.png","chars_A924873A_004.png","chars_A924873A_005.png","chars_A924873A_006.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 226,
              y: 281,
              w: 140,
              h: 44,
              text_size: 30,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: Gennnaio,Febbbraio,Marzo,Aprile,Magggio,Giugno,Luglio,Agosto,Settembre,Ottobre,Novembre,Dicembre,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 4,
              hour_startY: 178,
              hour_array: ["chars_BFE4B96D_000.png","chars_BFE4B96D_001.png","chars_BFE4B96D_002.png","chars_BFE4B96D_003.png","chars_BFE4B96D_004.png","chars_BFE4B96D_005.png","chars_BFE4B96D_006.png","chars_BFE4B96D_007.png","chars_BFE4B96D_008.png","chars_BFE4B96D_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 205,
              minute_startY: 178,
              minute_array: ["chars_3CA7EA88_000.png","chars_3CA7EA88_001.png","chars_3CA7EA88_002.png","chars_3CA7EA88_003.png","chars_3CA7EA88_004.png","chars_3CA7EA88_005.png","chars_3CA7EA88_006.png","chars_3CA7EA88_007.png","chars_3CA7EA88_008.png","chars_3CA7EA88_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BT Scollegato ⚠️⚠️⚠️,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: BT Collegato 😄😄😄,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT Scollegato ⚠️⚠️⚠️"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BT Collegato 😄😄😄"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion
            console.log('Watch_Face.Shortcuts');

            normal_vo2max_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 210,
              y: 50,
              w: 81,
              h: 81,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_recoveryTime_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 79,
              y: 50,
              w: 81,
              h: 81,
              type: hmUI.data_type.RECOVERY_TIME,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 42,
              y: 286,
              w: 295,
              h: 33,
              text: '',
              color: 0xFFFF8C00,
              text_size: 20,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 38,
              y: 188,
              w: 137,
              h: 87,
              text: '',
              color: 0xFFFF8C00,
              text_size: 20,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 224,
              y: 188,
              w: 143,
              h: 87,
              text: '',
              color: 0xFFFF8C00,
              text_size: 20,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 25,
              y: 98,
              w: 43,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 20,
              press_src: 'Empty.png',
              normal_src: 'Phone White.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 329,
              y: 95,
              w: 41,
              h: 46,
              text: '',
              color: 0xFFFF8C00,
              text_size: 20,
              press_src: 'Empty.png',
              normal_src: 'Find.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 11,
              y: 329,
              w: 163,
              h: 33,
              text: '',
              color: 0xFFFF8C00,
              text_size: 20,
              press_src: 'Empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 16,
              y: 369,
              w: 163,
              h: 25,
              text: '',
              color: 0xFFFF8C00,
              text_size: 20,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'oneKeyAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 244,
              y: 401,
              w: 140,
              h: 28,
              text: '',
              color: 0xFFFF8C00,
              text_size: 20,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 201,
              y: 365,
              w: 163,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 20,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 201,
              y: 329,
              w: 163,
              h: 33,
              text: '',
              color: 0xFFFF8C00,
              text_size: 20,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 40,
              y: 397,
              w: 100,
              h: 33,
              text: '',
              color: 0xFFFF8C00,
              text_size: 20,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 71,
              y: 140,
              w: 250,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 20,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBG_Color');
            // Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.SwitchBG_Color, {
              // x: 155,
              // y: 398,
              // w: 73,
              // h: 80,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'Empty.png',
              // normal_src: 'Empty.png',
              // color_list: 0xFFFF8000|0xFF00FF00|0xFFFFFF00|0xFFFF0000|0xFF0080FF|0xFF6C828B|0xFF408080|0xFFFFFFFF|0xFF808080,
              // toast_list: Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s,
              // use_crown: False,
              // use_in_AOD: True,
              // vibro: False,
            // });

            Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 155,
              y: 398,
              w: 73,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                switchBG_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('month font');
              if (updateHour) {
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                checkConnection();
                stopVibro();

                //SwitchBgColor
                if (hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`) === undefined) {
                  bgColorIndex = 0;
                  hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
                } else {
                  bgColorIndex = hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg) normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
                if (screenType == hmSetting.screen_type.AOD && idle_background_bg) idle_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}