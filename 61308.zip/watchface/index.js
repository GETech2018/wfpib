﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_week_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 320,
              h: 380,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 165,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 209,
              minute_startY: 165,
              minute_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 139,
              second_startY: 169,
              second_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 142,
              am_y: 135,
              am_sc_path: '32.png',
              am_en_path: '32.png',
              pm_x: 142,
              pm_y: 135,
              pm_sc_path: '33.png',
              pm_en_path: '33.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 140,
              day_startY: 91,
              day_sc_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              day_tc_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              day_en_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 93,
              month_startY: 91,
              month_sc_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              month_tc_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              month_en_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 181,
              y: 89,
              week_en: ["54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              week_tc: ["54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              week_sc: ["54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 224,
              image_array: ["72.png","73.png","74.png","75.png","76.png","77.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '105.png',
              center_x: 58,
              center_y: 298,
              x: 6,
              y: 45,
              start_angle: -86,
              end_angle: 200,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 29,
              y: 224,
              image_array: ["89.png","90.png","91.png","92.png","93.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '105.png',
              center_x: 262,
              center_y: 298,
              x: 6,
              y: 45,
              start_angle: -124,
              end_angle: 124,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '106.png',
              center_x: 161,
              center_y: 293,
              x: 6,
              y: 53,
              start_angle: -134,
              end_angle: 134,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 130,
              y: 49,
              font_array: ["115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png"],
              padding: false,
              h_space: 0,
              invalid_image: '125.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 41,
              y: 19,
              image_array: ["126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png"],
              image_length: 8,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 320,
              h: 380,
              src: '134.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 165,
              hour_array: ["135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 209,
              minute_startY: 165,
              minute_array: ["145.png","146.png","147.png","148.png","149.png","150.png","151.png","152.png","153.png","154.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 142,
              am_y: 135,
              am_sc_path: '155.png',
              am_en_path: '155.png',
              pm_x: 142,
              pm_y: 135,
              pm_sc_path: '156.png',
              pm_en_path: '156.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 139,
              day_startY: 99,
              day_sc_array: ["167.png","168.png","169.png","170.png","171.png","172.png","173.png","174.png","175.png","176.png"],
              day_tc_array: ["167.png","168.png","169.png","170.png","171.png","172.png","173.png","174.png","175.png","176.png"],
              day_en_array: ["167.png","168.png","169.png","170.png","171.png","172.png","173.png","174.png","175.png","176.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 95,
              month_startY: 99,
              month_sc_array: ["157.png","158.png","159.png","160.png","161.png","162.png","163.png","164.png","165.png","166.png"],
              month_tc_array: ["157.png","158.png","159.png","160.png","161.png","162.png","163.png","164.png","165.png","166.png"],
              month_en_array: ["157.png","158.png","159.png","160.png","161.png","162.png","163.png","164.png","165.png","166.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 177,
              y: 99,
              week_en: ["177.png","178.png","179.png","180.png","181.png","182.png","183.png"],
              week_tc: ["177.png","178.png","179.png","180.png","181.png","182.png","183.png"],
              week_sc: ["177.png","178.png","179.png","180.png","181.png","182.png","183.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}