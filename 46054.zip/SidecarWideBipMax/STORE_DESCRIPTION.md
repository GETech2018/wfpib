# Sidecar Wide: store listing copy

**Name:** Sidecar Wide
**Device:** Amazfit Bip Max
**Category:** Digital · Data · Dark

## Short description (one line)
A dark, data-packed digital face: big time, week strip, Hybrid Charge, zone-coloured heart rate, sleep with naps, weather and PAI at a glance.

## Full description
Sidecar Wide puts everything you check during the day on one clean, dark screen, with no tapping through pages.

**Time & calendar**
- Big time with seconds and AM/PM (switches automatically when your watch is set to 24-hour)
- Week strip: past days filled, and today's box fills left to right as the day goes on
- Month and year progress, with days left and %

**Body**
- Hybrid Charge with a 10-segment meter
- Heart rate coloured by training zone, plus a zone bar
- Sleep that counts naps and leaves out the time you were awake during the night

**Sky**
- Weather icon for every condition (29 distinct icons), temperature, today's high and low
- Your city
- Next sun event: sunset while the sun is up, otherwise the next sunrise
- Moon phase

**Activity**
- Steps ring against your daily goal, steps and distance (km or mi, from your settings)
- PAI weekly total plus what you earned today as a small number next to it
- VO₂ max

**Everyday**
- Alarm time
- Battery with colour warnings: amber at 30%, red at 15%
- Always-on screen: outline time, date, alarm, week, Hybrid Charge, heart rate and battery, dimmed on black to save power
- Tap any stat to open its app

Shows "--" for anything that has no data yet, so you never see a misleading 0.

## Tags
digital, dark, data, health, heart rate zones, sleep, weather, PAI, Hybrid Charge, Bip 6

## Screenshots to upload
`preview/sample.png` (main), `preview/aod.png` (always-on), `preview/h24.png` (24-hour), `assets/bip6/preview.png` (store thumbnail)
