﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

const W = 390;
const H = 450;

// ===== โหลดค่าสีที่เคยบันทึก =====
let bgColor = hmFS.SysProGetInt("bgColor");
if (bgColor === undefined || bgColor === null) {
  bgColor = 0x003366;
}

// ===== พื้นหลัง =====
let screenType = hmSetting.getScreenType()
let bg = ''
let colorText= ''
if (screenType != hmSetting.screen_type.AOD) {
 bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
  x: 0, y: 0, w: W, h: H, color: bgColor,
});


/*
// ===== Text แสดงค่าสี =====
 colorText = hmUI.createWidget(hmUI.widget.TEXT, {
  x: 20, y: 300, w: 350, h: 30,
  text: "Color: 0x" + bgColor.toString(16).toUpperCase().padStart(6, "0"),
  color: 0xffffff, text_size: 20, align_h: hmUI.align.CENTER_H,
});
*/
}

// ===== สร้างสีหลัก 64 สีจาก HSV =====
function hsvToRgb(h) {
  let s = 1, v = 1;
  let c = v * s;
  let x = c * (1 - Math.abs((h / 60) % 2 - 1));
  let m = v - c;

  let r, g, b;
  if (h < 60)      { r = c; g = x; b = 0; }
  else if (h < 120){ r = x; g = c; b = 0; }
  else if (h < 180){ r = 0; g = c; b = x; }
  else if (h < 240){ r = 0; g = x; b = c; }
  else if (h < 300){ r = x; g = 0; b = c; }
  else             { r = c; g = 0; b = x; }

  return [
    Math.floor((r + m) * 255),
    Math.floor((g + m) * 255),
    Math.floor((b + m) * 255),
  ];
}

const baseColors = [];
for (let i = 0; i < 64; i++) {
  const hue = i * (360 / 64);
  baseColors.push(hsvToRgb(hue));
}

// ===== index (ค่าเริ่มต้นเดิม) =====
let colorIndex = 0;
let levelIndex = 20;

// ===== ไล่ระดับ 40 ขั้น =====
function makeShade(rgb, level) {
  const t = level / 39;
  let r, g, b;

  if (t < 0.5) {
    const k = t * 2;
    r = Math.floor(rgb[0] * k);
    g = Math.floor(rgb[1] * k);
    b = Math.floor(rgb[2] * k);
  } else {
    const k = (t - 0.5) * 2;
    r = Math.floor(rgb[0] + (255 - rgb[0]) * k);
    g = Math.floor(rgb[1] + (255 - rgb[1]) * k);
    b = Math.floor(rgb[2] + (255 - rgb[2]) * k);
  }

  return (r << 16) | (g << 8) | b;
}

// ===== 🔧 Sync colorIndex / levelIndex จาก bgColor ที่โหลดมา =====
function rgbFromInt(c) {
  return [(c >> 16) & 255, (c >> 8) & 255, c & 255];
}

(function syncIndexFromColor() {
  const [R, G, B] = rgbFromInt(bgColor);

  let bestDiff = 1e9;
  let bestColor = 0;
  let bestLevel = 20;

  for (let i = 0; i < baseColors.length; i++) {
    for (let l = 0; l < 40; l++) {
      const c = makeShade(baseColors[i], l);
      const r = (c >> 16) & 255;
      const g = (c >> 8) & 255;
      const b = c & 255;

      const diff =
        (r - R) * (r - R) +
        (g - G) * (g - G) +
        (b - B) * (b - B);

      if (diff < bestDiff) {
        bestDiff = diff;
        bestColor = i;
        bestLevel = l;
      }
    }
  }

  colorIndex = bestColor;
  levelIndex = bestLevel;
})();

function updateColor() {
  const c = makeShade(baseColors[colorIndex], levelIndex);
  bg.setProperty(hmUI.prop.COLOR, c);

  hmFS.SysProSetInt("bgColor", c);   // 👈 จำค่าสี
/*
  colorText.setProperty(
    hmUI.prop.TEXT,
    "Color: 0x" + c.toString(16).toUpperCase().padStart(6, "0")
  );
*/
}

/*

// ===== ปุ่มภาพ =====

// ← Color
hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 40, y: 340, w: 45, h: 45,
  text: '',
  normal_src: 'left.png',
  press_src:  'left.png',
  click_func: () => {
    colorIndex--;
    if (colorIndex < 0) colorIndex = baseColors.length - 1;
    levelIndex = 20;
    updateColor();
  },
  show_level: hmUI.show_level.ONLY_NORMAL,
});

// → Color
hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 110, y: 340, w: 45, h: 45,
  text: '',
  normal_src: 'right.png',
  press_src:  'right.png',
  click_func: () => {
    colorIndex++;
    if (colorIndex >= baseColors.length) colorIndex = 0;
    levelIndex = 20;
    updateColor();
  },
  show_level: hmUI.show_level.ONLY_NORMAL,
});

// ↑ Shade
hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 210, y: 340, w: 45, h: 45,
  text: '',
  normal_src: 'up.png',
  press_src:  'up.png',
  click_func: () => {
    levelIndex++;
    if (levelIndex > 39) levelIndex = 0;
    updateColor();
  },
  show_level: hmUI.show_level.ONLY_NORMAL,
});

// ↓ Shade
hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 280, y: 340, w: 45, h: 45,
  text: '',
  normal_src: 'down.png',
  press_src:  'down.png',
  click_func: () => {
    levelIndex--;
    if (levelIndex < 0) levelIndex = 39;
    updateColor();
  },
  show_level: hmUI.show_level.ONLY_NORMAL,
});

*/

// ===== แสดงสีที่โหลดมา (ไม่ทับ) =====

if (screenType != hmSetting.screen_type.AOD) {
bg.setProperty(hmUI.prop.COLOR, bgColor);
}
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_hrv_text_text_img = ''
        let normal_hrv_image_progress_img_level = ''
        let normal_hrv_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 210,
              minute_startY: 120,
              minute_array: ["TimeT_0.png","TimeT_1.png","TimeT_2.png","TimeT_3.png","TimeT_4.png","TimeT_5.png","TimeT_6.png","TimeT_7.png","TimeT_8.png","TimeT_9.png"],
              minute_zero: 1,
              minute_space: -3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 14,
              hour_startY: 120,
              hour_array: ["TimeT_0.png","TimeT_1.png","TimeT_2.png","TimeT_3.png","TimeT_4.png","TimeT_5.png","TimeT_6.png","TimeT_7.png","TimeT_8.png","TimeT_9.png"],
              hour_zero: 1,
              hour_space: -3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 328,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 246,
              y: 369,
              image_array: ["HRV_01.png","HRV_02.png","HRV_03.png","HRV_04.png","HRV_05.png","HRV_06.png","HRV_07.png","HRV_08.png","HRV_09.png","HRV_10.png"],
              image_length: 10,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 244,
              y: 366,
              src: 'Top_HRV_Progress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 265,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Act_0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 214,
              y: 299,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 348,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 307,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 56,
              y: 265,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 303,
              month_startY: 62,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 259,
              day_startY: 62,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 187,
              y: 62,
              week_en: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_tc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_sc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 51,
              y: 34,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 44,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_Unit.png',
              unit_tc: 'Temp_Unit.png',
              unit_en: 'Temp_Unit.png',
              imperial_unit_sc: 'Temp_Unit.png',
              imperial_unit_tc: 'Temp_Unit.png',
              imperial_unit_en: 'Temp_Unit.png',
              negative_image: 'Temp_Minus.png',
              invalid_image: 'Temp_Minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 107,
                y: 44,
                font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Temp_Unit.png',
                unit_tc: 'Temp_Unit.png',
                unit_en: 'Temp_Unit.png',
                imperial_unit_sc: 'Temp_Unit.png',
                imperial_unit_tc: 'Temp_Unit.png',
                imperial_unit_en: 'Temp_Unit.png',
                negative_image: 'Temp_Minus.png',
                invalid_image: 'Temp_Minus.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 306,
              // start_y: 29,
              // color: 0xFFFFFFFF,
              // lenght: 22,
              // line_width: 9,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 256,
              y: 295,
              src: 'Top_batt_progress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 22,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_Unit.png',
              unit_tc: 'Batt_Unit.png',
              unit_en: 'Batt_Unit.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 302,
              y: 25,
              src: 'icon_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 187,
              y: 410,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 186,
              y: 125,
              src: 'SystemAlarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 20,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_Unit.png',
              unit_tc: 'Batt_Unit.png',
              unit_en: 'Batt_Unit.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 219,
              minute_startY: 172,
              minute_array: ["AOD_0.png","AOD_1.png","AOD_2.png","AOD_3.png","AOD_4.png","AOD_5.png","AOD_6.png","AOD_7.png","AOD_8.png","AOD_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 7,
              hour_startY: 172,
              hour_array: ["AOD_0.png","AOD_1.png","AOD_2.png","AOD_3.png","AOD_4.png","AOD_5.png","AOD_6.png","AOD_7.png","AOD_8.png","AOD_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 152,
              y: 160,
              src: 'AOD_Dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 24,
              y: 258,
              w: 160,
              h: 33,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 209,
              y: 257,
              w: 39,
              h: 54,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 25,
              y: 341,
              w: 118,
              h: 36,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 21,
              y: 7,
              w: 69,
              h: 86,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 104,
              y: 27,
              w: 78,
              h: 57,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 262,
              y: 265,
              w: 82,
              h: 45,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 255,
              y: 140,
              w: 77,
              h: 67,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 75,
              y: 141,
              w: 66,
              h: 68,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 176,
              y: 102,
              w: 38,
              h: 43,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 73,
              y: 388,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'left.png',
              normal_src: 'left.png',
              click_func: (button_widget) => {
                //color up
    colorIndex--;
    if (colorIndex < 0) colorIndex = baseColors.length - 1;
    levelIndex = 20;
    updateColor();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 134,
              y: 388,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'right.png',
              normal_src: 'right.png',
              click_func: (button_widget) => {
                //colordown
    colorIndex++;
    if (colorIndex >= baseColors.length) colorIndex = 0;
    levelIndex = 20;
    updateColor();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 219,
              y: 388,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'left.png',
              normal_src: 'left.png',
              click_func: (button_widget) => {
                //shade up
    levelIndex++;
    if (levelIndex > 39) levelIndex = 0;
    updateColor();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 279,
              y: 388,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'right.png',
              normal_src: 'right.png',
              click_func: (button_widget) => {
                //shade down
    levelIndex--;
    if (levelIndex < 0) levelIndex = 39;
    updateColor();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 222,
              y: 14,
              w: 121,
              h: 31,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 59,
              w: 174,
              h: 31,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 24,
              y: 300,
              w: 161,
              h: 33,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 207,
              y: 325,
              w: 120,
              h: 54,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1047865, url: 'page/square_pamir/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 306;
                  let start_y_normal_battery = 29;
                  let lenght_ls_normal_battery = 22;
                  let line_width_ls_normal_battery = 9;
                  let color_ls_normal_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}