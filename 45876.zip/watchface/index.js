﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_step_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_icon_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_icon_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'background_e439914a.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 262,
              y: 119,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 102,
              y: 97,
              src: 'bd_1.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 320,
              font_array: ["chars_95108657_000.png","chars_95108657_001.png","chars_95108657_002.png","chars_95108657_003.png","chars_95108657_004.png","chars_95108657_005.png","chars_95108657_006.png","chars_95108657_007.png","chars_95108657_008.png","chars_95108657_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 255,
              y: 287,
              src: 'step_12_32x29.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 95,
              font_array: ["chars_51DDD35A_000.png","chars_51DDD35A_001.png","chars_51DDD35A_002.png","chars_51DDD35A_003.png","chars_51DDD35A_004.png","chars_51DDD35A_005.png","chars_51DDD35A_006.png","chars_51DDD35A_007.png","chars_51DDD35A_008.png","chars_51DDD35A_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_51DDD35A_011.png',
              unit_tc: 'chars_51DDD35A_011.png',
              unit_en: 'chars_51DDD35A_011.png',
              negative_image: 'chars_51DDD35A_010.png',
              invalid_image: 'chars_51DDD35A_012.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 145,
              y: 84,
              image_array: ["set_1_38x38_meteo_1.png","set_1_38x38_meteo_2.png","set_1_38x38_meteo_3.png","set_1_38x38_meteo_4.png","set_1_38x38_meteo_5.png","set_1_38x38_meteo_6.png","set_1_38x38_meteo_7.png","set_1_38x38_meteo_8.png","set_1_38x38_meteo_9.png","set_1_38x38_meteo_10.png","set_1_38x38_meteo_11.png","set_1_38x38_meteo_12.png","set_1_38x38_meteo_13.png","set_1_38x38_meteo_14.png","set_1_38x38_meteo_15.png","set_1_38x38_meteo_16.png","set_1_38x38_meteo_17.png","set_1_38x38_meteo_18.png","set_1_38x38_meteo_19.png","set_1_38x38_meteo_20.png","set_1_38x38_meteo_21.png","set_1_38x38_meteo_22.png","set_1_38x38_meteo_23.png","set_1_38x38_meteo_24.png","set_1_38x38_meteo_25.png","set_1_38x38_meteo_26.png","set_1_38x38_meteo_27.png","set_1_38x38_meteo_28.png","set_1_38x38_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 201,
              day_startY: 126,
              day_sc_array: ["chars_AE74F23E_000.png","chars_AE74F23E_001.png","chars_AE74F23E_002.png","chars_AE74F23E_003.png","chars_AE74F23E_004.png","chars_AE74F23E_005.png","chars_AE74F23E_006.png","chars_AE74F23E_007.png","chars_AE74F23E_008.png","chars_AE74F23E_009.png"],
              day_tc_array: ["chars_AE74F23E_000.png","chars_AE74F23E_001.png","chars_AE74F23E_002.png","chars_AE74F23E_003.png","chars_AE74F23E_004.png","chars_AE74F23E_005.png","chars_AE74F23E_006.png","chars_AE74F23E_007.png","chars_AE74F23E_008.png","chars_AE74F23E_009.png"],
              day_en_array: ["chars_AE74F23E_000.png","chars_AE74F23E_001.png","chars_AE74F23E_002.png","chars_AE74F23E_003.png","chars_AE74F23E_004.png","chars_AE74F23E_005.png","chars_AE74F23E_006.png","chars_AE74F23E_007.png","chars_AE74F23E_008.png","chars_AE74F23E_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 151,
              y: 129,
              week_en: ["chars_6BAE8426_000_1.png","chars_6BAE8426_001_1.png","chars_6BAE8426_002_1.png","chars_6BAE8426_003_1.png","chars_6BAE8426_004_1.png","chars_6BAE8426_005_1.png","chars_6BAE8426_006_1.png"],
              week_tc: ["chars_6BAE8426_000_1.png","chars_6BAE8426_001_1.png","chars_6BAE8426_002_1.png","chars_6BAE8426_003_1.png","chars_6BAE8426_004_1.png","chars_6BAE8426_005_1.png","chars_6BAE8426_006_1.png"],
              week_sc: ["chars_6BAE8426_000_1.png","chars_6BAE8426_001_1.png","chars_6BAE8426_002_1.png","chars_6BAE8426_003_1.png","chars_6BAE8426_004_1.png","chars_6BAE8426_005_1.png","chars_6BAE8426_006_1.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 151,
              hour_startY: 345,
              hour_array: ["chars_57A06F95_000.png","chars_57A06F95_001.png","chars_57A06F95_002.png","chars_57A06F95_003.png","chars_57A06F95_004.png","chars_57A06F95_005.png","chars_57A06F95_006.png","chars_57A06F95_007.png","chars_57A06F95_008.png","chars_57A06F95_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 203,
              minute_startY: 345,
              minute_array: ["chars_57A06F95_000.png","chars_57A06F95_001.png","chars_57A06F95_002.png","chars_57A06F95_003.png","chars_57A06F95_004.png","chars_57A06F95_005.png","chars_57A06F95_006.png","chars_57A06F95_007.png","chars_57A06F95_008.png","chars_57A06F95_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 269,
              y: 225,
              font_array: ["chars_BD996459_000.png","chars_BD996459_001.png","chars_BD996459_002.png","chars_BD996459_003.png","chars_BD996459_004.png","chars_BD996459_005.png","chars_BD996459_006.png","chars_BD996459_007.png","chars_BD996459_008.png","chars_BD996459_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 226,
              font_array: ["chars_BD996459_000.png","chars_BD996459_001.png","chars_BD996459_002.png","chars_BD996459_003.png","chars_BD996459_004.png","chars_BD996459_005.png","chars_BD996459_006.png","chars_BD996459_007.png","chars_BD996459_008.png","chars_BD996459_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 99,
              y: 291,
              image_array: ["set_8_44x34_img_level_1.png","set_8_44x34_img_level_2.png","set_8_44x34_img_level_3.png","set_8_44x34_img_level_4.png","set_8_44x34_img_level_5.png","set_8_44x34_img_level_6.png","set_8_44x34_img_level_7.png","set_8_44x34_img_level_8.png","set_8_44x34_img_level_9.png","set_8_44x34_img_level_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 318,
              font_array: ["chars_95108657_000.png","chars_95108657_001.png","chars_95108657_002.png","chars_95108657_003.png","chars_95108657_004.png","chars_95108657_005.png","chars_95108657_006.png","chars_95108657_007.png","chars_95108657_008.png","chars_95108657_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 125,
              y: 312,
              src: 'chars_CD060038_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 173,
              y: 303,
              font_array: ["chars_95108657_000.png","chars_95108657_001.png","chars_95108657_002.png","chars_95108657_003.png","chars_95108657_004.png","chars_95108657_005.png","chars_95108657_006.png","chars_95108657_007.png","chars_95108657_008.png","chars_95108657_009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'chars_95108657_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 180,
              y: 263,
              src: 'km_2_33x29_h206s11b100.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'pointers_hour_set_35_h_AE714A31.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 30,
              hour_posY: 163,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'pointers_minute_set_35_m_655968E3.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 29,
              minute_posY: 183,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'pointers_second_set_32_s_FC6480D3.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 33,
              second_posY: 169,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'aod_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 170,
              y: 291,
              image_array: ["set_8_44x34_img_level_1.png","set_8_44x34_img_level_2.png","set_8_44x34_img_level_3.png","set_8_44x34_img_level_4.png","set_8_44x34_img_level_5.png","set_8_44x34_img_level_6.png","set_8_44x34_img_level_7.png","set_8_44x34_img_level_8.png","set_8_44x34_img_level_9.png","set_8_44x34_img_level_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 318,
              font_array: ["chars_95108657_000.png","chars_95108657_001.png","chars_95108657_002.png","chars_95108657_003.png","chars_95108657_004.png","chars_95108657_005.png","chars_95108657_006.png","chars_95108657_007.png","chars_95108657_008.png","chars_95108657_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 207,
              y: 312,
              src: 'chars_CD060038_000.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'pointers_hour_set_35_h_AE714A31.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 30,
              hour_posY: 163,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'pointers_minute_set_35_m_655968E3.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 29,
              minute_posY: 183,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 143,
              y: 84,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 143,
              y: 124,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({ appid: 1057409, url: 'page/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 75,
              y: 194,
              w: 100,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StressHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 229,
              y: 194,
              w: 100,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 60,
              y: 291,
              w: 100,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 234,
              y: 285,
              w: 100,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}