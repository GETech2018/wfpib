/*
** Aroelzm Digital Minimal v1.0 - versi tanpa ikon  (Amazfit Bip Max, 432 x 514)
** Gelap, simetris, Poppins Bold, tanpa ikon, bar hari Mon-Sun, kotak tanggal.
** Tap angka jam -> ganti tema (9 warna + Colorful).
*/
try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() { return __$$app$$__.app; }
        function getCurrentPage() { return __$$app$$__.current && __$$app$$__.current.module; }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = DeviceRuntimeCore.HmLogger.getLogger('aroelzm_digital_minimal_noicon');
        //end of ignored block

        const FONT = 'fonts/PoppinsBold.ttf';
        // 0 cyan, 1 hijau, 2 kuning, 3 oranye, 4 merah, 5 pink, 6 ungu, 7 biru, 8 putih ; 9 = Colorful
        const COLORS = [0xFF26E6FF, 0xFF26FF6F, 0xFFFFD426, 0xFFFF6E26, 0xFFFF2643, 0xFFFF4FD8, 0xFFA526FF, 0xFF2F6BFF, 0xFFFFFFFF];
        const THEME_COUNT = 10, COLORFUL = 9;
        // tema Colorful: warna & indeks ikon per elemen
        const CF_COLOR = { hh: 0xFF26E6FF, colon: 0xFFFFFFFF, mm: 0xFFFF4FD8, sec: 0xFFFFD426, bar: 0xFF26FF6F,
                           hr: 0xFFFF2643, o2: 0xFF26E6FF, st: 0xFF26FF6F, bt: 0xFFFFD426, km: 0xFF2F6BFF, sl: 0xFFA526FF, kc: 0xFFFF6E26, day: 0xFFFFD426, dbar: 0xFF26E6FF, dnum: 0xFFFF6E26 };
                const THEME_KEY = 'AROELZM_DIGITAL_MINIMAL_THEME';
        const GRAY = 0xFF8A8F98, WHITE = 0xFFFFFFFF, DIM = 0xFF2A2D33;
        const AOD_VAL = 0xFFC4C7CC, AOD_LAB = 0xFF8F939B, BOX = 0xFF15181D;
        const DAYS = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        const MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
                const BAR_X = 40, BAR_W = 352, HW = 169;
        const CXL = 125, CXR = 307;            // pusat sel baris 2 (simetris terhadap 216)
        const C1L = 98, C1R = 334;             // pusat sel baris 1 (HR | kotak tanggal | SpO2)
        const DAYSX = 76, DAYSW = 280;       // bar hari dipendekkan & dipusatkan agar tidak terpotong sudut layar
        const CX3 = [80, 216, 352];            // pusat sel baris 3

        let themeIdx = 0;
        const reg = [];                         // {role, w, kind, name}
        let timeSensor, heart, step, cal, dist, batt, spo2, sleep;
        let tm = undefined;
        let screenType = 0;
        const W = {};
        const NL = () => hmUI.show_level.ONLY_NORMAL;
        const AL = () => hmUI.show_level.ONLY_AOD;

        function loadTheme() {
            try {
                if (typeof hmFS !== 'undefined' && typeof hmFS.SysProGetInt === 'function') {
                    const v = hmFS.SysProGetInt(THEME_KEY);
                    if (typeof v === 'number' && v >= 0 && v < THEME_COUNT) return v;
                }
            } catch (e) {}
            return 0;
        }
        function saveTheme(i) {
            try {
                if (typeof hmFS !== 'undefined' && typeof hmFS.SysProSetInt === 'function') hmFS.SysProSetInt(THEME_KEY, i);
            } catch (e) {}
        }
        function roleColor(role, t) { return t === COLORFUL ? CF_COLOR[role] : COLORS[t]; }

        function txt(x, y, w, hh, size, color, text, level, align) {
            return hmUI.createWidget(hmUI.widget.TEXT, {
                x: x, y: y, w: w, h: hh, text_size: size, char_space: 0, line_space: 0,
                font: FONT, color: color, align_h: align || hmUI.align.CENTER_H, align_v: hmUI.align.CENTER_V,
                text_style: hmUI.text_style.NONE, text: text, show_level: level
            });
        }
        function rect(x, y, w, hh, color, role, level) {
            const r = hmUI.createWidget(hmUI.widget.FILL_RECT, { x: x, y: y, w: w, h: hh, color: color, show_level: level || NL() });
            r.__x = x; r.__y = y; r.__h = hh;
            if (role) reg.push({ role: role, w: r, kind: 'rect' });
            return r;
        }
        function setW(r, w) {
            const v = Math.max(2, Math.round(w));
            if (typeof hmUI.prop.W !== 'undefined') r.setProperty(hmUI.prop.W, v);
            else r.setProperty(hmUI.prop.MORE, { x: r.__x, y: r.__y, w: v, h: r.__h, color: roleColor('bar', themeIdx) });
        }
        // nilai: satu widget utama (warna tema) + satu widget AOD (abu-abu), diperbarui bersamaan
        function val(role, x, y, w, hh, size, text) {
            const n = txt(x, y, w, hh, size, roleColor(role, themeIdx), text, NL());
            const a = txt(x, y, w, hh, size, AOD_VAL, text, AL());
            reg.push({ role: role, w: n, kind: 'text' });
            return { setProperty: function (k, v) { n.setProperty(k, v); a.setProperty(k, v); } };
        }
        // label di tengah sel (sejajar dengan angkanya)
        function label(cx, y, name, text) {
            txt(cx - 60, y, 120, 26, 18, GRAY, text, NL());
            txt(cx - 60, y, 120, 26, 18, AOD_LAB, text, AL());
        }
        // skala (tick + label) di bawah/di sekitar bar
        function scale(x0, w, ty, th, ly, labels, level) {
            const n = labels.length;
            for (let k = 0; k < n; k++) {
                const tx = Math.round(x0 + w * k / (n - 1));
                rect(Math.min(tx, x0 + w - 2), ty, 2, th, k % 2 === 0 ? WHITE : GRAY, null, level);
                const al = k === 0 ? hmUI.align.LEFT : (k === n - 1 ? hmUI.align.RIGHT : hmUI.align.CENTER_H);
                const lx = k === 0 ? x0 : (k === n - 1 ? x0 + w - 44 : tx - 22);
                txt(lx, ly, 44, 16, 13, GRAY, labels[k], level, al);
            }
        }
        function pad(n) { return n < 10 ? '0' + n : '' + n; }
        function safe(fn, dflt) { try { const v = fn(); return (v === undefined || v === null) ? dflt : v; } catch (e) { return dflt; } }

        function applyTheme(i) {
            themeIdx = i;
            reg.forEach(function (o) { o.w.setProperty(hmUI.prop.COLOR, roleColor(o.role, i)); });
            paintDays();
        }

        // ---- bar hari: MON ... SUN, progres mengikuti hari & jam ----
        const dayN = [], dayA = [];
        function dayIndex() { return timeSensor.week - 1; }
        function paintDays() {
            const t = dayIndex();
            for (let i = 0; i < 7; i++) {
                dayN[i].setProperty(hmUI.prop.COLOR, i === t ? roleColor('day', themeIdx) : GRAY);
                dayA[i].setProperty(hmUI.prop.COLOR, i === t ? AOD_VAL : AOD_LAB);
            }
        }
        function updateDayBar() {
            const frac = (dayIndex() + (timeSensor.hour * 60 + timeSensor.minute) / 1440) / 7;
            const w = Math.max(2, Math.round(DAYSW * frac));
            setW(W.dbar, w); setW(W.dbarA, w);
            paintDays();
        }

        function updateSlow() {
            let txtS = '--';
            try {
                const info = sleep.getBasicInfo();
                let total = info.totalTime || info.totoalTime;
                if (!total && typeof info.startTime === 'number' && typeof info.endTime === 'number') {
                    total = info.endTime >= info.startTime ? info.endTime - info.startTime : info.endTime + 1440 - info.startTime;
                }
                if (total > 0) txtS = Math.floor(total / 60) + ':' + pad(total % 60);
            } catch (e) {}
            W.sleep.setProperty(hmUI.prop.TEXT, txtS);
        }

        function update() {
            const hr = timeSensor.format_hour, mi = timeSensor.minute, se = timeSensor.second;
            W.hh.setProperty(hmUI.prop.TEXT, pad(hr));
            W.mm.setProperty(hmUI.prop.TEXT, pad(mi));
            W.timeA.setProperty(hmUI.prop.TEXT, pad(hr) + ':' + pad(mi));
            W.dnum.setProperty(hmUI.prop.TEXT, '' + timeSensor.day);
            W.dmon.setProperty(hmUI.prop.TEXT, MONTHS[timeSensor.month - 1]);
            updateDayBar();
            if (screenType !== hmSetting.screen_type.AOD) {
                W.sec.setProperty(hmUI.prop.TEXT, pad(se));
                setW(W.secBar, BAR_W * se / 60);
            }
            const hv = safe(function () { return heart.last; }, 0);
            W.hr.setProperty(hmUI.prop.TEXT, hv > 0 ? '' + hv : '--');
            const ov = safe(function () { return spo2.current !== undefined ? spo2.current : spo2.value; }, 0);
            W.spo2.setProperty(hmUI.prop.TEXT, ov > 0 ? ov + '%' : '--');
            const sc = safe(function () { return step.current; }, 0);
            W.step.setProperty(hmUI.prop.TEXT, '' + sc);
            setW(W.stepBar, HW * Math.min(1, sc / 10000));
            const bv = safe(function () { return batt.current; }, 0);
            W.bat.setProperty(hmUI.prop.TEXT, bv + '%');
            setW(W.batBar, HW * Math.min(1, bv / 100));
            const dv = safe(function () { return dist.current; }, 0);
            W.dist.setProperty(hmUI.prop.TEXT, (Math.round(dv / 10) / 100).toFixed(2));
            const cc = safe(function () { return cal.current; }, 0);
            W.cal.setProperty(hmUI.prop.TEXT, '' + cc);
        }

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                screenType = hmSetting.getScreenType();
                timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                heart = hmSensor.createSensor(hmSensor.id.HEART);
                step = hmSensor.createSensor(hmSensor.id.STEP);
                cal = hmSensor.createSensor(hmSensor.id.CALORIE);
                dist = hmSensor.createSensor(hmSensor.id.DISTANCE);
                batt = hmSensor.createSensor(hmSensor.id.BATTERY);
                try {
                    const sid = hmSensor.id.SPO2 || hmSensor.id.BLOOD_OXYGEN;
                    if (sid !== undefined) spo2 = hmSensor.createSensor(sid);
                } catch (e) {}
                try { if (hmSensor.id.SLEEP !== undefined) sleep = hmSensor.createSensor(hmSensor.id.SLEEP); } catch (e) {}
                timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () { update(); updateSlow(); });
                themeIdx = loadTheme();

                // bar hari di bagian atas
                for (let i = 0; i < 7; i++) {
                    const cx = Math.round(DAYSX + DAYSW * (i + 0.5) / 7);
                    dayN.push(txt(cx - 20, 4, 40, 24, 14, GRAY, DAYS[i], NL()));
                    dayA.push(txt(cx - 20, 4, 40, 24, 14, AOD_LAB, DAYS[i], AL()));
                }
                rect(DAYSX, 30, DAYSW, 5, DIM, null, NL()); rect(DAYSX, 30, DAYSW, 5, DIM, null, AL());
                W.dbar = rect(DAYSX, 30, 2, 5, roleColor('dbar', themeIdx), 'dbar', NL());
                W.dbarA = rect(DAYSX, 30, 2, 5, AOD_VAL, null, AL());
                for (let i = 0; i <= 7; i++) {
                    const tx = Math.min(Math.round(DAYSX + DAYSW * i / 7), DAYSX + DAYSW - 2);
                    rect(tx, 28, 2, 9, GRAY, null, NL()); rect(tx, 28, 2, 9, AOD_LAB, null, AL());
                }

                // kotak tanggal & bulan (di antara HR dan SpO2)
                // bingkai (warna tema) + isi kotak
                const frame = hmUI.createWidget(hmUI.widget.FILL_RECT, { x: 166, y: 46, w: 100, h: 78, radius: 14, color: roleColor('dnum', themeIdx), show_level: NL() });
                reg.push({ role: 'dnum', w: frame, kind: 'rect' });
                hmUI.createWidget(hmUI.widget.FILL_RECT, { x: 166, y: 46, w: 100, h: 78, radius: 14, color: 0xFF5A5E66, show_level: AL() });
                hmUI.createWidget(hmUI.widget.FILL_RECT, { x: 169, y: 49, w: 94, h: 72, radius: 11, color: BOX, show_level: NL() });
                hmUI.createWidget(hmUI.widget.FILL_RECT, { x: 169, y: 49, w: 94, h: 72, radius: 11, color: BOX, show_level: AL() });
                W.dnum = val('dnum', 166, 50, 100, 44, 38, '');
                W.dmon = (function () {
                    const n = txt(166, 94, 100, 26, 17, GRAY, '', NL()), a = txt(166, 94, 100, 26, 17, AOD_LAB, '', AL());
                    return { setProperty: function (k, v) { n.setProperty(k, v); a.setProperty(k, v); } };
                })();

                // baris 1: HR | SpO2
                label(C1L, 46, 'hr', 'HR'); label(C1R, 46, 'o2', 'SpO2');
                W.hr = val('hr', C1L - 70, 72, 140, 52, 44, '--');
                W.spo2 = val('o2', C1R - 70, 72, 140, 52, 44, '--');
                rect(BAR_X, 128, BAR_W, 2, DIM, null, NL()); rect(BAR_X, 128, BAR_W, 2, DIM, null, AL());

                // jam besar: HH : MM (tiap bagian bisa beda warna di tema Colorful)
                W.hh = txt(8, 132, 192, 104, 96, roleColor('hh', themeIdx), '', NL(), hmUI.align.RIGHT);
                reg.push({ role: 'hh', w: W.hh, kind: 'text' });
                W.colon = txt(196, 132, 40, 104, 96, roleColor('colon', themeIdx), ':', NL(), hmUI.align.CENTER_H);
                reg.push({ role: 'colon', w: W.colon, kind: 'text' });
                W.mm = txt(232, 132, 192, 104, 96, roleColor('mm', themeIdx), '', NL(), hmUI.align.LEFT);
                reg.push({ role: 'mm', w: W.mm, kind: 'text' });
                // AOD: jam penuh di tengah, abu-abu
                W.timeA = txt(4, 137, 424, 170, 132, AOD_VAL, '', AL());

                // detik + penggaris 0-15-30-45-60
                W.sec = txt(136, 236, 160, 34, 30, roleColor('sec', themeIdx), '', NL());
                reg.push({ role: 'sec', w: W.sec, kind: 'text' });
                rect(BAR_X, 282, BAR_W, 6, DIM, null, NL());
                W.secBar = rect(BAR_X, 282, 2, 6, roleColor('bar', themeIdx), 'bar', NL());
                for (let k = 0; k <= 12; k++) {
                    const tx = Math.round(BAR_X + BAR_W * k / 12), major = (k % 3 === 0);
                    rect(Math.min(tx, BAR_X + BAR_W - 2), major ? 276 : 279, 2, major ? 18 : 12, major ? WHITE : GRAY, null, NL());
                }
                const sl = ['0', '15', '30', '45', '60'];
                for (let k = 0; k < 5; k++) {
                    const tx = Math.round(BAR_X + BAR_W * k / 4);
                    const al = k === 0 ? hmUI.align.LEFT : (k === 4 ? hmUI.align.RIGHT : hmUI.align.CENTER_H);
                    txt(k === 0 ? BAR_X : (k === 4 ? BAR_X + BAR_W - 44 : tx - 22), 296, 44, 18, 14, GRAY, sl[k], NL(), al);
                }
                rect(BAR_X, 318, BAR_W, 2, DIM, null, NL()); rect(BAR_X, 318, BAR_W, 2, DIM, null, AL());

                // baris 2: STEPS | BAT  (dengan skala)
                label(CXL, 324, 'st', 'STEPS'); label(CXR, 324, 'bt', 'BAT');
                W.step = val('st', CXL - 85, 352, 170, 40, 36, '0');
                W.bat = val('bt', CXR - 85, 352, 170, 40, 36, '0');
                const RX = BAR_X + HW + 14;
                rect(BAR_X, 396, HW, 5, DIM, null, NL()); rect(RX, 396, HW, 5, DIM, null, NL());
                W.stepBar = rect(BAR_X, 396, 2, 5, roleColor('st', themeIdx), 'st', NL());
                W.batBar = rect(RX, 396, 2, 5, roleColor('bt', themeIdx), 'bt', NL());
                scale(BAR_X, HW, 393, 11, 404, ['0', '2.5K', '5K', '7.5K', '10K'], NL());
                scale(RX, HW, 393, 11, 404, ['0', '25', '50', '75', '100'], NL());
                rect(BAR_X, 424, BAR_W, 2, DIM, null, NL()); rect(BAR_X, 424, BAR_W, 2, DIM, null, AL());

                // baris 3: KM | SLEEP | KCAL
                label(CX3[0], 430, 'km', 'KM'); label(CX3[1], 430, 'sl', 'SLEEP'); label(CX3[2], 430, 'kc', 'KCAL');
                W.dist = val('km', CX3[0] - 66, 458, 132, 40, 32, '0');
                W.sleep = val('sl', CX3[1] - 66, 458, 132, 40, 32, '--');
                W.cal = val('kc', CX3[2] - 66, 458, 132, 40, 32, '0');

                // tap angka jam -> ganti tema
                hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 8, y: 132, w: 416, h: 140, text: '', color: 0xFFFFFFFF, text_size: 28,
                    press_src: 'tap.png', normal_src: 'tap.png',
                    click_func: function () { const n = (themeIdx + 1) % THEME_COUNT; applyTheme(n); saveTheme(n); },
                    show_level: NL()
                });

                // pintasan ke aplikasi bawaan
                const jump = function (x, y, w, hh, type) {
                    if (type !== undefined) hmUI.createWidget(hmUI.widget.IMG_CLICK, { x: x, y: y, w: w, h: hh, type: type, show_level: NL() });
                };
                jump(C1L - 70, 44, 140, 82, hmUI.data_type.HEART);
                jump(C1R - 70, 44, 140, 82, hmUI.data_type.SPO2);
                jump(CXL - 85, 322, 170, 72, hmUI.data_type.STEP);
                jump(CXR - 85, 322, 170, 72, hmUI.data_type.BATTERY);
                jump(CX3[0] - 66, 428, 132, 76, hmUI.data_type.DISTANCE);
                jump(CX3[1] - 66, 428, 132, 76, hmUI.data_type.SLEEP);
                jump(CX3[2] - 66, 428, 132, 76, hmUI.data_type.CAL);

                update(); updateSlow();

                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        update(); updateSlow();
                        if (!tm && screenType !== hmSetting.screen_type.AOD) tm = timer.createTimer(0, 1000, function () { update(); });
                    },
                    pause_call: function () {
                        if (tm) { timer.stopTimer(tm); tm = undefined; }
                    }
                });
            },
            onInit() { logger.log('aroelzm digital minimal init'); },
            build() { this.init_view(); logger.log('aroelzm digital minimal ready'); },
            onDestroy() { if (tm) { timer.stopTimer(tm); tm = undefined; } }
        });
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}
