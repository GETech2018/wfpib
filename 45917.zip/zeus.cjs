const path=require('node:path'),{spawnSync}=require('node:child_process');
const modules=path.join(__dirname,'node_modules/@zeppos/zeus-cli/private-modules');
const result=spawnSync(process.execPath,[path.join(__dirname,'node_modules/@zeppos/zeus-cli/bin/main.js'),...process.argv.slice(2)],{cwd:__dirname,stdio:'inherit',env:{...process.env,NODE_PATH:[modules,process.env.NODE_PATH].filter(Boolean).join(path.delimiter)}});
if(result.error){console.error(result.error.message);process.exit(1);}process.exit(result.status??1);
