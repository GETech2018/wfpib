# Install and publish your watchface

Target: Amazfit Bip Max, 432 × 514, square. Select this exact model in Zepp; similarly named variants are separate devices.

## Install on your watch with your own account

Watch Studio does not collect your Zepp password or use its owner's developer account. Building source and packages requires no Zepp login. Uploading an installation preview uses your own account through the official CLI on your computer.

1. Extract the source ZIP on Windows, macOS or Linux. Open Terminal (or Windows “Open in Terminal”) in the folder containing package.json and app.json. A phone alone cannot run the CLI.
2. Install Node.js 24 LTS from https://nodejs.org/en/download; reopen your terminal after installation.
3. Run each line:

```sh
npm install
npm run login
npm run preview
```

The login command opens Zepp's login page. The preview command compiles and uploads this source snapshot, then displays an installation QR in your terminal. Keep the terminal open while scanning. Login is managed locally by Zepp's CLI; never paste passwords or tokens into Watch Studio or project files.

4. Pair and sync your Amazfit Bip Max in Zepp. Enable Developer Mode: Profile → Settings → About → tap the Zepp icon seven times.
5. Open your paired watch → Developer Mode → Scan. Some Zepp versions place this under General, then +. Scan the terminal QR, allow installation and select your face.

Preview QRs expire after seven days. Run npm run preview to renew. A project QR or a .zab file alone does not replace Zepp's uploaded-preview installation flow.

## Publish with your own developer account

1. Register your own Zepp developer account. Create a watchface record using Watchface Maker (https://watchface.zepp.com/); find it in Zepp Console → Application Services → Watchface (https://console.zepp.com/). Obtain the assigned appId. This project JSON is not a Watchface Maker import file.
2. Edit app.json in the extracted source. Set app.appId to your assigned ID. Set app.version.name and increase app.version.code for updates. The generated development appId is for testing, can replace another test face, and is not a store identity.
3. Run npm install, then npm run build. The rebuilt .zab is in dist/. Upload that new file to your matching Console watchface record; a previously downloaded .zab keeps its previous appId.
4. Supply regions, supported languages, category, description, preview images and work statement. Meet Zepp's design/language requirements and test on physical hardware. Submit for review; publication requires Zepp's approval and is not guaranteed by Watch Studio.

## Files and troubleshooting

- project.json: reopen and edit in Watch Studio; no account needed.
- Source ZIP: JavaScript, app.json, PNG assets, zeus.cjs and these instructions.
- .zab: compiled output. Do not scan it as a QR. Publishing requires your own assigned appId.
- preview.svg and assets/watch/preview.png: design images, not installers.
- “npm not found”: install Node 24 LTS and reopen Terminal.
- “package.json not found”: run commands inside the extracted source folder.
- Expired login: npm run login, then npm run preview.
- Wrong watch: choose the exact model in Watch Studio, download new source and regenerate your QR.

## Official references

- CLI login, preview and build: https://docs.zepp.com/docs/guides/tools/cli/
- Developer Mode: https://docs.zepp.com/docs/guides/tools/zepp-app/
- Watchface publishing and appId requirements: https://docs.zepp.com/docs/distribute/watchface/

## Watch behavior

Custom-series charts and maps package your saved values and paths as artwork. Heart-rate-today charts instead read the watch’s recorded minute history with heart-rate permission, refreshing when the face opens or resumes. They leave gaps for missing readings and show -- when unavailable; they never start a measurement. Line and area charts require the watch’s polyline drawing support; transparent lines also require widget opacity support. Unsupported drawing stays empty. Maps do not enable live GPS, network tiles or navigation. Custom analog hands rotate natively. Layer opacity is preserved in generated assets.

All values in the editor are samples. Exported code uses watch bindings; unavailable values show --. Firmware, weather sync and permissions determine which values exist. Distance units are configured as labels in the editor; match the watch's unit preference. Native progress uses the watch's goal/scale, so its fill can differ from the sample preview. Sleep score refreshes on build/resume. BioCharge is a firmware extension and falls back to --. AQI is China-only. Always-on preflight budgets analog hands conservatively across rotation and counts overlapping components separately, so an elaborate clock may need a smaller or simpler always-on version. AOD and battery use still need on-watch verification.

Official guidance: https://docs.zepp.com/docs/guides/tools/zepp-app/
Data reference: https://docs.zepp.com/docs/watchface/api/hmUI/widget/data_type/

Rings use the same rendered start angle, direction and shape as the editor while retaining live native progress. Fonts and text outlines are baked into the glyphs. Animations use native frame playback while awake and a static first frame in always-on; continuous playback uses more battery. Calendar shortcuts need API 3 and a device with Calendar installed. Reading the next personal calendar event is not exposed by the public watchface API. Fully opaque artwork uses the compiler’s richer colour path; transparent artwork keeps alpha and the compiler’s palette limits.

## Design checks

These checks are advisory; inspect the preview and your watch.

- Ring: a long value such as 9999.99 may be clipped. Widen the layer or reduce its font size.
