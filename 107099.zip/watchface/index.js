try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     * 天气 271F
     */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);


    let start_time = 0;

    let rootPath = null;
    let week_enArray = null;
    let week_chArray = null;

    let img_bg = null;

    let iconPath = null;

    let bigNumArr = null;
    let smallNumArr = null;
    let num1_Arr = null;
    let num2_Arr = null;

    let weather_array = null;

    let bigNumObject = new Array(8);
    let smallNumObject = new Array(8);

    let flag = true;

    let milli_value = 0;
    let second_value = 0;
    let min_value = 0;

    let constSecond = 0;
    let constMin = 0;

    let minPoint = null;
    let hourPoint = null;
    let secondPoint = null;

    let item_icon_bg2 = null;
    let item_icon_bg3 = null;
    let item_icon_bg4 = null;
    let item_Text3 = null;

    let createCount = 0;
    let weather_img = null;
    let status_show = null;
    let letTopBtn, letBottomBtn,rightBottomBtn,rightTopBtn;
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

      drawWidget(item, id) {
        config0 = {
          iconX: null,
          iconY: null,
          icon_img: null
        };
        switch (id) {
          case 101:
            config0.iconX = 25;
            config0.iconY = 28;
            break;
          default:
            return config0;
            break;
        }
        switch (item) {
          case hmUI.edit_type.WEATHER:
            config0.type = hmUI.data_type.WEATHER;
            break;
          case hmUI.edit_type.ALARM_CLOCK:
            config0.icon_img = iconPath + "bg.png";
            config0.status_img = iconPath + "clock.png";
            config0.type = hmUI.data_type.ALARM_CLOCK;
            break;
          default:
            return config0;
            break;
        }


        if (item == hmUI.edit_type.WEATHER) {
          let weather_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
            x: config0.iconX,
            y: config0.iconY,
            image_array: weather_array,
            image_length: weather_array.length,
            type: hmUI.data_type.WEATHER,
            show_level: hmUI.show_level.ONLY_NORMAL
          });


        } else {
          item_icon_bg = hmUI.createWidget(hmUI.widget.IMG, {
            x: config0.iconX,
            y: config0.iconY,
            src: config0.icon_img,
            show_level: hmUI.show_level.ONLY_NORMAL
          });

          let status = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
            x: config0.iconX,
            y: config0.iconY,
            type: hmUI.system_status.CLOCK,
            src: config0.status_img,
            show_level: hmUI.show_level.ONLY_NORMAL
          });
        }


      },
      drawWidget2(item, id) {
        config1 = {
          iconX: null,
          iconY: null,
          icon_img: null
        };
        switch (id) {
          case 104:
            config1.iconX = 307;
            config1.iconY = 386;
            break;
          default:
            return config1;
            break;
        }
        switch (item) {
          case hmUI.edit_type.WEATHER:
            config1.type = hmUI.data_type.WEATHER;
            break;
          case hmUI.edit_type.ALARM_CLOCK:
            config1.icon_img = iconPath + "bg.png";
            config1.status_img = iconPath + "clock.png";
            config1.type = hmUI.data_type.ALARM_CLOCK;
            break;
          default:
            return config1;
            break;
        }


        if (item == hmUI.edit_type.WEATHER) {
          weather_img = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
            x: config1.iconX,
            y: config1.iconY,
            image_array: weather_array,
            image_length: weather_array.length,
            type: hmUI.data_type.WEATHER,
            show_level: hmUI.show_level.ONLY_NORMAL
          });


        } else {
          item_icon_bg4 = hmUI.createWidget(hmUI.widget.IMG, {
            x: config1.iconX,
            y: config1.iconY,
            src: config1.icon_img,
            show_level: hmUI.show_level.ONLY_NORMAL
          });

          status_show = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
            x: config1.iconX,
            y: config1.iconY,
            type: hmUI.system_status.CLOCK,
            src: config1.status_img,
            show_level: hmUI.show_level.ONLY_NORMAL
          });
        }


      },
      drawWidget3(item, id) {
        config2 = {
          iconX: null,
          iconY: null,
          icon_img: null,
          numX: null,
          numY: null,
          type: null,
          invalid_image: null,
          num_array: null,
          h: 0
        };
        switch (id) {
          case 103:
            config2.iconX = 25;
            config2.iconY = 386;
            config2.numX = 67;
            config2.numY = 398;
            break;
          case 102:
            config2.iconX = 288;
            config2.iconY = 29;
            config2.numX = 329;
            config2.numY = 43;
            break;

          default:
            break;
        }
        switch (item) {
          case hmUI.edit_type.HEART:
            config2.icon_img = iconPath + "heart.png";
            config2.type = hmUI.data_type.HEART;
            config2.invalid_image = rootPath + "num2/00.png";
            config2.num_array = num1_Arr;
            // config2.h =0
            break;
          case hmUI.edit_type.CAL:
            config2.icon_img = iconPath + "cal.png";
            config2.type = hmUI.data_type.CAL;
            config2.invalid_image = rootPath + "num2/00.png";
            config2.num_array = num1_Arr;
            // config2.h =0
            break;
          case hmUI.edit_type.BATTERY:
            config2.icon_img = iconPath + "battery.png";
            config2.type = hmUI.data_type.BATTERY;
            config2.invalid_image = rootPath + "num2/00.png";
            config2.num_array = num1_Arr;
            // config2.h =0
            break;
          case hmUI.edit_type.HUMIDITY:
            config2.icon_img = iconPath + "hum.png";
            config2.type = hmUI.data_type.HUMIDITY;
            config2.invalid_image = rootPath + "num2/00.png";
            config2.num_array = num1_Arr;
            // config2.h =0
            break;
          // case hmUI.edit_type.ALARM_CLOCK:
          //   config2.icon_img = iconPath + "clock.png"
          //   config2.type = hmUI.data_type.ALARM_CLOCK
          //   config2.invalid_image = rootPath + "num2/00.png"
          //   config2.num_array = num1_Arr
          //   // config2.h =0
          //   break;

          default:
            return config2;
            break;
        }
        if (id == 103) {
          item_icon_bg3 = hmUI.createWidget(hmUI.widget.IMG, {
            x: config2.iconX,
            y: config2.iconY,
            src: config2.icon_img,
            show_level: hmUI.show_level.ONLY_NORMAL
          });
          item_Text3 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: config2.numX,
            y: config2.numY,
            type: config2.type,
            font_array: config2.num_array,
            h_space: 0,
            align_h: hmUI.align.LEFT,
            show_level: hmUI.show_level.ONLY_NORMAL,
            invalid_image: config2.invalid_image,
            // padding: true
          });
        } else {
          item_icon_bg2 = hmUI.createWidget(hmUI.widget.IMG, {
            x: config2.iconX,
            y: config2.iconY,
            src: config2.icon_img,
            show_level: hmUI.show_level.ONLY_NORMAL
          });

          item_Text2 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: config2.numX,
            y: config2.numY - 2,
            type: config2.type,
            font_array: config2.num_array,
            h_space: 0,
            align_h: hmUI.align.LEFT,
            show_level: hmUI.show_level.ONLY_NORMAL,
            invalid_image: config2.invalid_image,
            // padding: true
          });
        }

      },
      init_view() {
        rootPath = "images/";
        iconPath = rootPath + "icon/";
        week_enArray = [
          rootPath + "week_en/1.png",
          rootPath + "week_en/2.png",
          rootPath + "week_en/3.png",
          rootPath + "week_en/4.png",
          rootPath + "week_en/5.png",
          rootPath + "week_en/6.png",
          rootPath + "week_en/7.png",
        ];
        week_chArray = [
          rootPath + "week_ch/01.png",
          rootPath + "week_ch/02.png",
          rootPath + "week_ch/03.png",
          rootPath + "week_ch/04.png",
          rootPath + "week_ch/05.png",
          rootPath + "week_ch/06.png",
          rootPath + "week_ch/07.png",
        ];
        bigNumArr = [
          rootPath + "bigNum/0.png",
          rootPath + "bigNum/1.png",
          rootPath + "bigNum/2.png",
          rootPath + "bigNum/3.png",
          rootPath + "bigNum/4.png",
          rootPath + "bigNum/5.png",
          rootPath + "bigNum/6.png",
          rootPath + "bigNum/7.png",
          rootPath + "bigNum/8.png",
          rootPath + "bigNum/9.png",
        ];
        num1_Arr = [
          rootPath + "num1/0.png",
          rootPath + "num1/1.png",
          rootPath + "num1/2.png",
          rootPath + "num1/3.png",
          rootPath + "num1/4.png",
          rootPath + "num1/5.png",
          rootPath + "num1/6.png",
          rootPath + "num1/7.png",
          rootPath + "num1/8.png",
          rootPath + "num1/9.png",
        ];

        num2_Arr = [
          rootPath + "num2/00.png",
          rootPath + "num2/01.png",
          rootPath + "num2/02.png",
          rootPath + "num2/03.png",
          rootPath + "num2/04.png",
          rootPath + "num2/05.png",
          rootPath + "num2/06.png",
          rootPath + "num2/07.png",
          rootPath + "num2/08.png",
          rootPath + "num2/09.png",
        ];
        weather_array = [
          rootPath + "weather/0.png",
          rootPath + "weather/1.png",
          rootPath + "weather/2.png",
          rootPath + "weather/3.png",
          rootPath + "weather/4.png",
          rootPath + "weather/5.png",
          rootPath + "weather/6.png",
          rootPath + "weather/7.png",
          rootPath + "weather/8.png",
          rootPath + "weather/9.png",
          rootPath + "weather/10.png",
          rootPath + "weather/11.png",
          rootPath + "weather/12.png",
          rootPath + "weather/13.png",
          rootPath + "weather/14.png",
          rootPath + "weather/15.png",
          rootPath + "weather/16.png",
          rootPath + "weather/17.png",
          rootPath + "weather/18.png",
          rootPath + "weather/19.png",
          rootPath + "weather/20.png",
          rootPath + "weather/21.png",
          rootPath + "weather/22.png",
          rootPath + "weather/23.png",
          rootPath + "weather/24.png",
          rootPath + "weather/25.png",
          rootPath + "weather/26.png",
          rootPath + "weather/27.png",
          rootPath + "weather/28.png",
        ];

        smallNumArr = [
          rootPath + "smallNum/0.png",
          rootPath + "smallNum/1.png",
          rootPath + "smallNum/2.png",
          rootPath + "smallNum/3.png",
          rootPath + "smallNum/4.png",
          rootPath + "smallNum/5.png",
          rootPath + "smallNum/6.png",
          rootPath + "smallNum/7.png",
          rootPath + "smallNum/8.png",
          rootPath + "smallNum/9.png",
        ];

        let pointObj = {
          hour_centerX: 238, //指针旋转中心 对应centerX
          hour_centerY: 238, //指针旋转中心 对应centerY
          hour_posX: 32, //指针自身旋转中心 对应positioin中的x
          hour_posY: 167, //指针自身旋转中心 对应positioin中的y
          hour_path: rootPath + "point/h.png",

          //分针 秒针同上 只需要把hour替换成minute/second 即可
          minute_centerX: 238, //指针旋转中心 对应centerX
          minute_centerY: 238, //指针旋转中心 对应centerY
          minute_posX: 23, //指针自身旋转中心 对应positioin中的x
          minute_posY: 230, //指针自身旋转中心 对应positioin中的y
          minute_path: rootPath + "point/m.png",
          //指针路径
          minute_cover_path: rootPath + "point/center.png",
          //指针圆心图片
          minute_cover_y: 214,
          minute_cover_x: 214,
        };
        //息屏状态
        var screenType = hmSetting.getScreenType();
        if (screenType == hmSetting.screen_type.AOD) {
          img_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
            x: 0,
            y: 0,
            w: 390,
            h: 450,
            color: 0x000000,
          });


        } else {
          img_bg = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 390,
            h: 450,
            src: rootPath + "bg/bg.png",
            show_level: hmUI.show_level.ONAL_NORML,
          });

        }



        hourPoint = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          pos_x: 116 - 8,
          pos_y: 224 - 51,
          center_x: 116,
          center_y: 224,
          src: rootPath + "point/left.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        minPoint = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          pos_x: 273 - 7,
          pos_y: 224 - 50,
          center_x: 273,
          center_y: 224,
          src: rootPath + "point/right.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        secondPoint = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          pos_x: 195 - 19,
          pos_y: 305 - 61,
          center_x: 195,
          center_y: 305,
          src: rootPath + "point/bottom.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL
        });
        secondPoint.setProperty(hmUI.prop.VISIBLE, false);
        let maskCover = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: rootPath + "mask/wd.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });

        let week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 101.5,
          y: 106,
          week_en: week_enArray,
          week_tc: week_chArray,
          week_sc: week_chArray,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD | hmUI.show_level.ONLY_EDIT,
        });

        let monthDay = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 165,
          month_startY: 155,
          month_unit_sc: rootPath + "smallNum/d.png",
          month_unit_tc: rootPath + "smallNum/d.png",
          month_unit_en: rootPath + "smallNum/d.png",
          month_align: hmUI.align.LEFT,
          month_space: 0,
          month_zero: 1,
          // month_follow: 0,
          month_en_array: smallNumArr,
          month_sc_array: smallNumArr,
          month_tc_array: smallNumArr,

          day_align: hmUI.align.LEFT,
          day_space: 0,
          day_zero: 1,
          day_follow: 1,
          day_en_array: smallNumArr,
          day_sc_array: smallNumArr,
          day_tc_array: smallNumArr,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD | hmUI.show_level.ONLY_EDIT,
        });

        let objSecondPointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          second_centerX: 195, //指针旋转中心 对应centerX
          second_centerY: 305, //指针旋转中心 对应centerY
          second_posX: 18, //指针自身旋转中心 对应positioin中的x
          second_posY: 62, //指针自身旋转中心 对应positioin中的y
          second_path: rootPath + "point/bottom.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
        });

        let timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: 195, //指针旋转中心 对应centerX
          hour_centerY: 225, //指针旋转中心 对应centerY
          hour_posX: 30, //指针自身旋转中心 对应positioin中的x
          hour_posY: 132, //指针自身旋转中心 对应positioin中的y
          hour_path: rootPath + "point/h.png",
          minute_centerX: 194, //指针旋转中心 对应centerX
          minute_centerY: 225, //指针旋转中心 对应centerY
          minute_posX: 22, //指针自身旋转中心 对应positioin中的x
          minute_posY: 180, //指针自身旋转中心 对应positioin中的y
          minute_path: rootPath + "point/m.png",
          minute_cover_path: rootPath + "point/center.png",
          minute_cover_y: 200.5,
          minute_cover_x: 171,

          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
        });
        // let btn = hmUI.createWidget(hmUI.widget.IMG, {
        //   x: 7,
        //   y: 37,
        //   src: rootPath + "bg/out.png",
        //   show_level: hmUI.show_level.ONLY_NORMAL,
        // })
       
        let btn2 = hmUI.createWidget(hmUI.widget.IMG, {
          x: 47.5,
          y: 77.5,
          src: rootPath + "bg/inner.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let left_btn = hmUI.createWidget(hmUI.widget.IMG, {
          x: 27.14,
          y: 373.14,
          src: rootPath + "btn/back.png",
          show_level: hmUI.show_level.ONAL_NORML,
        });

        let right_btn = hmUI.createWidget(hmUI.widget.IMG, {
          x: 308,
          y: 368,
          src: rootPath + "btn/lv.png",
          show_level: hmUI.show_level.ONAL_NORML,
        });
        let btn = hmUI.createWidget(hmUI.widget.IMG, {
          x: 141,
          y: 253,
          w: 108,
          h: 108,
          show_level: hmUI.show_level.ONAL_NORML,
        });
        left_btn.setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示
        right_btn.setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示


        btn.addEventListener(hmUI.event.CLICK_UP, (function (info) {
          // let letTopBtn, letBottomBtn,rightBottomBtn,rightTopBtn;
          btn.setProperty(hmUI.prop.VISIBLE, false);
          letTopBtn.setProperty(hmUI.prop.VISIBLE, false);
          letBottomBtn.setProperty(hmUI.prop.VISIBLE, false);
          rightBottomBtn.setProperty(hmUI.prop.VISIBLE, false);
          rightTopBtn.setProperty(hmUI.prop.VISIBLE, false);

          left_btn.setProperty(hmUI.prop.VISIBLE, true);
          right_btn.setProperty(hmUI.prop.VISIBLE, true);
          secondPoint.setProperty(hmUI.prop.VISIBLE, true);
          week.setProperty(hmUI.prop.VISIBLE, false);
          monthDay.setProperty(hmUI.prop.VISIBLE, false);
          item_icon_bg3.setProperty(hmUI.prop.VISIBLE, false);
          item_Text3.setProperty(hmUI.prop.VISIBLE, false);

          if (item_icon_bg4 == null) {
            weather_img.setProperty(hmUI.prop.VISIBLE, false);
          } else {
            item_icon_bg4.setProperty(hmUI.prop.VISIBLE, false);
          }
          if (status_show != null) {
            status_show.setProperty(hmUI.prop.VISIBLE, false);
          }
          timePointer.setProperty(hmUI.prop.VISIBLE, false);
          objSecondPointer.setProperty(hmUI.prop.VISIBLE, false);
          // centerSecondPointer.setProperty(hmUI.prop.VISIBLE, true);
          for (let n = 0; n < 8; n++) {
            bigNumObject[n].setProperty(hmUI.prop.VISIBLE, true); //false隐藏 true显示
            smallNumObject[n].setProperty(hmUI.prop.VISIBLE, true); //false隐藏 true显示
            if (n == 0 || n == 1 || n == 3 || n == 4 || n == 6 || n == 7) {
              bigNumObject[n].setProperty(hmUI.prop.SRC, rootPath + "bigNum/0.png");
              smallNumObject[n].setProperty(hmUI.prop.SRC, rootPath + "smallNum/0.png");
            }
          }
          milli_value = 0;
          second_value = 0;
          min_value = 0;

          constSecond = 0;
          constMin = 0;
          // backBtn.setProperty(hmUI.prop.VISIBLE, true); //false隐藏 true显示
          // green_red_btn.setProperty(hmUI.prop.VISIBLE, true); //false隐藏 true显示
          flag = true;
        }));

        for (let i = 0; i < bigNumObject.length; i++) {

          if (i == 2 || i == 5) {
            bigNumObject[i] = hmUI.createWidget(hmUI.widget.IMG, {
              x: 115 + i * 21,
              y: 113,
              src: rootPath + "bigNum/sp.png",
              show_level: hmUI.show_level.ONLY_NORMAL
            });
          } else {
            bigNumObject[i] = hmUI.createWidget(hmUI.widget.IMG, {
              x: 109 + i * 21,
              y: 113,
              src: rootPath + "bigNum/0.png",
              show_level: hmUI.show_level.ONLY_NORMAL
            });
          }
          bigNumObject[i].setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示
        }
        for (let j = 0; j < smallNumObject.length; j++) {
          if (j == 2 || j == 5) {
            smallNumObject[j] = hmUI.createWidget(hmUI.widget.IMG, {
              x: 145 + j * 13,
              y: 150,
              src: rootPath + "smallNum/n.png",
              show_level: hmUI.show_level.ONLY_NORMAL
            });
          } else {
            smallNumObject[j] = hmUI.createWidget(hmUI.widget.IMG, {
              x: 140 + j * 13,
              y: 150,
              src: rootPath + "smallNum/0.png",
              show_level: hmUI.show_level.ONLY_NORMAL
            });
          }
          smallNumObject[j].setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示
        }



        left_btn.addEventListener(hmUI.event.CLICK_UP, (function (info) {
          timer.stopTimer(hsTimer);
          timer.stopTimer(sTimer);
          btn.setProperty(hmUI.prop.VISIBLE, true);
          hmSetting.setBrightScreenCancel(); //取消屏幕常亮
          right_btn.setProperty(hmUI.prop.SRC, rootPath + "btn/lv.png"); //false隐藏 true显示
          for (let n = 0; n < 8; n++) {
            bigNumObject[n].setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示
            smallNumObject[n].setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示
          }
          left_btn.setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示
          right_btn.setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示
          item_icon_bg3.setProperty(hmUI.prop.VISIBLE, true);
          if (item_icon_bg4 == null) {
            weather_img.setProperty(hmUI.prop.VISIBLE, true);
          } else {
            item_icon_bg4.setProperty(hmUI.prop.VISIBLE, true);
          }
          // 防止报错
          if (status_show != null) {
            status_show.setProperty(hmUI.prop.VISIBLE, true);
          }
          // item_icon_bg4.setProperty(hmUI.prop.VISIBLE, true);
          week.setProperty(hmUI.prop.VISIBLE, true);
          monthDay.setProperty(hmUI.prop.VISIBLE, true);
          item_Text3.setProperty(hmUI.prop.VISIBLE, true);
          objSecondPointer.setProperty(hmUI.prop.VISIBLE, true);
          timePointer.setProperty(hmUI.prop.VISIBLE, true);
          // secondPointer.setProperty(hmUI.prop.VISIBLE, true);
          // centerSecondPointer.setProperty(hmUI.prop.VISIBLE, false);
          minPoint.setProperty(hmUI.prop.ANGLE, 0);
          hourPoint.setProperty(hmUI.prop.ANGLE, 0);
          secondPoint.setProperty(hmUI.prop.ANGLE, 0);
          secondPoint.setProperty(hmUI.prop.VISIBLE, false);
          letTopBtn.setProperty(hmUI.prop.VISIBLE, true);
          letBottomBtn.setProperty(hmUI.prop.VISIBLE, true);
          rightBottomBtn.setProperty(hmUI.prop.VISIBLE, true);
          rightTopBtn.setProperty(hmUI.prop.VISIBLE, true);
        }));

        right_btn.addEventListener(hmUI.event.CLICK_UP, (function (info) {
          flag = !flag;
          minPoint.setProperty(hmUI.prop.ANGLE, 0);
          hourPoint.setProperty(hmUI.prop.ANGLE, 0);
          secondPoint.setProperty(hmUI.prop.ANGLE, 0);
          if (flag) {
            hmSetting.setBrightScreenCancel(); //取消屏幕常亮
            right_btn.setProperty(hmUI.prop.SRC, rootPath + "btn/lv.png"); //false隐藏 true显示
            timer.stopTimer(hsTimer);
            timer.stopTimer(sTimer);
            bigNumObject[0].setProperty(hmUI.prop.SRC, rootPath + "bigNum/0.png");
            bigNumObject[1].setProperty(hmUI.prop.SRC, rootPath + "bigNum/0.png");
            bigNumObject[3].setProperty(hmUI.prop.SRC, rootPath + "bigNum/0.png");
            bigNumObject[4].setProperty(hmUI.prop.SRC, rootPath + "bigNum/0.png");
            bigNumObject[6].setProperty(hmUI.prop.SRC, rootPath + "bigNum/0.png");
            bigNumObject[7].setProperty(hmUI.prop.SRC, rootPath + "bigNum/0.png");

            smallNumObject[0].setProperty(hmUI.prop.SRC, rootPath + "smallNum/" + hmFS.SysProGetInt("t0") + ".png");
            smallNumObject[1].setProperty(hmUI.prop.SRC, rootPath + "smallNum/" + hmFS.SysProGetInt("t1") + ".png");
            smallNumObject[3].setProperty(hmUI.prop.SRC, rootPath + "smallNum/" + hmFS.SysProGetInt("t3") + ".png");
            smallNumObject[4].setProperty(hmUI.prop.SRC, rootPath + "smallNum/" + hmFS.SysProGetInt("t4") + ".png");
            smallNumObject[6].setProperty(hmUI.prop.SRC, rootPath + "smallNum/" + hmFS.SysProGetInt("t6") + ".png");
            smallNumObject[7].setProperty(hmUI.prop.SRC, rootPath + "smallNum/" + hmFS.SysProGetInt("t7") + ".png");
          } else {
            hmSetting.setBrightScreen(10*60)
            right_btn.setProperty(hmUI.prop.SRC, rootPath + "btn/red.png"); //false隐藏 true显示
            hmFS.SysProSetInt("t0", 0);
            hmFS.SysProSetInt("t1", 0);
            hmFS.SysProSetInt("t3", 0);
            hmFS.SysProSetInt("t4", 0);
            hmFS.SysProSetInt("t6", 0);
            hmFS.SysProSetInt("t7", 0);
            milli_value = 0;
            second_value = 0;
            min_value = 0;

            constSecond = 0;
            constMin = 0;
            timerSample();

          }
        }));






        let hsTimer = null;
        let sTimer = null;

        function setHaomiao(t) { //设置毫秒
          if (milli_value >= 99) {
            milli_value = -1;
          }
          milli_value++;
          bigNumObject[6].setProperty(hmUI.prop.SRC, rootPath + "bigNum/" + parseInt(milli_value / 10) + ".png");
          bigNumObject[7].setProperty(hmUI.prop.SRC, rootPath + "bigNum/" + parseInt(milli_value % 10) + ".png");

          hmFS.SysProSetInt("t6", parseInt(milli_value / 10));
          hmFS.SysProSetInt("t7", parseInt(milli_value % 10));

        }

        function setmiao(t) {  //设置秒
          if (second_value >= 59) {
            second_value = -1;
          }
          second_value++;
          constSecond++;
          setAngle(constSecond);
          if (second_value == 0) {
            min_value++;
            setfen();
          }
          bigNumObject[3].setProperty(hmUI.prop.SRC, rootPath + "bigNum/" + parseInt(second_value / 10) + ".png");
          bigNumObject[4].setProperty(hmUI.prop.SRC, rootPath + "bigNum/" + parseInt(second_value % 10) + ".png");

          hmFS.SysProSetInt("t3", parseInt(second_value / 10));
          hmFS.SysProSetInt("t4", parseInt(second_value % 10));


        }

        function setfen(t) {  //设置分钟
          if (min_value > 59) {
            min_value = 59;
          }

          bigNumObject[0].setProperty(hmUI.prop.SRC, rootPath + "bigNum/" + parseInt(min_value / 10) + ".png");
          bigNumObject[1].setProperty(hmUI.prop.SRC, rootPath + "bigNum/" + parseInt(min_value % 10) + ".png");

          hmFS.SysProSetInt("t0", parseInt(min_value / 10));
          hmFS.SysProSetInt("t1", parseInt(min_value % 10));
        }

        function timerSample() {

          hsTimer = timer.createTimer(
            10, 10, setHaomiao, {});
          sTimer = timer.createTimer(
            1000, 1000, setmiao, {});
        }

        function setAngle(seconds) {
          minPoint.setProperty(hmUI.prop.ANGLE, parseInt(seconds * 0.008));
          hourPoint.setProperty(hmUI.prop.ANGLE, parseInt(seconds * 0.2));
          secondPoint.setProperty(hmUI.prop.ANGLE, parseInt(seconds * 6));
        }


        let widgetOptionalArray = [{
          type: hmUI.edit_type.CAL,
          preview: iconPath + "cal.png"
        },
        {
          type: hmUI.edit_type.BATTERY,
          preview: iconPath + "battery.png"
        },
        {
          type: hmUI.edit_type.HEART,
          preview: iconPath + "heart.png"
        },
        {
          type: hmUI.edit_type.HUMIDITY,
          preview: iconPath + "hum.png"
        },
          // { type: hmUI.edit_type.ALARM_CLOCK, preview: iconPath + "clock.png" },
        ];

        let widgetOptionalArray2 = [{
          type: hmUI.edit_type.WEATHER,
          preview: iconPath + "weather.png"
        },
        {
          type: hmUI.edit_type.ALARM_CLOCK,
          preview: iconPath + "clock.png"
        },
          // { type: hmUI.edit_type.AQI, preview: iconPath + "aqi.png" },
        ];


        let edit_list_config = {
          title_font_size :34 ,  // 标题字号的大小
          title_align_h: hmUI.align.CENTER_H ,  //标题位置样式(左对齐，居中，右对齐)
          list_item_vspace: 8 , // 列表子元素的行间距
          list_tips_text_font_size: 32, //子元素的字号大小
          list_tips_text_align_h : hmUI.align.LEFT, //子元素位置样式(左对齐，居中，右对齐)
      };
        let itemX1 = 20;
        let itemY1 = 23;

        let Group1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 101,
          x: itemX1,
          y: itemY1,
          w: 54,
          h: 54,
          select_image: rootPath + "mask/select.png",
          un_select_image: rootPath + "mask/unselect.png",
          default_type: hmUI.edit_type.WEATHER,
          optional_types: widgetOptionalArray2,
          count: widgetOptionalArray2.length,
          tips_BG: rootPath + "mask/tag.png",
          tips_x: -6,
          tips_y: 59,
          tips_width: 104,
          tips_margin: 10,
          select_list: edit_list_config,
        });
        var item1 = Group1.getProperty(hmUI.prop.CURRENT_TYPE);
        this.drawWidget(item1, 101);


        let itemX2 = 283;
        let itemY2 = 22;

        let Group2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 102,
          x: itemX2,
          y: itemY2,
          w: 54,
          h: 54,
          select_image: rootPath + "mask/select.png",
          un_select_image: rootPath + "mask/unselect.png",
          default_type: hmUI.edit_type.BATTERY,
          optional_types: widgetOptionalArray,
          count: widgetOptionalArray.length,
          tips_BG: rootPath + "mask/tag.png",
          tips_x: -58,
          tips_y: 59,
          tips_width: 104,
          tips_margin: 10,
          select_list: edit_list_config,
        });
        var item2 = Group2.getProperty(hmUI.prop.CURRENT_TYPE);
        this.drawWidget3(item2, 102);


        let itemX3 = 25;
        let itemY3 = 370;

        let Group3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 103,
          x: itemX3,
          y: itemY3,
          w: 54,
          h: 54,
          select_image: rootPath + "mask/select.png",
          un_select_image: rootPath + "mask/unselect.png",
          default_type: hmUI.edit_type.HEART,
          optional_types: widgetOptionalArray,
          count: widgetOptionalArray.length,
          tips_BG: rootPath + "mask/tag.png",
          tips_x: 0,
          tips_y: -51,
          tips_width: 104,
          tips_margin: 10,
          select_list: edit_list_config,
        });
        var item3 = Group3.getProperty(hmUI.prop.CURRENT_TYPE);
        this.drawWidget3(item3, 103);

        let itemX4 = 310;
        let itemY4 = 370;

        let Group4 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          edit_id: 104,
          x: itemX4,
          y: itemY4,
          w: 54,
          h: 54,
          select_image: rootPath + "mask/select.png",
          un_select_image: rootPath + "mask/unselect.png",
          default_type: hmUI.edit_type.ALARM_CLOCK,
          optional_types: widgetOptionalArray2,
          count: widgetOptionalArray2.length,
          tips_BG: rootPath + "mask/tag.png",
          tips_x: -40,
          tips_y: -44,
          tips_width: 104,
          tips_margin: 10,
          select_list: edit_list_config,
        });
        var item4 = Group4.getProperty(hmUI.prop.CURRENT_TYPE);
        this.drawWidget2(item4, 104);




        let AOD_timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_centerX: 195, //指针旋转中心 对应centerX
          hour_centerY: 225, //指针旋转中心 对应centerY
          hour_posX: 30, //指针自身旋转中心 对应positioin中的x
          hour_posY: 132, //指针自身旋转中心 对应positioin中的y
          hour_path: rootPath + "point/h.png",
          minute_centerX: 194, //指针旋转中心 对应centerX
          minute_centerY: 225, //指针旋转中心 对应centerY
          minute_posX: 22, //指针自身旋转中心 对应positioin中的x
          minute_posY: 180, //指针自身旋转中心 对应positioin中的y
          minute_path: rootPath + "point/m.png",
          minute_cover_path: rootPath + "point/center.png",
          minute_cover_y: 200.5,
          minute_cover_x: 171,
          show_level: hmUI.show_level.ONAL_AOD
        });

      

        let mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: rootPath + "mask/mask70.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });


      


        function fn(type) {
          const groupJump = {};
          switch (type) {
            case hmUI.edit_type.HEART:
              groupJump.type = hmUI.data_type.HEART;
              break;
            case hmUI.edit_type.HUMIDITY:
              groupJump.type = hmUI.data_type.HUMIDITY;
              break;
            case hmUI.edit_type.BATTERY:
              groupJump.type = hmUI.data_type.BATTERY;
              break;
            case hmUI.edit_type.CAL:
              groupJump.type = hmUI.data_type.CAL;
              break;
          }
          return groupJump.type;
        }
        function jumpApp(x ,y ,w ,h ,type){
        return  hmUI.createWidget(hmUI.widget.IMG_CLICK,{
            x, y, w, h, type ,//type必写 跳转的action
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
        }
        letTopBtn = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 0,
          y: 0,
          w: 91,
          h: 74,
          type: config0.type,//type必写 跳转的action
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        rightBottomBtn = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 295,
          y: 395,
          w: 96,
          h: 56,
          type: config1.type,//type必写 跳转的action
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        letBottomBtn = jumpApp(0,395,115,56,fn(item3))
        rightTopBtn = jumpApp(295,0,96,74,fn(item2))

      },

      onInit() {
        console.log('index page.js on init invoke');
        this.init_view();

      },

      onReady() {
        console.log('index page.js on ready invoke');
      },

      onShow() {
        console.log('index page.js on show invoke');
      },

      onHide() {
        console.log('index page.js on hide invoke');
      },

      onDestory() {
        console.log('index page.js on destory invoke');
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}