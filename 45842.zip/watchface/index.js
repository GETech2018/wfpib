﻿    /*
    ** Watch_Face_Editor tool v 18.2
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let time24 = hmSensor.createSensor(hmSensor.id.TIME);
let normal_24Hcheck =''
let idle_24Hcheck = ''
let checknum = ''

 function check24h(){
       if (time24.is24Hour){
        checknum = 1
        is24H()
       }

       if (!time24.is24Hour){
       checknum = 2
       isAMPM()
       }
hmFS.SysProSetInt('ampm24h', checknum);
 }

function is24H(){
        normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, true);
        idle_24Hcheck.setProperty(hmUI.prop.VISIBLE, true);

}

function isAMPM(){
        normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, false);
        idle_24Hcheck.setProperty(hmUI.prop.VISIBLE, false);

}
 
     // Start color LCD
         let colornumber = 1
        let totalcolors = 7
        let namecolor = ''

        function click_ColorLCD() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "GRAY"}
if ( colornumber == 2) { namecolor = "BLUE"}
if ( colornumber == 3) { namecolor = "YELLOW"}
if ( colornumber == 4) { namecolor = "LEMON"}
if ( colornumber == 5) { namecolor = "GREEN"}
if ( colornumber == 6) { namecolor = "PURPLE"}
if ( colornumber == 7) { namecolor = "MAGENTA"}
hmUI.showToast({text: namecolor });

                    normal_heart_rate_icon_img.setProperty(hmUI.prop.SRC, "LCD_" + parseInt(colornumber) + ".png");
                           
        }
////////////////

        // Start color BAR
         let colornumberB = 1
        let totalcolorsB = 7
        let namecolorB = ''

        function click_ColorBAR() {
            if(colornumberB>=totalcolorsB) {
            colornumberB=1;
                }
            else {
                colornumberB=colornumberB+1;
            }

if ( colornumberB == 1) { namecolorB = "STYLE 1"}
if ( colornumberB == 2) { namecolorB = "STYLE 2"}
if ( colornumberB == 3) { namecolorB = "STYLE 3"}
if ( colornumberB == 4) { namecolorB = "STYLE 4"}
if ( colornumberB == 5) { namecolorB = "STYLE 5"}
if ( colornumberB == 6) { namecolorB = "STYLE 6"}
if ( colornumberB == 7) { namecolorB = "STYLE 7"}
hmUI.showToast({text: namecolorB });

                    normal_image_img.setProperty(hmUI.prop.SRC, "Bar_" + parseInt(colornumberB) + ".png");
                           
        }
////////////////
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_image_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_linear_scale_pointer_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_linear_scale_pointer_img = ''
        let normal_step_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_humidity_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_image_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_low_separator_img = ''
        let idle_temperature_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_linear_scale_pointer_img = ''
        let idle_battery_text_text_img = ''
        let idle_step_linear_scale = ''
        let idle_step_linear_scale_pointer_img = ''
        let idle_step_current_text_img = ''
        let idle_step_icon_img = ''
        let idle_humidity_text_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let normal_moon_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 52,
              y: 18,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 4,
              y: 171,
              src: 'Bar_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 132,
              src: 'LCD_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 35,
              y: 387,
              font_array: ["Act_W_S_0.png","Act_W_S_1.png","Act_W_S_2.png","Act_W_S_3.png","Act_W_S_4.png","Act_W_S_5.png","Act_W_S_6.png","Act_W_S_7.png","Act_W_S_8.png","Act_W_S_9.png"],
              padding: false,
              h_space: -9,
              invalid_image: 'Temp_Symbol1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 7,
              y: 352,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 233,
              y: 146,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 162,
              day_startY: 146,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: -7,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 234,
              y: -13,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 102,
              font_array: ["BATT_Font_0.png","BATT_Font_1.png","BATT_Font_2.png","BATT_Font_3.png","BATT_Font_4.png","BATT_Font_5.png","BATT_Font_6.png","BATT_Font_7.png","BATT_Font_8.png","BATT_Font_9.png"],
              padding: false,
              h_space: -6,
              unit_sc: 'Temp_unit_small.png',
              unit_tc: 'Temp_unit_small.png',
              unit_en: 'Temp_unit_small.png',
              imperial_unit_sc: 'Temp_unit_small.png',
              imperial_unit_tc: 'Temp_unit_small.png',
              imperial_unit_en: 'Temp_unit_small.png',
              negative_image: 'Temp_Symbol1.png',
              invalid_image: 'Temp_Symbol1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 96,
                y: 102,
                font_array: ["BATT_Font_0.png","BATT_Font_1.png","BATT_Font_2.png","BATT_Font_3.png","BATT_Font_4.png","BATT_Font_5.png","BATT_Font_6.png","BATT_Font_7.png","BATT_Font_8.png","BATT_Font_9.png"],
                padding: false,
                h_space: -6,
                unit_sc: 'Temp_unit_small.png',
                unit_tc: 'Temp_unit_small.png',
                unit_en: 'Temp_unit_small.png',
                imperial_unit_sc: 'Temp_unit_small.png',
                imperial_unit_tc: 'Temp_unit_small.png',
                imperial_unit_en: 'Temp_unit_small.png',
                negative_image: 'Temp_Symbol1.png',
                invalid_image: 'Temp_Symbol1.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 20,
              y: 102,
              font_array: ["BATT_Font_0.png","BATT_Font_1.png","BATT_Font_2.png","BATT_Font_3.png","BATT_Font_4.png","BATT_Font_5.png","BATT_Font_6.png","BATT_Font_7.png","BATT_Font_8.png","BATT_Font_9.png"],
              padding: false,
              h_space: -6,
              unit_sc: 'Temp_unit_small.png',
              unit_tc: 'Temp_unit_small.png',
              unit_en: 'Temp_unit_small.png',
              imperial_unit_sc: 'Temp_unit_small.png',
              imperial_unit_tc: 'Temp_unit_small.png',
              imperial_unit_en: 'Temp_unit_small.png',
              negative_image: 'Temp_Symbol1.png',
              invalid_image: 'Temp_Symbol1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 84,
              y: 97,
              src: 'Temp_Stepper.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 20,
                y: 102,
                font_array: ["BATT_Font_0.png","BATT_Font_1.png","BATT_Font_2.png","BATT_Font_3.png","BATT_Font_4.png","BATT_Font_5.png","BATT_Font_6.png","BATT_Font_7.png","BATT_Font_8.png","BATT_Font_9.png"],
                padding: false,
                h_space: -6,
                unit_sc: 'Temp_unit_small.png',
                unit_tc: 'Temp_unit_small.png',
                unit_en: 'Temp_unit_small.png',
                imperial_unit_sc: 'Temp_unit_small.png',
                imperial_unit_tc: 'Temp_unit_small.png',
                imperial_unit_en: 'Temp_unit_small.png',
                negative_image: 'Temp_Symbol1.png',
                invalid_image: 'Temp_Symbol1.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 29,
              font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              padding: false,
              h_space: -6,
              unit_sc: 'Temp_unit1.png',
              unit_tc: 'Temp_unit1.png',
              unit_en: 'Temp_unit1.png',
              imperial_unit_sc: 'Temp_unit1.png',
              imperial_unit_tc: 'Temp_unit1.png',
              imperial_unit_en: 'Temp_unit1.png',
              negative_image: 'Temp_Symbol1.png',
              invalid_image: 'Temp_Symbol1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 115,
                y: 29,
                font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
                padding: false,
                h_space: -6,
                unit_sc: 'Temp_unit1.png',
                unit_tc: 'Temp_unit1.png',
                unit_en: 'Temp_unit1.png',
                imperial_unit_sc: 'Temp_unit1.png',
                imperial_unit_tc: 'Temp_unit1.png',
                imperial_unit_en: 'Temp_unit1.png',
                negative_image: 'Temp_Symbol1.png',
                invalid_image: 'Temp_Symbol1.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 370,
              font_array: ["Act_W_S_0.png","Act_W_S_1.png","Act_W_S_2.png","Act_W_S_3.png","Act_W_S_4.png","Act_W_S_5.png","Act_W_S_6.png","Act_W_S_7.png","Act_W_S_8.png","Act_W_S_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 430,
              font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              padding: true,
              h_space: -9,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_battery_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 38,
              // start_y: 175,
              // color: 0xFFFF8C00,
              // pointer: 'Pointer1.png',
              // lenght: 69,
              // line_width: 0,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 142,
              font_array: ["BATT_Font_0.png","BATT_Font_1.png","BATT_Font_2.png","BATT_Font_3.png","BATT_Font_4.png","BATT_Font_5.png","BATT_Font_6.png","BATT_Font_7.png","BATT_Font_8.png","BATT_Font_9.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_step_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 156,
              // start_y: 352,
              // color: 0xFFFF8C00,
              // pointer: 'Pointer1.png',
              // lenght: 245,
              // line_width: 0,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 299,
              font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              padding: true,
              h_space: -9,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 70,
              src: 'Top_Frame1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 342,
              y: 88,
              font_array: ["BATT_Font_0.png","BATT_Font_1.png","BATT_Font_2.png","BATT_Font_3.png","BATT_Font_4.png","BATT_Font_5.png","BATT_Font_6.png","BATT_Font_7.png","BATT_Font_8.png","BATT_Font_9.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js

            normal_24Hcheck = hmUI.createWidget(hmUI.widget.IMG, {
              x: 3,
              y: 214,
              src: 'Clock_24H.png',
             show_level: hmUI.show_level.ONLY_NORMAL,
            });


// check24h()
            // end user_script.js

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 3,
              am_y: 214,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 3,
              pm_y: 214,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 69,
              second_startY: 209,
              second_array: ["Time_S_B_0.png","Time_S_B_1.png","Time_S_B_2.png","Time_S_B_3.png","Time_S_B_4.png","Time_S_B_5.png","Time_S_B_6.png","Time_S_B_7.png","Time_S_B_8.png","Time_S_B_9.png"],
              second_zero: 1,
              second_space: -11,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 284,
              minute_startY: 199,
              minute_array: ["Time_B_0.png","Time_B_1.png","Time_B_2.png","Time_B_3.png","Time_B_4.png","Time_B_5.png","Time_B_6.png","Time_B_7.png","Time_B_8.png","Time_B_9.png"],
              minute_zero: 1,
              minute_space: -17,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 140,
              hour_startY: 199,
              hour_array: ["Time_B_0.png","Time_B_1.png","Time_B_2.png","Time_B_3.png","Time_B_4.png","Time_B_5.png","Time_B_6.png","Time_B_7.png","Time_B_8.png","Time_B_9.png"],
              hour_zero: 1,
              hour_space: -17,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 275,
              y: 197,
              src: 'Time_Dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 353,
              y: 425,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 137,
              y: 184,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 52,
              y: 18,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 4,
              y: 171,
              src: 'Bar_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 132,
              src: 'LCD_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 35,
              y: 387,
              font_array: ["Act_W_S_0.png","Act_W_S_1.png","Act_W_S_2.png","Act_W_S_3.png","Act_W_S_4.png","Act_W_S_5.png","Act_W_S_6.png","Act_W_S_7.png","Act_W_S_8.png","Act_W_S_9.png"],
              padding: false,
              h_space: -9,
              invalid_image: 'Temp_Symbol1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 7,
              y: 352,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 233,
              y: 146,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 162,
              day_startY: 146,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: -7,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 234,
              y: -13,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 102,
              font_array: ["BATT_Font_0.png","BATT_Font_1.png","BATT_Font_2.png","BATT_Font_3.png","BATT_Font_4.png","BATT_Font_5.png","BATT_Font_6.png","BATT_Font_7.png","BATT_Font_8.png","BATT_Font_9.png"],
              padding: false,
              h_space: -6,
              unit_sc: 'Temp_unit_small.png',
              unit_tc: 'Temp_unit_small.png',
              unit_en: 'Temp_unit_small.png',
              imperial_unit_sc: 'Temp_unit_small.png',
              imperial_unit_tc: 'Temp_unit_small.png',
              imperial_unit_en: 'Temp_unit_small.png',
              negative_image: 'Temp_Symbol1.png',
              invalid_image: 'Temp_Symbol1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 96,
                y: 102,
                font_array: ["BATT_Font_0.png","BATT_Font_1.png","BATT_Font_2.png","BATT_Font_3.png","BATT_Font_4.png","BATT_Font_5.png","BATT_Font_6.png","BATT_Font_7.png","BATT_Font_8.png","BATT_Font_9.png"],
                padding: false,
                h_space: -6,
                unit_sc: 'Temp_unit_small.png',
                unit_tc: 'Temp_unit_small.png',
                unit_en: 'Temp_unit_small.png',
                imperial_unit_sc: 'Temp_unit_small.png',
                imperial_unit_tc: 'Temp_unit_small.png',
                imperial_unit_en: 'Temp_unit_small.png',
                negative_image: 'Temp_Symbol1.png',
                invalid_image: 'Temp_Symbol1.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 20,
              y: 102,
              font_array: ["BATT_Font_0.png","BATT_Font_1.png","BATT_Font_2.png","BATT_Font_3.png","BATT_Font_4.png","BATT_Font_5.png","BATT_Font_6.png","BATT_Font_7.png","BATT_Font_8.png","BATT_Font_9.png"],
              padding: false,
              h_space: -6,
              unit_sc: 'Temp_unit_small.png',
              unit_tc: 'Temp_unit_small.png',
              unit_en: 'Temp_unit_small.png',
              imperial_unit_sc: 'Temp_unit_small.png',
              imperial_unit_tc: 'Temp_unit_small.png',
              imperial_unit_en: 'Temp_unit_small.png',
              negative_image: 'Temp_Symbol1.png',
              invalid_image: 'Temp_Symbol1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 84,
              y: 97,
              src: 'Temp_Stepper.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 20,
                y: 102,
                font_array: ["BATT_Font_0.png","BATT_Font_1.png","BATT_Font_2.png","BATT_Font_3.png","BATT_Font_4.png","BATT_Font_5.png","BATT_Font_6.png","BATT_Font_7.png","BATT_Font_8.png","BATT_Font_9.png"],
                padding: false,
                h_space: -6,
                unit_sc: 'Temp_unit_small.png',
                unit_tc: 'Temp_unit_small.png',
                unit_en: 'Temp_unit_small.png',
                imperial_unit_sc: 'Temp_unit_small.png',
                imperial_unit_tc: 'Temp_unit_small.png',
                imperial_unit_en: 'Temp_unit_small.png',
                negative_image: 'Temp_Symbol1.png',
                invalid_image: 'Temp_Symbol1.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 29,
              font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              padding: false,
              h_space: -6,
              unit_sc: 'Temp_unit1.png',
              unit_tc: 'Temp_unit1.png',
              unit_en: 'Temp_unit1.png',
              imperial_unit_sc: 'Temp_unit1.png',
              imperial_unit_tc: 'Temp_unit1.png',
              imperial_unit_en: 'Temp_unit1.png',
              negative_image: 'Temp_Symbol1.png',
              invalid_image: 'Temp_Symbol1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 115,
                y: 29,
                font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
                padding: false,
                h_space: -6,
                unit_sc: 'Temp_unit1.png',
                unit_tc: 'Temp_unit1.png',
                unit_en: 'Temp_unit1.png',
                imperial_unit_sc: 'Temp_unit1.png',
                imperial_unit_tc: 'Temp_unit1.png',
                imperial_unit_en: 'Temp_unit1.png',
                negative_image: 'Temp_Symbol1.png',
                invalid_image: 'Temp_Symbol1.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 370,
              font_array: ["Act_W_S_0.png","Act_W_S_1.png","Act_W_S_2.png","Act_W_S_3.png","Act_W_S_4.png","Act_W_S_5.png","Act_W_S_6.png","Act_W_S_7.png","Act_W_S_8.png","Act_W_S_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 430,
              font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              padding: true,
              h_space: -9,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            idle_battery_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 38,
              // start_y: 175,
              // color: 0xFFFF8C00,
              // pointer: 'Pointer1.png',
              // lenght: 69,
              // line_width: 0,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 142,
              font_array: ["BATT_Font_0.png","BATT_Font_1.png","BATT_Font_2.png","BATT_Font_3.png","BATT_Font_4.png","BATT_Font_5.png","BATT_Font_6.png","BATT_Font_7.png","BATT_Font_8.png","BATT_Font_9.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            idle_step_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // idle_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 156,
              // start_y: 352,
              // color: 0xFFFF8C00,
              // pointer: 'Pointer1.png',
              // lenght: 245,
              // line_width: 0,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 299,
              font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              padding: true,
              h_space: -9,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 70,
              src: 'Top_Frame1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 342,
              y: 88,
              font_array: ["BATT_Font_0.png","BATT_Font_1.png","BATT_Font_2.png","BATT_Font_3.png","BATT_Font_4.png","BATT_Font_5.png","BATT_Font_6.png","BATT_Font_7.png","BATT_Font_8.png","BATT_Font_9.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('AOD_user_script.js');
            // start AOD_user_script.js



            idle_24Hcheck = hmUI.createWidget(hmUI.widget.IMG, {
              x: 3,
              y: 214,
              src: 'Clock_24H.png',
            show_level: hmUI.show_level.ONLY_AOD,
            });


check24h()
            // end AOD_user_script.js

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 3,
              am_y: 214,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 3,
              pm_y: 214,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 284,
              minute_startY: 199,
              minute_array: ["Time_B_0.png","Time_B_1.png","Time_B_2.png","Time_B_3.png","Time_B_4.png","Time_B_5.png","Time_B_6.png","Time_B_7.png","Time_B_8.png","Time_B_9.png"],
              minute_zero: 1,
              minute_space: -17,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 84,
              y: 214,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 140,
              hour_startY: 199,
              hour_array: ["Time_B_0.png","Time_B_1.png","Time_B_2.png","Time_B_3.png","Time_B_4.png","Time_B_5.png","Time_B_6.png","Time_B_7.png","Time_B_8.png","Time_B_9.png"],
              hour_zero: 1,
              hour_space: -17,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 275,
              y: 197,
              src: 'Time_Dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 353,
              y: 425,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 137,
              y: 184,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

const customHeartRate = hmSensor.createSensor(hmSensor.id.HEART);

        // =========================
        // CONFIG & OPTIMIZATION FOR REAL WATCH
        // =========================
        const heartCurveX = 22;
        const heartCurveY = 302;
        const heartCurveHeight = 37;

        const heartCurveCount = 16;
        const heartCurveStep = 7;
        const heartCurvePointSize = 2;
        const heartLineWidth = 2;

        let heartCurveHistory = [];
        let lastDrawnHeartRate = null; // เก็บค่าที่วาดไปล่าสุดเพื่อเช็กค่าซ้ำ

        // =========================
        // COLOR ZONES FUNCTION (แบ่งเป็น 6 ช่วงสีตามชีพจร)
        // =========================
        function getHeartRateColor(hr) {
          if (hr < 90) {
            return 0x00FFFF; // สีฟ้า (Zone 1: พักผ่อน / ต่ำมาก)
          } else if (hr < 110) {
            return 0x00FF00; // สีเขียว (Zone 2: เบาๆ / ปกติ)
          } else if (hr < 130) {
            return 0xADFF2F; // สีเขียวตองอ่อน (Zone 3: ปานกลาง)
          } else if (hr < 150) {
            return 0xFFD700; // สีเหลือง (Zone 4: ค่อนข้างหนัก)
          } else if (hr < 170) {
            return 0xFF6B00; // สีส้ม (Zone 5: หนักมาก)
          } else {
            return 0xFF0000; // สีแดง (Zone 6: สูงสุดอันตราย)
          }
        }


        function getHeartFillColor(hr) {
      if (hr < 90) {
            return 0x226688; // สีฟ้าสว่างขึ้น (โปร่งแสงน้อยลง/ชัดขึ้น)
          } else if (hr < 110) {
            return 0x228822; // สีเขียวสว่างขึ้น
          } else if (hr < 130) {
            return 0x668822; // สีเขียวตองสว่างขึ้น
          } else if (hr < 150) {
            return 0x888822; // สีเหลืองสว่างขึ้น
          } else if (hr < 170) {
            return 0x885522; // สีส้มสว่างขึ้น
          } else {
            return 0x882222; // สีแดงสว่างขึ้น
          }
        }

        // =========================
        // CREATE MINIMAL WIDGETS
        // =========================
        // 1. Points
        let heartCurvePoints = [];
        for (let i = 0; i < heartCurveCount; i++) {
          const point = hmUI.createWidget(hmUI.widget.FILL_RECT, {
            x: heartCurveX + i * heartCurveStep,
            y: heartCurveY + heartCurveHeight,
            w: heartCurvePointSize,
            h: heartCurvePointSize,
            color: 0xFFFE575E,
            alpha: 90,
            show_level: hmUI.show_level.ONLY_NORMAL
          });
          point.setProperty(hmUI.prop.VISIBLE, false);
          heartCurvePoints.push(point);
        }

        // 2. Lines (2 slices/segment)
        const lineSlicesPerSegment = 3;
        let heartCurveLines = [];
        for (let i = 0; i < heartCurveCount - 1; i++) {
          let segment = [];
          for (let s = 0; s < lineSlicesPerSegment; s++) {
            const line = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: heartCurveX + i * heartCurveStep,
              y: heartCurveY + heartCurveHeight,
              w: 5,
              h: heartLineWidth,
              color: 0xFFFE575E,
              show_level: hmUI.show_level.ONLY_NORMAL
            });
            line.setProperty(hmUI.prop.VISIBLE, false);
            segment.push(line);
          }
          heartCurveLines.push(segment);
        }

        // 3. Fills (2 slices/segment)
        let heartCurveFills = [];
        for (let i = 0; i < heartCurveCount - 1; i++) {
          let segment = [];
          for (let s = 0; s < lineSlicesPerSegment; s++) {
            const fill = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: heartCurveX + i * heartCurveStep,
              y: heartCurveY + heartCurveHeight,
              w: 5,
              h: 1,
              color: 0x652225,
              alpha: 90,
              show_level: hmUI.show_level.ONLY_NORMAL
            });
            fill.setProperty(hmUI.prop.VISIBLE, false);
            segment.push(fill);
          }
          heartCurveFills.push(segment);
        }

        // 4. Marker
        const heartCurveMarker = hmUI.createWidget(hmUI.widget.IMG, {
          x: heartCurveX + (heartCurveCount - 1) * heartCurveStep - 8,
          y: heartCurveY + heartCurveHeight - 8,
          src: 'heart_marker.png',
          show_level: hmUI.show_level.ONLY_NORMAL
        });
        heartCurveMarker.setProperty(hmUI.prop.VISIBLE, false);

        /////// can change min and max 
        function getHeartY(heartRate) {
          const minHR = 5;  // อย่าลืมคำนวนหักลบขนาด icon 
          const maxHR = 180;
          
          const normalizedValue = Math.max(0, Math.min(1, (heartRate - minHR) / (maxHR - minHR)));

          return (
            heartCurveY +
            heartCurveHeight -
            Math.round(normalizedValue * heartCurveHeight)
          );
        }

        function updateHeartCurve() {
          let currentHeartRate = customHeartRate.current || customHeartRate.last;

          if (!currentHeartRate || currentHeartRate <= 0) {
            if (typeof customHeartRate.getToday === 'function') {
              const todayData = customHeartRate.getToday();
              if (todayData && todayData.length > 0) {
                currentHeartRate = todayData[todayData.length - 1];
              }
            }
          }

          if (!currentHeartRate || currentHeartRate <= 0) {
            return;
          }

          // ----------------------------------------------------
          // CHECK DUPLICATE: ถ้าค่าเท่าเดิม ให้ข้ามการวาดทันที
          // ----------------------------------------------------
          if (currentHeartRate === lastDrawnHeartRate) {
            return;
          }

          // อัปเดตค่าล่าสุดไว้สำหรับเช็กครั้งถัดไป
          lastDrawnHeartRate = currentHeartRate;

          heartCurveHistory.push(currentHeartRate);

          if (heartCurveHistory.length > heartCurveCount) {
            heartCurveHistory.shift();
          }

          const historyLen = heartCurveHistory.length;

          // Hide All
          for (let i = 0; i < heartCurveCount; i++) {
            heartCurvePoints[i].setProperty(hmUI.prop.VISIBLE, false);
          }
          for (let i = 0; i < heartCurveCount - 1; i++) {
            for (let s = 0; s < lineSlicesPerSegment; s++) {
              heartCurveLines[i][s].setProperty(hmUI.prop.VISIBLE, false);
              heartCurveFills[i][s].setProperty(hmUI.prop.VISIBLE, false);
            }
          }

          // Draw Points
          for (let i = 0; i < historyLen; i++) {
            const slotIndex = (heartCurveCount - historyLen) + i;
            const heartRate = heartCurveHistory[i];
            const pointY = getHeartY(heartRate);
            const pointX = heartCurveX + slotIndex * heartCurveStep;

            // กำหนดสีตามช่วง 6 โซนของจุดนั้นๆ
            const pointColor = getHeartRateColor(heartRate);

            const point = heartCurvePoints[slotIndex];
            point.setProperty(hmUI.prop.MORE, {
              x: pointX,
              y: pointY,
              w: heartCurvePointSize,
              h: heartCurvePointSize,
              color: pointColor
            });
            point.setProperty(hmUI.prop.VISIBLE, true);
          }

          // Draw Lines & Fills
          for (let i = 0; i < historyLen - 1; i++) {
            const slotIndex = (heartCurveCount - historyLen) + i;
            const hr1 = heartCurveHistory[i];
            const hr2 = heartCurveHistory[i + 1];

            const y1 = getHeartY(hr1);
            const y2 = getHeartY(hr2);
            const x1 = heartCurveX + slotIndex * heartCurveStep;
            const dy = y2 - y1;
            const bottom = heartCurveY + heartCurveHeight;

            for (let s = 0; s < lineSlicesPerSegment; s++) {
              const progress = s / (lineSlicesPerSegment - 1);
              const x = x1 + Math.round(progress * heartCurveStep);
              const y = y1 + Math.round(progress * dy);

              // ดึงสีตามช่วง 6 โซนของจุดเริ่มต้นช่วง (hr1)
              const activeColor = getHeartRateColor(hr1);
              const activeFillColor = getHeartFillColor(hr1);

              const line = heartCurveLines[slotIndex][s];
              line.setProperty(hmUI.prop.MORE, {
                x: x,
                y: y - Math.floor(heartLineWidth / 2),
                w: 6,
                h: heartLineWidth,
                color: activeColor
              });
              line.setProperty(hmUI.prop.VISIBLE, true);

              const fillHeight = bottom - y;
              if (fillHeight > 0) {
                const fill = heartCurveFills[slotIndex][s];
                fill.setProperty(hmUI.prop.MORE, {
                  x: x,
                  y: y,
                  w: 6,
                  h: fillHeight,
                  color: activeFillColor
                });
                fill.setProperty(hmUI.prop.VISIBLE, true);
              }
            }
          }

          // Draw Marker
          if (historyLen > 0) {
            const lastHeartRate = heartCurveHistory[historyLen - 1];
            const markerY = getHeartY(lastHeartRate);
            const markerX = heartCurveX + (heartCurveCount - 1) * heartCurveStep - 8;

            heartCurveMarker.setProperty(hmUI.prop.MORE, {
              x: markerX,
              y: markerY - 8
            });
            heartCurveMarker.setProperty(hmUI.prop.VISIBLE, true);
          }
        }

        // Event Listener
        customHeartRate.addEventListener(
          hmSensor.event.CHANGE,
          function () {
            updateHeartCurve();
          }
        );

        // Initial Exec
        updateHeartCurve();


            // end user_script_beforeShortcuts.js
            console.log('Watch_Face.Shortcuts');

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 48,
              y: 17,
              w: 68,
              h: 68,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 157,
              y: 296,
              w: 216,
              h: 48,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 22,
              y: 300,
              w: 89,
              h: 43,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 130,
              y: 422,
              w: 172,
              h: 49,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 263,
              y: 34,
              w: 70,
              h: 61,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 136,
              y: 18,
              w: 93,
              h: 63,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 382,
              w: 49,
              h: 42,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 78,
              y: 208,
              w: 73,
              h: 41,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 266,
              y: 200,
              w: 45,
              h: 68,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 126,
              y: 172,
              w: 37,
              h: 35,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 166,
              y: 138,
              w: 265,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 145,
              y: 362,
              w: 102,
              h: 42,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 4,
              y: 140,
              w: 101,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 395,
              y: 193,
              w: 42,
              h: 81,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // LCD
                click_ColorLCD()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 2,
              y: 361,
              w: 37,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // Bar
                click_ColorBAR()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let normal_times_linear_scale = ''
         let intervalId;

         if (screenType != hmSetting.screen_type.AOD) {
              normal_times_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

let times = hmSensor.createSensor(hmSensor.id.TIME);


          function second_line_call() {

                console.log('update scales TIME');
                
                let valueTimes = times.second;
if (valueTimes == 0) { valueTimes = 60}
                let targetTimes = 60;
                let progressTimes = valueTimes/targetTimes;
                if (progressTimes > 1) progressTimes = 1;
                let progress_ls_normal_times = progressTimes;



                if (screenType != hmSetting.screen_type.AOD) {





                  // normal_times_linear_scale
                  // initial parameters
                  let start_x_normal_times = 37;
                  let start_y_normal_times = 258;
                  let lenght_ls_normal_times = 82;
                  let line_width_ls_normal_times = 10;
                  let color_ls_normal_times = 0xFFFFFEFD;
                  
                  // calculated parameters
                  let start_x_normal_times_draw = start_x_normal_times;
                  let start_y_normal_times_draw = start_y_normal_times;
                  lenght_ls_normal_times = lenght_ls_normal_times * progress_ls_normal_times;
                  let lenght_ls_normal_times_draw = lenght_ls_normal_times;
                  let line_width_ls_normal_times_draw = line_width_ls_normal_times;
                  if (lenght_ls_normal_times < 0){
                    line_width_ls_normal_times_draw = -lenght_ls_normal_times;
                    start_x_normal_times_draw = start_x_normal_times_draw - lenght_ls_normal_times_draw;
                  };
                  
                  normal_times_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_times_draw,
                    y: start_y_normal_times_draw,
                    w: lenght_ls_normal_times_draw,
                    h: line_width_ls_normal_times_draw,
                    color: color_ls_normal_times,
                  });
                };

         };

function startInterval() {
intervalId = setInterval(second_line_call, 1000); // เรียกใช้ฟังก์ชัน scale_call() ทุก 1 วินาที (1000 มิลลิวินาที)
}
startInterval();

if(hmFS.SysProGetInt('ampm24h') == 1) {
                  is24H();}

if(hmFS.SysProGetInt('ampm24h') == 2) {
                  isAMPM();}

            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 38;
                  let start_y_normal_battery = 175;
                  let lenght_ls_normal_battery = 69;
                  let line_width_ls_normal_battery = 0;
                  let color_ls_normal_battery = 0xFFFF8C00;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_battery = 12;
                  let pointer_offset_y_ls_normal_battery = 12;
                  normal_battery_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery + lenght_ls_normal_battery - pointer_offset_x_ls_normal_battery,
                    y: start_y_normal_battery_draw + line_width_ls_normal_battery / 2 - pointer_offset_y_ls_normal_battery,
                    src: 'Pointer1.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 156;
                  let start_y_normal_step = 352;
                  let lenght_ls_normal_step = 245;
                  let line_width_ls_normal_step = 0;
                  let color_ls_normal_step = 0xFFFF8C00;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_step = 12;
                  let pointer_offset_y_ls_normal_step = 12;
                  normal_step_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step + lenght_ls_normal_step - pointer_offset_x_ls_normal_step,
                    y: start_y_normal_step_draw + line_width_ls_normal_step / 2 - pointer_offset_y_ls_normal_step,
                    src: 'Pointer1.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 38;
                  let start_y_idle_battery = 175;
                  let lenght_ls_idle_battery = 69;
                  let line_width_ls_idle_battery = 0;
                  let color_ls_idle_battery = 0xFFFF8C00;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_idle_battery = 12;
                  let pointer_offset_y_ls_idle_battery = 12;
                  idle_battery_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery + lenght_ls_idle_battery - pointer_offset_x_ls_idle_battery,
                    y: start_y_idle_battery_draw + line_width_ls_idle_battery / 2 - pointer_offset_y_ls_idle_battery,
                    src: 'Pointer1.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                  });
                };

                console.log('update scales STEP');
                let progress_ls_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_linear_scale
                  // initial parameters
                  let start_x_idle_step = 156;
                  let start_y_idle_step = 352;
                  let lenght_ls_idle_step = 245;
                  let line_width_ls_idle_step = 0;
                  let color_ls_idle_step = 0xFFFF8C00;
                  
                  // calculated parameters
                  let start_x_idle_step_draw = start_x_idle_step;
                  let start_y_idle_step_draw = start_y_idle_step;
                  lenght_ls_idle_step = lenght_ls_idle_step * progress_ls_idle_step;
                  let lenght_ls_idle_step_draw = lenght_ls_idle_step;
                  let line_width_ls_idle_step_draw = line_width_ls_idle_step;
                  if (lenght_ls_idle_step < 0){
                    lenght_ls_idle_step_draw = -lenght_ls_idle_step;
                    start_x_idle_step_draw = start_x_idle_step - lenght_ls_idle_step_draw;
                  };
                  
                  idle_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step_draw,
                    y: start_y_idle_step_draw,
                    w: lenght_ls_idle_step_draw,
                    h: line_width_ls_idle_step_draw,
                    color: color_ls_idle_step,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_idle_step = 12;
                  let pointer_offset_y_ls_idle_step = 12;
                  idle_step_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step + lenght_ls_idle_step - pointer_offset_x_ls_idle_step,
                    y: start_y_idle_step_draw + line_width_ls_idle_step / 2 - pointer_offset_y_ls_idle_step,
                    src: 'Pointer1.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();

                console.log('resume_call.js');
                // start resume_call.js

updateHeartCurve()
 check24h()
                // end resume_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}