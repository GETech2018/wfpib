﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block


// start user_functions.js
// Temporary device brightness override, ONLY when firmware reports AOD.
// Public Zepp APIs; no light sensor subscription and no recurring timer.
function ptCreateAodBrightness(settings) {
  let saved = null;
  let pending = null;
  let generation = 0;
  let destroyed = false;
  const limit = 10;
  function supported() {
    return settings && settings.screen_type &&
      settings.screen_type.AOD !== undefined &&
      ['getScreenType','getBrightness','getScreenAutoBright',
       'setBrightness','setScreenAutoBright'].every(function(name) {
        return typeof settings[name] === 'function';
      });
  }
  function write(name, value) {
    try { return settings[name](value) === 0; }
    catch (e) { return false; }
  }
  function restore() {
    if (!saved) return;
    // Set the previous level while manual, then restore the previous mode.
    write('setScreenAutoBright', false);
    const levelOK = write('setBrightness', saved.level);
    const autoOK = write('setScreenAutoBright', saved.auto);
    if (levelOK && autoOK) saved = null;
  }
  function sync() {
    if (destroyed || !supported()) return;
    try {
      if (settings.getScreenType() !== settings.screen_type.AOD) {
        restore();
        return;
      }
      if (saved) return;
      const auto = settings.getScreenAutoBright();
      const level = settings.getBrightness();
      if (typeof auto !== 'boolean' || typeof level !== 'number' ||
          !isFinite(level) || level < 0 || level > 100) return;
      const target = Math.min(limit, level);
      if (!auto && level === target) return;
      saved = {auto:auto, level:level};
      if (!write('setScreenAutoBright', false) ||
          !write('setBrightness', target)) restore();
    } catch (e) { restore(); }
  }
  function cancel() {
    generation++;
    if (pending !== null && typeof clearTimeout === 'function') {
      clearTimeout(pending);
    }
    pending = null;
  }
  function event() {
    cancel();
    if (destroyed || !supported()) return;
    sync();
    // One check after the transition, in case getScreenType updates late.
    // A subsequent lifecycle event invalidates it even if timers were paused.
    const token = generation;
    if (typeof setTimeout === 'function' && typeof clearTimeout === 'function') {
      pending = setTimeout(function() {
        if (destroyed || token !== generation) return;
        pending = null;
        sync();
      }, 120);
    }
  }
  function release() { cancel(); restore(); }
  function destroy() { destroyed = true; release(); }
  return {event:event, release:release, destroy:destroy};
}
const ptAodBrightness = ptCreateAodBrightness(hmSetting);

// end user_functions.js
__$$module$$__.module=DeviceRuntimeCore.WatchFace({init_view(){
// start user_script.js
const normal=hmUI.show_level.ONLY_NORMAL;
function dexArray(prefix){let a=[];for(let i=0;i<10;i++)a.push(prefix+i+'.png');return a;}
const clock=dexArray('dex_clock_'),stats=dexArray('dex_stat_'),date=dexArray('dex_date_'),bat=dexArray('dex_bat_');
hmUI.createWidget(hmUI.widget.IMG,{x:0,y:0,src:'dex_bg.png',show_level:normal});
hmUI.createWidget(hmUI.widget.IMG_TIME,{hour_startX:85,hour_startY:103,hour_array:clock,hour_zero:1,hour_space:10,hour_align:hmUI.align.LEFT,hour_unit_en:'dex_colon.png',hour_unit_sc:'dex_colon.png',hour_unit_tc:'dex_colon.png',minute_startX:211,minute_startY:103,minute_array:clock,minute_zero:1,minute_space:10,minute_follow:0,minute_align:hmUI.align.LEFT,show_level:normal});
hmUI.createWidget(hmUI.widget.IMG_TIME,{am_x:320,am_y:143,am_en_path:'dex_am.png',am_sc_path:'dex_am.png',pm_x:320,pm_y:143,pm_en_path:'dex_pm.png',pm_sc_path:'dex_pm.png',show_level:normal});
const weeks=['dex_week_0.png','dex_week_1.png','dex_week_2.png','dex_week_3.png','dex_week_4.png','dex_week_5.png','dex_week_6.png'];
hmUI.createWidget(hmUI.widget.IMG_WEEK,{x:104,y:169,week_en:weeks,week_sc:weeks,week_tc:weeks,show_level:normal});
hmUI.createWidget(hmUI.widget.IMG_DATE,{day_startX:207,day_startY:169,day_en_array:date,day_sc_array:date,day_tc_array:date,day_zero:1,day_space:2,day_align:hmUI.align.LEFT,day_unit_en:'dex_slash.png',day_unit_sc:'dex_slash.png',day_unit_tc:'dex_slash.png',month_startX:241,month_startY:169,month_en_array:date,month_sc_array:date,month_tc_array:date,month_zero:1,month_space:2,month_align:hmUI.align.LEFT,month_is_character:false,show_level:normal});
hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:280,y:36,w:70,h:18,font_array:bat,h_space:5,type:hmUI.data_type.BATTERY,padding:false,align_h:hmUI.align.RIGHT,unit_en:'dex_percent.png',unit_sc:'dex_percent.png',unit_tc:'dex_percent.png',show_level:normal});
[[hmUI.data_type.STEP,30],[hmUI.data_type.DISTANCE,144],[hmUI.data_type.HEART,258]].forEach(function(v){hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:v[1],y:328,w:103,h:20,font_array:stats,h_space:5,padding:false,align_h:hmUI.align.CENTER_H,type:v[0],dot_image:'dex_decimal.png',invalid_image:'dex_invalid.png',show_level:normal});});
// Decorative segmented accents below the native readings match the chosen concept.
[[19,'SportListScreen'],[138,'ScheduleCalScreen']].forEach(function(v){hmUI.createWidget(hmUI.widget.BUTTON,{x:v[0],y:400,w:114,h:32,text:'',normal_src:'0_Empty.png',press_src:'0_Empty.png',click_func:function(){ptAodBrightness.release();hmApp.startApp({appid:1,url:v[1],native:true});},show_level:normal});});
hmUI.createWidget(hmUI.widget.IMG_CLICK,{x:257,y:400,w:114,h:32,src:'0_Empty.png',type:hmUI.data_type.COUNT_DOWN,show_level:normal});

hmUI.createWidget(hmUI.widget.IMG,{x:0,y:0,src:'approved_black.png',show_level:hmUI.show_level.ONLY_AOD});
let idle_digital_clock_img_time, idle_digital_clock_img_time_AmPm;
            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 74,
              hour_startY: 70,
              hour_array: ["approved_clock_0.png","approved_clock_1.png","approved_clock_2.png","approved_clock_3.png","approved_clock_4.png","approved_clock_5.png","approved_clock_6.png","approved_clock_7.png","approved_clock_8.png","approved_clock_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: 'approved_colon.png',
              hour_unit_tc: 'approved_colon.png',
              hour_unit_en: 'approved_colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 208,
              minute_startY: 70,
              minute_array: ["approved_clock_0.png","approved_clock_1.png","approved_clock_2.png","approved_clock_3.png","approved_clock_4.png","approved_clock_5.png","approved_clock_6.png","approved_clock_7.png","approved_clock_8.png","approved_clock_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 180,
              am_y: 150,
              am_sc_path: 'approved_am.png',
              am_en_path: 'approved_am.png',
              pm_x: 180,
              pm_y: 150,
              pm_sc_path: 'approved_pm.png',
              pm_en_path: 'approved_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


function ptImg(src,x,y,group,level){return hmUI.createWidget(hmUI.widget.IMG,{src:src,x:x,y:y,show_level:level});}
// Approved AOD: sprites, elemental icons, footprints, route and ECG are static art.
// Numeric readings remain automatic native widgets, not painted sample values.
ptImg('approved_scene.png',39,202,null,hmUI.show_level.ONLY_AOD);
const approvedDigits=['approved_num_0.png','approved_num_1.png','approved_num_2.png','approved_num_3.png','approved_num_4.png','approved_num_5.png','approved_num_6.png','approved_num_7.png','approved_num_8.png','approved_num_9.png'];
[[hmUI.data_type.STEP,28,94],[hmUI.data_type.DISTANCE,147,94],[hmUI.data_type.HEART,266,94]].forEach(function(v){hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:v[1],y:374,w:v[2],h:24,font_array:approvedDigits,h_space:1,padding:false,align_h:hmUI.align.CENTER_H,type:v[0],dot_image:'approved_decimal.png',invalid_image:'approved_invalid.png',show_level:hmUI.show_level.ONLY_AOD});});

// end user_script.js
hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE,{resume_call:function(){ptAodBrightness.event();},pause_call:function(){ptAodBrightness.event();}});
},build(){this.init_view();ptAodBrightness.event();},onInit(){},onDestroy(){ptAodBrightness.destroy();}});
})();}catch(e){console.log('Mini Program Error',e);}
