try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_3b1e7d5731124c048dc45885ed5677ab = '';
        let normal$_$text_6694abde06dc40cbac9e087373cdaf18 = '';
        let normal$_$text_ad670db413064299b7ed0c8e3d701c21 = '';
        let stepSensor = '';
        let batterySensor = '';
        let heartSensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 320,
                    h: 380,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_3b1e7d5731124c048dc45885ed5677ab = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 112,
                    y: 213,
                    w: 100,
                    h: 40,
                    text: '[SC]',
                    color: '0xFF000000',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_6694abde06dc40cbac9e087373cdaf18 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 171,
                    y: 123,
                    w: 75,
                    h: 40,
                    text: '[BATT_PER]',
                    color: '0xFF000000',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_ad670db413064299b7ed0c8e3d701c21 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 75,
                    y: 123,
                    w: 75,
                    h: 40,
                    text: '[HR]',
                    color: '0xFF000000',
                    text_size: 20,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 160,
                    hour_centerY: 190,
                    hour_posX: 25,
                    hour_posY: 160,
                    hour_path: '3.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 160,
                    minute_centerY: 190,
                    minute_posX: 25,
                    minute_posY: 160,
                    minute_path: '4.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 160,
                    second_centerY: 190,
                    second_posX: 25,
                    second_posY: 160,
                    second_path: '5.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_3b1e7d5731124c048dc45885ed5677ab.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_6694abde06dc40cbac9e087373cdaf18.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }` });
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_ad670db413064299b7ed0c8e3d701c21.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 0,
                    y: 190,
                    w: 140,
                    h: 180,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 180,
                    y: 190,
                    w: 140,
                    h: 180,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_3b1e7d5731124c048dc45885ed5677ab.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        normal$_$text_6694abde06dc40cbac9e087373cdaf18.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }` });
                        normal$_$text_ad670db413064299b7ed0c8e3d701c21.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}