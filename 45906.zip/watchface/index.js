try{(()=>{var __$$app$$__=__$$hmAppManager$$__.currentApp;var __$$module$$__=__$$app$$__.current;var e=new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__,__$$module$$__),"orange");"use strict";
__$$module$$__.module=DeviceRuntimeCore.WatchFace({
init_view(){
const N=hmUI.show_level.ONLY_NORMAL, AOD=hmUI.show_level.ONLY_AOD, DT=hmUI.data_type, L=hmUI.align.LEFT, CH=hmUI.align.CENTER_H;
const safe=(f)=>{try{f()}catch(err){console.log(err)}};
const img=(x,y,w,h,src,lv)=>safe(()=>hmUI.createWidget(hmUI.widget.IMG,{x:x,y:y,w:w,h:h,src:src,show_level:lv||N}));
const level=(x,y,arr,type)=>safe(()=>hmUI.createWidget(hmUI.widget.IMG_LEVEL,{x:x,y:y,image_array:arr,image_length:arr.length,type:type,show_level:N}));
const text=(x,y,w,h,arr,type,al,extra)=>safe(()=>hmUI.createWidget(hmUI.widget.TEXT_IMG,Object.assign({x:x,y:y,w:w,h:h,font_array:arr,h_space:0,align_h:al,type:type,show_level:N},extra||{})));
const un=(u)=>({unit_sc:u,unit_tc:u,unit_en:u,imperial_unit_sc:u,imperial_unit_tc:u,imperial_unit_en:u});
img(0,0,390,450,"0114.png");
// arcos: pasos (izq) y calorias (der)
level(94,156,["0102.png", "0103.png", "0104.png", "0105.png", "0106.png", "0107.png"],DT.STEP);
level(269,156,["0108.png", "0109.png", "0110.png", "0111.png", "0112.png", "0113.png"],DT.CAL);
// hora: horas contorno, minutos solidos
safe(()=>hmUI.createWidget(hmUI.widget.IMG_TIME,{
 hour_startX:141,hour_startY:118,hour_array:["0001.png", "0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png"],hour_zero:1,hour_space:0,hour_align:L,
 minute_startX:141,minute_startY:210,minute_array:["0011.png", "0012.png", "0013.png", "0014.png", "0015.png", "0016.png", "0017.png", "0018.png", "0019.png", "0020.png"],minute_zero:1,minute_space:0,minute_align:L,show_level:N}));
// fecha
safe(()=>hmUI.createWidget(hmUI.widget.IMG_DATE,{
 month_startX:122,month_startY:14,month_sc_array:["0051.png", "0052.png", "0053.png", "0054.png", "0055.png", "0056.png", "0057.png", "0058.png", "0059.png", "0060.png", "0061.png", "0062.png"],month_tc_array:["0051.png", "0052.png", "0053.png", "0054.png", "0055.png", "0056.png", "0057.png", "0058.png", "0059.png", "0060.png", "0061.png", "0062.png"],month_en_array:["0051.png", "0052.png", "0053.png", "0054.png", "0055.png", "0056.png", "0057.png", "0058.png", "0059.png", "0060.png", "0061.png", "0062.png"],month_is_character:true,month_align:L,
 day_startX:210,day_startY:14,day_sc_array:["0041.png", "0042.png", "0043.png", "0044.png", "0045.png", "0046.png", "0047.png", "0048.png", "0049.png", "0050.png"],day_tc_array:["0041.png", "0042.png", "0043.png", "0044.png", "0045.png", "0046.png", "0047.png", "0048.png", "0049.png", "0050.png"],day_en_array:["0041.png", "0042.png", "0043.png", "0044.png", "0045.png", "0046.png", "0047.png", "0048.png", "0049.png", "0050.png"],day_zero:0,day_space:0,day_align:L,show_level:N}));
safe(()=>hmUI.createWidget(hmUI.widget.IMG_WEEK,{x:110,y:52,week_en:["0063.png", "0064.png", "0065.png", "0066.png", "0067.png", "0068.png", "0069.png"],week_tc:["0063.png", "0064.png", "0065.png", "0066.png", "0067.png", "0068.png", "0069.png"],week_sc:["0063.png", "0064.png", "0065.png", "0066.png", "0067.png", "0068.png", "0069.png"],show_level:N}));
// iconos
img(80,118,30,32,"0088.png");
img(276,118,40,32,"0092.png");
img(39,222,26,30,"0089.png");
img(327,222,24,30,"0090.png");
img(79,269,34,30,"0091.png");
// cifras
text(40,73,100,34,["0031.png", "0032.png", "0033.png", "0034.png", "0035.png", "0036.png", "0037.png", "0038.png", "0039.png", "0040.png"],DT.STEP,CH);
text(250,75,100,34,["0031.png", "0032.png", "0033.png", "0034.png", "0035.png", "0036.png", "0037.png", "0038.png", "0039.png", "0040.png"],DT.WEATHER_CURRENT,CH,Object.assign({negative_image:"0075.png",invalid_image:"0070.png"},un("0072.png")));
text(-2,177,100,34,["0031.png", "0032.png", "0033.png", "0034.png", "0035.png", "0036.png", "0037.png", "0038.png", "0039.png", "0040.png"],DT.CAL,CH);
text(289,177,100,34,["0031.png", "0032.png", "0033.png", "0034.png", "0035.png", "0036.png", "0037.png", "0038.png", "0039.png", "0040.png"],DT.DISTANCE,CH,Object.assign({dot_image:"0071.png"},un("0074.png")));
text(43,317,100,34,["0031.png", "0032.png", "0033.png", "0034.png", "0035.png", "0036.png", "0037.png", "0038.png", "0039.png", "0040.png"],DT.HEART,CH,{invalid_image:"0070.png"});
level(176,347,["0096.png", "0097.png", "0098.png", "0099.png", "0100.png", "0101.png"],DT.BATTERY);
text(141,381,110,34,["0031.png", "0032.png", "0033.png", "0034.png", "0035.png", "0036.png", "0037.png", "0038.png", "0039.png", "0040.png"],DT.BATTERY,CH,un("0073.png"));
safe(()=>hmUI.createWidget(hmUI.widget.IMG_STATUS,{x:142,y:344,type:hmUI.system_status.CONNECT,src:"0095.png",show_level:N}));
// amanecer / atardecer (cambia solo)
(function(){
var DG=["0076.png", "0077.png", "0078.png", "0079.png", "0080.png", "0081.png", "0082.png", "0083.png", "0084.png", "0085.png"], COL="0086.png", BL="0087.png", SR="0093.png", SS="0094.png";
var CX=300, Y=318, DW=16, CW=8, slots=[], icon=null, tm=null, ws=null;
for(var i=0;i<5;i++){try{slots.push(hmUI.createWidget(hmUI.widget.IMG,{x:CX-40+i*16,y:Y,w:16,h:32,src:BL,show_level:N}))}catch(err){console.log(err)}}
try{icon=hmUI.createWidget(hmUI.widget.IMG,{x:277,y:279,w:34,h:30,src:SS,show_level:N})}catch(err){console.log(err)}
try{ws=hmSensor.createSensor(hmSensor.id.WEATHER)}catch(err){console.log(err)}
try{tm=hmSensor.createSensor(hmSensor.id.TIME)}catch(err){console.log(err)}
var set=function(w,o){try{w.setProperty(hmUI.prop.MORE,o)}catch(err){try{if(o.src)w.setProperty(hmUI.prop.SRC,o.src)}catch(e2){}}};
var nowMin=function(){try{if(tm&&typeof tm.hour==="number")return tm.hour*60+tm.minute}catch(err){}var d=new Date();return d.getHours()*60+d.getMinutes()};
var up=function(){try{
 var f=ws.getForecastWeather(), t=f.tideData.data[0], sr=t.sunrise.hour*60+t.sunrise.minute, ss=t.sunset.hour*60+t.sunset.minute, n=nowMin();
 var day=(n>=sr&&n<ss), v=day?t.sunset:t.sunrise, h=v.hour%12; if(h===0)h=12;
 var chars=[]; if(h>=10)chars.push(DG[Math.floor(h/10)]); chars.push(DG[h%10]); chars.push(COL); chars.push(DG[Math.floor(v.minute/10)]); chars.push(DG[v.minute%10]);
 var w=0; for(var i=0;i<chars.length;i++)w+=(chars[i]===COL?CW:DW); var x=CX-Math.floor(w/2);
 for(var j=0;j<5;j++){ if(j<chars.length){var cw=(chars[j]===COL?CW:DW); set(slots[j],{x:x,y:Y,w:cw,h:32,src:chars[j]}); x+=cw}else{set(slots[j],{x:0,y:Y,w:16,h:32,src:BL})} }
 set(icon,{x:277,y:279,w:34,h:30,src:day?SS:SR});
}catch(err){console.log(err)}};
up();
try{tm.addEventListener(hmSensor.event.MINUTEEND,up)}catch(err){}
try{hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE,{resume_call:up})}catch(err){}
})();
// AOD
img(0,0,390,450,"0115.png",AOD);
safe(()=>hmUI.createWidget(hmUI.widget.IMG_TIME,{
 hour_startX:141,hour_startY:118,hour_array:["0021.png", "0022.png", "0023.png", "0024.png", "0025.png", "0026.png", "0027.png", "0028.png", "0029.png", "0030.png"],hour_zero:1,hour_space:0,hour_align:L,
 minute_startX:141,minute_startY:210,minute_array:["0021.png", "0022.png", "0023.png", "0024.png", "0025.png", "0026.png", "0027.png", "0028.png", "0029.png", "0030.png"],minute_zero:1,minute_space:0,minute_align:L,show_level:AOD}));
},
onInit(){this.init_view()},onReady(){},onShow(){},onHide(){},onDestroy(){}
})})()}catch(e){console.log(e)}
