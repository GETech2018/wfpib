﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'img_0004.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 107,
              day_startY: 400,
              day_sc_array: ["digits_size_30_0.png","digits_size_30_1.png","digits_size_30_2.png","digits_size_30_3.png","digits_size_30_4.png","digits_size_30_5.png","digits_size_30_6.png","digits_size_30_7.png","digits_size_30_8.png","digits_size_30_9.png"],
              day_tc_array: ["digits_size_30_0.png","digits_size_30_1.png","digits_size_30_2.png","digits_size_30_3.png","digits_size_30_4.png","digits_size_30_5.png","digits_size_30_6.png","digits_size_30_7.png","digits_size_30_8.png","digits_size_30_9.png"],
              day_en_array: ["digits_size_30_0.png","digits_size_30_1.png","digits_size_30_2.png","digits_size_30_3.png","digits_size_30_4.png","digits_size_30_5.png","digits_size_30_6.png","digits_size_30_7.png","digits_size_30_8.png","digits_size_30_9.png"],
              day_zero: 1,
              day_space: -20,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 159,
              month_startY: 404,
              month_sc_array: ["MONTHS_EN_1.png","MONTHS_EN_2.png","MONTHS_EN_3.png","MONTHS_EN_4.png","MONTHS_EN_5.png","MONTHS_EN_6.png","MONTHS_EN_7.png","MONTHS_EN_8.png","MONTHS_EN_9.png","MONTHS_EN_10.png","MONTHS_EN_11.png","MONTHS_EN_12.png"],
              month_tc_array: ["MONTHS_EN_1.png","MONTHS_EN_2.png","MONTHS_EN_3.png","MONTHS_EN_4.png","MONTHS_EN_5.png","MONTHS_EN_6.png","MONTHS_EN_7.png","MONTHS_EN_8.png","MONTHS_EN_9.png","MONTHS_EN_10.png","MONTHS_EN_11.png","MONTHS_EN_12.png"],
              month_en_array: ["MONTHS_EN_1.png","MONTHS_EN_2.png","MONTHS_EN_3.png","MONTHS_EN_4.png","MONTHS_EN_5.png","MONTHS_EN_6.png","MONTHS_EN_7.png","MONTHS_EN_8.png","MONTHS_EN_9.png","MONTHS_EN_10.png","MONTHS_EN_11.png","MONTHS_EN_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 43,
              y: 404,
              week_en: ["DAYS_EN_1.png","DAYS_EN_2.png","DAYS_EN_3.png","DAYS_EN_4.png","DAYS_EN_5.png","DAYS_EN_6.png","DAYS_EN_7.png"],
              week_tc: ["DAYS_EN_1.png","DAYS_EN_2.png","DAYS_EN_3.png","DAYS_EN_4.png","DAYS_EN_5.png","DAYS_EN_6.png","DAYS_EN_7.png"],
              week_sc: ["DAYS_EN_1.png","DAYS_EN_2.png","DAYS_EN_3.png","DAYS_EN_4.png","DAYS_EN_5.png","DAYS_EN_6.png","DAYS_EN_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 408,
              font_array: ["img_arr_0000_00.png","img_arr_0000_01.png","img_arr_0000_02.png","img_arr_0000_03.png","img_arr_0000_04.png","img_arr_0000_05.png","img_arr_0000_06.png","img_arr_0000_07.png","img_arr_0000_08.png","img_arr_0000_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 269,
              y: 25,
              image_array: ["WEATHERICON_1.png","WEATHERICON_2.png","WEATHERICON_3.png","WEATHERICON_4.png","WEATHERICON_5.png","WEATHERICON_6.png","WEATHERICON_7.png","WEATHERICON_8.png","WEATHERICON_9.png","WEATHERICON_10.png","WEATHERICON_11.png","WEATHERICON_12.png","WEATHERICON_13.png","WEATHERICON_14.png","WEATHERICON_15.png","WEATHERICON_16.png","WEATHERICON_17.png","WEATHERICON_18.png","WEATHERICON_19.png","WEATHERICON_20.png","WEATHERICON_21.png","WEATHERICON_22.png","WEATHERICON_23.png","WEATHERICON_24.png","WEATHERICON_25.png","WEATHERICON_26.png","WEATHERICON_27.png","WEATHERICON_28.png","WEATHERICON_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 276,
              y: 88,
              font_array: ["img_arr_0001_00.png","img_arr_0001_01.png","img_arr_0001_02.png","img_arr_0001_03.png","img_arr_0001_04.png","img_arr_0001_05.png","img_arr_0001_06.png","img_arr_0001_07.png","img_arr_0001_08.png","img_arr_0001_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'img_0003.png',
              unit_tc: 'img_0003.png',
              unit_en: 'img_0003.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 342,
              font_array: ["img_arr_0001_00.png","img_arr_0001_01.png","img_arr_0001_02.png","img_arr_0001_03.png","img_arr_0001_04.png","img_arr_0001_05.png","img_arr_0001_06.png","img_arr_0001_07.png","img_arr_0001_08.png","img_arr_0001_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 301,
              // center_y: 207,
              // start_angle: 27,
              // end_angle: 330,
              // radius: 55,
              // line_width: 13,
              // line_cap: Rounded,
              // color: 0xFFFEE401,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 301,
              center_y: 207,
              start_angle: 27,
              end_angle: 330,
              radius: 49,
              line_width: 13,
              corner_flag: 0,
              color: 0xFFFEE401,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 192,
              font_array: ["img_arr_0001_00.png","img_arr_0001_01.png","img_arr_0001_02.png","img_arr_0001_03.png","img_arr_0001_04.png","img_arr_0001_05.png","img_arr_0001_06.png","img_arr_0001_07.png","img_arr_0001_08.png","img_arr_0001_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 25,
              hour_startY: 17,
              hour_array: ["img_arr_0004_00.png","img_arr_0004_01.png","img_arr_0004_02.png","img_arr_0004_03.png","img_arr_0004_04.png","img_arr_0004_05.png","img_arr_0004_06.png","img_arr_0004_07.png","img_arr_0004_08.png","img_arr_0004_09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 25,
              minute_startY: 206,
              minute_array: ["img_arr_0005_00.png","img_arr_0005_01.png","img_arr_0005_02.png","img_arr_0005_03.png","img_arr_0005_04.png","img_arr_0005_05.png","img_arr_0005_06.png","img_arr_0005_07.png","img_arr_0005_08.png","img_arr_0005_09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 107,
              day_startY: 400,
              day_sc_array: ["digits_size_30_0.png","digits_size_30_1.png","digits_size_30_2.png","digits_size_30_3.png","digits_size_30_4.png","digits_size_30_5.png","digits_size_30_6.png","digits_size_30_7.png","digits_size_30_8.png","digits_size_30_9.png"],
              day_tc_array: ["digits_size_30_0.png","digits_size_30_1.png","digits_size_30_2.png","digits_size_30_3.png","digits_size_30_4.png","digits_size_30_5.png","digits_size_30_6.png","digits_size_30_7.png","digits_size_30_8.png","digits_size_30_9.png"],
              day_en_array: ["digits_size_30_0.png","digits_size_30_1.png","digits_size_30_2.png","digits_size_30_3.png","digits_size_30_4.png","digits_size_30_5.png","digits_size_30_6.png","digits_size_30_7.png","digits_size_30_8.png","digits_size_30_9.png"],
              day_zero: 1,
              day_space: -20,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 159,
              month_startY: 404,
              month_sc_array: ["MONTHS_EN_1.png","MONTHS_EN_2.png","MONTHS_EN_3.png","MONTHS_EN_4.png","MONTHS_EN_5.png","MONTHS_EN_6.png","MONTHS_EN_7.png","MONTHS_EN_8.png","MONTHS_EN_9.png","MONTHS_EN_10.png","MONTHS_EN_11.png","MONTHS_EN_12.png"],
              month_tc_array: ["MONTHS_EN_1.png","MONTHS_EN_2.png","MONTHS_EN_3.png","MONTHS_EN_4.png","MONTHS_EN_5.png","MONTHS_EN_6.png","MONTHS_EN_7.png","MONTHS_EN_8.png","MONTHS_EN_9.png","MONTHS_EN_10.png","MONTHS_EN_11.png","MONTHS_EN_12.png"],
              month_en_array: ["MONTHS_EN_1.png","MONTHS_EN_2.png","MONTHS_EN_3.png","MONTHS_EN_4.png","MONTHS_EN_5.png","MONTHS_EN_6.png","MONTHS_EN_7.png","MONTHS_EN_8.png","MONTHS_EN_9.png","MONTHS_EN_10.png","MONTHS_EN_11.png","MONTHS_EN_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 44,
              y: 404,
              week_en: ["DAYS_EN_1.png","DAYS_EN_2.png","DAYS_EN_3.png","DAYS_EN_4.png","DAYS_EN_5.png","DAYS_EN_6.png","DAYS_EN_7.png"],
              week_tc: ["DAYS_EN_1.png","DAYS_EN_2.png","DAYS_EN_3.png","DAYS_EN_4.png","DAYS_EN_5.png","DAYS_EN_6.png","DAYS_EN_7.png"],
              week_sc: ["DAYS_EN_1.png","DAYS_EN_2.png","DAYS_EN_3.png","DAYS_EN_4.png","DAYS_EN_5.png","DAYS_EN_6.png","DAYS_EN_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 25,
              hour_startY: 17,
              hour_array: ["img_arr_0004_00.png","img_arr_0004_01.png","img_arr_0004_02.png","img_arr_0004_03.png","img_arr_0004_04.png","img_arr_0004_05.png","img_arr_0004_06.png","img_arr_0004_07.png","img_arr_0004_08.png","img_arr_0004_09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 25,
              minute_startY: 206,
              minute_array: ["img_arr_0005_00.png","img_arr_0005_01.png","img_arr_0005_02.png","img_arr_0005_03.png","img_arr_0005_04.png","img_arr_0005_05.png","img_arr_0005_06.png","img_arr_0005_07.png","img_arr_0005_08.png","img_arr_0005_09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 160,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 286,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 252,
              y: 401,
              w: 100,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 28,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 38,
              y: 216,
              w: 187,
              h: 188,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 38,
              y: 22,
              w: 187,
              h: 188,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 38,
              y: 408,
              w: 187,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 301,
                      center_y: 207,
                      start_angle: 27,
                      end_angle: 330,
                      radius: 49,
                      line_width: 13,
                      corner_flag: 0,
                      color: 0xFFFEE401,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}