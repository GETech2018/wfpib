﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_calorie_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time = ''
        let normal_cal_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 390,
              // h: 450,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_0.png', path: 'bg_0.png' },
                { id: 2, preview: 'bg_1.png', path: 'bg_1.png' },
                { id: 3, preview: 'bg_2.png', path: 'bg_2.png' },
                { id: 4, preview: 'bg_3.png', path: 'bg_3.png' },
                { id: 5, preview: 'bg_4.png', path: 'bg_4.png' },
                { id: 6, preview: 'bg_5.png', path: 'bg_5.png' },
              ],
              count: 6,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 278,
              y: 204,
              week_en: ["DAYS_ES_01.png","DAYS_ES_02.png","DAYS_ES_03.png","DAYS_ES_04.png","DAYS_ES_05.png","DAYS_ES_06.png","DAYS_ES_07.png"],
              week_tc: ["DAYS_ES_01.png","DAYS_ES_02.png","DAYS_ES_03.png","DAYS_ES_04.png","DAYS_ES_05.png","DAYS_ES_06.png","DAYS_ES_07.png"],
              week_sc: ["DAYS_ES_01.png","DAYS_ES_02.png","DAYS_ES_03.png","DAYS_ES_04.png","DAYS_ES_05.png","DAYS_ES_06.png","DAYS_ES_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 318,
              day_startY: 241,
              day_sc_array: ["MEDIUMNUMBERS_0.png","MEDIUMNUMBERS_1.png","MEDIUMNUMBERS_2.png","MEDIUMNUMBERS_3.png","MEDIUMNUMBERS_4.png","MEDIUMNUMBERS_5.png","MEDIUMNUMBERS_6.png","MEDIUMNUMBERS_7.png","MEDIUMNUMBERS_8.png","MEDIUMNUMBERS_9.png"],
              day_tc_array: ["MEDIUMNUMBERS_0.png","MEDIUMNUMBERS_1.png","MEDIUMNUMBERS_2.png","MEDIUMNUMBERS_3.png","MEDIUMNUMBERS_4.png","MEDIUMNUMBERS_5.png","MEDIUMNUMBERS_6.png","MEDIUMNUMBERS_7.png","MEDIUMNUMBERS_8.png","MEDIUMNUMBERS_9.png"],
              day_en_array: ["MEDIUMNUMBERS_0.png","MEDIUMNUMBERS_1.png","MEDIUMNUMBERS_2.png","MEDIUMNUMBERS_3.png","MEDIUMNUMBERS_4.png","MEDIUMNUMBERS_5.png","MEDIUMNUMBERS_6.png","MEDIUMNUMBERS_7.png","MEDIUMNUMBERS_8.png","MEDIUMNUMBERS_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 288,
              y: 376,
              font_array: ["SMALLNUMBERS_0.png","SMALLNUMBERS_1.png","SMALLNUMBERS_2.png","SMALLNUMBERS_3.png","SMALLNUMBERS_4.png","SMALLNUMBERS_5.png","SMALLNUMBERS_6.png","SMALLNUMBERS_7.png","SMALLNUMBERS_8.png","SMALLNUMBERS_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 56,
              y: 376,
              font_array: ["SMALLNUMBERS_0.png","SMALLNUMBERS_1.png","SMALLNUMBERS_2.png","SMALLNUMBERS_3.png","SMALLNUMBERS_4.png","SMALLNUMBERS_5.png","SMALLNUMBERS_6.png","SMALLNUMBERS_7.png","SMALLNUMBERS_8.png","SMALLNUMBERS_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 164,
              y: 376,
              font_array: ["SMALLNUMBERS_0.png","SMALLNUMBERS_1.png","SMALLNUMBERS_2.png","SMALLNUMBERS_3.png","SMALLNUMBERS_4.png","SMALLNUMBERS_5.png","SMALLNUMBERS_6.png","SMALLNUMBERS_7.png","SMALLNUMBERS_8.png","SMALLNUMBERS_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 27,
              hour_array: ["CLOCKNUMBERS_0.png","CLOCKNUMBERS_1.png","CLOCKNUMBERS_2.png","CLOCKNUMBERS_3.png","CLOCKNUMBERS_4.png","CLOCKNUMBERS_5.png","CLOCKNUMBERS_6.png","CLOCKNUMBERS_7.png","CLOCKNUMBERS_8.png","CLOCKNUMBERS_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 20,
              minute_startY: 162,
              minute_array: ["CLOCKNUMBERS_0.png","CLOCKNUMBERS_1.png","CLOCKNUMBERS_2.png","CLOCKNUMBERS_3.png","CLOCKNUMBERS_4.png","CLOCKNUMBERS_5.png","CLOCKNUMBERS_6.png","CLOCKNUMBERS_7.png","CLOCKNUMBERS_8.png","CLOCKNUMBERS_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bg_6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 278,
              y: 204,
              week_en: ["DAYS_ES_01.png","DAYS_ES_02.png","DAYS_ES_03.png","DAYS_ES_04.png","DAYS_ES_05.png","DAYS_ES_06.png","DAYS_ES_07.png"],
              week_tc: ["DAYS_ES_01.png","DAYS_ES_02.png","DAYS_ES_03.png","DAYS_ES_04.png","DAYS_ES_05.png","DAYS_ES_06.png","DAYS_ES_07.png"],
              week_sc: ["DAYS_ES_01.png","DAYS_ES_02.png","DAYS_ES_03.png","DAYS_ES_04.png","DAYS_ES_05.png","DAYS_ES_06.png","DAYS_ES_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 318,
              day_startY: 241,
              day_sc_array: ["MEDIUMNUMBERS_0.png","MEDIUMNUMBERS_1.png","MEDIUMNUMBERS_2.png","MEDIUMNUMBERS_3.png","MEDIUMNUMBERS_4.png","MEDIUMNUMBERS_5.png","MEDIUMNUMBERS_6.png","MEDIUMNUMBERS_7.png","MEDIUMNUMBERS_8.png","MEDIUMNUMBERS_9.png"],
              day_tc_array: ["MEDIUMNUMBERS_0.png","MEDIUMNUMBERS_1.png","MEDIUMNUMBERS_2.png","MEDIUMNUMBERS_3.png","MEDIUMNUMBERS_4.png","MEDIUMNUMBERS_5.png","MEDIUMNUMBERS_6.png","MEDIUMNUMBERS_7.png","MEDIUMNUMBERS_8.png","MEDIUMNUMBERS_9.png"],
              day_en_array: ["MEDIUMNUMBERS_0.png","MEDIUMNUMBERS_1.png","MEDIUMNUMBERS_2.png","MEDIUMNUMBERS_3.png","MEDIUMNUMBERS_4.png","MEDIUMNUMBERS_5.png","MEDIUMNUMBERS_6.png","MEDIUMNUMBERS_7.png","MEDIUMNUMBERS_8.png","MEDIUMNUMBERS_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 288,
              y: 376,
              font_array: ["SMALLNUMBERS_0.png","SMALLNUMBERS_1.png","SMALLNUMBERS_2.png","SMALLNUMBERS_3.png","SMALLNUMBERS_4.png","SMALLNUMBERS_5.png","SMALLNUMBERS_6.png","SMALLNUMBERS_7.png","SMALLNUMBERS_8.png","SMALLNUMBERS_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 56,
              y: 376,
              font_array: ["SMALLNUMBERS_0.png","SMALLNUMBERS_1.png","SMALLNUMBERS_2.png","SMALLNUMBERS_3.png","SMALLNUMBERS_4.png","SMALLNUMBERS_5.png","SMALLNUMBERS_6.png","SMALLNUMBERS_7.png","SMALLNUMBERS_8.png","SMALLNUMBERS_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 164,
              y: 376,
              font_array: ["SMALLNUMBERS_0.png","SMALLNUMBERS_1.png","SMALLNUMBERS_2.png","SMALLNUMBERS_3.png","SMALLNUMBERS_4.png","SMALLNUMBERS_5.png","SMALLNUMBERS_6.png","SMALLNUMBERS_7.png","SMALLNUMBERS_8.png","SMALLNUMBERS_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 161,
              hour_array: ["CLOCKNUMBERS_0.png","CLOCKNUMBERS_1.png","CLOCKNUMBERS_2.png","CLOCKNUMBERS_3.png","CLOCKNUMBERS_4.png","CLOCKNUMBERS_5.png","CLOCKNUMBERS_6.png","CLOCKNUMBERS_7.png","CLOCKNUMBERS_8.png","CLOCKNUMBERS_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 20,
              minute_startY: 25,
              minute_array: ["CLOCKNUMBERS_0.png","CLOCKNUMBERS_1.png","CLOCKNUMBERS_2.png","CLOCKNUMBERS_3.png","CLOCKNUMBERS_4.png","CLOCKNUMBERS_5.png","CLOCKNUMBERS_6.png","CLOCKNUMBERS_7.png","CLOCKNUMBERS_8.png","CLOCKNUMBERS_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 266,
              y: 322,
              w: 100,
              h: 100,
              src: 'BIG_BUTTON.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 19,
              y: 26,
              w: 213,
              h: 129,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BIG_BUTTON.png',
              normal_src: 'BIG_BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 19,
              y: 162,
              w: 213,
              h: 129,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BIG_BUTTON.png',
              normal_src: 'BIG_BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 293,
              y: 198,
              w: 88,
              h: 93,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BIG_BUTTON.png',
              normal_src: 'BIG_BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 26,
              y: 319,
              w: 98,
              h: 102,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BIG_BUTTON.png',
              normal_src: 'BIG_BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 146,
              y: 321,
              w: 98,
              h: 102,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BIG_BUTTON.png',
              normal_src: 'BIG_BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}