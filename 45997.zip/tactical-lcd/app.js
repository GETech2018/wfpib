App({
  globalData: {},
  onCreate() {},
  onDestroy() {},
});
