# Tactical LCD — Amazfit Bip Max watch face

Zepp OS watch face project built from your skin, at the Bip Max's native
432 × 514 resolution (deviceSource 11206915).

## What's live on the face
| Area | Shows |
|---|---|
| Analog hands | hour / minute / sweeping red second hand |
| Top box | month name (JAN … DEC) |
| Left LCD panel | steps today |
| Right LCD panel | current temperature + weather icon |
| Centre column | heart rate |
| Info strip | STAND current/goal · SPO2 · POWER (battery %) |
| Bottom LCD | date (MM-DD) and time HH:MM:SS |
| Bottom row | weekday, today highlighted |
| Always-on display | dimmed bezel, outlined hands, HH:MM |

Tap steps, weather, heart rate, SpO2 or battery to open that app.

## Install on the watch

You need a computer with Node.js 18+ and your phone with the Zepp app.

1. Install the Zepp OS command-line tool:
   ```
   npm i -g @zeppos/zeus-cli
   ```
2. In the Zepp app, turn on **Developer Mode** (see Zepp's docs: "Zepp App –
   Developer Mode").
3. Open a terminal in this folder and run:
   ```
   zeus login
   zeus preview
   ```
   Choose the `bipmax` target. A QR code appears.
4. In the Zepp app, open Developer Mode → **Scan** and scan the QR code. The
   watch face installs on the watch; select it from the watch face list.

To get an installable package file instead, run `zeus build`; the `.zab`
appears in `dist/`.

## Customising
- **Date order**: in `watchface/index.js` set `DATE_DAY_FIRST = true` for DD-MM.
- **Positions**: every coordinate is in the `LAYOUT` object at the top of
  `watchface/index.js` (pixels on the 432 × 514 screen).
- **Graphics**: all images are PNGs in `assets/bipmax/` — replace any of them
  with same-size images. `bg.png` is the static background.

## If the install fails
Some developers have reported "Send package to device failed" when sideloading
onto the Bip Max via `zeus preview`. If you hit that, update the Zepp app and
watch firmware and retry. As a fallback, the images in `assets/bipmax/` can be
loaded into Zepp's online Watchface Maker (choose Amazfit Bip Max) and placed
using the coordinates in `LAYOUT`.

Digit/label glyphs were rendered from Barlow Condensed (SIL Open Font License,
see `OFL.txt`).
