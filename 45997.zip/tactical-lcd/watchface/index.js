/*
 * Tactical LCD — hybrid analog + LCD watch face for Amazfit Bip Max
 * Screen 432 x 514 (designWidth 432, so all coordinates are native pixels).
 *
 * Everything that changes (hands, month, steps, temperature + icon, heart
 * rate, stand, SpO2, battery, date, time, weekday) is drawn live on top of a
 * static background. Edit the numbers in LAYOUT to move things around.
 */

const NORMAL = hmUI.show_level.ONLY_NORMAL;
const AOD = hmUI.show_level.ONLY_AOD;

// Set to true to show the date as DD-MM instead of MM-DD.
const DATE_DAY_FIRST = false;

const LAYOUT = {
  center: { x: 217, y: 204 },
  hands: {
    hour: { path: 'hands/hour.png', posX: 10, posY: 118 },
    minute: { path: 'hands/minute.png', posX: 9, posY: 152 },
    second: { path: 'hands/second.png', posX: 6, posY: 142 },
    cap: { path: 'hands/cap.png', size: 40 },
  },
  month: { x: 184, y: 120 },
  steps: { x: 25, y: 242, w: 120, h: 32 },
  temp: { x: 287, y: 242, w: 120, h: 32 },
  weatherIcon: { x: 325, y: 292 },
  heart: { x: 166, y: 256, w: 100, h: 37 },
  strip: { y: 341, h: 23 },
  stand: { x: 95, w: 21, slashX: 117, targetX: 126 },
  spo2: { x: 229, w: 50 },
  power: { x: 365, w: 50 },
  date: { y: 418, firstX: 40, secondX: 91, space: 2 },
  time: { y: 388, hourX: 140, minuteX: 233, secondX: 326, space: 3 },
  week: { x: 136, y: 479 },
};

const range = (n) => Array.from({ length: n }, (_, i) => i);
const digits = (dir) => range(10).map((i) => `${dir}/${i}.png`);

const LCD_L = digits('lcd_l');
const LCD_L_AOD = digits('aod/lcd_l');
const LCD_M = digits('lcd_m');
const HR = digits('hr');
const SMALL = digits('small');
const MONTHS = range(12).map((i) => `month/${i}.png`);
const WEEK = range(7).map((i) => `week/${i}.png`);
const WEATHER = range(29).map((i) => `weather/${i}.png`);

WatchFace({
  build() {
    this.buildNormal();
    this.buildAod();
  },

  // ------------------------------------------------------------------ normal
  buildNormal() {
    hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, src: 'bg.png', show_level: NORMAL });

    // month name in the top box (FEB)
    hmUI.createWidget(hmUI.widget.IMG_DATE, {
      month_startX: LAYOUT.month.x,
      month_startY: LAYOUT.month.y,
      month_en_array: MONTHS,
      month_sc_array: MONTHS,
      month_tc_array: MONTHS,
      month_is_character: true,
      show_level: NORMAL,
    });

    // steps (left LCD panel)
    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      ...LAYOUT.steps,
      font_array: LCD_M,
      h_space: 2,
      align_h: hmUI.align.CENTER_H,
      type: hmUI.data_type.STEP,
      show_level: NORMAL,
    });

    // temperature + condition icon (right LCD panel)
    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      ...LAYOUT.temp,
      font_array: LCD_M,
      h_space: 2,
      align_h: hmUI.align.CENTER_H,
      type: hmUI.data_type.WEATHER_CURRENT,
      negative_image: 'lcd_m/minus.png',
      invalid_image: 'lcd_m/none.png',
      unit_en: 'lcd_m/degree.png',
      unit_sc: 'lcd_m/degree.png',
      unit_tc: 'lcd_m/degree.png',
      show_level: NORMAL,
    });
    hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
      x: LAYOUT.weatherIcon.x,
      y: LAYOUT.weatherIcon.y,
      image_array: WEATHER,
      image_length: WEATHER.length,
      type: hmUI.data_type.WEATHER_CURRENT,
      show_level: NORMAL,
    });

    // heart rate (centre column)
    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      ...LAYOUT.heart,
      font_array: HR,
      h_space: 1,
      align_h: hmUI.align.CENTER_H,
      type: hmUI.data_type.HEART,
      invalid_image: 'hr/none.png',
      show_level: NORMAL,
    });

    this.buildStrip();
    this.buildDate();

    // big LCD time, colons are part of the background
    hmUI.createWidget(hmUI.widget.IMG_TIME, {
      hour_zero: 1,
      hour_startX: LAYOUT.time.hourX,
      hour_startY: LAYOUT.time.y,
      hour_array: LCD_L,
      hour_space: LAYOUT.time.space,
      hour_align: hmUI.align.LEFT,
      minute_zero: 1,
      minute_startX: LAYOUT.time.minuteX,
      minute_startY: LAYOUT.time.y,
      minute_array: LCD_L,
      minute_space: LAYOUT.time.space,
      minute_align: hmUI.align.LEFT,
      minute_follow: 0,
      second_zero: 1,
      second_startX: LAYOUT.time.secondX,
      second_startY: LAYOUT.time.y,
      second_array: LCD_L,
      second_space: LAYOUT.time.space,
      second_align: hmUI.align.LEFT,
      second_follow: 0,
      show_level: NORMAL,
    });

    // weekday row, current day highlighted
    hmUI.createWidget(hmUI.widget.IMG_WEEK, {
      x: LAYOUT.week.x,
      y: LAYOUT.week.y,
      week_en: WEEK,
      week_sc: WEEK,
      week_tc: WEEK,
      show_level: NORMAL,
    });

    // analog hands (drawn last so they sit above the panels)
    const c = LAYOUT.center;
    const h = LAYOUT.hands;
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      hour_centerX: c.x,
      hour_centerY: c.y,
      hour_posX: h.hour.posX,
      hour_posY: h.hour.posY,
      hour_path: h.hour.path,
      minute_centerX: c.x,
      minute_centerY: c.y,
      minute_posX: h.minute.posX,
      minute_posY: h.minute.posY,
      minute_path: h.minute.path,
      second_centerX: c.x,
      second_centerY: c.y,
      second_posX: h.second.posX,
      second_posY: h.second.posY,
      second_path: h.second.path,
      second_cover_path: h.cap.path,
      second_cover_x: c.x - h.cap.size / 2,
      second_cover_y: c.y - h.cap.size / 2,
      show_level: NORMAL,
    });

    this.buildTapZones();
  },

  buildStrip() {
    const y = LAYOUT.strip.y;
    const hgt = LAYOUT.strip.h;

    // STAND: current / goal
    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      x: LAYOUT.stand.x,
      y,
      w: LAYOUT.stand.w,
      h: hgt,
      font_array: SMALL,
      h_space: 1,
      align_h: hmUI.align.RIGHT,
      type: hmUI.data_type.STAND,
      show_level: NORMAL,
    });
    hmUI.createWidget(hmUI.widget.IMG, { x: LAYOUT.stand.slashX, y, src: 'small/slash.png', show_level: NORMAL });
    const standTarget = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      x: LAYOUT.stand.targetX,
      y,
      w: 30,
      h: hgt,
      font_array: SMALL,
      h_space: 1,
      align_h: hmUI.align.LEFT,
      text: '12',
      show_level: NORMAL,
    });
    let standSensor = null;
    try {
      standSensor = hmSensor.createSensor(hmSensor.id.STAND);
    } catch (e) {
      standSensor = null;
    }
    const updateStandTarget = () => {
      const target = standSensor && standSensor.target ? standSensor.target : 12;
      standTarget.setProperty(hmUI.prop.TEXT, String(target));
    };
    hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, { resume_call: updateStandTarget });
    updateStandTarget();

    // SpO2
    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      x: LAYOUT.spo2.x,
      y,
      w: LAYOUT.spo2.w,
      h: hgt,
      font_array: SMALL,
      h_space: 1,
      align_h: hmUI.align.LEFT,
      type: hmUI.data_type.SPO2,
      invalid_image: 'small/none.png',
      show_level: NORMAL,
    });

    // POWER (battery %)
    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      x: LAYOUT.power.x,
      y,
      w: LAYOUT.power.w,
      h: hgt,
      font_array: SMALL,
      h_space: 0,
      align_h: hmUI.align.LEFT,
      type: hmUI.data_type.BATTERY,
      show_level: NORMAL,
    });
  },

  buildDate() {
    const d = LAYOUT.date;
    const monthX = DATE_DAY_FIRST ? d.secondX : d.firstX;
    const dayX = DATE_DAY_FIRST ? d.firstX : d.secondX;
    hmUI.createWidget(hmUI.widget.IMG_DATE, {
      month_startX: monthX,
      month_startY: d.y,
      month_en_array: LCD_M,
      month_sc_array: LCD_M,
      month_tc_array: LCD_M,
      month_zero: 1,
      month_space: d.space,
      month_is_character: false,
      day_startX: dayX,
      day_startY: d.y,
      day_en_array: LCD_M,
      day_sc_array: LCD_M,
      day_tc_array: LCD_M,
      day_zero: 1,
      day_space: d.space,
      day_follow: 0,
      show_level: NORMAL,
    });
  },

  // Tap a value to open its app.
  buildTapZones() {
    const zone = (x, y, w, h, type) =>
      hmUI.createWidget(hmUI.widget.IMG_CLICK, { x, y, w, h, src: 'click.png', type, show_level: NORMAL });
    zone(22, 228, 128, 104, hmUI.data_type.STEP);
    zone(282, 228, 128, 104, hmUI.data_type.WEATHER_CURRENT);
    zone(160, 245, 112, 85, hmUI.data_type.HEART);
    zone(200, 336, 80, 32, hmUI.data_type.SPO2);
    zone(300, 336, 110, 32, hmUI.data_type.BATTERY);
  },

  // ----------------------------------------------------- always-on display
  buildAod() {
    hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, src: 'aod/bg.png', show_level: AOD });

    hmUI.createWidget(hmUI.widget.IMG_TIME, {
      hour_zero: 1,
      hour_startX: LAYOUT.time.hourX,
      hour_startY: LAYOUT.time.y,
      hour_array: LCD_L_AOD,
      hour_space: LAYOUT.time.space,
      hour_align: hmUI.align.LEFT,
      minute_zero: 1,
      minute_startX: LAYOUT.time.minuteX,
      minute_startY: LAYOUT.time.y,
      minute_array: LCD_L_AOD,
      minute_space: LAYOUT.time.space,
      minute_align: hmUI.align.LEFT,
      minute_follow: 0,
      show_level: AOD,
    });

    const c = LAYOUT.center;
    const h = LAYOUT.hands;
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      hour_centerX: c.x,
      hour_centerY: c.y,
      hour_posX: h.hour.posX,
      hour_posY: h.hour.posY,
      hour_path: 'aod/hour.png',
      minute_centerX: c.x,
      minute_centerY: c.y,
      minute_posX: h.minute.posX,
      minute_posY: h.minute.posY,
      minute_path: 'aod/minute.png',
      minute_cover_path: 'aod/cap.png',
      minute_cover_x: c.x - h.cap.size / 2,
      minute_cover_y: c.y - h.cap.size / 2,
      show_level: AOD,
    });
  },

  onInit() {},
  onDestroy() {},
});
