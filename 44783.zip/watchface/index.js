﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let ButtonNumber = '';
let  ButtonBackSpace = '';
let ButtonToggleSign = '';
let ButtonClear = '';
let display = '';
let cc = 0;

  // Calculator
        let elementnumber_1 = 1
        let total_elemente = 2

        function Calculator() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Calculator OFF'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Calculator ON'});
        }

        //Calculator OFF
        function UpdateElementeOne(){

        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, true);

        normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        Button_2 .setProperty(hmUI.prop.VISIBLE, true);
        Button_3.setProperty(hmUI.prop.VISIBLE, true);
        Button_4.setProperty(hmUI.prop.VISIBLE, true);



ButtonNumber.setProperty(hmUI.prop.VISIBLE, false);
ButtonBackSpace.setProperty(hmUI.prop.VISIBLE, false);
ButtonToggleSign.setProperty(hmUI.prop.VISIBLE, false);
ButtonClear.setProperty(hmUI.prop.VISIBLE, false);
display.setProperty(hmUI.prop.VISIBLE, false);



 normal_background_bg_img.setProperty(hmUI.prop.SRC, "2.png");


        }

        //Calculator ON
        function UpdateElementeTwo(){
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        Button_2 .setProperty(hmUI.prop.VISIBLE, false);
        Button_3.setProperty(hmUI.prop.VISIBLE, false);
        Button_4.setProperty(hmUI.prop.VISIBLE, false);


ButtonNumber.setProperty(hmUI.prop.VISIBLE, true);
ButtonBackSpace.setProperty(hmUI.prop.VISIBLE, true);
ButtonToggleSign.setProperty(hmUI.prop.VISIBLE, true);
ButtonClear.setProperty(hmUI.prop.VISIBLE, true);
display.setProperty(hmUI.prop.VISIBLE, true);



 normal_background_bg_img.setProperty(hmUI.prop.SRC, "CalculatorScreen.png");

        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_cal_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 320,
              h: 369,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 184,
              y: 66,
              image_array: ["Weather_image_B_01.png","Weather_image_B_02.png","Weather_image_B_03.png","Weather_image_B_04.png","Weather_image_B_05.png","Weather_image_B_06.png","Weather_image_B_07.png","Weather_image_B_08.png","Weather_image_B_09.png","Weather_image_B_10.png","Weather_image_B_11.png","Weather_image_B_12.png","Weather_image_B_13.png","Weather_image_B_14.png","Weather_image_B_15.png","Weather_image_B_16.png","Weather_image_B_17.png","Weather_image_B_18.png","Weather_image_B_19.png","Weather_image_B_20.png","Weather_image_B_21.png","Weather_image_B_22.png","Weather_image_B_23.png","Weather_image_B_24.png","Weather_image_B_25.png","Weather_image_B_26.png","Weather_image_B_27.png","Weather_image_B_28.png","Weather_image_B_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
// ===== CASIO Calculator Layout (MATCH IMAGE) =====
//let ButtonNumber = '';
//let  ButtonBackSpace = '';
// let ButtonClear = '';
// let ButtonToggleSign = '';

// ===== CASIO Calculator Layout (MATCH IMAGE) =====

// ===== Display =====
display = hmUI.createWidget(hmUI.widget.TEXT, {
  x: 49,
  y: 72,
  w: 222,
  h: 72,
  text: "0",
  text_size: 54,
  color: 0x000000
});

// ===== State =====
let current = "";
let previous = "";
let operator = "";
let justCalculated = false;

// 🔥 เพิ่ม (สำหรับ = ซ้ำ)
let lastOperator = "";
let lastValue = "";

// ===== Update =====
function update() {
  let text = "0";

  if (current !== "") {
    text = current;
  } else if (previous !== "") {
    text = previous;
  }

  display.setProperty(hmUI.prop.TEXT, text);
}

// ===== Compute =====
function compute() {
  if (current === "" || previous === "") return;

  let a = parseFloat(previous);
  let b = parseFloat(current);
  let r = 0;

  switch (operator) {
    case "+": r = a + b; break;
    case "-": r = a - b; break;
    case "*": r = a * b; break;
    case "/": r = b !== 0 ? a / b : 0; break;
  }

  if (isNaN(r)) r = 0;

  r = Math.round(r * 1000) / 1000;
  current = r.toFixed(3);
}

// ===== Input =====
function press(n) {

  if (justCalculated) {
    current = "";
    justCalculated = false;
  }

  if (n === ".") {
    if (current.indexOf(".") !== -1) return;

    if (current === "") {
      current = "0.";
      update();
      return;
    }
  }

  current += n;
  update();
}

// ===== 🔥 เพิ่ม +/- =====
function toggleSign() {
  if (current === "") return;

  if (current.startsWith("-")) {
    current = current.substring(1);
  } else {
    current = "-" + current;
  }

  update();
}

// ===== Operator =====
function setOp(op) {

  if (previous !== "" && current !== "") {
    compute();
    previous = current;
    current = "";
  } 
  else if (current !== "") {
    previous = current;
    current = "";
  }

  operator = op;
  justCalculated = false;
  update();
}

// ===== = (เพิ่ม repeat) =====
function calc() {

  // 🔥 กด = ซ้ำ
  if (current === "" && previous !== "" && lastOperator !== "") {

    let a = parseFloat(previous);
    let b = parseFloat(lastValue);
    let r = 0;

    switch (lastOperator) {
      case "+": r = a + b; break;
      case "-": r = a - b; break;
      case "*": r = a * b; break;
      case "/": r = b !== 0 ? a / b : 0; break;
    }

    r = Math.round(r * 1000) / 1000;

    previous = r.toFixed(3); // 👈 สำคัญ
    current = "";

    update();
    return;
  }

  // 🔥 กด = ครั้งแรก
  if (current === "" || previous === "") return;

  lastOperator = operator;
  lastValue = current;

  // 👇 คำนวณเอง (ไม่ใช้ compute เดิม)
  let a = parseFloat(previous);
  let b = parseFloat(current);
  let r = 0;

  switch (operator) {
    case "+": r = a + b; break;
    case "-": r = a - b; break;
    case "*": r = a * b; break;
    case "/": r = b !== 0 ? a / b : 0; break;
  }

  r = Math.round(r * 1000) / 1000;

  previous = r.toFixed(3); // 👈 ใส่ตรงนี้แทน
  current = "";
  operator = "";
  justCalculated = true;

  update();
}

// ===== Clear =====
function clearAll() {
  current = "";
  previous = "";
  operator = "";
  lastOperator = "";
  lastValue = "";
  justCalculated = false;
  update();
}

// ===== Backspace =====
function backspace() {
  if (justCalculated) return;

  if (current.length > 0) {
    current = current.slice(0, -1);
  }
  update();
}

// ===== Button =====
let touch = function(x, y, w, h, fn) {
  ButtonNumber = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: x,
    y: y,
    w: w,
    h: h,
    text: ' ',
    normal_src: '0_Empty.png',
    press_src: '0_Empty2.png',
    click_func: fn,
    show_level: hmUI.show_level.ONLY_NORMAL
  });
};

//  Backspace / Clear/ toggleSign
ButtonBackSpace = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 12,
  y: 95,
  w: 30,
  h: 20,
  text: ' ',
  normal_src: '0_Empty.png',
  press_src: '0_Empty3.png',
  click_func: backspace,
  show_level: hmUI.show_level.ONLY_NORMAL
});

ButtonClear = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 12,
  y: 62,
  w: 30,
  h: 20,
  text: ' ',
  normal_src: '0_Empty.png',
  press_src: '0_Empty3.png',
  click_func: clearAll,
  show_level: hmUI.show_level.ONLY_NORMAL
});


ButtonToggleSign = hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 12,
  y: 127,
  w: 30,
  h: 20,
  text: ' ',
  normal_src: '0_Empty.png',
  press_src: '0_Empty3.png',
  click_func: toggleSign,
  show_level: hmUI.show_level.ONLY_NORMAL
});



// ===== Layout =====
let sx = 44;
let sy = 197;
let gx = 66;
let gy = 39;
let w = 43;
let h = 22;

// Row 1
touch(sx+gx*0, sy+gy*0, w, h, () => press("7"));
touch(sx+gx*1, sy+gy*0, w, h, () => press("8"));
touch(sx+gx*2, sy+gy*0, w, h, () => press("9"));
touch(sx+gx*3, sy+gy*0, w, h, () => setOp("/"));

// Row 2
touch(sx+gx*0, sy+gy*1, w, h, () => press("4"));
touch(sx+gx*1, sy+gy*1, w, h, () => press("5"));
touch(sx+gx*2, sy+gy*1, w, h, () => press("6"));
touch(sx+gx*3, sy+gy*1, w, h, () => setOp("*"));

// Row 3
touch(sx+gx*0, sy+gy*2, w, h, () => press("1"));
touch(sx+gx*1, sy+gy*2, w, h, () => press("2"));
touch(sx+gx*2, sy+gy*2, w, h, () => press("3"));
touch(sx+gx*3, sy+gy*2, w, h, () => setOp("-"));

// Row 4
touch(sx+gx*0, sy+gy*3, w, h, () => press("0"));
touch(sx+gx*1, sy+gy*3, w, h, () => press("."));
touch(sx+gx*2, sy+gy*3, w, h, calc);
touch(sx+gx*3, sy+gy*3, w, h, () => setOp("+"));
            // end user_script.js

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 88,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 251,
              y: 89,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 128,
              month_startY: 67,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 97,
              day_startY: 66,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 50,
              y: 67,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 67,
              font_array: ["Batt_0.png","Batt_1.png","Batt_2.png","Batt_3.png","Batt_4.png","Batt_5.png","Batt_6.png","Batt_7.png","Batt_8.png","Batt_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 217,
              y: 69,
              image_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 222,
              second_startY: 108,
              second_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              second_zero: 1,
              second_space: 5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 140,
              minute_startY: 89,
              minute_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 89,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 118,
              y: 95,
              src: '13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 320,
              h: 369,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 184,
              y: 66,
              image_array: ["Weather_image_B_01.png","Weather_image_B_02.png","Weather_image_B_03.png","Weather_image_B_04.png","Weather_image_B_05.png","Weather_image_B_06.png","Weather_image_B_07.png","Weather_image_B_08.png","Weather_image_B_09.png","Weather_image_B_10.png","Weather_image_B_11.png","Weather_image_B_12.png","Weather_image_B_13.png","Weather_image_B_14.png","Weather_image_B_15.png","Weather_image_B_16.png","Weather_image_B_17.png","Weather_image_B_18.png","Weather_image_B_19.png","Weather_image_B_20.png","Weather_image_B_21.png","Weather_image_B_22.png","Weather_image_B_23.png","Weather_image_B_24.png","Weather_image_B_25.png","Weather_image_B_26.png","Weather_image_B_27.png","Weather_image_B_28.png","Weather_image_B_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 88,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 251,
              y: 89,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 128,
              month_startY: 67,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 97,
              day_startY: 66,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 50,
              y: 67,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 67,
              font_array: ["Batt_0.png","Batt_1.png","Batt_2.png","Batt_3.png","Batt_4.png","Batt_5.png","Batt_6.png","Batt_7.png","Batt_8.png","Batt_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 217,
              y: 69,
              image_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 140,
              minute_startY: 89,
              minute_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 89,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 118,
              y: 95,
              src: '13.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 286,
              y: 53,
              w: 33,
              h: 53,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 179,
              y: 63,
              w: 27,
              h: 23,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 226,
              y: 110,
              w: 36,
              h: 34,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 120,
              y: 97,
              w: 21,
              h: 49,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 287,
              y: 117,
              w: 32,
              h: 43,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 34,
              y: 16,
              w: 81,
              h: 32,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: '0_Empty3.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                Calculator()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 214,
              y: 65,
              w: 54,
              h: 21,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: '0_Empty3.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 53,
              y: 66,
              w: 84,
              h: 20,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: '0_Empty3.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 222,
              y: 21,
              w: 62,
              h: 25,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: '0_Empty3.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if ( cc == 0) {
UpdateElementeOne()
cc =1
}
            // end user_script_end.js


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}