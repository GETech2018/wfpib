﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_stand_icon_img = ''
        let normal_stand_circle_scale = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_step_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_uvi_text_text_img = ''
        let normal_aqi_text_text_img = ''
        let normal_wind_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_stand_icon_img = ''
        let idle_stand_circle_scale = ''
        let idle_calorie_icon_img = ''
        let idle_calorie_circle_scale = ''
        let idle_step_icon_img = ''
        let idle_step_circle_scale = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_icon_img = ''
        let idle_uvi_text_text_img = ''
        let idle_aqi_text_text_img = ''
        let idle_wind_text_text_img = ''
        let idle_humidity_text_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 303,
              y: 363,
              src: 'Ring stand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 324,
              // center_y: 384,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 21,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFF00D5D5,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 324,
              center_y: 384,
              start_angle: 0,
              end_angle: 360,
              radius: 16,
              line_width: 10,
              corner_flag: 0,
              color: 0xFF00D5D5,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 291,
              y: 351,
              src: 'Ring calories.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 324,
              // center_y: 384,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 33,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFF00F700,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 324,
              center_y: 384,
              start_angle: 0,
              end_angle: 360,
              radius: 28,
              line_width: 10,
              corner_flag: 0,
              color: 0xFF00F700,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 339,
              src: 'Ring steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 324,
              // center_y: 384,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 45,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFFFD0241,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 324,
              center_y: 384,
              start_angle: 0,
              end_angle: 360,
              radius: 41,
              line_width: 9,
              corner_flag: 0,
              color: 0xFFFD0241,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 43,
              y: 372,
              font_array: ["date-0_0.png","date-0_1.png","date-0_2.png","date-0_3.png","date-0_4.png","date-0_5.png","date-0_6.png","date-0_7.png","date-0_8.png","date-0_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 29,
              y: 339,
              image_array: ["img_arr_0002_00.png","img_arr_0002_01.png","img_arr_0002_02.png","img_arr_0002_03.png","img_arr_0002_04.png","img_arr_0002_05.png","img_arr_0002_06.png","img_arr_0002_07.png","img_arr_0002_08.png","img_arr_0002_09.png","img_arr_0002_10.png","img_arr_0002_11.png","img_arr_0002_12.png","img_arr_0002_13.png","img_arr_0002_14.png","img_arr_0002_15.png"],
              image_length: 16,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 154,
              y: 339,
              src: 'img_0021.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 301,
              y: 248,
              font_array: ["temp-0_0.png","temp-0_1.png","temp-0_2.png","temp-0_3.png","temp-0_4.png","temp-0_5.png","temp-0_6.png","temp-0_7.png","temp-0_8.png","temp-0_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_aqi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 232,
              y: 248,
              font_array: ["temp-0_0.png","temp-0_1.png","temp-0_2.png","temp-0_3.png","temp-0_4.png","temp-0_5.png","temp-0_6.png","temp-0_7.png","temp-0_8.png","temp-0_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 248,
              font_array: ["temp-0_0.png","temp-0_1.png","temp-0_2.png","temp-0_3.png","temp-0_4.png","temp-0_5.png","temp-0_6.png","temp-0_7.png","temp-0_8.png","temp-0_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 248,
              font_array: ["temp-0_0.png","temp-0_1.png","temp-0_2.png","temp-0_3.png","temp-0_4.png","temp-0_5.png","temp-0_6.png","temp-0_7.png","temp-0_8.png","temp-0_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 55,
              y: 242,
              image_array: ["WEATHERICON_1.png","WEATHERICON_2.png","WEATHERICON_3.png","WEATHERICON_4.png","WEATHERICON_5.png","WEATHERICON_6.png","WEATHERICON_7.png","WEATHERICON_8.png","WEATHERICON_9.png","WEATHERICON_10.png","WEATHERICON_11.png","WEATHERICON_12.png","WEATHERICON_13.png","WEATHERICON_14.png","WEATHERICON_15.png","WEATHERICON_16.png","WEATHERICON_17.png","WEATHERICON_18.png","WEATHERICON_19.png","WEATHERICON_20.png","WEATHERICON_21.png","WEATHERICON_22.png","WEATHERICON_23.png","WEATHERICON_24.png","WEATHERICON_25.png","WEATHERICON_26.png","WEATHERICON_27.png","WEATHERICON_28.png","WEATHERICON_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 87,
              y: 174,
              font_array: ["temp-max-0_0.png","temp-max-0_1.png","temp-max-0_2.png","temp-max-0_3.png","temp-max-0_4.png","temp-max-0_5.png","temp-max-0_6.png","temp-max-0_7.png","temp-max-0_8.png","temp-max-0_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'temp-max-0_arrowH.png',
              unit_tc: 'temp-max-0_arrowH.png',
              unit_en: 'temp-max-0_arrowH.png',
              negative_image: 'temp-max-0_negative-sign.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 174,
              font_array: ["temp-max-0_0.png","temp-max-0_1.png","temp-max-0_2.png","temp-max-0_3.png","temp-max-0_4.png","temp-max-0_5.png","temp-max-0_6.png","temp-max-0_7.png","temp-max-0_8.png","temp-max-0_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'temp-max-0_arrowL.png',
              unit_tc: 'temp-max-0_arrowL.png',
              unit_en: 'temp-max-0_arrowL.png',
              negative_image: 'temp-max-0_negative-sign.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 22,
              y: 174,
              font_array: ["temp-0_0.png","temp-0_1.png","temp-0_2.png","temp-0_3.png","temp-0_4.png","temp-0_5.png","temp-0_6.png","temp-0_7.png","temp-0_8.png","temp-0_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'temp-0_degree.png',
              unit_tc: 'temp-0_degree.png',
              unit_en: 'temp-0_degree.png',
              negative_image: 'temp-0_negative-sign.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 28,
              y: 72,
              image_array: ["img_arr_0005_00.png","img_arr_0005_01.png","img_arr_0005_02.png","img_arr_0005_03.png","img_arr_0005_04.png","img_arr_0005_05.png","img_arr_0005_06.png","img_arr_0005_07.png","img_arr_0005_08.png","img_arr_0005_09.png","img_arr_0005_10.png","img_arr_0005_11.png","img_arr_0005_12.png","img_arr_0005_13.png","img_arr_0005_14.png","img_arr_0005_15.png","img_arr_0005_16.png","img_arr_0005_17.png","img_arr_0005_18.png","img_arr_0005_19.png","img_arr_0005_20.png","img_arr_0005_21.png","img_arr_0005_22.png","img_arr_0005_23.png","img_arr_0005_24.png","img_arr_0005_25.png","img_arr_0005_26.png","img_arr_0005_27.png","img_arr_0005_28.png","img_arr_0005_29.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 221,
              y: 17,
              week_en: ["dias_1.png","dias_2.png","dias_3.png","dias_4.png","dias_5.png","dias_6.png","dias_7.png"],
              week_tc: ["dias_1.png","dias_2.png","dias_3.png","dias_4.png","dias_5.png","dias_6.png","dias_7.png"],
              week_sc: ["dias_1.png","dias_2.png","dias_3.png","dias_4.png","dias_5.png","dias_6.png","dias_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 318,
              day_startY: 31,
              day_sc_array: ["date-0_0.png","date-0_1.png","date-0_2.png","date-0_3.png","date-0_4.png","date-0_5.png","date-0_6.png","date-0_7.png","date-0_8.png","date-0_9.png"],
              day_tc_array: ["date-0_0.png","date-0_1.png","date-0_2.png","date-0_3.png","date-0_4.png","date-0_5.png","date-0_6.png","date-0_7.png","date-0_8.png","date-0_9.png"],
              day_en_array: ["date-0_0.png","date-0_1.png","date-0_2.png","date-0_3.png","date-0_4.png","date-0_5.png","date-0_6.png","date-0_7.png","date-0_8.png","date-0_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 140,
              hour_startY: 81,
              hour_array: ["img_arr_0000_00.png","img_arr_0000_01.png","img_arr_0000_02.png","img_arr_0000_03.png","img_arr_0000_04.png","img_arr_0000_05.png","img_arr_0000_06.png","img_arr_0000_07.png","img_arr_0000_08.png","img_arr_0000_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 262,
              minute_startY: 81,
              minute_array: ["img_arr_0000_00.png","img_arr_0000_01.png","img_arr_0000_02.png","img_arr_0000_03.png","img_arr_0000_04.png","img_arr_0000_05.png","img_arr_0000_06.png","img_arr_0000_07.png","img_arr_0000_08.png","img_arr_0000_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 245,
              y: 95,
              src: 'dos puntos.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 303,
              y: 363,
              src: 'Ring stand.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 324,
              // center_y: 384,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 21,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFF00D5D5,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 324,
              center_y: 384,
              start_angle: 0,
              end_angle: 360,
              radius: 16,
              line_width: 10,
              corner_flag: 0,
              color: 0xFF00D5D5,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 291,
              y: 351,
              src: 'Ring calories.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 324,
              // center_y: 384,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 33,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFF00F700,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 324,
              center_y: 384,
              start_angle: 0,
              end_angle: 360,
              radius: 28,
              line_width: 10,
              corner_flag: 0,
              color: 0xFF00F700,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 339,
              src: 'Ring steps.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 324,
              // center_y: 384,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 45,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFFFD0241,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 324,
              center_y: 384,
              start_angle: 0,
              end_angle: 360,
              radius: 41,
              line_width: 9,
              corner_flag: 0,
              color: 0xFFFD0241,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 43,
              y: 372,
              font_array: ["date-0_0.png","date-0_1.png","date-0_2.png","date-0_3.png","date-0_4.png","date-0_5.png","date-0_6.png","date-0_7.png","date-0_8.png","date-0_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 29,
              y: 339,
              image_array: ["img_arr_0002_00.png","img_arr_0002_01.png","img_arr_0002_02.png","img_arr_0002_03.png","img_arr_0002_04.png","img_arr_0002_05.png","img_arr_0002_06.png","img_arr_0002_07.png","img_arr_0002_08.png","img_arr_0002_09.png","img_arr_0002_10.png","img_arr_0002_11.png","img_arr_0002_12.png","img_arr_0002_13.png","img_arr_0002_14.png","img_arr_0002_15.png"],
              image_length: 16,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 154,
              y: 339,
              src: 'img_0021.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 301,
              y: 248,
              font_array: ["temp-0_0.png","temp-0_1.png","temp-0_2.png","temp-0_3.png","temp-0_4.png","temp-0_5.png","temp-0_6.png","temp-0_7.png","temp-0_8.png","temp-0_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_aqi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 232,
              y: 248,
              font_array: ["temp-0_0.png","temp-0_1.png","temp-0_2.png","temp-0_3.png","temp-0_4.png","temp-0_5.png","temp-0_6.png","temp-0_7.png","temp-0_8.png","temp-0_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 248,
              font_array: ["temp-0_0.png","temp-0_1.png","temp-0_2.png","temp-0_3.png","temp-0_4.png","temp-0_5.png","temp-0_6.png","temp-0_7.png","temp-0_8.png","temp-0_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 248,
              font_array: ["temp-0_0.png","temp-0_1.png","temp-0_2.png","temp-0_3.png","temp-0_4.png","temp-0_5.png","temp-0_6.png","temp-0_7.png","temp-0_8.png","temp-0_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 55,
              y: 242,
              image_array: ["WEATHERICON_1.png","WEATHERICON_2.png","WEATHERICON_3.png","WEATHERICON_4.png","WEATHERICON_5.png","WEATHERICON_6.png","WEATHERICON_7.png","WEATHERICON_8.png","WEATHERICON_9.png","WEATHERICON_10.png","WEATHERICON_11.png","WEATHERICON_12.png","WEATHERICON_13.png","WEATHERICON_14.png","WEATHERICON_15.png","WEATHERICON_16.png","WEATHERICON_17.png","WEATHERICON_18.png","WEATHERICON_19.png","WEATHERICON_20.png","WEATHERICON_21.png","WEATHERICON_22.png","WEATHERICON_23.png","WEATHERICON_24.png","WEATHERICON_25.png","WEATHERICON_26.png","WEATHERICON_27.png","WEATHERICON_28.png","WEATHERICON_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 87,
              y: 174,
              font_array: ["temp-max-0_0.png","temp-max-0_1.png","temp-max-0_2.png","temp-max-0_3.png","temp-max-0_4.png","temp-max-0_5.png","temp-max-0_6.png","temp-max-0_7.png","temp-max-0_8.png","temp-max-0_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'temp-max-0_arrowH.png',
              unit_tc: 'temp-max-0_arrowH.png',
              unit_en: 'temp-max-0_arrowH.png',
              negative_image: 'temp-max-0_negative-sign.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 174,
              font_array: ["temp-max-0_0.png","temp-max-0_1.png","temp-max-0_2.png","temp-max-0_3.png","temp-max-0_4.png","temp-max-0_5.png","temp-max-0_6.png","temp-max-0_7.png","temp-max-0_8.png","temp-max-0_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'temp-max-0_arrowL.png',
              unit_tc: 'temp-max-0_arrowL.png',
              unit_en: 'temp-max-0_arrowL.png',
              negative_image: 'temp-max-0_negative-sign.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 22,
              y: 174,
              font_array: ["temp-0_0.png","temp-0_1.png","temp-0_2.png","temp-0_3.png","temp-0_4.png","temp-0_5.png","temp-0_6.png","temp-0_7.png","temp-0_8.png","temp-0_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'temp-0_degree.png',
              unit_tc: 'temp-0_degree.png',
              unit_en: 'temp-0_degree.png',
              negative_image: 'temp-0_negative-sign.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 28,
              y: 72,
              image_array: ["img_arr_0005_00.png","img_arr_0005_01.png","img_arr_0005_02.png","img_arr_0005_03.png","img_arr_0005_04.png","img_arr_0005_05.png","img_arr_0005_06.png","img_arr_0005_07.png","img_arr_0005_08.png","img_arr_0005_09.png","img_arr_0005_10.png","img_arr_0005_11.png","img_arr_0005_12.png","img_arr_0005_13.png","img_arr_0005_14.png","img_arr_0005_15.png","img_arr_0005_16.png","img_arr_0005_17.png","img_arr_0005_18.png","img_arr_0005_19.png","img_arr_0005_20.png","img_arr_0005_21.png","img_arr_0005_22.png","img_arr_0005_23.png","img_arr_0005_24.png","img_arr_0005_25.png","img_arr_0005_26.png","img_arr_0005_27.png","img_arr_0005_28.png","img_arr_0005_29.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 221,
              y: 17,
              week_en: ["dias_1.png","dias_2.png","dias_3.png","dias_4.png","dias_5.png","dias_6.png","dias_7.png"],
              week_tc: ["dias_1.png","dias_2.png","dias_3.png","dias_4.png","dias_5.png","dias_6.png","dias_7.png"],
              week_sc: ["dias_1.png","dias_2.png","dias_3.png","dias_4.png","dias_5.png","dias_6.png","dias_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 318,
              day_startY: 31,
              day_sc_array: ["date-0_0.png","date-0_1.png","date-0_2.png","date-0_3.png","date-0_4.png","date-0_5.png","date-0_6.png","date-0_7.png","date-0_8.png","date-0_9.png"],
              day_tc_array: ["date-0_0.png","date-0_1.png","date-0_2.png","date-0_3.png","date-0_4.png","date-0_5.png","date-0_6.png","date-0_7.png","date-0_8.png","date-0_9.png"],
              day_en_array: ["date-0_0.png","date-0_1.png","date-0_2.png","date-0_3.png","date-0_4.png","date-0_5.png","date-0_6.png","date-0_7.png","date-0_8.png","date-0_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 140,
              hour_startY: 81,
              hour_array: ["img_arr_0000_00.png","img_arr_0000_01.png","img_arr_0000_02.png","img_arr_0000_03.png","img_arr_0000_04.png","img_arr_0000_05.png","img_arr_0000_06.png","img_arr_0000_07.png","img_arr_0000_08.png","img_arr_0000_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 262,
              minute_startY: 81,
              minute_array: ["img_arr_0000_00.png","img_arr_0000_01.png","img_arr_0000_02.png","img_arr_0000_03.png","img_arr_0000_04.png","img_arr_0000_05.png","img_arr_0000_06.png","img_arr_0000_07.png","img_arr_0000_08.png","img_arr_0000_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 245,
              y: 95,
              src: 'dos puntos.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 274,
              y: 338,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 336,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 25,
              y: 336,
              w: 100,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 30,
              y: 168,
              w: 199,
              h: 37,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 263,
              y: 80,
              w: 100,
              h: 75,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 141,
              y: 77,
              w: 100,
              h: 80,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 243,
              y: 25,
              w: 124,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 22,
              y: 74,
              w: 109,
              h: 84,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 38,
              y: 218,
              w: 317,
              h: 97,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 324,
                      center_y: 384,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 16,
                      line_width: 10,
                      corner_flag: 0,
                      color: 0xFF00D5D5,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 324,
                      center_y: 384,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 28,
                      line_width: 10,
                      corner_flag: 0,
                      color: 0xFF00F700,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 324,
                      center_y: 384,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 41,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFFFD0241,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STAND');
                let progress_cs_idle_stand = progressStand;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_stand * 100);
                  if (idle_stand_circle_scale) {
                    idle_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 324,
                      center_y: 384,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 16,
                      line_width: 10,
                      corner_flag: 0,
                      color: 0xFF00D5D5,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_calorie * 100);
                  if (idle_calorie_circle_scale) {
                    idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 324,
                      center_y: 384,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 28,
                      line_width: 10,
                      corner_flag: 0,
                      color: 0xFF00F700,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 324,
                      center_y: 384,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 41,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFFFD0241,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}