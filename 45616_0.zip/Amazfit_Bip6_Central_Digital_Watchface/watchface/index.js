const ROOT = 'assets/390x450-amazfit-bip-6/'

function digits(color) {
  return Array.from({length: 10}, (_, i) => ROOT + 'digits_' + color + '/' + i + '.png')
}

function text(x, y, w, h, value, size, color, align = hmUI.align.CENTER_H) {
  return hmUI.createWidget(hmUI.widget.TEXT, {
    x, y, w, h,
    text: value,
    text_size: size,
    color,
    align_h: align,
    align_v: hmUI.align.CENTER_V,
    text_style: hmUI.text_style.NONE
  })
}

function dataImg(x, y, w, h, type, color, unit) {
  return hmUI.createWidget(hmUI.widget.TEXT_IMG, {
    x, y, w, h,
    type,
    font_array: digits(color),
    h_space: 0,
    align_h: hmUI.align.CENTER_H,
    unit_en: unit || ''
  })
}

WatchFace({
  onInit() {},
  build() {
    // Background
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 0, y: 0, src: ROOT + 'background.png'
    })

    // Battery
    text(120, 8, 150, 28, 'BATTERIA', 15, 0x35f05f)
    dataImg(130, 30, 130, 42, hmUI.data_type.BATTERY, 'green', '%')

    // Date / day
    const t = hmSensor.createSensor(hmSensor.id.TIME)
    const dayNames = ['DOM', 'LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB']
    const date = ('0' + t.day).slice(-2) + '/' + ('0' + t.month).slice(-2)
    text(20, 75, 125, 30, date, 22, 0xffffff)
    text(145, 75, 100, 30, dayNames[t.week] || '', 22, 0x38b7ff)
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 248, y: 58, src: ROOT + 'weather.png'
    })
    dataImg(305, 70, 70, 34, hmUI.data_type.WEATHER_CURRENT, 'white', '°C')

    // Main digital time using rounded image digits.
    const hour = ('0' + t.hour).slice(-2)
    const minute = ('0' + t.minute).slice(-2)
    const time = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      x: 22, y: 118, w: 346, h: 100,
      text: hour + minute,
      font_array: digits('white'),
      h_space: -1,
      align_h: hmUI.align.CENTER_H
    })

    // Blue colon overlay
    text(184, 137, 22, 60, ':', 54, 0x38b7ff)

    // Lower metrics
    // Vertical separators
    ;[96, 193, 290].forEach(x => hmUI.createWidget(hmUI.widget.IMG, {
      x, y: 285, src: ROOT + 'divider.png'
    }))

    // Labels and dynamic data
    text(8, 274, 80, 22, 'PASSI', 13, 0x23f05f)
    dataImg(3, 295, 88, 42, hmUI.data_type.STEP, 'green')

    text(105, 274, 78, 22, 'KM', 13, 0x38b7ff)
    dataImg(101, 295, 84, 42, hmUI.data_type.DISTANCE, 'blue')

    text(201, 274, 78, 22, 'BPM', 13, 0xff5073)
    dataImg(198, 295, 84, 42, hmUI.data_type.HEART, 'pink')

    text(299, 274, 84, 22, 'KCAL', 13, 0xff9623)
    dataImg(296, 295, 86, 42, hmUI.data_type.CAL, 'orange')

    // Small descriptive footer
    text(15, 355, 360, 26, 'AMAZFIT  •  BIP 6', 13, 0x6f7890)
  },
  onDestroy() {}
})
