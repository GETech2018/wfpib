@echo off
echo Installazione Zeus CLI...
call npm install --global @zeppos/zeus-cli
echo.
echo Build quadrante Amazfit Bip 6...
call zeus build
echo.
echo Se la build e' riuscita, il file ZAB e' nella cartella dist.
pause
