App({
  globalData: {},
  onCreate() {},
  onDestroy() {}
})
