# Amazfit Bip 6 – Central Digital Watchface

Quadrante Zepp OS per Amazfit Bip 6, 390x450.

## Layout
- Batteria in alto
- Data, giorno e temperatura/meteo
- Ora digitale centrale molto grande
- Passi, distanza, battiti e calorie in basso
- Sfondo nero
- Numeri generati con un font arrotondato

## Build ufficiale Zepp OS
Il pacchetto ZAB viene generato dal tool ufficiale Zeus CLI:

1. Installare Node.js
2. `npm install --global @zeppos/zeus-cli`
3. Entrare nella cartella del progetto
4. `zeus build`
5. Il file ZAB viene creato nella cartella `dist/`

Per installazione diretta sul Bip 6 tramite QR:
`zeus preview`

Il QR va scansionato nell'app Zepp tramite la modalità sviluppatore.
