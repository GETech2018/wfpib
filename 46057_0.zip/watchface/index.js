try{(()=>{var app=__$$hmAppManager$$__.currentApp, mod=app.current, factory=new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(app,mod),"aroelzm_modern");"use strict";
mod.module=DeviceRuntimeCore.WatchFace({
init_view(){
const N=hmUI.show_level.ONLY_NORMAL,A=hmUI.show_level.ONLY_AOD,DT=hmUI.data_type,L=hmUI.align.LEFT,C=hmUI.align.CENTER_H;
const safe=(f)=>{try{return f()}catch(e){console.log(e);return null}};
const img=(x,y,w,h,src,lv)=>safe(()=>hmUI.createWidget(hmUI.widget.IMG,{x,y,w,h,src,show_level:lv||N}));
const txt=(x,y,w,h,content,size,color,align)=>safe(()=>hmUI.createWidget(hmUI.widget.TEXT,{x,y,w,h,text:content,text_size:size,color:color,align_h:align||L,show_level:N}));
const digit=(x,y,w,h,src,lv)=>img(x,y,w,h,src,lv);
img(0,0,432,514,"modern_bg.png",N);
img(0,0,432,514,"modern_aod.png",A);

// Header date and weekday
safe(()=>hmUI.createWidget(hmUI.widget.IMG_WEEK,{x:28,y:70,week_en:["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png"],week_tc:["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png"],week_sc:["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png"],show_level:N}));
safe(()=>hmUI.createWidget(hmUI.widget.IMG_DATE,{day_startX:113,day_startY:70,day_sc_array:["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],day_tc_array:["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],day_en_array:["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],day_zero:1,day_space:0,day_align:L,month_startX:151,month_startY:70,month_sc_array:["0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],month_tc_array:["0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],month_en_array:["0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png"],month_is_character:true,month_align:L,show_level:N}));

// Main digital time; tapping the hour/minute/second digits immediately applies the next color.
var time=safe(()=>hmSensor.createSensor(hmSensor.id.TIME)), hourColor=1, minuteColor=1, secondColor=1, tick=null;
var hw=[],mw=[],sw=[];
function makeDigits(){
 // Larger, evenly spaced HH:MM digits. Seconds remain compact at the right edge.
 hw.push(digit(52,133,66,112,"3000.png"));
 hw.push(digit(124,133,66,112,"3000.png"));
 mw.push(digit(236,133,66,112,"3000.png"));
 mw.push(digit(308,133,66,112,"3000.png"));
 sw.push(digit(380,204,24,44,"4000.png"));
 img(204,148,16,82,"modern_colon.png",N);
}
function setPair(arr,val,prefix,color){
 var s=("0"+val).slice(-2);
 for(var i=0;i<2;i++){try{arr[i].setProperty(hmUI.prop.SRC,prefix+color+"0"+s.charAt(i)+".png")}catch(e){}}
}
function updateTime(){
 var h=(time&&typeof time.hour==="number")?time.hour:new Date().getHours();
 var m=(time&&typeof time.minute==="number")?time.minute:new Date().getMinutes();
 var s=(time&&typeof time.second==="number")?time.second:new Date().getSeconds();
 setPair(hw,h,"3",hourColor);setPair(mw,m,"3",minuteColor);setPair(sw,s,"4",secondColor);
}
function hit(x,y,w,h,fn){safe(()=>hmUI.createWidget(hmUI.widget.BUTTON,{x,y,w,h,text:"",normal_src:"touch_clear.png",press_src:"touch_clear.png",click_func:fn}));}
makeDigits();updateTime();
hit(46,126,148,126,()=>{hourColor=(hourColor+1)%7;updateTime()});
hit(230,126,148,126,()=>{minuteColor=(minuteColor+1)%7;updateTime()});
hit(376,198,31,54,()=>{secondColor=(secondColor+1)%7;updateTime()});
try{time.addEventListener(hmSensor.event.MINUTEEND,updateTime)}catch(e){}
function start(){if(tick===null){try{tick=setInterval(updateTime,1000)}catch(e){tick=null}}}
function stop(){if(tick!==null){try{clearInterval(tick)}catch(e){}tick=null}}
start();

// Four configurable information cards. Tap any card to cycle its data field.
// Supported fields are based on the native data types already used by the source watchface.
var metrics=[
 {name:"STEPS",type:DT.STEP,arr:["card_steps_0.png","card_steps_1.png","card_steps_2.png","card_steps_3.png","card_steps_4.png","card_steps_5.png","card_steps_6.png","card_steps_7.png","card_steps_8.png","card_steps_9.png"],icon:"icon_steps.png"},
 {name:"HEART RATE",type:DT.HEART,arr:["card_heart_0.png","card_heart_1.png","card_heart_2.png","card_heart_3.png","card_heart_4.png","card_heart_5.png","card_heart_6.png","card_heart_7.png","card_heart_8.png","card_heart_9.png"],invalid:"0142.png",icon:"icon_heart.png"},
 {name:"CALORIES",type:DT.CAL,arr:["card_calories_0.png","card_calories_1.png","card_calories_2.png","card_calories_3.png","card_calories_4.png","card_calories_5.png","card_calories_6.png","card_calories_7.png","card_calories_8.png","card_calories_9.png"],icon:"icon_calories.png"},
 {name:"DISTANCE",type:DT.DISTANCE,arr:["card_distance_0.png","card_distance_1.png","card_distance_2.png","card_distance_3.png","card_distance_4.png","card_distance_5.png","card_distance_6.png","card_distance_7.png","card_distance_8.png","card_distance_9.png"],dot:"0141.png",icon:"icon_distance.png"},
 {name:"BATTERY",type:DT.BATTERY,arr:["card_battery_0.png","card_battery_1.png","card_battery_2.png","card_battery_3.png","card_battery_4.png","card_battery_5.png","card_battery_6.png","card_battery_7.png","card_battery_8.png","card_battery_9.png"],unit:"0147.png",icon:"icon_battery.png"},
 {name:"STANDING",type:DT.STAND,arr:["card_standing_0.png","card_standing_1.png","card_standing_2.png","card_standing_3.png","card_standing_4.png","card_standing_5.png","card_standing_6.png","card_standing_7.png","card_standing_8.png","card_standing_9.png"],invalid:"0142.png",icon:"icon_standing.png"},
 {name:"HUMIDITY",type:DT.HUMIDITY,arr:["card_humidity_0.png","card_humidity_1.png","card_humidity_2.png","card_humidity_3.png","card_humidity_4.png","card_humidity_5.png","card_humidity_6.png","card_humidity_7.png","card_humidity_8.png","card_humidity_9.png"],invalid:"0142.png",icon:"icon_humidity.png"},
 {name:"WEATHER",type:DT.WEATHER_CURRENT,arr:["card_weather_0.png","card_weather_1.png","card_weather_2.png","card_weather_3.png","card_weather_4.png","card_weather_5.png","card_weather_6.png","card_weather_7.png","card_weather_8.png","card_weather_9.png"],unit:"0144.png",negative:"0143.png",invalid:"0142.png",icon:"icon_weather.png"},
 {name:"HIGH TEMP",type:DT.WEATHER_HIGH,arr:["card_high_0.png","card_high_1.png","card_high_2.png","card_high_3.png","card_high_4.png","card_high_5.png","card_high_6.png","card_high_7.png","card_high_8.png","card_high_9.png"],unit:"0145.png",negative:"0143.png",icon:"icon_high.png"},
 {name:"LOW TEMP",type:DT.WEATHER_LOW,arr:["card_low_0.png","card_low_1.png","card_low_2.png","card_low_3.png","card_low_4.png","card_low_5.png","card_low_6.png","card_low_7.png","card_low_8.png","card_low_9.png"],unit:"0145.png",negative:"0143.png",icon:"icon_low.png"}
];
var slots=[
 {x:38,y:316,w:155,h:43,index:0,labelX:63,labelY:292,iconX:38,iconY:289},
 {x:238,y:316,w:155,h:43,index:1,labelX:263,labelY:292,iconX:238,iconY:289},
 {x:38,y:414,w:155,h:43,index:2,labelX:63,labelY:390,iconX:38,iconY:387},
 {x:238,y:414,w:155,h:43,index:3,labelX:263,labelY:390,iconX:238,iconY:387}
];
function buildSlot(i){
 var s=slots[i],m=metrics[s.index];
 if(s.labelWidget)safe(()=>hmUI.deleteWidget(s.labelWidget));
 if(s.valueWidget)safe(()=>hmUI.deleteWidget(s.valueWidget));
 if(s.iconWidget)safe(()=>hmUI.deleteWidget(s.iconWidget));
 s.iconWidget=img(s.iconX,s.iconY,20,20,m.icon||"icon_steps.png",N);
 s.labelWidget=txt(s.labelX,s.labelY,130,20,m.name,12,0x82AFC4,L);
 var extra={};
 if(m.unit)extra.unit_sc=m.unit,extra.unit_tc=m.unit,extra.unit_en=m.unit,extra.imperial_unit_sc=m.unit,extra.imperial_unit_tc=m.unit,extra.imperial_unit_en=m.unit;
 if(m.dot)extra.dot_image=m.dot;
 if(m.negative)extra.negative_image=m.negative;
 if(m.invalid)extra.invalid_image=m.invalid;
 s.valueWidget=safe(()=>hmUI.createWidget(hmUI.widget.TEXT_IMG,Object.assign({x:s.x,y:s.y,w:s.w,h:s.h,font_array:m.arr,h_space:1,align_h:C,type:m.type,show_level:N},extra)));
}
for(var k=0;k<4;k++){buildSlot(k);(function(index){var s=slots[index];hit(s.x-15,s.labelY-7,s.w+30,82,function(){s.index=(s.index+1)%metrics.length;buildSlot(index)})})(k);}

// battery bar and percent at footer
safe(()=>hmUI.createWidget(hmUI.widget.IMG_LEVEL,{x:28,y:471,w:110,h:14,image_array:["0209.png","0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png","0218.png","0219.png","0220.png","0221.png","0222.png","0223.png","0224.png","0225.png","0226.png","0227.png","0228.png","0229.png","0230.png","0231.png","0232.png","0233.png"],image_length:25,type:DT.BATTERY,show_level:N}));
txt(151,468,100,20,"TAP A CARD TO CHANGE DATA",9,0x6C91A8,C);
safe(()=>hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:300,y:468,w:95,h:22,font_array:["0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png"],h_space:0,align_h:C,type:DT.BATTERY,show_level:N,unit_sc:"0147.png",unit_tc:"0147.png",unit_en:"0147.png"}));

// AOD time and date (monochrome / low refresh)
safe(()=>hmUI.createWidget(hmUI.widget.IMG_TIME,{hour_startX:52,hour_startY:148,hour_array:["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],hour_zero:1,hour_space:0,hour_align:L,minute_startX:236,minute_startY:148,minute_array:["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],minute_zero:1,minute_space:0,minute_align:L,show_level:A}));
// Always-On Display: low-information monochrome date and battery indicator.
safe(()=>hmUI.createWidget(hmUI.widget.IMG_DATE,{day_startX:165,day_startY:286,day_sc_array:["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],day_tc_array:["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],day_en_array:["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],day_zero:1,day_space:0,day_align:C,show_level:A}));
safe(()=>hmUI.createWidget(hmUI.widget.IMG_LEVEL,{x:190,y:330,w:52,h:7,image_array:["0209.png","0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png","0218.png","0219.png","0220.png","0221.png","0222.png","0223.png","0224.png","0225.png","0226.png","0227.png","0228.png","0229.png","0230.png","0231.png","0232.png","0233.png"],image_length:25,type:DT.BATTERY,show_level:A}));
safe(()=>hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE,{resume_call:function(){updateTime();start()},pause_call:stop}));
},
onInit(){this.init_view()},onReady(){},onShow(){},onHide(){},onDestroy(){}
})})()}catch(e){console.log(e)}
