﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_date_img_date_day = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_week_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_wind_text_text_img = ''
        let normal_wind_icon_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_icon_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_week_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'background_b6833105.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 5,
              hour_startY: 187,
              hour_array: ["chars_E5A6BF37_000.png","chars_E5A6BF37_001.png","chars_E5A6BF37_002.png","chars_E5A6BF37_003.png","chars_E5A6BF37_004.png","chars_E5A6BF37_005.png","chars_E5A6BF37_006.png","chars_E5A6BF37_007.png","chars_E5A6BF37_008.png","chars_E5A6BF37_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 140,
              minute_startY: 186,
              minute_array: ["chars_E5A6BF37_000.png","chars_E5A6BF37_001.png","chars_E5A6BF37_002.png","chars_E5A6BF37_003.png","chars_E5A6BF37_004.png","chars_E5A6BF37_005.png","chars_E5A6BF37_006.png","chars_E5A6BF37_007.png","chars_E5A6BF37_008.png","chars_E5A6BF37_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 277,
              second_startY: 186,
              second_array: ["chars_FD89FFF7_000.png","chars_FD89FFF7_001.png","chars_FD89FFF7_002.png","chars_FD89FFF7_003.png","chars_FD89FFF7_004.png","chars_FD89FFF7_005.png","chars_FD89FFF7_006.png","chars_FD89FFF7_007.png","chars_FD89FFF7_008.png","chars_FD89FFF7_009.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: -2,
              y: 112,
              font_array: ["chars_70D819ED_000.png","chars_70D819ED_001.png","chars_70D819ED_002.png","chars_70D819ED_003.png","chars_70D819ED_004.png","chars_70D819ED_005.png","chars_70D819ED_006.png","chars_70D819ED_007.png","chars_70D819ED_008.png","chars_70D819ED_009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'chars_70D819ED_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 313,
              y: 112,
              font_array: ["chars_70D819ED_000.png","chars_70D819ED_001.png","chars_70D819ED_002.png","chars_70D819ED_003.png","chars_70D819ED_004.png","chars_70D819ED_005.png","chars_70D819ED_006.png","chars_70D819ED_007.png","chars_70D819ED_008.png","chars_70D819ED_009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'chars_70D819ED_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 119,
              day_startY: 138,
              day_sc_array: ["chars_71A8314F_000.png","chars_71A8314F_001.png","chars_71A8314F_002.png","chars_71A8314F_003.png","chars_71A8314F_004.png","chars_71A8314F_005.png","chars_71A8314F_006.png","chars_71A8314F_007.png","chars_71A8314F_008.png","chars_71A8314F_009.png"],
              day_tc_array: ["chars_71A8314F_000.png","chars_71A8314F_001.png","chars_71A8314F_002.png","chars_71A8314F_003.png","chars_71A8314F_004.png","chars_71A8314F_005.png","chars_71A8314F_006.png","chars_71A8314F_007.png","chars_71A8314F_008.png","chars_71A8314F_009.png"],
              day_en_array: ["chars_71A8314F_000.png","chars_71A8314F_001.png","chars_71A8314F_002.png","chars_71A8314F_003.png","chars_71A8314F_004.png","chars_71A8314F_005.png","chars_71A8314F_006.png","chars_71A8314F_007.png","chars_71A8314F_008.png","chars_71A8314F_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 1,
              y: 65,
              font_array: ["chars_AB535ECE_000.png","chars_AB535ECE_001.png","chars_AB535ECE_002.png","chars_AB535ECE_003.png","chars_AB535ECE_004.png","chars_AB535ECE_005.png","chars_AB535ECE_006.png","chars_AB535ECE_007.png","chars_AB535ECE_008.png","chars_AB535ECE_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_AB535ECE_011.png',
              unit_tc: 'chars_AB535ECE_011.png',
              unit_en: 'chars_AB535ECE_011.png',
              negative_image: 'chars_AB535ECE_010.png',
              invalid_image: 'chars_AB535ECE_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 65,
              font_array: ["chars_AB535ECE_000.png","chars_AB535ECE_001.png","chars_AB535ECE_002.png","chars_AB535ECE_003.png","chars_AB535ECE_004.png","chars_AB535ECE_005.png","chars_AB535ECE_006.png","chars_AB535ECE_007.png","chars_AB535ECE_008.png","chars_AB535ECE_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_AB535ECE_011.png',
              unit_tc: 'chars_AB535ECE_011.png',
              unit_en: 'chars_AB535ECE_011.png',
              negative_image: 'chars_AB535ECE_010.png',
              invalid_image: 'chars_AB535ECE_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 156,
              y: 24,
              font_array: ["chars_D82E1F6E_000.png","chars_D82E1F6E_001.png","chars_D82E1F6E_002.png","chars_D82E1F6E_003.png","chars_D82E1F6E_004.png","chars_D82E1F6E_005.png","chars_D82E1F6E_006.png","chars_D82E1F6E_007.png","chars_D82E1F6E_008.png","chars_D82E1F6E_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_D82E1F6E_011.png',
              unit_tc: 'chars_D82E1F6E_011.png',
              unit_en: 'chars_D82E1F6E_011.png',
              negative_image: 'chars_D82E1F6E_010.png',
              invalid_image: 'chars_D82E1F6E_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 156,
              y: 55,
              image_array: ["set_22_80x80_meteo_1.png","set_22_80x80_meteo_2.png","set_22_80x80_meteo_3.png","set_22_80x80_meteo_4.png","set_22_80x80_meteo_5.png","set_22_80x80_meteo_6.png","set_22_80x80_meteo_7.png","set_22_80x80_meteo_8.png","set_22_80x80_meteo_9.png","set_22_80x80_meteo_10.png","set_22_80x80_meteo_11.png","set_22_80x80_meteo_12.png","set_22_80x80_meteo_13.png","set_22_80x80_meteo_14.png","set_22_80x80_meteo_15.png","set_22_80x80_meteo_16.png","set_22_80x80_meteo_17.png","set_22_80x80_meteo_18.png","set_22_80x80_meteo_19.png","set_22_80x80_meteo_20.png","set_22_80x80_meteo_21.png","set_22_80x80_meteo_22.png","set_22_80x80_meteo_23.png","set_22_80x80_meteo_24.png","set_22_80x80_meteo_25.png","set_22_80x80_meteo_26.png","set_22_80x80_meteo_27.png","set_22_80x80_meteo_28.png","set_22_80x80_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 171,
              month_startY: 138,
              month_sc_array: ["chars_7169F311_000.png","chars_7169F311_001.png","chars_7169F311_002.png","chars_7169F311_003.png","chars_7169F311_004.png","chars_7169F311_005.png","chars_7169F311_006.png","chars_7169F311_007.png","chars_7169F311_008.png","chars_7169F311_009.png"],
              month_tc_array: ["chars_7169F311_000.png","chars_7169F311_001.png","chars_7169F311_002.png","chars_7169F311_003.png","chars_7169F311_004.png","chars_7169F311_005.png","chars_7169F311_006.png","chars_7169F311_007.png","chars_7169F311_008.png","chars_7169F311_009.png"],
              month_en_array: ["chars_7169F311_000.png","chars_7169F311_001.png","chars_7169F311_002.png","chars_7169F311_003.png","chars_7169F311_004.png","chars_7169F311_005.png","chars_7169F311_006.png","chars_7169F311_007.png","chars_7169F311_008.png","chars_7169F311_009.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 210,
              y: 138,
              week_en: ["chars_D4EF99E2_000.png","chars_D4EF99E2_001.png","chars_D4EF99E2_002.png","chars_D4EF99E2_003.png","chars_D4EF99E2_004.png","chars_D4EF99E2_005.png","chars_D4EF99E2_006.png"],
              week_tc: ["chars_D4EF99E2_000.png","chars_D4EF99E2_001.png","chars_D4EF99E2_002.png","chars_D4EF99E2_003.png","chars_D4EF99E2_004.png","chars_D4EF99E2_005.png","chars_D4EF99E2_006.png"],
              week_sc: ["chars_D4EF99E2_000.png","chars_D4EF99E2_001.png","chars_D4EF99E2_002.png","chars_D4EF99E2_003.png","chars_D4EF99E2_004.png","chars_D4EF99E2_005.png","chars_D4EF99E2_006.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 133,
              y: 350,
              font_array: ["chars_D82E1F6E_000.png","chars_D82E1F6E_001.png","chars_D82E1F6E_002.png","chars_D82E1F6E_003.png","chars_D82E1F6E_004.png","chars_D82E1F6E_005.png","chars_D82E1F6E_006.png","chars_D82E1F6E_007.png","chars_D82E1F6E_008.png","chars_D82E1F6E_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 278,
              y: 346,
              src: 'chars_AA7F822C_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 94,
              y: 329,
              image_array: ["set_7_206x6_img_level_1.png","set_7_206x6_img_level_2.png","set_7_206x6_img_level_3.png","set_7_206x6_img_level_4.png","set_7_206x6_img_level_5.png"],
              image_length: 5,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 74,
              y: 346,
              src: 'chars_AA7F822C_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 2,
              y: 294,
              font_array: ["chars_56FE5C54_000.png","chars_56FE5C54_001.png","chars_56FE5C54_002.png","chars_56FE5C54_003.png","chars_56FE5C54_004.png","chars_56FE5C54_005.png","chars_56FE5C54_006.png","chars_56FE5C54_007.png","chars_56FE5C54_008.png","chars_56FE5C54_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 294,
              font_array: ["chars_D82E1F6E_000.png","chars_D82E1F6E_001.png","chars_D82E1F6E_002.png","chars_D82E1F6E_003.png","chars_D82E1F6E_004.png","chars_D82E1F6E_005.png","chars_D82E1F6E_006.png","chars_D82E1F6E_007.png","chars_D82E1F6E_008.png","chars_D82E1F6E_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 219,
              y: 409,
              font_array: ["chars_72319BCA_000.png","chars_72319BCA_001.png","chars_72319BCA_002.png","chars_72319BCA_003.png","chars_72319BCA_004.png","chars_72319BCA_005.png","chars_72319BCA_006.png","chars_72319BCA_007.png","chars_72319BCA_008.png","chars_72319BCA_009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'chars_72319BCA_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 317,
              y: 413,
              src: 'chars_76E307CD_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 409,
              font_array: ["chars_E9506EEB_000.png","chars_E9506EEB_001.png","chars_E9506EEB_002.png","chars_E9506EEB_003.png","chars_E9506EEB_004.png","chars_E9506EEB_005.png","chars_E9506EEB_006.png","chars_E9506EEB_007.png","chars_E9506EEB_008.png","chars_E9506EEB_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 29,
              y: 413,
              src: 'chars_35238221_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 263,
              y: 80,
              font_array: ["chars_A7313A6A_000.png","chars_A7313A6A_001.png","chars_A7313A6A_002.png","chars_A7313A6A_003.png","chars_A7313A6A_004.png","chars_A7313A6A_005.png","chars_A7313A6A_006.png","chars_A7313A6A_007.png","chars_A7313A6A_008.png","chars_A7313A6A_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 261,
              y: 111,
              src: 'chars_B3947C3B_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 81,
              y: 80,
              font_array: ["chars_930B5228_000.png","chars_930B5228_001.png","chars_930B5228_002.png","chars_930B5228_003.png","chars_930B5228_004.png","chars_930B5228_005.png","chars_930B5228_006.png","chars_930B5228_007.png","chars_930B5228_008.png","chars_930B5228_009.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'chars_930B5228_011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 97,
              y: 111,
              src: 'chars_A5DDF851_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 75,
              hour_startY: 187,
              hour_array: ["chars_E5A6BF37_000.png","chars_E5A6BF37_001.png","chars_E5A6BF37_002.png","chars_E5A6BF37_003.png","chars_E5A6BF37_004.png","chars_E5A6BF37_005.png","chars_E5A6BF37_006.png","chars_E5A6BF37_007.png","chars_E5A6BF37_008.png","chars_E5A6BF37_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 207,
              minute_startY: 186,
              minute_array: ["chars_E5A6BF37_000.png","chars_E5A6BF37_001.png","chars_E5A6BF37_002.png","chars_E5A6BF37_003.png","chars_E5A6BF37_004.png","chars_E5A6BF37_005.png","chars_E5A6BF37_006.png","chars_E5A6BF37_007.png","chars_E5A6BF37_008.png","chars_E5A6BF37_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 119,
              day_startY: 138,
              day_sc_array: ["chars_71A8314F_000.png","chars_71A8314F_001.png","chars_71A8314F_002.png","chars_71A8314F_003.png","chars_71A8314F_004.png","chars_71A8314F_005.png","chars_71A8314F_006.png","chars_71A8314F_007.png","chars_71A8314F_008.png","chars_71A8314F_009.png"],
              day_tc_array: ["chars_71A8314F_000.png","chars_71A8314F_001.png","chars_71A8314F_002.png","chars_71A8314F_003.png","chars_71A8314F_004.png","chars_71A8314F_005.png","chars_71A8314F_006.png","chars_71A8314F_007.png","chars_71A8314F_008.png","chars_71A8314F_009.png"],
              day_en_array: ["chars_71A8314F_000.png","chars_71A8314F_001.png","chars_71A8314F_002.png","chars_71A8314F_003.png","chars_71A8314F_004.png","chars_71A8314F_005.png","chars_71A8314F_006.png","chars_71A8314F_007.png","chars_71A8314F_008.png","chars_71A8314F_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 171,
              month_startY: 138,
              month_sc_array: ["chars_7169F311_000.png","chars_7169F311_001.png","chars_7169F311_002.png","chars_7169F311_003.png","chars_7169F311_004.png","chars_7169F311_005.png","chars_7169F311_006.png","chars_7169F311_007.png","chars_7169F311_008.png","chars_7169F311_009.png"],
              month_tc_array: ["chars_7169F311_000.png","chars_7169F311_001.png","chars_7169F311_002.png","chars_7169F311_003.png","chars_7169F311_004.png","chars_7169F311_005.png","chars_7169F311_006.png","chars_7169F311_007.png","chars_7169F311_008.png","chars_7169F311_009.png"],
              month_en_array: ["chars_7169F311_000.png","chars_7169F311_001.png","chars_7169F311_002.png","chars_7169F311_003.png","chars_7169F311_004.png","chars_7169F311_005.png","chars_7169F311_006.png","chars_7169F311_007.png","chars_7169F311_008.png","chars_7169F311_009.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 210,
              y: 138,
              week_en: ["chars_D4EF99E2_000.png","chars_D4EF99E2_001.png","chars_D4EF99E2_002.png","chars_D4EF99E2_003.png","chars_D4EF99E2_004.png","chars_D4EF99E2_005.png","chars_D4EF99E2_006.png"],
              week_tc: ["chars_D4EF99E2_000.png","chars_D4EF99E2_001.png","chars_D4EF99E2_002.png","chars_D4EF99E2_003.png","chars_D4EF99E2_004.png","chars_D4EF99E2_005.png","chars_D4EF99E2_006.png"],
              week_sc: ["chars_D4EF99E2_000.png","chars_D4EF99E2_001.png","chars_D4EF99E2_002.png","chars_D4EF99E2_003.png","chars_D4EF99E2_004.png","chars_D4EF99E2_005.png","chars_D4EF99E2_006.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 151,
              y: 15,
              w: 100,
              h: 114,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 117,
              y: 139,
              w: 157,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({ appid: 1057409, url: 'page/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 7,
              y: 290,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 86,
              y: 299,
              w: 199,
              h: 92,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 294,
              y: 286,
              w: 101,
              h: 92,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 39,
              y: 402,
              w: 305,
              h: 92,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 18,
              y: 187,
              w: 183,
              h: 92,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 187,
              w: 183,
              h: 92,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}