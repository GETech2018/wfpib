﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start
		
      const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
      const battery = hmSensor.createSensor(hmSensor.id.BATTERY)
      const step = hmSensor.createSensor(hmSensor.id.STEP);
      const heart_rate = hmSensor.createSensor(hmSensor.id.HEART); //heart_rate.last
      const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
      const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
//      const stand = hmSensor.createSensor(hmSensor.id.STAND)
//      const pai = hmSensor.createSensor(hmSensor.id.PAI);
//      const fatburn = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
//      const spo2 = hmSensor.createSensor(hmSensor.id.SPO2);
//      const stress = hmSensor.createSensor(hmSensor.id.STRESS);

        
        let normal_background_bg = ''
        let normal_stand_icon_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_image_img = ''
        let normal_digital_clock_img_time = ''
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_weather_image_progress_img_level = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_alarm_clock_icon_img = ''
        let normal_alarm_clock_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_date_img_date_day = ''
        let normal_calorie_icon_img = ''
        let normal_date_img_date_month_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_battery_current_text_font = ''
        let idle_background_bg = ''
        let idle_stand_icon_img = ''
        let idle_image_img = ''
        let idle_digital_clock_img_time = ''
        let idle_time_hour_min_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_weather_image_progress_img_level = ''
        let idle_alarm_clock_current_text_font = ''
        let idle_alarm_clock_icon_img = ''
        let idle_alarm_clock_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_date_img_date_day = ''
        let idle_calorie_icon_img = ''
        let idle_date_img_date_month_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_font = ''
        let idle_battery_current_text_font = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Bebas11.ttf; FontSize: 38
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 399,
              h: 54,
              text_size: 38,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFF0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Bebas11.ttf; FontSize: 37
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 396,
              h: 52,
              text_size: 37,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Bebas11.ttf; FontSize: 36
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 379,
              h: 51,
              text_size: 36,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

/*            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'str_S.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 268,
              second_posY: 268,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/
				
				

/*            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_cap.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
*/
            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 52-37,
              hour_startY: 160,
              hour_array: ["NUMBERS_B_00.png","NUMBERS_B_01.png","NUMBERS_B_02.png","NUMBERS_B_03.png","NUMBERS_B_04.png","NUMBERS_B_05.png","NUMBERS_B_06.png","NUMBERS_B_07.png","NUMBERS_B_08.png","NUMBERS_B_09.png"],
              hour_zero: 1,
              hour_space: 11,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 252-37,
              minute_startY: 160,
              minute_array: ["NUMBERS_B_00.png","NUMBERS_B_01.png","NUMBERS_B_02.png","NUMBERS_B_03.png","NUMBERS_B_04.png","NUMBERS_B_05.png","NUMBERS_B_06.png","NUMBERS_B_07.png","NUMBERS_B_08.png","NUMBERS_B_09.png"],
              minute_zero: 1,
              minute_space: 11,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: -213-37,
              second_startY: 189,
              second_array: ["S_0.png","S_1.png","S_2.png","S_3.png","S_4.png","S_5.png","S_6.png","S_7.png","S_8.png","S_9.png"],
              second_zero: 1,
              second_space: 400,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
/*            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 154,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 5,
              y: 391,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 188,
              y: 113,
              w: 150,
              h: 50,
              text_size: 38,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFF0000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 129,
              font_array: ["AL_0.png","AL_1.png","AL_2.png","AL_3.png","AL_4.png","AL_5.png","AL_6.png","AL_7.png","AL_8.png","AL_9.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'AL_13.png',
              dot_image: 'AL_0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: -26,
              y: -5,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 87,
              y: -11,
              src: 'main_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 111,
              day_startY: 31,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: -4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 304,
              y: 110,
              src: 'bg_month.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 317,
              month_startY: 118,
              month_sc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_tc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_en_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 315,
              w: 390,
              h: 50,
              text_size: 37,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              //type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 351,
              w: 390,
              h: 50,
              text_size: 37,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              //type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -38,
              y: -10,
              src: 'main_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
            normal_alarm_clock_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 41,
              y: 23,
              src: 'stat_BT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'str_S_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

				

            console.log('Watch_Face.ScreenAOD');

            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

/*            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_cap.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
*/
            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 52-37,
              hour_startY: 160,
              hour_array: ["NUMBERS_B_00.png","NUMBERS_B_01.png","NUMBERS_B_02.png","NUMBERS_B_03.png","NUMBERS_B_04.png","NUMBERS_B_05.png","NUMBERS_B_06.png","NUMBERS_B_07.png","NUMBERS_B_08.png","NUMBERS_B_09.png"],
              hour_zero: 1,
              hour_space: 11,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 252-37,
              minute_startY: 160,
              minute_array: ["NUMBERS_B_00.png","NUMBERS_B_01.png","NUMBERS_B_02.png","NUMBERS_B_03.png","NUMBERS_B_04.png","NUMBERS_B_05.png","NUMBERS_B_06.png","NUMBERS_B_07.png","NUMBERS_B_08.png","NUMBERS_B_09.png"],
              minute_zero: 1,
              minute_space: 11,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

/*              second_startX: -213,
              second_startY: 189,
              second_array: ["S_0.png","S_1.png","S_2.png","S_3.png","S_4.png","S_5.png","S_6.png","S_7.png","S_8.png","S_9.png"],
              second_zero: 1,
              second_space: 400,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,*/

              show_level: hmUI.show_level.ONLY_AOD,
            });

/*            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 154,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });*/

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 5,
              y: 391,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 188,
              y: 113,
              w: 150,
              h: 50,
              text_size: 38,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFF0000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            idle_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 129,
              font_array: ["AL_0.png","AL_1.png","AL_2.png","AL_3.png","AL_4.png","AL_5.png","AL_6.png","AL_7.png","AL_8.png","AL_9.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'AL_13.png',
              dot_image: 'AL_0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: -26,
              y: -5,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 87,
              y: -11,
              src: 'main_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 111,
              day_startY: 31,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: -4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 304,
              y: 110,
              src: 'bg_month.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 317,
              month_startY: 118,
              month_sc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_tc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_en_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 315,
              w: 390,
              h: 50,
              text_size: 37,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
             // type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 351,
              w: 390,
              h: 50,
              text_size: 37,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              //type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -38,
              y: -10,
              src: 'main_3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });	
				
            idle_alarm_clock_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 41,
              y: 23,
              src: 'stat_BT.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
				
				
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 81,
              y: 191,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 263,
              y: 191,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
            //#region time_update
				
				
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;
				
				
normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.SRC, 'str_S_'+second+'.png' ); 
				
normal_alarm_clock_icon_img.setProperty(hmUI.prop.VISIBLE, hmBle.connectStatus() ); 
idle_alarm_clock_icon_img.setProperty(hmUI.prop.VISIBLE, hmBle.connectStatus() ); 
				

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
				  
 let distanceCurrent = distance.current;
 let normal_distance_string = (distanceCurrent / 1000).toFixed(2);
normal_step_current_text_font.setProperty(hmUI.prop.TEXT, "ЧС " + heart_rate.last + " / ШГ " + step.current + " / " + normal_distance_string + " КМ");
idle_step_current_text_font.setProperty(hmUI.prop.TEXT, "ЧС " + heart_rate.last + " / ШГ " + step.current + " / " + normal_distance_string + " КМ");
				  
  let weatherData = weatherSensor.getForecastWeather();
  let temperature_current_temp = -100;
  if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
   temperature_current_temp = weatherSensor.current;
  }; // end currentWeather; 
				  
normal_battery_current_text_font.setProperty(hmUI.prop.TEXT, temperature_current_temp + "°С / " + calorie.current + " ККАЛ / АКБ " + battery.current+ "%");	
idle_battery_current_text_font.setProperty(hmUI.prop.TEXT, temperature_current_temp + "°С / " + calorie.current + " ККАЛ / АКБ " + battery.current+ "%");	

				  
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}