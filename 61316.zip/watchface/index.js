﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 9;
        let normal_calorie_TextCircle_img_height = 12;
        let normal_calorie_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 9;
        let normal_battery_TextCircle_img_height = 12;
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 9;
        let normal_heart_rate_TextCircle_img_height = 12;
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 9;
        let normal_step_TextCircle_img_height = 12;
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_hour_TextCircle = new Array(2);
        let normal_hour_TextCircle_ASCIIARRAY = new Array(10);
        let normal_hour_TextCircle_img_width = 17;
        let normal_hour_TextCircle_img_height = 25;
        let normal_hour_TextCircle_unit = null;
        let normal_hour_TextCircle_unit_width = 7;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextCircle = new Array(2);
        let normal_minute_TextCircle_ASCIIARRAY = new Array(10);
        let normal_minute_TextCircle_img_width = 17;
        let normal_minute_TextCircle_img_height = 25;
        let image_top_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 320,
              h: 380,
              src: 'rainbow_dial_(1).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 142,
              y: 231,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 24,
              y: 299,
              src: 'cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 160,
              // circle_center_Y: 190,
              // font_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              // radius: 182,
              // angle: 217,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = '0019.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = '0020.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = '0021.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = '0022.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = '0023.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = '0024.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = '0025.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = '0026.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = '0027.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = '0028.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 320,
                h: 380,
                center_x: 160,
                center_y: 190,
                pos_x: 160 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 190 + 170,
                src: '0019.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 8,
              y: 246,
              image_array: ["calorias_5.png","calorias_6.png","calorias_7.png","calorias_8.png","calorias_9.png","calorias_10.png","calorias_11.png","calorias_12.png","calorias_13.png","calorias_14.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 249,
              y: 325,
              src: 'batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 160,
              // circle_center_Y: 190,
              // font_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              // radius: 182,
              // angle: 140,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = '0019.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = '0020.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = '0021.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = '0022.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = '0023.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = '0024.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = '0025.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = '0026.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = '0027.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = '0028.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 320,
                h: 380,
                center_x: 160,
                center_y: 190,
                pos_x: 160 - normal_battery_TextCircle_img_width / 2,
                pos_y: 190 + 170,
                src: '0019.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 221,
              y: 214,
              image_array: ["bateria_5.png","bateria_6.png","bateria_7.png","bateria_8.png","bateria_9.png","bateria_10.png","bateria_11.png","bateria_12.png","bateria_13.png","bateria_14.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 241,
              y: 32,
              src: 'bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 160,
              // circle_center_Y: 190,
              // font_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              // radius: 170,
              // angle: 42,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = '0019.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = '0020.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = '0021.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = '0022.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = '0023.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = '0024.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = '0025.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = '0026.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = '0027.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = '0028.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 320,
                h: 380,
                center_x: 160,
                center_y: 190,
                pos_x: 160 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 190 - 182,
                src: '0019.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 179,
              y: 27,
              image_array: ["5.png","6.png","7.png","8.png","9.png","10.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 14,
              y: 81,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 160,
              // circle_center_Y: 192,
              // font_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
              // radius: 169,
              // angle: -41,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = '0019.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = '0020.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = '0021.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = '0022.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = '0023.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = '0024.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = '0025.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = '0026.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = '0027.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = '0028.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 320,
                h: 380,
                center_x: 160,
                center_y: 192,
                pos_x: 160 - normal_step_TextCircle_img_width / 2,
                pos_y: 192 - 181,
                src: '0019.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 6,
              y: 37,
              image_array: ["pasos_5.png","pasos_6.png","pasos_7.png","pasos_8.png","pasos_9.png","pasos_10.png","pasos_11.png","pasos_12.png","pasos_13.png","pasos_14.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 123,
              y: 150,
              week_en: ["day_0026.png","day_0027.png","day_0028.png","day_0029.png","day_0030.png","day_0031.png","day_0038.png"],
              week_tc: ["day_0026.png","day_0027.png","day_0028.png","day_0029.png","day_0030.png","day_0031.png","day_0038.png"],
              week_sc: ["day_0026.png","day_0027.png","day_0028.png","day_0029.png","day_0030.png","day_0031.png","day_0038.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 117,
              y: 330,
              image_array: ["0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 157,
              y: 336,
              font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0018.png',
              unit_tc: '0018.png',
              unit_en: '0018.png',
              negative_image: '0017.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 145,
              day_startY: 120,
              day_sc_array: ["0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png"],
              day_tc_array: ["0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png"],
              day_en_array: ["0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hout_52.png',
              hour_centerX: 160,
              hour_centerY: 190,
              hour_posX: 70,
              hour_posY: 137,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_53.png',
              minute_centerX: 160,
              minute_centerY: 190,
              minute_posX: 59,
              minute_posY: 159,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_36ls.png',
              second_centerX: 160,
              second_centerY: 190,
              second_posX: 39,
              second_posY: 147,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 160,
              // circle_center_Y: 190,
              // font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              // radius: 147,
              // angle: -6,
              // char_space_angle: 0,
              // unit: 'maohao.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextCircle_ASCIIARRAY[0] = '0007.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[1] = '0008.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[2] = '0009.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[3] = '0010.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[4] = '0011.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[5] = '0012.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[6] = '0013.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[7] = '0014.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[8] = '0015.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[9] = '0016.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 320,
                h: 380,
                center_x: 160,
                center_y: 190,
                pos_x: 160 - normal_hour_TextCircle_img_width / 2,
                pos_y: 190 - 172,
                src: '0007.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_hour_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 320,
              h: 380,
              center_x: 160,
              center_y: 190,
              pos_x: 160 - normal_hour_TextCircle_unit_width / 2,
              pos_y: 190 - 172,
              src: 'maohao.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            // normal_minute_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 160,
              // circle_center_Y: 190,
              // font_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              // radius: 147,
              // angle: 8,
              // char_space_angle: 0,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextCircle_ASCIIARRAY[0] = '0007.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[1] = '0008.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[2] = '0009.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[3] = '0010.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[4] = '0011.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[5] = '0012.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[6] = '0013.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[7] = '0014.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[8] = '0015.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[9] = '0016.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 320,
                h: 380,
                center_x: 160,
                center_y: 190,
                pos_x: 160 - normal_minute_TextCircle_img_width / 2,
                pos_y: 190 - 172,
                src: '0007.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block



            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 147,
              y: 180,
              src: 'icon_0042.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 15,
              y: 31,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 205,
              y: 28,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 133,
              y: 220,
              w: 64,
              h: 59,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 116,
              y: 325,
              w: 100,
              h: 46,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 16,
              y: 253,
              w: 84,
              h: 100,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 397;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 182));
                  // alignment = CENTER_H
                  let normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_img_angle * (normal_calorie_circle_string.length - 1);
                  normal_calorie_TextCircle_angleOffset = -normal_calorie_TextCircle_angleOffset;
                  char_Angle -= normal_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 160 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_calorie_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 320;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 182));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 160 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 42;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 170));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 160 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -41;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 169));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 160 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_circle_string = parseInt(valueHour).toString();
              normal_hour_circle_string = normal_hour_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -6;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_circle_string.length > 0 && normal_hour_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_hour_TextCircle_img_angle = 0;
                  let normal_hour_TextCircle_dot_img_angle = 0;
                  let normal_hour_TextCircle_unit_angle = 0;
                  normal_hour_TextCircle_img_angle = toDegree(Math.atan2(normal_hour_TextCircle_img_width/2, 147));
                  normal_hour_TextCircle_unit_angle = toDegree(Math.atan2(normal_hour_TextCircle_unit_width/2, 147));
                  // alignment = CENTER_H
                  let normal_hour_TextCircle_angleOffset = normal_hour_TextCircle_img_angle * (normal_hour_circle_string.length - 1);
                  normal_hour_TextCircle_angleOffset = normal_hour_TextCircle_angleOffset + (normal_hour_TextCircle_img_angle + normal_hour_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= normal_hour_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 160 - normal_hour_TextCircle_img_width / 2);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.SRC, normal_hour_TextCircle_ASCIIARRAY[charCode]);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_hour_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_hour_TextCircle_unit_angle;
                  normal_hour_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_circle_string = parseInt(valueMinute).toString();
              normal_minute_circle_string = normal_minute_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 8;
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_circle_string.length > 0 && normal_minute_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_minute_TextCircle_img_angle = 0;
                  let normal_minute_TextCircle_dot_img_angle = 0;
                  normal_minute_TextCircle_img_angle = toDegree(Math.atan2(normal_minute_TextCircle_img_width/2, 147));
                  // alignment = CENTER_H
                  let normal_minute_TextCircle_angleOffset = normal_minute_TextCircle_img_angle * (normal_minute_circle_string.length - 1);
                  char_Angle -= normal_minute_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_minute_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_minute_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.POS_X, 160 - normal_minute_TextCircle_img_width / 2);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.SRC, normal_minute_TextCircle_ASCIIARRAY[charCode]);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_minute_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}