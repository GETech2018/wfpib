﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// for vibration feedback
const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
let timer_StopVibrate = null;

function makeVibrate(level = 1) {
  let stopDelay = 50;
  stopVibrate();
  
  // after oct 23 system update the values are as follow: 1 (scene 26 - low) for buttons,
  // 2 (scene 27 - mid) for open settings and 3 (scene 29 - high) for closing settings.
  const levelToScene = {
    1: 26,
    2: 27,
    3: 29
  };

  let scene = levelToScene[level] || 25;
  vibrate.scene = scene;
  if (scene > 25) stopDelay = 1300;
  vibrate.start();
  timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibrate, {});
}

function stopVibrate() {
  vibrate.stop();
  if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
}

// variables with default values
let isStyleTwoActive = false;
let clockHrHighCurrSize = "BIG";
let clockHrLowCurrSize  = "SMALL";
let clockMinHighCurrSize = "SMALL";
let clockMinLowCurrSize  = "BIG";
let clockHrHighCurrWidth = 186;
let clockHrLowCurrWidth = 94;
let clockMinHighCurrWidth = 94;
let clockMinLowCurrWidth = 186;
let clockHrLowCurrXPos  = 243;
let clockMinLowCurrXPos = 150;
let currBGStyle = "STYLE1"

const colorsSet = [
    "BLUE",
    "CYAN",
    "TURQUOISE",
    "LIME",
    "GREEN",
    "YELLOW",
    "ORANGE",
    "RED",
    "PINK",
    "VIOLET",
    "GREY"
];
let colorsIndex = 0;
let currColor = colorsSet[colorsIndex];

const hrOverlaysSet = [
    "WHITE", "WHITE-2", "GREY", "DARK"
];
let hrOverlaysIndex = 0;
let currHrOverlay = hrOverlaysSet[hrOverlaysIndex];
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_time_second_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_battery_current_text_font = ''
        let idle_time_second_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SFCompactRounded-Medium-MOD.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 381,
              h: 43,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SFCompactRounded-Medium-MOD.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SFCompactRounded-Medium-MOD.ttf; FontSize: 30; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 36,
              h: 36,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SFCompactRounded-Medium-MOD.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

let bgColor = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'colors/BLUE.png',
    x: 0,
    y: 0,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockHROverlay = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'hroverlay/WHITE.png',
    x: 0,
    y: 0,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockBGStyle = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'OVERLAY_STYLE1.png',
    x: 0,
    y: 0,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'TRANSPARENT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 155,
              y: 0,
              w: 80,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 307,
              y: 51,
              image_array: ["WEATHERICON_INV_1.png","WEATHERICON_INV_2.png","WEATHERICON_INV_3.png","WEATHERICON_INV_4.png","WEATHERICON_INV_5.png","WEATHERICON_INV_6.png","WEATHERICON_INV_7.png","WEATHERICON_INV_8.png","WEATHERICON_INV_9.png","WEATHERICON_INV_10.png","WEATHERICON_INV_11.png","WEATHERICON_INV_12.png","WEATHERICON_INV_13.png","WEATHERICON_INV_14.png","WEATHERICON_INV_15.png","WEATHERICON_INV_16.png","WEATHERICON_INV_17.png","WEATHERICON_INV_18.png","WEATHERICON_INV_19.png","WEATHERICON_INV_20.png","WEATHERICON_INV_21.png","WEATHERICON_INV_22.png","WEATHERICON_INV_23.png","WEATHERICON_INV_24.png","WEATHERICON_INV_25.png","WEATHERICON_INV_26.png","WEATHERICON_INV_27.png","WEATHERICON_INV_28.png","WEATHERICON_INV_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 150,
              y: 48,
              w: 150,
              h: 60,
              text_size: 30,
              char_space: 0,
              font: 'fonts/SFCompactRounded-Medium-MOD.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 89,
              y: 48,
              w: 150,
              h: 60,
              text_size: 30,
              char_space: 0,
              font: 'fonts/SFCompactRounded-Medium-MOD.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_type: 1,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 81,
              y: 361,
              w: 150,
              h: 60,
              text_size: 30,
              char_space: 0,
              font: 'fonts/SFCompactRounded-Medium-MOD.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 0,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

let clockDigitHrHigh = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'NUMBER_BIG_0.png',
    x: 53,
    y: 102,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockDigitHrLow = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'NUMBER_SMALL_0.png',
    x: 243,
    y: 102,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockDigitMinHigh = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'NUMBER_SMALL_0.png',
    x: 53,
    y: 229,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockDigitMinLow = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'NUMBER_BIG_0.png',
    x: 150,
    y: 229,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let bgAOD = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'BG_AOD.png',
    x: 0,
    y: 0,
    show_level: hmUI.show_level.ONLY_AOD,
});

let clockDigitHrHighAOD_S1 = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'NUMBER_AOD_BIG_0.png',
    x: 53,
    y: 102,
    show_level: hmUI.show_level.ONLY_AOD,
});

let clockDigitHrLowAOD_S1 = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'NUMBER_AOD_SMALL_0.png',
    x: 243,
    y: 102,
    show_level: hmUI.show_level.ONLY_AOD,
});

let clockDigitMinHighAOD_S1 = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'NUMBER_AOD_SMALL_0.png',
    x: 53,
    y: 229,
    show_level: hmUI.show_level.ONLY_AOD,
});

let clockDigitMinLowAOD_S1 = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'NUMBER_AOD_BIG_0.png',
    x: 150,
    y: 229,
    show_level: hmUI.show_level.ONLY_AOD,
});

let clockDigitHrHighAOD_S2 = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'NUMBER_AOD_SMALL_0.png',
    x: 53,
    y: 102,
    show_level: hmUI.show_level.ONLY_AOD,
});

let clockDigitHrLowAOD_S2 = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'NUMBER_AOD_BIG_0.png',
    x: 150,
    y: 102,
    show_level: hmUI.show_level.ONLY_AOD,
});

let clockDigitMinHighAOD_S2 = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'NUMBER_AOD_BIG_0.png',
    x: 53,
    y: 229,
    show_level: hmUI.show_level.ONLY_AOD,
});

let clockDigitMinLowAOD_S2 = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'NUMBER_AOD_SMALL_0.png',
    x: 243,
    y: 229,
    show_level: hmUI.show_level.ONLY_AOD,
});

//set visibility for digits
clockDigitHrHighAOD_S1.setProperty(hmUI.prop.VISIBLE, hmFS.SysProGetBool('styleOneVisible') ?? true);
clockDigitHrLowAOD_S1.setProperty(hmUI.prop.VISIBLE, hmFS.SysProGetBool('styleOneVisible') ?? true);
clockDigitMinHighAOD_S1.setProperty(hmUI.prop.VISIBLE, hmFS.SysProGetBool('styleOneVisible') ?? true);
clockDigitMinLowAOD_S1.setProperty(hmUI.prop.VISIBLE, hmFS.SysProGetBool('styleOneVisible') ?? true);
clockDigitHrHighAOD_S2.setProperty(hmUI.prop.VISIBLE, hmFS.SysProGetBool('styleTwoVisible') ?? false);
clockDigitHrLowAOD_S2.setProperty(hmUI.prop.VISIBLE, hmFS.SysProGetBool('styleTwoVisible') ?? false);
clockDigitMinHighAOD_S2.setProperty(hmUI.prop.VISIBLE, hmFS.SysProGetBool('styleTwoVisible') ?? false);
clockDigitMinLowAOD_S2.setProperty(hmUI.prop.VISIBLE, hmFS.SysProGetBool('styleTwoVisible') ?? false);

function updateMins(){
    let currHourFormat = hmSetting.getTimeFormat(); // 0 = 12h, 1 = 24h
    let clockHr = timeSensor.hour;
    let clockMin = timeSensor.minute;

    //convert clock depending on format
    if (currHourFormat == 0){
        if (clockHr == 0){
            clockHr = 12;
        }else if (clockHr > 12){
            clockHr -= 12;
        }
    }

    //add zeros if its less than 10
    let clockHrTXT = clockHr.toString().padStart(2, "0");
    let clockMinsTXT = clockMin.toString().padStart(2, "0");

    //set digits (normal and aod)
    //normal
    let clockHrHigh_SRC = "NUMBER_" + clockHrHighCurrSize + "_" + clockHrTXT[0] + ".png";
    let clockHrLow_SRC = "NUMBER_" + clockHrLowCurrSize + "_" + clockHrTXT[1] + ".png";
    let clockMinsHigh_SRC = "NUMBER_" + clockMinHighCurrSize + "_" + clockMinsTXT[0] + ".png";
    let clockMinsLow_SRC = "NUMBER_" + clockMinLowCurrSize + "_" + clockMinsTXT[1] + ".png";
    //aod
    //style1
    let clockAODHrHigh_S1_SRC = "NUMBER_AOD_BIG_" + clockHrTXT[0] + ".png";
    let clockAODHrLow_S1_SRC = "NUMBER_AOD_SMALL_" + clockHrTXT[1] + ".png";
    let clockAODMinsHigh_S1_SRC = "NUMBER_AOD_SMALL_" + clockMinsTXT[0] + ".png";
    let clockAODMinsLow_S1_SRC = "NUMBER_AOD_BIG_" + clockMinsTXT[1] + ".png";
    //style2
    let clockAODHrHigh_S2_SRC = "NUMBER_AOD_SMALL_" + clockHrTXT[0] + ".png";
    let clockAODHrLow_S2_SRC = "NUMBER_AOD_BIG_" + clockHrTXT[1] + ".png";
    let clockAODMinsHigh_S2_SRC = "NUMBER_AOD_BIG_" + clockMinsTXT[0] + ".png";
    let clockAODMinsLow_S2_SRC = "NUMBER_AOD_SMALL_" + clockMinsTXT[1] + ".png";

    //update digits (normal and aod)
    //normal
    clockDigitHrHigh.setProperty(hmUI.prop.MORE, {
        src: clockHrHigh_SRC,
        w: clockHrHighCurrWidth
    });
    clockDigitHrLow.setProperty(hmUI.prop.MORE, {
        src: clockHrLow_SRC,
        x: clockHrLowCurrXPos,
        w: clockHrLowCurrWidth
    });
    clockDigitMinHigh.setProperty(hmUI.prop.MORE, {
        src: clockMinsHigh_SRC,
        w: clockMinHighCurrWidth
    });
    clockDigitMinLow.setProperty(hmUI.prop.MORE, {
        src: clockMinsLow_SRC,
        x: clockMinLowCurrXPos,
        w: clockMinLowCurrWidth
    });
    //aod
    //style1
    clockDigitHrHighAOD_S1.setProperty(hmUI.prop.SRC, clockAODHrHigh_S1_SRC);
    clockDigitHrLowAOD_S1.setProperty(hmUI.prop.SRC, clockAODHrLow_S1_SRC);
    clockDigitMinHighAOD_S1.setProperty(hmUI.prop.SRC, clockAODMinsHigh_S1_SRC);
    clockDigitMinLowAOD_S1.setProperty(hmUI.prop.SRC, clockAODMinsLow_S1_SRC);
    //style2
    clockDigitHrHighAOD_S2.setProperty(hmUI.prop.SRC, clockAODHrHigh_S2_SRC);
    clockDigitHrLowAOD_S2.setProperty(hmUI.prop.SRC, clockAODHrLow_S2_SRC);
    clockDigitMinHighAOD_S2.setProperty(hmUI.prop.SRC, clockAODMinsHigh_S2_SRC);
    clockDigitMinLowAOD_S2.setProperty(hmUI.prop.SRC, clockAODMinsLow_S2_SRC);
}
updateMins();
            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 46,
              y: 46,
              w: 140,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 220,
              y: 46,
              w: 120,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 70,
              y: 112,
              w: 250,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 70,
              y: 238,
              w: 250,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 46,
              y: 360,
              w: 125,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 254,
              y: 342,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'MusicCommonScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 140,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                showSettings()
makeVibrate(2)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let settingsBG = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: "settings/SETTINGS_BG.png"
});

let prevColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 0,
    y: 45,
    w: 100,
    h: 360,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/EDGEBTN_PREV_PRESSED.png',
    normal_src: 'settings/EDGEBTN_PREV_NORMAL.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    click_func: (button_widget) => {
    prevColor()
    makeVibrate(1)
    }, // end func
}); // end button

let nextColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 290,
    y: 45,
    w: 100,
    h: 360,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/EDGEBTN_NEXT_PRESSED.png',
    normal_src: 'settings/EDGEBTN_NEXT_NORMAL.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    click_func: (button_widget) => {
    nextColor()
    makeVibrate(1)
    }, // end func
}); // end button

let changeHrOverlaybtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 52,
    y: 102,
    w: 284,
    h: 117,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'BUTTON.png',
    normal_src: 'BUTTON.png',
    click_func: (button_widget) => {
    changeHrOverlay()
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let changeClockStylebtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 52,
    y: 229,
    w: 284,
    h: 117,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'BUTTON.png',
    normal_src: 'BUTTON.png',
    click_func: (button_widget) => {
    changeClockStyle()
    updateMins()
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let Confirmbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 135,
    y: 350,
    w: 120,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_CONFIRM_PRESSED.png',
    normal_src: 'settings/BTN_CONFIRM_NORMAL.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    click_func: (button_widget) => {
    hideSettings()
    makeVibrate(3)
    }, // end func
}); // end button

// functions to change colors
function prevColor(){
    colorsIndex = (colorsIndex - 1 + colorsSet.length) % colorsSet.length;
    updateWatchface();
}

function nextColor(){
    colorsIndex = (colorsIndex + 1) % colorsSet.length;
    updateWatchface();
}

function updateWatchface(){
    currColor = colorsSet[colorsIndex];
    let currBgColor_SRC = "colors/" + currColor + ".png";
    bgColor.setProperty(hmUI.prop.SRC, currBgColor_SRC);
}

function changeHrOverlay(){
    hrOverlaysIndex = (hrOverlaysIndex + 1) % hrOverlaysSet.length;
    currHrOverlay = hrOverlaysSet[hrOverlaysIndex];

    let currHrOverlay_SRC = "hroverlay/" + currHrOverlay + ".png";
    clockHROverlay.setProperty(hmUI.prop.SRC, currHrOverlay_SRC);
}

function changeClockStyle(){
    isStyleTwoActive = !isStyleTwoActive
    
    if (isStyleTwoActive){
        // Clock numbers size
        clockHrHighCurrSize = "SMALL"
        clockHrLowCurrSize = "BIG"
        clockMinHighCurrSize = "BIG"
        clockMinLowCurrSize = "SMALL"

        // Clock low digits position and width
        clockHrHighCurrWidth = 94;
        clockHrLowCurrWidth = 186;
        clockMinHighCurrWidth = 186;
        clockMinLowCurrWidth = 94;
        clockHrLowCurrXPos = 150;
        clockMinLowCurrXPos = 243;

        // BG Style
        currBGStyle = "STYLE2"
        hmFS.SysProSetBool('styleOneVisible', false);
        hmFS.SysProSetBool('styleTwoVisible', true);
    }else{
        clockHrHighCurrSize = "BIG"
        clockHrLowCurrSize = "SMALL"
        clockMinHighCurrSize = "SMALL"
        clockMinLowCurrSize = "BIG"

        // Clock digits position and width
        clockHrHighCurrWidth = 186;
        clockHrLowCurrWidth = 94;
        clockMinHighCurrWidth = 94;
        clockMinLowCurrWidth = 186;
        clockHrLowCurrXPos = 243;
        clockMinLowCurrXPos = 150;

        // BG Style
        currBGStyle = "STYLE1"
        hmFS.SysProSetBool('styleOneVisible', true);
        hmFS.SysProSetBool('styleTwoVisible', false);
    }
    let currBGStyle_SRC = "OVERLAY_" + currBGStyle + ".png";
    clockBGStyle.setProperty(hmUI.prop.SRC, currBGStyle_SRC);
}
changeClockStyle();

function hideSettings(){
    // normal buttons
    Button_1.setProperty(hmUI.prop.VISIBLE, true);
    Button_2.setProperty(hmUI.prop.VISIBLE, true);
    Button_3.setProperty(hmUI.prop.VISIBLE, true);
    Button_4.setProperty(hmUI.prop.VISIBLE, true);
    Button_5.setProperty(hmUI.prop.VISIBLE, true);
    Button_6.setProperty(hmUI.prop.VISIBLE, true);

    // settings layout
    settingsBG.setProperty(hmUI.prop.VISIBLE, false);
    prevColorbtn.setProperty(hmUI.prop.VISIBLE, false);
    nextColorbtn.setProperty(hmUI.prop.VISIBLE, false);
    changeHrOverlaybtn.setProperty(hmUI.prop.VISIBLE, false);
    changeClockStylebtn.setProperty(hmUI.prop.VISIBLE, false);
    Confirmbtn.setProperty(hmUI.prop.VISIBLE, false);
}
hideSettings();

function showSettings(){
    // normal buttons
    Button_1.setProperty(hmUI.prop.VISIBLE, false);
    Button_2.setProperty(hmUI.prop.VISIBLE, false);
    Button_3.setProperty(hmUI.prop.VISIBLE, false);
    Button_4.setProperty(hmUI.prop.VISIBLE, false);
    Button_5.setProperty(hmUI.prop.VISIBLE, false);
    Button_6.setProperty(hmUI.prop.VISIBLE, false);
    
    // settings layout
    settingsBG.setProperty(hmUI.prop.VISIBLE, true);
    prevColorbtn.setProperty(hmUI.prop.VISIBLE, true);
    nextColorbtn.setProperty(hmUI.prop.VISIBLE, true);
    changeHrOverlaybtn.setProperty(hmUI.prop.VISIBLE, true);
    changeClockStylebtn.setProperty(hmUI.prop.VISIBLE, true);
    Confirmbtn.setProperty(hmUI.prop.VISIBLE, true);
}
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
                updateMins();
                console.log('full date str');
                if (updateHour) {
                    let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                    let normal_dayStr = timeSensor.day.toString();

                    let fullDateStr = normal_DOW_Str + " " + normal_dayStr;
                    normal_dow_text_font.setProperty(hmUI.prop.TEXT, fullDateStr );
                };
            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      time_update(updateHour);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      time_update(updateHour);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}