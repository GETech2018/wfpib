try { (()=>{
const app=__$$hmAppManager$$__.currentApp,module=app.current;
module.module=DeviceRuntimeCore.WatchFace({
init_view(){
const N=hmUI.show_level.ONLY_NORMAL,A=hmUI.show_level.ONAL_AOD;
const time=hmSensor.createSensor(hmSensor.id.TIME),battery=hmSensor.createSensor(hmSensor.id.BATTERY);
const tx=(x,y,w,h,text,size,color,level,align=hmUI.align.CENTER_H)=>hmUI.createWidget(hmUI.widget.TEXT,{x,y,w,h,text,text_size:size,color,align_h:align,align_v:hmUI.align.CENTER_V,show_level:level});
const hours=Array.from({length:10},(_,i)=>`tower_hour_${i}.png`);
const minutes=Array.from({length:10},(_,i)=>`tower2_minute_${i}.png`);
const seconds=Array.from({length:10},(_,i)=>`tower_second_${i}.png`);
const smallDigits=Array.from({length:10},(_,i)=>`${String(87+i).padStart(4,'0')}.png`);
const largeDigits=Array.from({length:10},(_,i)=>`line2_font_${i}.png`);
function timeWidgets(level){
  hmUI.createWidget(hmUI.widget.IMG_TIME,{hour_startX:20,hour_startY:116,hour_array:hours,hour_zero:true,hour_space:0,hour_align:hmUI.align.LEFT,enable:false,show_level:level});
  hmUI.createWidget(hmUI.widget.IMG_TIME,{minute_startX:198,minute_startY:58,minute_array:minutes,minute_zero:true,minute_space:0,minute_align:hmUI.align.LEFT,enable:false,show_level:level});
  // Date and weekday share a right edge below the minute digits.
  const weekday=tx(180,353,104,38,'FRI',33,0x646464,level,hmUI.align.RIGHT);
  const date=tx(180,390,104,40,'NOV 13',24,0xffffff,level,hmUI.align.RIGHT);
  return {weekday,date};
}
const normal=timeWidgets(N),aod=timeWidgets(A);
hmUI.createWidget(hmUI.widget.IMG_TIME,{second_startX:292,second_startY:355,second_array:seconds,second_zero:true,second_space:0,second_follow:0,second_align:hmUI.align.LEFT,enable:false,show_level:N});
const weatherImages=Array.from({length:29},(_,i)=>`line2_weather_${String(i).padStart(2,'0')}.png`);
for(const level of [N,A]){
  hmUI.createWidget(hmUI.widget.IMG_LEVEL,{x:51,y:72,image_array:weatherImages,image_length:29,type:hmUI.data_type.WEATHER_CURRENT,show_level:level});
  hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:89,y:72,w:102,h:46,font_array:largeDigits,padding:false,h_space:0,unit_sc:['line2_degree.png'],unit_tc:['line2_degree.png'],unit_en:['line2_degree.png'],negative_image:['line2_minus.png'],invalid_image:['line2_minus.png'],align_h:hmUI.align.LEFT,type:hmUI.data_type.WEATHER_CURRENT,show_level:level});
}
// The three groups center the live battery icon and value for 1, 2 or 3 digits.
const batteryImages=Array.from({length:10},(_,i)=>`line2_battery_${i}.png`);
const batteryGroups=[1,2,3].map(n=>{
  const x=290-Math.floor((26+4+n*16+13)/2);
  return {
    icon:hmUI.createWidget(hmUI.widget.IMG_LEVEL,{x,y:17,image_array:batteryImages,image_length:10,type:hmUI.data_type.BATTERY,show_level:N}),
    value:hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:x+30,y:25,w:64,h:37,font_array:smallDigits,padding:false,h_space:0,unit_sc:['inline_percent.png'],unit_tc:['inline_percent.png'],unit_en:['inline_percent.png'],align_h:hmUI.align.LEFT,type:hmUI.data_type.BATTERY,show_level:N})
  };
});
// Fixed groups allow system-bound numbers to update without losing spacing.
const stepGroups=[1,2,3,4,5].map(n=>{
  const x=100-Math.floor((25+3+n*20)/2);
  return {
    icon:hmUI.createWidget(hmUI.widget.IMG,{x,y:21,src:'line2_steps.png',show_level:N}),
    value:hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:x+28,y:19,w:100,h:46,font_array:largeDigits,padding:false,h_space:0,align_h:hmUI.align.LEFT,type:hmUI.data_type.STEP,show_level:N})
  };
});
let steps;
try{steps=hmSensor.createSensor(hmSensor.id.STEP)}catch(e){}
function reading(sensor,prop,method){try{const n=sensor&&typeof sensor[method]==='function'?sensor[method]():sensor&&sensor[prop];return n!==null&&n!==undefined&&Number.isFinite(Number(n))?Math.max(0,Math.floor(Number(n))):null}catch(e){return null}}
function displayGroup(groups,len){groups.forEach((g,i)=>{g.icon.setProperty(hmUI.prop.VISIBLE,i===len-1);g.value.setProperty(hmUI.prop.VISIBLE,i===len-1)})}
function alignSteps(){const n=reading(steps,'current','getCurrent');displayGroup(stepGroups,n===null?3:Math.min(5,String(n).length))}
function alignBattery(){const n=reading(battery,'current','getCurrent');displayGroup(batteryGroups,n===null?2:Math.min(3,String(n).length))}
const days=['MON','TUE','WED','THU','FRI','SAT','SUN'],months=['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
function update(){
  const day=days[(time.week+6)%7],date=months[time.month-1]+' '+time.day;
  for(const item of [normal,aod]){item.weekday.setProperty(hmUI.prop.MORE,{text:day});item.date.setProperty(hmUI.prop.MORE,{text:date})}
  try{alignSteps();alignBattery()}catch(e){}
}
// Keep destinations unchanged from the earlier Line watchface.
for(const [x,y,w,h,url] of [[20,116,160,312,'CountdownAppScreen'],[198,58,168,282,'CountdownAppScreen'],[292,355,74,72,'CountdownAppScreen'],[32,68,160,47,'WeatherScreen'],[180,350,104,82,'ScheduleCalScreen']]){
  hmUI.createWidget(hmUI.widget.BUTTON,{x,y,w,h,text:'',normal_src:'tap_clear.png',press_src:'tap_clear.png',show_level:N,click_func:()=>hmApp.startApp({url,native:true})});
}
hmUI.createWidget(hmUI.widget.IMG_CLICK,{x:29,y:12,w:145,h:48,src:'',type:hmUI.data_type.STEP,show_level:N});
time.addEventListener(hmSensor.event.CHANGE,update);
try{if(steps)steps.addEventListener(hmSensor.event.CHANGE,alignSteps)}catch(e){}
try{battery.addEventListener(hmSensor.event.CHANGE,alignBattery)}catch(e){}
hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE,{resume_call(){update()},pause_call(){}});update();
},onInit(){this.init_view()},onReady(){},onShow(){},onHide(){},onDestroy(){}});
})()}catch(e){console.log(e)}
