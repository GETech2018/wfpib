﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// ===== GLOBAL STATE =====

const bgTextures = [
    "bg/rgb.png",
    "bg/neon.png",
    "bg/beige.png",
    "bg/purple.png",
    "bg/violet.png",
    "bg/orange.png"
];

let bgIndex = hmFS.SysProGetInt("bgIndex") ?? 0;

// go next
function nextBG(){
    bgIndex = (bgIndex + 1) % bgTextures.length;
    hmFS.SysProSetInt("bgIndex", bgIndex);
}

// ===== DIGIT STYLE BASED ON BG =====
function getDigitStyle(){
    // orange(5), purple(3), violet(4) → WHITE
    if (bgIndex == 5 || bgIndex == 3 || bgIndex == 4){
        return "white";
    }
    // rest → BLACK
    return "black";
}
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_time_second_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let idle_time_second_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'TRANSPARENT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
// ===== CREATE BACKGROUND =====

var bg = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: bgTextures[bgIndex],
    show_level: hmUI.show_level.ONLY_NORMAL
});

// ===== AOD BACKGROUND =====

var aodBg = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: "bg/aodbg.png",
    show_level: hmUI.show_level.ONLY_AOD
});

// ===== CONSTANT POSITIONS =====

const LEFT_X = 104;
const RIGHT_X = 186;

const HOURS_Y = 86;
const MINUTES_Y = 224;

// ===== DIGITS =====

// HOURS
var hour1 = hmUI.createWidget(hmUI.widget.IMG, {
    x: LEFT_X,
    y: HOURS_Y,
    w: 200,
    h: 200,
    src: "numbers/black/NUMBER_0.png",
    show_level: hmUI.show_level.ONLY_NORMAL
});

var hour2 = hmUI.createWidget(hmUI.widget.IMG, {
    x: RIGHT_X,
    y: HOURS_Y,
    w: 200,
    h: 200,
    src: "numbers/black/NUMBER_0.png",
    show_level: hmUI.show_level.ONLY_NORMAL
});

// MINUTES
var min1 = hmUI.createWidget(hmUI.widget.IMG, {
    x: LEFT_X,
    y: MINUTES_Y,
    w: 200,
    h: 200,
    src: "numbers/black/NUMBER_0.png",
    show_level: hmUI.show_level.ONLY_NORMAL
});

var min2 = hmUI.createWidget(hmUI.widget.IMG, {
    x: RIGHT_X,
    y: MINUTES_Y,
    w: 200,
    h: 200,
    src: "numbers/black/NUMBER_0.png",
    show_level: hmUI.show_level.ONLY_NORMAL
});


var bg_AOD = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: "bg/aodbg.png",
    show_level: hmUI.show_level.ONLY_AOD
});

// ===== AOD DIGITS =====

// HOURS AOD
var hour1_AOD = hmUI.createWidget(hmUI.widget.IMG, {
    x: LEFT_X,
    y: HOURS_Y,
    w: 200,
    h: 200,
    src: "numbers/white/NUMBER_0.png",
    show_level: hmUI.show_level.ONLY_AOD
});

var hour2_AOD = hmUI.createWidget(hmUI.widget.IMG, {
    x: RIGHT_X,
    y: HOURS_Y,
    w: 200,
    h: 200,
    src: "numbers/white/NUMBER_0.png",
    show_level: hmUI.show_level.ONLY_AOD
});

// MINUTES AOD
var min1_AOD = hmUI.createWidget(hmUI.widget.IMG, {
    x: LEFT_X,
    y: MINUTES_Y,
    w: 200,
    h: 200,
    src: "numbers/white/NUMBER_0.png",
    show_level: hmUI.show_level.ONLY_AOD
});

var min2_AOD = hmUI.createWidget(hmUI.widget.IMG, {
    x: RIGHT_X,
    y: MINUTES_Y,
    w: 200,
    h: 200,
    src: "numbers/white/NUMBER_0.png",
    show_level: hmUI.show_level.ONLY_AOD
});
            // end user_script.js

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 0,
              w: 150,
              h: 30,
              text_size: 1,
              char_space: 0,
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 0,
              w: 150,
              h: 30,
              text_size: 1,
              char_space: 0,
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

// ===== FULL SCREEN TAP =====

var tapZone = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 120,
    y: 120,
    w: 150,
    h: 150,
    text: "",
    normal_src: "",
    press_src: "",
    click_func: () => {
        nextBG();
        renderBG();
        renderClock(); // ⭐ update digits immediately
    }
});
            // end user_script_beforeShortcuts.js

            console.log('user_script_end.js');
            // start user_script_end.js

// ===== RENDER BACKGROUND =====

function renderBG(){
    bg.setProperty(hmUI.prop.SRC, bgTextures[bgIndex]);
}

// initial render
renderBG();

// ===== TIME SENSOR =====
// Note: timeSensor is declared by Sasha's generated wrapper before this script runs.
// We just use it directly, same as the reference.

// ===== UPDATE CLOCK =====

function renderClock() {
    let h = timeSensor.hour;
    let m = timeSensor.minute;

    let hStr = h.toString().padStart(2, "0");
    let mStr = m.toString().padStart(2, "0");

    let style = getDigitStyle();

    // ===== HOURS =====
    let isSingleDigitHour = (hStr[0] === "0");

    hour1.setProperty(hmUI.prop.SRC, "numbers/" + style + "/NUMBER_" + hStr[0] + ".png");
    hour2.setProperty(hmUI.prop.SRC, "numbers/" + style + "/NUMBER_" + hStr[1] + ".png");

    // ===== MINUTES =====
    min1.setProperty(hmUI.prop.SRC, "numbers/" + style + "/NUMBER_" + mStr[0] + ".png");
    min2.setProperty(hmUI.prop.SRC, "numbers/" + style + "/NUMBER_" + mStr[1] + ".png");

    // ===== AOD =====
    hour1_AOD.setProperty(hmUI.prop.SRC, "numbers/white/NUMBER_" + hStr[0] + ".png");
    hour2_AOD.setProperty(hmUI.prop.SRC, "numbers/white/NUMBER_" + hStr[1] + ".png");

    min1_AOD.setProperty(hmUI.prop.SRC, "numbers/white/NUMBER_" + mStr[0] + ".png");
    min2_AOD.setProperty(hmUI.prop.SRC, "numbers/white/NUMBER_" + mStr[1] + ".png");
}

// initial render
renderClock();
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
              console.log('second font');
                let idle_secondStr = second.toString();
                idle_time_second_text_font.setProperty(hmUI.prop.TEXT, idle_secondStr );
            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

                console.log('pause_call.js');
                // start pause_call.js

// ===== KEEP STATE ON RESUME =====

function pause_call(){
    // nothing needed but prevents reset issues
}
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}