try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        const __$$module$$__ = __$$app$$__.current;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 390, h: 450, src: 'bg.png', show_level: hmUI.show_level.ONLY_NORMAL });

                // Hora principal ajustada do BIN original 302x320 para o projeto Bip 6.
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 152,
                    hour_startY: 63,
                    hour_array: ["img_003.png", "img_004.png", "img_005.png", "img_006.png", "img_007.png", "img_008.png", "img_009.png", "img_010.png", "img_011.png", "img_012.png"],
                    hour_space: -3,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 242,
                    minute_startY: 63,
                    minute_array: ["img_003.png", "img_004.png", "img_005.png", "img_006.png", "img_007.png", "img_008.png", "img_009.png", "img_010.png", "img_011.png", "img_012.png"],
                    minute_space: -3,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, { x: 223, y: 65, src: 'colon.png', show_level: hmUI.show_level.ONLY_NORMAL });

                // Dia da semana e dia do mês no topo direito.
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 256,
                    y: 46,
                    week_en: ["img_023.png", "img_024.png", "img_025.png", "img_026.png", "img_027.png", "img_028.png", "img_029.png"],
                    week_sc: ["img_023.png", "img_024.png", "img_025.png", "img_026.png", "img_027.png", "img_028.png", "img_029.png"],
                    week_tc: ["img_023.png", "img_024.png", "img_025.png", "img_026.png", "img_027.png", "img_028.png", "img_029.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 323,
                    day_startY: 45,
                    day_sc_array: ["img_013.png", "img_014.png", "img_015.png", "img_016.png", "img_017.png", "img_018.png", "img_019.png", "img_020.png", "img_021.png", "img_022.png"],
                    day_tc_array: ["img_013.png", "img_014.png", "img_015.png", "img_016.png", "img_017.png", "img_018.png", "img_019.png", "img_020.png", "img_021.png", "img_022.png"],
                    day_en_array: ["img_013.png", "img_014.png", "img_015.png", "img_016.png", "img_017.png", "img_018.png", "img_019.png", "img_020.png", "img_021.png", "img_022.png"],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });

                // Passos no cartão do alarme.
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 95,
                    y: 240,
                    type: hmUI.data_type.STEP,
                    font_array: ["img_030.png", "img_031.png", "img_032.png", "img_033.png", "img_034.png", "img_035.png", "img_036.png", "img_037.png", "img_038.png", "img_039.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });

                // Batimentos no círculo esquerdo.
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 66,
                    y: 343,
                    type: hmUI.data_type.HEART,
                    font_array: ["img_030.png", "img_031.png", "img_032.png", "img_033.png", "img_034.png", "img_035.png", "img_036.png", "img_037.png", "img_038.png", "img_039.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });

                // Temperatura no centro inferior.
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 181,
                    y: 384,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: ["img_030.png", "img_031.png", "img_032.png", "img_033.png", "img_034.png", "img_035.png", "img_036.png", "img_037.png", "img_038.png", "img_039.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });

                // Bateria no círculo direito.
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 294,
                    y: 342,
                    type: hmUI.data_type.BATTERY,
                    font_array: ["img_030.png", "img_031.png", "img_032.png", "img_033.png", "img_034.png", "img_035.png", "img_036.png", "img_037.png", "img_038.png", "img_039.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
            },
            onInit() {},
            build() { this.init_view(); },
            onDestroy() {}
        });
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
