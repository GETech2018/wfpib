try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_8e48a8dfff204394a8cd4af4b0a4393e = '';
        let normal$_$text_560114db21784e7686cbb0d6d5678f11 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_b416396a407d411ba24606305e30652e = '';
        let stepSensor = '';
        let timeSensor = '';
        let batterySensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 320,
                    h: 380,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_8e48a8dfff204394a8cd4af4b0a4393e = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 126,
                    y: 288,
                    w: 68,
                    h: 40,
                    text: '[SC]',
                    color: '0xFFffffff',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_560114db21784e7686cbb0d6d5678f11 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 212,
                    y: 30,
                    w: 55,
                    h: 20,
                    text: '[MON_Z]/[DAY_Z]',
                    color: '0xFFffffff',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_b416396a407d411ba24606305e30652e = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 54,
                    y: 30,
                    w: 55,
                    h: 20,
                    text: '[BATT_PER]%',
                    color: '0xFFffffff',
                    text_size: 19,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 14,
                    hour_startY: 74,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: -7,
                    hour_unit_sc: '13.png',
                    hour_unit_tc: '13.png',
                    hour_unit_en: '13.png',
                    hour_align: hmUI.align.CENTER_H,
                    minute_zero: 1,
                    minute_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    minute_follow: 1,
                    am_x: 36,
                    am_y: 141,
                    am_en_path: '14.png',
                    pm_x: 36,
                    pm_y: 141,
                    pm_en_path: '15.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 166,
                    y: 271,
                    image_array: [
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png'
                    ],
                    image_length: 6,
                    type: hmUI.data_type.SPO2,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 241,
                    y: 326,
                    type: hmUI.data_type.SPO2,
                    font_array: [
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '32.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 0,
                    y: 271,
                    image_array: [
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png'
                    ],
                    image_length: 6,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 40,
                    y: 326,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '39.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 160,
                    center_y: 313,
                    radius: 90,
                    start_angle: -58,
                    end_angle: 59,
                    color: 4288652885,
                    line_width: 10,
                    src_bg: '40.png',
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 148,
                    y: 48,
                    src: '41.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 19,
                    y: 213,
                    src: '42.png',
                    type: hmUI.system_status.DISTURB,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 148,
                    y: 11,
                    src: '43.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 279,
                    y: 213,
                    src: '44.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_8e48a8dfff204394a8cd4af4b0a4393e.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_560114db21784e7686cbb0d6d5678f11.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_560114db21784e7686cbb0d6d5678f11.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_560114db21784e7686cbb0d6d5678f11.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_b416396a407d411ba24606305e30652e.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_8e48a8dfff204394a8cd4af4b0a4393e.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_560114db21784e7686cbb0d6d5678f11.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_560114db21784e7686cbb0d6d5678f11.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_560114db21784e7686cbb0d6d5678f11.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_b416396a407d411ba24606305e30652e.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}