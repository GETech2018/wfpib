﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_background_bg_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 239,
              // start_y: 18,
              // color: 0xFFFFFFFF,
              // lenght: 23,
              // line_width: 11,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 267,
              y: 12,
              font_array: ["Day_00.png","Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 50,
              y: 12,
              week_en: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_tc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_sc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 112,
              day_startY: 12,
              day_sc_array: ["Day_00.png","Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png"],
              day_tc_array: ["Day_00.png","Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png"],
              day_en_array: ["Day_00.png","Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 155,
              month_startY: 12,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 277,
              minute_startY: 44,
              minute_array: ["Number_0.png","Number_1.png","Number_2.png","Number_3.png","Number_4.png","Number_5.png","Number_6.png","Number_7.png","Number_8.png","Number_9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 176,
              hour_startY: 44,
              hour_array: ["Number_0.png","Number_1.png","Number_2.png","Number_3.png","Number_4.png","Number_5.png","Number_6.png","Number_7.png","Number_8.png","Number_9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
//Ver B10 AI LEVEL EDITION
const { width, height } = hmSetting.getDeviceInfo()

// ===== CONFIG =====
const PADDLE_H = 80
const BALL_SIZE = 20

let BASE_SPEED = 8
let MAX_SPEED = 22

const WIN_SCORE = 10 // 🎯 ชนะ 10 แต้ม

const TOP_LIMIT = height * 0.25
const BOTTOM_LIMIT = height * 0.92

// ===== AI LEVEL =====
const AI_LEVEL = 2

// ===== STATE =====
let playerY = TOP_LIMIT
let aiY = TOP_LIMIT

let ballX = width / 2 - BALL_SIZE / 2
let ballY = (TOP_LIMIT + BOTTOM_LIMIT) / 2 - BALL_SIZE / 2

let vx = 0
let vy = 0

let speed = BASE_SPEED

let playerScore = 0
let aiScore = 0

let waitingServe = true
let gameOver = false

let powerBoost = 0
let winnerText = null

let aiTick = 0
let aiMemoryY = ballY

// ===== UI =====
const player = hmUI.createWidget(hmUI.widget.IMG, {
  x: 10,
  y: playerY,
  src: "paddle.png",
})

const ai = hmUI.createWidget(hmUI.widget.IMG, {
  x: width - 30,
  y: aiY,
  src: "paddle.png",
})

const ball = hmUI.createWidget(hmUI.widget.IMG, {
  x: ballX,
  y: ballY,
  src: "ball.png",
})

const score = hmUI.createWidget(hmUI.widget.TEXT, {
  x: 2,
  y: 112,
  w: width,
  h: 40,
  text: "0 -- 0",
  color: 0xffffff,
  text_size: 28,
  align_h: hmUI.align.CENTER_H,
})

// ===== TOUCH =====
let touch=hmUI.createWidget(hmUI.widget.IMG, {
  x: 0,
  y: 112,
  w: width,
  h: 323,
  src: "touch.png",
}).addEventListener(hmUI.event.CLICK_DOWN, function (info) {

  if (gameOver) {
    gameOver = false

    playerScore = 0
    aiScore = 0

    speed = BASE_SPEED

    vx = 0
    vy = 0

    resetBall()

    waitingServe = true

    if (winnerText) {
      winnerText.setProperty(hmUI.prop.VISIBLE, false)
      winnerText = null
    }
    return
  }

  playerY = info.y - PADDLE_H / 2

  if (playerY < TOP_LIMIT) playerY = TOP_LIMIT
  if (playerY > height - PADDLE_H) playerY = height - PADDLE_H

  if (waitingServe) {
    waitingServe = false
    speed = BASE_SPEED

    vx = (Math.random() > 0.5 ? 1 : -1) * speed
    vy = (Math.random() - 0.5) * speed
  }
})

// ===== WIN =====
function showWinner(text) {
  gameOver = true
  hmUI.vibrate && hmUI.vibrate(2)

  winnerText = hmUI.createWidget(hmUI.widget.TEXT, {
    x: 0,
    y: height * 0.45,
    w: width,
    h: 80,
    text: text,
    color: 0xffffff,
    text_size: 36,
    align_h: hmUI.align.CENTER_H,
  })
}

// ===== RESET BALL =====
function resetBall() {
  ballX = width / 2 - BALL_SIZE / 2
  ballY = (TOP_LIMIT + BOTTOM_LIMIT) / 2 - BALL_SIZE / 2

  vx = 0
  vy = 0
  speed = BASE_SPEED
}

// ===== SPEED =====
function checkSpeedUp() {
  let total = playerScore + aiScore
  if (total > 0 && total % 3 === 0) {
    BASE_SPEED += 1
    MAX_SPEED += 1
  }
}

// ==============================
// LOOP
// ==============================
timer.createTimer(0, 180, function () {

  if (gameOver) return

  if (!waitingServe) {

    ballX += vx
    ballY += vy

    // ===== WALL =====
    if (ballY <= TOP_LIMIT) {
      ballY = TOP_LIMIT
      vy = Math.abs(vy)
    }

    if (ballY >= BOTTOM_LIMIT) {
      ballY = BOTTOM_LIMIT
      vy = -Math.abs(vy)
    }

    // ===== PLAYER HIT =====
    if (
      ballX <= 20 &&
      ballY >= playerY &&
      ballY <= playerY + PADDLE_H
    ) {
      let hit = (ballY - (playerY + PADDLE_H / 2)) / (PADDLE_H / 2)

      speed = Math.min(speed + 1, MAX_SPEED)

      vx = speed
      vy = speed * hit * 2

      powerBoost = 10
      hmUI.vibrate && hmUI.vibrate(1)
    }

    // ===== AI HIT =====
    if (
      ballX >= width - 40 &&
      ballY >= aiY &&
      ballY <= aiY + PADDLE_H
    ) {
      let hit = (ballY - (aiY + PADDLE_H / 2)) / (PADDLE_H / 2)

      speed = Math.min(speed + 1, MAX_SPEED)

      vx = -speed
      vy = speed * hit * 2
    }

    // =========================
    // 🤖 AI 3 LEVELS (NO CHEAT)
    // =========================

    aiTick++

    let aiSpeed = 14

    if (AI_LEVEL === 1) aiSpeed = 11
    if (AI_LEVEL === 2) aiSpeed = 15
    if (AI_LEVEL === 3) aiSpeed = 18

    // Easy: delay + weak
    if (AI_LEVEL === 1) {
      if (aiTick % 3 !== 0) return
      aiMemoryY = ballY
    }

    // Normal: slight delay
    if (AI_LEVEL === 2) {
      if (aiTick % 2 === 0) {
        aiMemoryY = ballY
      }
    }

    // Hard: fast reaction but no prediction
    if (AI_LEVEL === 3) {
      aiMemoryY = ballY
    }

    // Move AI (NO jitter)
    let target = aiMemoryY - PADDLE_H / 2
    let diff = target - aiY

    if (Math.abs(diff) > 6) {
      aiY += Math.sign(diff) * aiSpeed
    }

    // ===== BOUNDS =====
    if (aiY < TOP_LIMIT) aiY = TOP_LIMIT
    if (aiY > height - PADDLE_H) aiY = height - PADDLE_H

    // ===== SCORE =====
    if (ballX < 0) {
      aiScore++
      hmUI.vibrate && hmUI.vibrate(1)
      checkSpeedUp()
      resetBall()
      waitingServe = true
    }

    if (ballX > width) {
      playerScore++
      hmUI.vibrate && hmUI.vibrate(1)
      checkSpeedUp()
      resetBall()
      waitingServe = true
    }

    // ===== WIN =====
    if (playerScore >= WIN_SCORE) showWinner("YOU WIN")
    if (aiScore >= WIN_SCORE) showWinner("AI WIN")
  }

  // ===== UI UPDATE =====
  player.setProperty(hmUI.prop.MORE, { y: playerY })
  ai.setProperty(hmUI.prop.MORE, { y: aiY })
  ball.setProperty(hmUI.prop.MORE, { x: ballX, y: ballY })
  score.setProperty(hmUI.prop.TEXT, playerScore + " -- " + aiScore)

})
            // end user_script.js


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 239,
              // start_y: 18,
              // color: 0xFFFFFFFF,
              // lenght: 23,
              // line_width: 11,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 267,
              y: 12,
              font_array: ["Day_00.png","Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 50,
              y: 12,
              week_en: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_tc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_sc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 112,
              day_startY: 12,
              day_sc_array: ["Day_00.png","Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png"],
              day_tc_array: ["Day_00.png","Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png"],
              day_en_array: ["Day_00.png","Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 155,
              month_startY: 12,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 277,
              minute_startY: 44,
              minute_array: ["Number_0.png","Number_1.png","Number_2.png","Number_3.png","Number_4.png","Number_5.png","Number_6.png","Number_7.png","Number_8.png","Number_9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 176,
              hour_startY: 44,
              hour_array: ["Number_0.png","Number_1.png","Number_2.png","Number_3.png","Number_4.png","Number_5.png","Number_6.png","Number_7.png","Number_8.png","Number_9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 239;
                  let start_y_normal_battery = 18;
                  let lenght_ls_normal_battery = 23;
                  let line_width_ls_normal_battery = 11;
                  let color_ls_normal_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 239;
                  let start_y_idle_battery = 18;
                  let lenght_ls_idle_battery = 23;
                  let line_width_ls_idle_battery = 11;
                  let color_ls_idle_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}