﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//////Vibration feedback for buttons
const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
let timer_StopVibrate = null;

function makeVibrate(level = 1) {
  stopVibrate();

  //The values are used as follows: 1 for buttons, 2 for open settings menu, 3 for close settings menu
  const levelToScene = {
    1: 26,
    2: 27,
    3: 29
  };

  let scene = levelToScene[level] || 25;
  let stopDelay = scene > 25 ? 1300 : 50;

  vibrate.scene = scene;
  vibrate.start();

  timer_StopVibrate = timer.createTimer(stopDelay, 0, stopVibrate, {});
}

function stopVibrate() {
  vibrate.stop();
  if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
  timer_StopVibrate = null;
}

//////Watchface Language Sets (Uppercase)
const watchfaceLangs = {
  EN:{
    WEEKDAYS_SHORT: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
    WEEKDAYS_FULL:  ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"],
  },

  ES:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MIÉ", "JUE", "VIE", "SÁB", "DOM"],
    WEEKDAYS_FULL:  ["LUNES", "MARTES", "MIÉRCOLES", "JUEVES", "VIERNES", "SÁBADO", "DOMINGO"],
  },

  IT:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MER", "GIO", "VEN", "SAB", "DOM"],
    WEEKDAYS_FULL:  ["LUNEDÌ", "MARTEDÌ", "MERCOLEDÌ", "GIOVEDÌ", "VENERDÌ", "SABATO", "DOMENICA"],
  },

  PT:{
    WEEKDAYS_SHORT: ["SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM"],
    WEEKDAYS_FULL:  ["SEGUNDA-FEIRA", "TERÇA-FEIRA", "QUARTA-FEIRA", "QUINTA-FEIRA", "SEXTA-FEIRA", "SÁBADO", "DOMINGO"],
  },

  FR:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MER", "JEU", "VEN", "SAM", "DIM"],
    WEEKDAYS_FULL:  ["LUNDI", "MARDI", "MERCREDI", "JEUDI", "VENDREDI", "SAMEDI", "DIMANCHE"],
  },

  DE:{
    WEEKDAYS_SHORT: ["MON", "DIE", "MIT", "DON", "FRE", "SAM", "SON"],
    WEEKDAYS_FULL:  ["MONTAG", "DIENSTAG", "MITTWOCH", "DONNERSTAG", "FREITAG", "SAMSTAG", "SONNTAG"],
  },
  
  RU:{
    WEEKDAYS_SHORT: ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"],
    WEEKDAYS_FULL:  ["ПОНЕДЕЛЬНИК", "ВТОРНИК", "СРЕДА", "ЧЕТВЕРГ", "ПЯТНИЦА", "СУББОТА", "ВОСКРЕСЕНЬЕ"],
  },
};
let currWatchfaceLang;
let currLangCode;
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];
        let normal_day_month_font = ''
        let normal_heart_rate_text_font = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_font = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_battery_circle_scale = ''
        let normal_battery_current_text_font = ''
        let idle_background_bg_img = ''
        let idle_time_hour_min_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];
        let idle_day_month_font = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SF-Compact-Rounded-Bold.ttf; FontSize: 76
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 1068,
              h: 108,
              text_size: 76,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF-Compact-Rounded-Bold.ttf; FontSize: 26; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 31,
              h: 31,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF-Compact-Rounded-Bold.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 561,
              h: 57,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF-Compact-Rounded-Bold.ttf; FontSize: 22; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 26,
              h: 26,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

//////Function to detect current language from system
function detectLanguage() {
    const zeppAvailableLangs = [
        "ZH", // 0  Chinese (Simplified)
        "ZH", // 1  Chinese (Traditional)
        "EN", // 2  English
        "ES", // 3  Spanish
        "RU", // 4  Russian
        "KO", // 5  Korean
        "FR", // 6  French
        "DE", // 7  German
        "ID", // 8  Indonesian
        "PL", // 9  Polish
        "IT", // 10 Italian
        "JA", // 11 Japanese
        "TH", // 12 Thai
        "AR", // 13 Arabic
        "VI", // 14 Vietnamese
        "PT", // 15 Portuguese (Portugal)
        "NL", // 16 Dutch
        "TR", // 17 Turkish
        "UK", // 18 Ukrainian
        "HE", // 19 Hebrew
        "PT", // 20 Portuguese (Brazil)
        "RO", // 21 Romanian
        "CS", // 22 Czech
        "EL", // 23 Greek
        "SR", // 24 Serbian
        "CA", // 25 Catalan
        "FI", // 26 Finnish
        "NO", // 27 Norwegian
        "DA", // 28 Danish
        "SV", // 29 Swedish
        "HU", // 30 Hungarian
        "MS", // 31 Malay
        "SK", // 32 Slovak
        "HI"  // 33 Hindi
    ];
    let langCode = zeppAvailableLangs[hmSetting.getLanguage()]; //Get current language on watch

    currLangCode = watchfaceLangs[langCode] ? langCode : "EN";
    currWatchfaceLang = watchfaceLangs[currLangCode];
}
detectLanguage();
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 45,
              y: 125,
              w: 300,
              h: 200,
              text_size: 76,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 45,
              y: 150,
              w: 300,
              h: 60,
              text_size: 26,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 45,
              y: 275,
              w: 300,
              h: 60,
              text_size: 26,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 120,
              y: 230,
              w: 150,
              h: 100,
              text_size: 40,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 225,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 110,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFFE8E010,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 225,
              start_angle: 0,
              end_angle: 360,
              radius: 106,
              line_width: 8,
              corner_flag: 0,
              color: 0xFFE8E010,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 45,
              y: 230,
              w: 300,
              h: 100,
              text_size: 40,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 45,
              y: 268,
              w: 300,
              h: 30,
              text_size: 22,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 170,
              y: 161,
              image_array: ["WEATHERICON_1.png","WEATHERICON_2.png","WEATHERICON_3.png","WEATHERICON_4.png","WEATHERICON_5.png","WEATHERICON_6.png","WEATHERICON_7.png","WEATHERICON_8.png","WEATHERICON_9.png","WEATHERICON_10.png","WEATHERICON_11.png","WEATHERICON_12.png","WEATHERICON_13.png","WEATHERICON_14.png","WEATHERICON_15.png","WEATHERICON_16.png","WEATHERICON_17.png","WEATHERICON_18.png","WEATHERICON_19.png","WEATHERICON_20.png","WEATHERICON_21.png","WEATHERICON_22.png","WEATHERICON_23.png","WEATHERICON_24.png","WEATHERICON_25.png","WEATHERICON_26.png","WEATHERICON_27.png","WEATHERICON_28.png","WEATHERICON_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 120,
              y: 210,
              w: 150,
              h: 100,
              text_size: 40,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 225,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 110,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFF98DC30,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 225,
              start_angle: 0,
              end_angle: 360,
              radius: 106,
              line_width: 8,
              corner_flag: 0,
              color: 0xFF98DC30,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 120,
              y: 230,
              w: 150,
              h: 100,
              text_size: 40,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
let iconHRM = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: "ICON_HRM.png",
    show_level: hmUI.show_level.ONLY_NORMAL,
});
iconHRM.setProperty(hmUI.prop.VISIBLE, false);

let iconBattery = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: "ICON_BATTERY.png",
    show_level: hmUI.show_level.ONLY_NORMAL,
});
iconBattery.setProperty(hmUI.prop.VISIBLE, false);

let iconSteps = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: "ICON_STEPS.png",
    show_level: hmUI.show_level.ONLY_NORMAL,
});
iconSteps.setProperty(hmUI.prop.VISIBLE, false);
            // end user_script.js


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 45,
              y: 125,
              w: 300,
              h: 200,
              text_size: 76,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 45,
              y: 150,
              w: 300,
              h: 60,
              text_size: 26,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 45,
              y: 275,
              w: 300,
              h: 60,
              text_size: 26,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 195,
              h: 225,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON_1_PRESSED.png',
              normal_src: 'BUTTON_1_NORMAL.png',
              click_func: (button_widget) => {
                showWidget("weather")
makeVibrate(1)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 225,
              w: 195,
              h: 225,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON_3_PRESSED.png',
              normal_src: 'BUTTON_3_NORMAL.png',
              click_func: (button_widget) => {
                showWidget("hrm")
makeVibrate(1)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 195,
              y: 0,
              w: 195,
              h: 225,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON_2_PRESSED.png',
              normal_src: 'BUTTON_2_NORMAL.png',
              click_func: (button_widget) => {
                showWidget("battery")
makeVibrate(1)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 195,
              y: 225,
              w: 195,
              h: 225,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON_4_PRESSED.png',
              normal_src: 'BUTTON_4_NORMAL.png',
              click_func: (button_widget) => {
                showWidget("steps")
makeVibrate(1)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 85,
              y: 115,
              w: 220,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
makeVibrate(1)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 85,
              y: 190,
              w: 220,
              h: 145,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
makeVibrate(1)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let shortcutWeather_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 0,
    y: 0,
    w: 195,
    h: 225,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'BUTTON_1_SHORTCUT.png',
    normal_src: 'BUTTON_1_SHORTCUT.png',
    click_func: (button_widget) => {
    hmApp.startApp({url: 'WeatherScreen', native: true });
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let shortcutHRM_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 0,
    y: 225,
    w: 195,
    h: 225,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'BUTTON_3_SHORTCUT.png',
    normal_src: 'BUTTON_3_SHORTCUT.png',
    click_func: (button_widget) => {
    hmApp.startApp({url: 'heart_app_Screen', native: true });
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let shortcutBattery_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 195,
    y: 0,
    w: 195,
    h: 225,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'BUTTON_2_SHORTCUT.png',
    normal_src: 'BUTTON_2_SHORTCUT.png',
    click_func: (button_widget) => {
    hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let shortcutSteps_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 195,
    y: 225,
    w: 195,
    h: 225,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'BUTTON_4_SHORTCUT.png',
    normal_src: 'BUTTON_4_SHORTCUT.png',
    click_func: (button_widget) => {
    hmApp.startApp({url: 'activityAppScreen', native: true });
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let shortcutHome_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 95,
    y: 125,
    w: 200,
    h: 200,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'BUTTON.png',
    normal_src: 'BUTTON.png',
    click_func: (button_widget) => {
    goHome()
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let home_module = [ normal_dow_text_font, normal_time_hour_min_text_font, normal_day_month_font, Button_5, Button_6 ]
let hrm_module = [ iconHRM, normal_heart_rate_text_font, shortcutHRM_btn ]
let weather_module = [ normal_weather_image_progress_img_level, normal_temperature_current_text_font, normal_city_name_text, shortcutWeather_btn ]
let battery_module = [ iconBattery, normal_battery_current_text_font, normal_battery_circle_scale, shortcutBattery_btn ]
let steps_module = [ iconSteps, normal_step_current_text_font, normal_step_circle_scale, shortcutSteps_btn ]

let all_modules = [
  ...hrm_module,
  ...weather_module,
  ...battery_module,
  ...steps_module
]
all_modules.forEach(el => el.setProperty(hmUI.prop.VISIBLE, false))

function showWidget(widgetType){    
    all_modules.forEach(el => el.setProperty(hmUI.prop.VISIBLE, false))
    home_module.forEach(el => el.setProperty(hmUI.prop.VISIBLE, false))

    switch(widgetType){
        case "weather":
            weather_module.forEach(el => el.setProperty(hmUI.prop.VISIBLE, true))
            break;
        case "hrm":
            hrm_module.forEach(el => el.setProperty(hmUI.prop.VISIBLE, true))
            break;
        case "battery":
            battery_module.forEach(el => el.setProperty(hmUI.prop.VISIBLE, true))
            break;
        case "steps":
            steps_module.forEach(el => el.setProperty(hmUI.prop.VISIBLE, true))
            break;
    }
    shortcutHome_btn.setProperty(hmUI.prop.VISIBLE, true)
}

function goHome(){
    all_modules.forEach(el => el.setProperty(hmUI.prop.VISIBLE, false))
    home_module.forEach(el => el.setProperty(hmUI.prop.VISIBLE, true))
    shortcutHome_btn.setProperty(hmUI.prop.VISIBLE, false)
}
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0');
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = currWatchfaceLang.WEEKDAYS_FULL[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '/' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '/' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let idle_HourMinStr = format_hour.toString();
                idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0');
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = currWatchfaceLang.WEEKDAYS_FULL[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('day/month font');
              if (updateHour) {
                let idle_DayStr = timeSensor.day.toString();
                let idle_MonthStr = timeSensor.month.toString();
                let idle_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  idle_DayMonthStr = idle_MonthStr + '/' + idle_DayStr;
                }
                if (dateFormat == 1) {
                  idle_DayMonthStr = idle_DayStr + '/' + idle_MonthStr;
                }
                idle_day_month_font.setProperty(hmUI.prop.TEXT, idle_DayMonthStr );
              };
            };


            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 225,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 106,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFFE8E010,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 225,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 106,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF98DC30,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

                console.log('pause_call.js');
                // start pause_call.js

goHome()
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}