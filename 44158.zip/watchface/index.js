﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

        let normal_stand_pointer_progress_img_pointer = ''
        let idle_stand_pointer_progress_img_pointer = ''
        let SUN_CURRENT_PROGRESS = ''	
        let normal_calorie_pointer_progress_img_pointer = ''	
        let idle_calorie_pointer_progress_img_pointer = ''	
        let normal_calorie_icon_img = ''
		let idle_calorie_icon_img	
		let normal_analog_clock_time_pointer_second	

const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
let isDayIcons = false

		
 function getSunTimes(weatherData) {
  let tideData = weatherData.tideData;
	 
  // Получение времени заката
  let sunset_hour = -1;
  let sunset_minute = -1;
  if (tideData.count > 0) {
   sunset_hour = tideData.data[0].sunset.hour;
   sunset_minute = tideData.data[0].sunset.minute;
  }

  let normal_sunset = undefined;
  if (sunset_hour >= 0 && sunset_minute >= 0) {
   normal_sunset = String(sunset_hour).padStart(2, '0') + ':' + String(sunset_minute).padStart(2, '0');
  }

  // Получение времени восхода
  let sunrise_hour = -1;
  let sunrise_minute = -1;
  if (tideData.count > 0) {
   sunrise_hour = tideData.data[0].sunrise.hour;
   sunrise_minute = tideData.data[0].sunrise.minute;
  }

  let normal_sunrise = undefined;
  if (sunrise_hour >= 0 && sunrise_minute >= 0) {
   normal_sunrise = String(sunrise_hour).padStart(2, '0') + ':' + String(sunrise_minute).padStart(2, '0');
  }

  return {
   normal_sunset_circle_string: normal_sunset,
   normal_sunrise_circle_string: normal_sunrise
  };
 }


function autoToggleWeatherIcons() {

  let weatherData = weatherSensor.getForecastWeather();
  let tideData = weatherData.tideData;

  sunData = weatherData.tideData;
  if (sunData.count > 0) {
   today = sunData.data[0];
   sunriseMins = (today.sunrise.hour) * 60 + today.sunrise.minute;
   sunsetMins = (today.sunset.hour) * 60 + today.sunset.minute;
  } else {
   sunriseMins = sunriseMins_def;
   sunsetMins = sunsetMins_def;
  }
  curMins = timeSensor.hour * 60 + timeSensor.minute;
  let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

  if (isDayNow) {
   if (!isDayIcons) {
    isDayIcons = true;
   }
  } else {
   if (isDayIcons) {
    isDayIcons = false;
   }
  }
  


  const {
   normal_sunset_circle_string,
   normal_sunrise_circle_string
  } = getSunTimes(weatherData);

normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, !isDayIcons);	
normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons);
idle_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, !isDayIcons);	
idle_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons);
	
normal_calorie_icon_img.setProperty(hmUI.prop.SRC, isDayIcons ? 'bg_sun_0.png' : 'bg_sun_1.png');	
idle_calorie_icon_img.setProperty(hmUI.prop.SRC, isDayIcons ? 'bg_sun_0.png' : 'bg_sun_1.png');	
	
  let T_N = curMins;

  // Получаем часы и минуты из строки формата "HH:MM"
  const [sunriseHours, sunriseMinutes] = normal_sunrise_circle_string.split(':').map(Number);
  const [sunsetHours, sunsetMinutes] = normal_sunset_circle_string.split(':').map(Number);

  let T_V = sunriseHours * 60 + sunriseMinutes;
  let T_Z = sunsetHours * 60 + sunsetMinutes;


  let T_24 = T_Z - T_N;
  let level_SUN_CURRENT_day = (T_N - T_V) / (T_Z - T_V) * 100;
  let level_SUN_CURRENT_night = T_24 < 0 ? (T_N - T_Z) / ((24 * 60 - T_Z) + T_V) * 100 : (24 * 60 - T_Z + T_N) / ((24 * 60 - T_Z) + T_V) * 100;

/*  SUN_CURRENT_PROGRESS.setProperty(hmUI.prop.MORE, {
   center_x: 175 + 116 + 7,
   center_y: 166 + 116,
   start_angle: -135,
   end_angle: 135,
   radius: 39,
   line_width: 10,
   corner_flag: 3,
   color: isDayIcons ? 0xffef42 : 0x42ffeb,
   level: isDayIcons ? level_SUN_CURRENT_day : level_SUN_CURRENT_night,
   // type: hmUI.data_type.SUN_CURRENT,
   show_level: hmUI.show_level.ONLY_NORMAL,
  });*/
	
	normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
	 x: 0,
	 y: 0,
	 w: 391,
	 h: 451,
	 pos_x: 98,
	 pos_y: 175,
	 center_x: 106,
	 center_y: 225,
	 angle: isDayIcons ? (level_SUN_CURRENT_day* 2.8)-140 : (level_SUN_CURRENT_night* 2.8)-140,
	 src: 'pointer_sun.png',
	 show_level: hmUI.show_level.ONLY_NORMAL,
	});

	idle_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
	 x: 0,
	 y: 0,
	 w: 391,
	 h: 451,
	 pos_x: 98,
	 pos_y: 175,
	 center_x: 106,
	 center_y: 225,
	 angle: isDayIcons ? (level_SUN_CURRENT_day* 2.8)-140 : (level_SUN_CURRENT_night* 2.8)-140,
	 src: 'pointer_sun.png',
	 show_level: hmUI.show_level.ONLY_NORMAL,
	});
	

 }

//let tap = 0
function click_tap() {
//tap	= (tap + 1)%2
normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
normal_image_img.setProperty(hmUI.prop.VISIBLE, true);
Button_1.setProperty(hmUI.prop.VISIBLE, false);	
Button_2.setProperty(hmUI.prop.VISIBLE, true);
Button_3.setProperty(hmUI.prop.VISIBLE, true);
Button_4.setProperty(hmUI.prop.VISIBLE, true);
Button_5.setProperty(hmUI.prop.VISIBLE, true);
Button_6.setProperty(hmUI.prop.VISIBLE, true);
	
vibro();	
 }

//let tap_select = 0
function click_tap_select() {
//tap_select	= (tap_select + 1)%2
normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
normal_image_img.setProperty(hmUI.prop.VISIBLE, false);
Button_1.setProperty(hmUI.prop.VISIBLE, true);	
Button_2.setProperty(hmUI.prop.VISIBLE, false);	
Button_3.setProperty(hmUI.prop.VISIBLE, false);
Button_4.setProperty(hmUI.prop.VISIBLE, false);
Button_5.setProperty(hmUI.prop.VISIBLE, false);
Button_6.setProperty(hmUI.prop.VISIBLE, false);
	
vibro();	
 }
	

const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
let stopVibro_Timer = null;

function vibro(scene = 25) {
 vibrate.stop();
 vibrate.scene = scene;
 vibrate.start();

}

// запуск приложения с заданным appId (если оно установлено) или системного приложения
function launchAppOrAppId(url, appId, page = 'page/index') {
 let appInstalled = false;
 try {
  const id16 = appId.toString(16).padStart(8, "0"); // переводим appId в 16-ричный формат
  const [fs_stat, err] = hmFS.stat_asset(`../../../js_apps/${id16}/app.json`); // проверяем наличие файла 'app.json' в папке приложения
  if (err == 0) { //  если файл есть,  то приложение установлено
   appInstalled = true;
  } else {
   console.log("err:", err);
  }
 } catch (error) {
  console.log("error:", error);
  console.log("FAIL: No access to hmFS.");
 }
 if (appInstalled) hmApp.startApp({
  appid: appId,
  url: page
 })
 else hmApp.startApp({
  url: url,
  native: true
 });
}


        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let normal_day_text_font = ''
        let normal_step_circle_scale = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_sun_high_text_font = ''
        let normal_humidity_current_text_font = ''
        let normal_humidity_image_progress_img_level = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_font = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_heart_rate_text_font = ''
        let normal_battery_circle_scale = ''
        let normal_battery_current_text_font = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_alarm_clock_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_time_hour_min_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let idle_day_text_font = ''
        let idle_step_circle_scale = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_font = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_text_font = ''
        let idle_temperature_low_text_font = ''
        let idle_temperature_current_text_font = ''
        let idle_sun_low_text_font = ''
        let idle_sun_high_text_font = ''
        let idle_humidity_current_text_font = ''
        let idle_humidity_image_progress_img_level = ''
        let idle_calorie_circle_scale = ''
        let idle_calorie_current_text_font = ''
        let idle_heart_rate_circle_scale_2 = ''
        let idle_heart_rate_text_font = ''
        let idle_battery_circle_scale = ''
        let idle_battery_current_text_font = ''
        let idle_alarm_clock_current_text_font = ''
        let idle_alarm_clock_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SF_C_Round_B.ttf; FontSize: 54
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 688,
              h: 78,
              text_size: 54,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF_C_Round_B.ttf; FontSize: 24; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 28,
              h: 28,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFE63255,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF_C_Round_B.ttf; FontSize: 48
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 614,
              h: 70,
              text_size: 48,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF_C_Round_B.ttf; FontSize: 32
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 414,
              h: 46,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 45,
              y: 96,
              w: 300,
              h: 70,
              text_size: 54,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 209,
              y: 187,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFE63255,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 209,
              y: 205,
              w: 150,
              h: 55,
              text_size: 48,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 197,
              // center_y: 226,
              // start_angle: 321,
              // end_angle: 345,
              // radius: 206,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFFD5F76C,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 197,
              center_y: 226,
              start_angle: 321,
              end_angle: 345,
              radius: 200,
              line_width: 12,
              corner_flag: 0,
              color: 0xFFD5F76C,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_step.png',
              center_x: 197,
              center_y: 226,
              x: 5,
              y: 204,
              start_angle: 318,
              end_angle: 343,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -19,
              y: 10,
              w: 432,
              h: 432,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 270,
              end_angle: 320,
              mode: 0,
              // radius: 216,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 88,
              y: 240,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -17,
              y: 12,
              w: 428,
              h: 428,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 54,
              end_angle: 180,
              mode: 0,
              // radius: 214,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -17,
              y: 12,
              w: 428,
              h: 428,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -55,
              end_angle: 14,
              mode: 0,
              // radius: 214,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -57,
              y: -28,
              w: 508,
              h: 508,
              text_size: 32,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -21,
              end_angle: 90,
              mode: 0,
              // radius: 254,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 31,
              y: 208,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 31,
              y: 208,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -12,
              y: 17,
              w: 418,
              h: 418,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFF85DCD3,
              // use_text_circle: true,
              start_angle: 90,
              end_angle: 200,
              mode: 1,
              // radius: 209,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 176,
              y: 295,
              image_array: ["VL_0.png","VL_1.png","VL_2.png","VL_3.png","VL_4.png","VL_5.png","VL_6.png","VL_7.png","VL_8.png","VL_9.png"],
              image_length: 10,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 314,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 34,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFFB1FF49,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 314,
              start_angle: 0,
              end_angle: 360,
              radius: 30,
              line_width: 8,
              corner_flag: 0,
              color: 0xFFB1FF49,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -12,
              y: 17,
              w: 418,
              h: 418,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFB1FF49,
              // use_text_circle: true,
              start_angle: 90,
              end_angle: 130,
              mode: 1,
              // radius: 209,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 314,
              start_angle: 0,
              end_angle: 360,
              radius: 44,
              line_width: 8,
              corner_flag: 0,
              type: hmUI.data_type.HEART,
              color: 0xFFE63255,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -12,
              y: 17,
              w: 418,
              h: 418,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFE63255,
              // use_text_circle: true,
              start_angle: 161,
              end_angle: 218,
              mode: 1,
              // radius: 209,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 197,
              // center_y: 226,
              // start_angle: 191,
              // end_angle: 224,
              // radius: 202,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFFFD9B06,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 197,
              center_y: 226,
              start_angle: 191,
              end_angle: 224,
              radius: 196,
              line_width: 12,
              corner_flag: 0,
              color: 0xFFFD9B06,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -16,
              y: 13,
              w: 426,
              h: 426,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFD9B06,
              // use_text_circle: true,
              start_angle: 226,
              end_angle: 257,
              mode: 1,
              // radius: 213,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -52,
              y: -23,
              w: 498,
              h: 498,
              text_size: 32,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 90,
              end_angle: 194,
              mode: 1,
              // radius: 249,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              unit_type: 1,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 395,
              font_array: ["AL_0.png","AL_1.png","AL_2.png","AL_3.png","AL_4.png","AL_5.png","AL_6.png","AL_7.png","AL_8.png","AL_9.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'AL_13.png',
              dot_image: 'AL_0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 176,
              y: 76,
              src: 'stat_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'str_H.png',
              hour_centerX: 194,
              hour_centerY: 225,
              hour_posX: 12,
              hour_posY: 95,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'str_M.png',
              minute_centerX: 194,
              minute_centerY: 225,
              minute_posX: 12,
              minute_posY: 157,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
            normal_stand_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_temp.png',
              center_x: 197,
              center_y: 226,
              x: 7,
              y: 212,
              start_angle: 16,
              end_angle: 47,
              invalid_visible: false,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

/*        SUN_CURRENT_PROGRESS = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 175 + 116 + 7,
         center_y: 166 + 116,
         start_angle: -135,
         end_angle: 135,
         radius: 39,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         // type: hmUI.data_type.SUN_CURRENT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });*/
            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 58,
              y: 176,
              src: 'bg_sun_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 391,
              h: 451,
              pos_x: 98,
              pos_y: 175,
              center_x: 106,
              center_y: 225,
              angle: 0,
              src: 'pointer_sun.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            // end user_script.js

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_tap.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 45,
              y: 96,
              w: 300,
              h: 70,
              text_size: 54,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 209,
              y: 187,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFE63255,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 209,
              y: 205,
              w: 150,
              h: 55,
              text_size: 48,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 197,
              // center_y: 226,
              // start_angle: 321,
              // end_angle: 345,
              // radius: 206,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFFD5F76C,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 197,
              center_y: 226,
              start_angle: 321,
              end_angle: 345,
              radius: 200,
              line_width: 12,
              corner_flag: 0,
              color: 0xFFD5F76C,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_step.png',
              center_x: 197,
              center_y: 226,
              x: 5,
              y: 204,
              start_angle: 318,
              end_angle: 343,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -19,
              y: 10,
              w: 432,
              h: 432,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 270,
              end_angle: 320,
              mode: 0,
              // radius: 216,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 88,
              y: 240,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -17,
              y: 12,
              w: 428,
              h: 428,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 54,
              end_angle: 180,
              mode: 0,
              // radius: 214,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -17,
              y: 12,
              w: 428,
              h: 428,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -55,
              end_angle: 14,
              mode: 0,
              // radius: 214,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -57,
              y: -28,
              w: 508,
              h: 508,
              text_size: 32,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -21,
              end_angle: 90,
              mode: 0,
              // radius: 254,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 31,
              y: 208,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 31,
              y: 208,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -12,
              y: 17,
              w: 418,
              h: 418,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFF85DCD3,
              // use_text_circle: true,
              start_angle: 90,
              end_angle: 200,
              mode: 1,
              // radius: 209,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 176,
              y: 295,
              image_array: ["VL_0.png","VL_1.png","VL_2.png","VL_3.png","VL_4.png","VL_5.png","VL_6.png","VL_7.png","VL_8.png","VL_9.png"],
              image_length: 10,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 314,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 34,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFFB1FF49,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 314,
              start_angle: 0,
              end_angle: 360,
              radius: 30,
              line_width: 8,
              corner_flag: 0,
              color: 0xFFB1FF49,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -12,
              y: 17,
              w: 418,
              h: 418,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFB1FF49,
              // use_text_circle: true,
              start_angle: 90,
              end_angle: 130,
              mode: 1,
              // radius: 209,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 314,
              start_angle: 0,
              end_angle: 360,
              radius: 44,
              line_width: 8,
              corner_flag: 0,
              type: hmUI.data_type.HEART,
              color: 0xFFE63255,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -12,
              y: 17,
              w: 418,
              h: 418,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFE63255,
              // use_text_circle: true,
              start_angle: 161,
              end_angle: 218,
              mode: 1,
              // radius: 209,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 197,
              // center_y: 226,
              // start_angle: 191,
              // end_angle: 224,
              // radius: 202,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFFFD9B06,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 197,
              center_y: 226,
              start_angle: 191,
              end_angle: 224,
              radius: 196,
              line_width: 12,
              corner_flag: 0,
              color: 0xFFFD9B06,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -16,
              y: 13,
              w: 426,
              h: 426,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFD9B06,
              // use_text_circle: true,
              start_angle: 226,
              end_angle: 257,
              mode: 1,
              // radius: 213,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -52,
              y: -23,
              w: 498,
              h: 498,
              text_size: 32,
              char_space: 0,
              font: 'fonts/SF_C_Round_B.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 90,
              end_angle: 194,
              mode: 1,
              // radius: 249,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              unit_type: 1,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 395,
              font_array: ["AL_0.png","AL_1.png","AL_2.png","AL_3.png","AL_4.png","AL_5.png","AL_6.png","AL_7.png","AL_8.png","AL_9.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'AL_13.png',
              dot_image: 'AL_0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 176,
              y: 76,
              src: 'stat_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'str_H.png',
              hour_centerX: 194,
              hour_centerY: 225,
              hour_posX: 12,
              hour_posY: 95,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'str_M.png',
              minute_centerX: 194,
              minute_centerY: 225,
              minute_posX: 12,
              minute_posY: 157,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

           
            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'str_S.png',
              second_centerX: 194,
              second_centerY: 225,
              second_posX: 12,
              second_posY: 172,
              fresh_frequency: 25,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

idle_stand_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_temp.png',
              center_x: 197,
              center_y: 226,
              x: 7,
              y: 212,
              start_angle: 16,
              end_angle: 47,
              invalid_visible: false,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 58,
              y: 176,
              src: 'bg_sun_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 391,
              h: 451,
              pos_x: 98,
              pos_y: 175,
              center_x: 106,
              center_y: 225,
              angle: 0,
              src: 'pointer_sun.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 290,
              y: 0,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              longpress_func: (button_widget) => {
                click_tap();


              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 145,
              y: 380,
              w: 100,
              h: 70,
              text: 'OK',
              color: 0xFFFFFFFF,
              text_size: 40,
              radius: 12,
              press_color: 0xFF800040,
              normal_color: 0xFF464646,
              click_func: (button_widget) => {
                click_tap_select();

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 55,
              y: 51,
              w: 113,
              h: 113,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 40,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                launchAppOrAppId('ScheduleCalScreen', 1057409);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 221,
              y: 51,
              w: 113,
              h: 113,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 40,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 55,
              y: 214,
              w: 113,
              h: 113,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 40,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 221,
              y: 214,
              w: 113,
              h: 113,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 40,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

normal_image_img.setProperty(hmUI.prop.VISIBLE, false);
Button_2.setProperty(hmUI.prop.VISIBLE, false);
Button_3.setProperty(hmUI.prop.VISIBLE, false);
Button_4.setProperty(hmUI.prop.VISIBLE, false);
Button_5.setProperty(hmUI.prop.VISIBLE, false);
Button_6.setProperty(hmUI.prop.VISIBLE, false);

            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_HourMinStr = 'pm ' + normal_HourMinStr
                  else normal_HourMinStr = 'am ' + normal_HourMinStr
                };
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let idle_HourMinStr = format_hour.toString();
                idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) idle_HourMinStr = 'pm ' + idle_HourMinStr
                  else idle_HourMinStr = 'am ' + idle_HourMinStr
                };
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 197,
                      center_y: 226,
                      start_angle: 321,
                      end_angle: 345,
                      radius: 200,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFFD5F76C,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 314,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 30,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFFB1FF49,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 197,
                      center_y: 226,
                      start_angle: 191,
                      end_angle: 224,
                      radius: 196,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFFFD9B06,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 197,
                      center_y: 226,
                      start_angle: 321,
                      end_angle: 345,
                      radius: 200,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFFD5F76C,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_calorie * 100);
                  if (idle_calorie_circle_scale) {
                    idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 314,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 30,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFFB1FF49,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 197,
                      center_y: 226,
                      start_angle: 191,
                      end_angle: 224,
                      radius: 196,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFFFD9B06,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

autoToggleWeatherIcons();
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}