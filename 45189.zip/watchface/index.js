try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var e = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );
    "use strict";

    let a = "";
    let r = "";
    let s = "";
    let I = "";
    let o = "";
    let _ = "";
    let m = "";
    let i = "";
    let w = "";
    let U = "";
    let V = "";
    let d = "";
    let c;
    let y = "";
    let L = "";
    let F = "";
    let X = "";
    let D = "";
    let K = "";
    let j = "";
    let N = "";
    let $ = ["0040.png", "0041.png", "0042.png"];
    let O = "";
    let z = ["0043.png", "0044.png", "0045.png", "0046.png", "0047.png", "0048.png", "0049.png", "0050.png", "0051.png", "0052.png"];
    let M = "";
    let q = ["0053.png", "0054.png", "0055.png", "0056.png", "0057.png", "0058.png"];
    let f = "";
    let J = ["0059.png", "0060.png", "0061.png", "0062.png", "0063.png", "0064.png", "0065.png", "0066.png", "0067.png", "0068.png"];
    let Q = "";
    let Z = "";
    let ee = "";
    let ne = "";
    let ge = "";
    let pe = "";
    let te = "";
    let le = "";
    let he = "";
    let ae = "";
    let re = "";
    let se = "";
    let A = "";
    let Ie = ["0146.png", "0147.png", "0148.png"];
    let R = "";
    let oe = ["0146.png", "0147.png", "0148.png", "0149.png", "0150.png", "0151.png", "0152.png", "0153.png", "0154.png", "0155.png"];
    let _e = "";
    let E = "";
    let me = ["0146.png", "0147.png", "0148.png", "0149.png", "0150.png", "0151.png"];
    let ie = "";
    let x = "";
    let we = "";
    let Ue = "";
    let de = "";
    let ce = "";
    let ye = "";
    let Le = "";
    let ve = "";
    let Ne = "";
    let Oe = "";
    let W = new Array(4);
    let Me = false;
    let G = ["0186.png", "0187.png", "0188.png", "0189.png", "0190.png", "0191.png", "0192.png", "0193.png", "0194.png", "0195.png", "0196.png", "0197.png", "0196.png"];
    let Y = new Array(4);
    let fe = false;
    let u = ["0186.png", "0187.png", "0188.png", "0189.png", "0190.png", "0191.png", "0192.png", "0193.png", "0194.png", "0195.png", "0196.png", "0197.png", "0196.png"];
    let S = new Array(4);
    let Ae = false;
    let T = ["0186.png", "0187.png", "0188.png", "0189.png", "0190.png", "0191.png", "0192.png", "0193.png", "0194.png", "0195.png", "0196.png", "0197.png", "0196.png"];
    let b = new Array(4);
    let Re = false;
    let P = ["0186.png", "0187.png", "0188.png", "0189.png", "0190.png", "0191.png", "0192.png", "0193.png", "0194.png", "0195.png", "0196.png", "0197.png", "0196.png"];
    let Ee = "";
    let xe = "";
    let C = "";
    let We = ["0198.png", "0199.png", "0200.png", "0201.png", "0202.png", "0203.png", "0204.png", "0205.png", "0206.png", "0207.png", "0208.png", "0209.png", "0210.png", "0211.png", "0212.png", "0213.png", "0214.png", "0215.png", "0216.png", "0217.png", "0218.png", "0219.png", "0220.png", "0221.png", "0222.png", "0223.png", "0224.png", "0225.png", "0226.png"];
    let k = "";
    let Ge = ["0198.png", "0199.png", "0200.png", "0201.png", "0202.png", "0203.png", "0204.png", "0205.png", "0206.png", "0207.png", "0208.png", "0209.png", "0210.png", "0211.png", "0212.png", "0213.png", "0214.png", "0215.png", "0216.png", "0217.png", "0218.png", "0219.png", "0220.png", "0221.png", "0222.png", "0223.png", "0224.png", "0225.png", "0226.png"];
    let H = "";
    let Ye = ["0198.png", "0199.png", "0200.png", "0201.png", "0202.png", "0203.png", "0204.png", "0205.png", "0206.png", "0207.png", "0208.png", "0209.png", "0210.png", "0211.png", "0212.png", "0213.png", "0214.png", "0215.png", "0216.png", "0217.png", "0218.png", "0219.png", "0220.png", "0221.png", "0222.png", "0223.png", "0224.png", "0225.png", "0226.png"];
    let B = "";
    let ue = ["0198.png", "0199.png", "0200.png", "0201.png", "0202.png", "0203.png", "0204.png", "0205.png", "0206.png", "0207.png", "0208.png", "0209.png", "0210.png", "0211.png", "0212.png", "0213.png", "0214.png", "0215.png", "0216.png", "0217.png", "0218.png", "0219.png", "0220.png", "0221.png", "0222.png", "0223.png", "0224.png", "0225.png", "0226.png"];
    let Se = "";
    let Te = "";
    let be = "";
    let Pe = "";
    let Ce = "";
    let ke = "";
    let He = "";
    let Be = "";
    let Ve = "";
    let Fe = "";
    let Xe = "";
    let De = "";
    let Ke = "";
    let je = "";

    const n = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        const e = hmSensor.createSensor(hmSensor.id.TIME);
        const v = hmSensor.createSensor(hmSensor.id.WEATHER);
        const n = hmSensor.createSensor(hmSensor.id.SLEEP);
        let g = hmSetting.getScreenType();

        a = hmUI.createWidget(hmUI.widget.IMG, {  //表盤背景框
          x: 0, y: 0,
          w: 450, h: 550,
          src: "0002.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        r = hmUI.createWidget(hmUI.widget.IMG, {  // 方黑框
          x: 214, y: -9,
          w: 226, h: 233,
          src: "0003.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        s = hmUI.createWidget(hmUI.widget.IMG, {  // 橫黑隔線
          x: 0, y: 111,
          w: 395, h: 14,
          src: "0004.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        I = hmUI.createWidget(hmUI.widget.IMG, {  // 橫黑隔線
          x: 0, y: 308,
          w: 498, h: 14,
          src: "0005.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        o = hmUI.createWidget(hmUI.widget.IMG, {  // 圓時鐘的黑背景
          x: 228, y: 5,
          w: 213, h: 213,
          src: "0006.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        _ = hmUI.createWidget(hmUI.widget.IMG, {  // SLEEP
          x: 51, y: 439,
          w: 69, h: 27,
          src: "0007.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        m = hmUI.createWidget(hmUI.widget.IMG, {  // KCAL
          x: 281, y: 334,
          w: 61, h: 27,
          src: "0008.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        i = hmUI.createWidget(hmUI.widget.IMG, {  // DIST
          x: 281, y: 367,
          w: 52, h: 27,
          src: "0009.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        w = hmUI.createWidget(hmUI.widget.IMG, {  // BIOCHARGE
          x: 152, y: 439,
          w: 131, h: 27,
          src: "0010.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        U = hmUI.createWidget(hmUI.widget.IMG, {  // BPM
          x: 327, y: 439,
          w: 51, h: 27,
          src: "0011.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        V = hmUI.createWidget(hmUI.widget.IMG, {   // 圓時鐘的圓框
          x: 224, y: 10,
          w: 200, h: 200,
          src: "0012.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });
        d = hmUI.createWidget(hmUI.widget.IMG, {   // 圓時鐘的時針
          x: 0, y: 0,
          w: 432, h: 516,
          center_x: 324, center_y: 110,
          pos_x: 316, pos_y: 29,
          src: "0013.png",
          enable: false,
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL
        });
        y = hmUI.createWidget(hmUI.widget.IMG, {  // 圓時鐘的分針
          x: 0, y: 0,
          w: 432, h: 516,
          center_x: 324, center_y: 110,
          pos_x: 317, pos_y: 29,
          src: "0014.png",
          enable: false,
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL
        });
        L = hmUI.createWidget(hmUI.widget.IMG, {  // 圓時鐘的秒針
          x: 0, y: 0,
          w: 432, h: 516,
          center_x: 324, center_y: 110,
          pos_x: 321, pos_y: 26,
          src: "0015.png",
          enable: false,
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL
        });
        F = hmUI.createWidget(hmUI.widget.IMG, {  // STEPS
          x: 75, y: 334,
          w: 73, h: 23,
          src: "0016.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        X = hmUI.createWidget(hmUI.widget.TEXT_IMG, {  //步數的數字
          x: 75, y: 362,
          font_array: ["0017.png", "0018.png", "0019.png", "0020.png", "0021.png", "0022.png", "0023.png", "0024.png", "0025.png", "0026.png"],
          padding: false,
          h_space: -1,
          align_h: hmUI.align.LEFT,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        D = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {  //步數的圈圈
          x: 12, y: 334,
          image_array: ["0027.png", "0028.png", "0029.png", "0030.png", "0031.png", "0032.png", "0033.png", "0034.png", "0035.png", "0036.png", "0037.png"],
          image_length: 11,
          type: hmUI.data_type.STEP,
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        K = hmUI.createWidget(hmUI.widget.IMG, {// 鞋印綠符號的外圈
          x: 12, y: 334,
          w: 56, h: 58,
          src: "0038.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        j = hmUI.createWidget(hmUI.widget.IMG, {  // 鞋印綠符號
          x: 25, y: 348,
          w: 29, h: 30,
          src: "0039.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        N = hmUI.createWidget(hmUI.widget.IMG, {// 2 (數字時鐘)
          x: 50, y: 41,
          w: 50, h: 41,
          src: "0042.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        O = hmUI.createWidget(hmUI.widget.IMG, {// 9 (數字時鐘)
          x: 83, y: 41,
          w: 83, h: 41,
          src: "0052.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        M = hmUI.createWidget(hmUI.widget.IMG, { // 5 (數字時鐘)
          x: 131, y: 40,
          w: 131, h: 40,
          src: "0058.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        f = hmUI.createWidget(hmUI.widget.IMG, { // 9 (數字時鐘)
          x: 164, y: 40,
          w: 164, h: 40,
          src: "0068.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        Q = hmUI.createWidget(hmUI.widget.IMG, { // TIME (數字時鐘)
          x: 60, y: 6,
          w: 133, h: 27,
          src: "0069.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        Z = hmUI.createWidget(hmUI.widget.IMG, {  // : (數字時鐘)
          x: 115, y: 40,
          w: 17, h: 64,
          src: "0070.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        ee = hmUI.createWidget(hmUI.widget.IMG_WEEK, {  //星期字体
          x: 339, y: 235,
          week_en: ["0071.png", "0072.png", "0073.png", "0074.png", "0075.png", "0076.png", "0077.png"],
          week_tc: ["0071.png", "0072.png", "0073.png", "0074.png", "0075.png", "0076.png", "0077.png"],
          week_sc: ["0071.png", "0072.png", "0073.png", "0074.png", "0075.png", "0076.png", "0077.png"],
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        ne = hmUI.createWidget(hmUI.widget.IMG, {  //电量背景黑塊
          x: 28, y: 412,
          w: 377, h: 2,
          src: "0078.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        ge = hmUI.createWidget(hmUI.widget.IMG_DATE, {  //月份字体
          month_startX: 339,
          month_startY: 264,
          month_sc_array: ["0079.png", "0080.png", "0081.png", "0082.png", "0083.png", "0084.png", "0085.png", "0086.png", "0087.png", "0088.png", "0089.png", "0090.png"],
          month_tc_array: ["0079.png", "0080.png", "0081.png", "0082.png", "0083.png", "0084.png", "0085.png", "0086.png", "0087.png", "0088.png", "0089.png", "0090.png"],
          month_en_array: ["0079.png", "0080.png", "0081.png", "0082.png", "0083.png", "0084.png", "0085.png", "0086.png", "0087.png", "0088.png", "0089.png", "0090.png"],
          month_is_character: true,
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        pe = hmUI.createWidget(hmUI.widget.IMG_DATE, {  //日期紅字体
          day_startX: 275,
          day_startY: 234,
          day_sc_array: ["0091.png", "0092.png", "0093.png", "0094.png", "0095.png", "0096.png", "0097.png", "0098.png", "0099.png", "0100.png"],
          day_tc_array: ["0091.png", "0092.png", "0093.png", "0094.png", "0095.png", "0096.png", "0097.png", "0098.png", "0099.png", "0100.png"],
          day_en_array: ["0091.png", "0092.png", "0093.png", "0094.png", "0095.png", "0096.png", "0097.png", "0098.png", "0099.png", "0100.png"],
          day_zero: true,
          day_space: -3,
          day_align: hmUI.align.LEFT,
          day_is_character: false,
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        te = hmUI.createWidget(hmUI.widget.IMG, { //电量背景
          x: 169, y: 398,
          w: 92, h: 33,
          src: "0101.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        le = hmUI.createWidget(hmUI.widget.IMG, {  //电量背景黑塊
          x: 171, y: 400,
          w: 28, h: 29,
          src: "0102.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        he = hmUI.createWidget(hmUI.widget.TEXT_IMG, {  //不明小黑塊
          x: 195, y: 403,
          font_array: ["0103.png", "0104.png", "0105.png", "0106.png", "0107.png", "0108.png", "0109.png", "0110.png", "0111.png", "0112.png"],
          padding: false,
          h_space: 0,
          unit_sc: "0113.png",
          unit_tc: "0113.png",
          unit_en: "0113.png",
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        ae = hmUI.createWidget(hmUI.widget.TEXT_IMG, {  //白小字
          x: 347, y: 335,
          font_array: ["0114.png", "0115.png", "0116.png", "0117.png", "0118.png", "0119.png", "0120.png", "0121.png", "0122.png", "0123.png"],
          padding: false,
          h_space: -2,
          align_h: hmUI.align.LEFT,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        re = hmUI.createWidget(hmUI.widget.TEXT_IMG, {  //熱量字体
          x: 347, y: 368,
          font_array: ["0124.png", "0125.png", "0126.png", "0127.png", "0128.png", "0129.png", "0130.png", "0131.png", "0132.png", "0133.png"],
          padding: false,
          h_space: -2,
          dot_image: "0134.png",
          align_h: hmUI.align.LEFT,
          type: hmUI.data_type.DISTANCE,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        se = hmUI.createWidget(hmUI.widget.TEXT_IMG, {  //距離字体
          x: 327, y: 466,
          font_array: ["0135.png", "0136.png", "0137.png", "0138.png", "0139.png", "0140.png", "0141.png", "0142.png", "0143.png", "0144.png"],
          padding: false,
          h_space: -2,
          invalid_image: "0145.png",
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        A = hmUI.createWidget(hmUI.widget.IMG, {  // 2
          x: 49, y: 466,
          w: 49, h: 466,
          src: "0148.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        R = hmUI.createWidget(hmUI.widget.IMG, {  // 9
          x: 64, y: 466,
          w: 64, h: 466,
          src: "0155.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        _e = hmUI.createWidget(hmUI.widget.IMG, {  // .
          x: 80, y: 465,
          w: 10, h: 30,
          src: "0156.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        E = hmUI.createWidget(hmUI.widget.IMG, {  // 5
          x: 88, y: 466,
          w: 88, h: 466,
          src: "0151.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        ie = hmUI.createWidget(hmUI.widget.IMG, {  // H (睡眠時長)
          x: 106, y: 466,
          w: 18, h: 24,
          src: "0157.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        x = hmUI.createWidget(hmUI.widget.TEXT, {    // 天氣預報所在地區
          x: 6, y: 129,
          w: 213, h: 26,
          color: 15330328,
          text: "--",
          text_size: 25,
          align_h: hmUI.align.LEFT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          //font: "fonts/ProductSans-Light.ttf",
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        we = hmUI.createWidget(hmUI.widget.IMG, {  //天氣藍色箭頭
          x: 7, y: 165,
          w: 22, h: 23,
          src: "0158.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        Ue = hmUI.createWidget(hmUI.widget.TEXT_IMG, {    //溫度的藍字
          x: 30, y: 165,
          font_array: ["0159.png", "0160.png", "0161.png", "0162.png", "0163.png", "0164.png", "0165.png", "0166.png", "0167.png", "0168.png"],
          padding: false,
          h_space: 0,
          unit_sc: ["0170.png"],
          unit_tc: ["0170.png"],
          unit_en: ["0170.png"],
          negative_image: ["0169.png"],
          invalid_image: ["0171.png"],
          align_h: hmUI.align.LEFT,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        de = hmUI.createWidget(hmUI.widget.IMG, {  // H: (天氣)
          x: 81, y: 165,
          w: 25, h: 26,
          src: "0172.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        ce = hmUI.createWidget(hmUI.widget.IMG, {  // L:  (天氣)
          x: 161, y: 165,
          w: 20, h: 26,
          src: "0173.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        ye = hmUI.createWidget(hmUI.widget.TEXT_IMG, {  // 低溫的數字
          x: 182, y: 165,
          font_array: ["0174.png", "0175.png", "0176.png", "0177.png", "0178.png", "0179.png", "0180.png", "0181.png", "0182.png", "0183.png"],
          padding: false,
          h_space: 0,
          unit_sc: ["0184.png"],
          unit_tc: ["0184.png"],
          unit_en: ["0184.png"],
          negative_image: ["0171.png"],
          invalid_image: ["0171.png"],
          align_h: hmUI.align.LEFT,
          type: hmUI.data_type.WEATHER_LOW,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        Le = hmUI.createWidget(hmUI.widget.TEXT_IMG, {  //高溫的數字
          x: 107, y: 165,
          font_array: ["0174.png", "0175.png", "0176.png", "0177.png", "0178.png", "0179.png", "0180.png", "0181.png", "0182.png", "0183.png"],
          padding: false,
          h_space: 0,
          unit_sc: ["0184.png"],
          unit_tc: ["0184.png"],
          unit_en: ["0184.png"],
          negative_image: ["0171.png"],
          invalid_image: ["0171.png"],
          align_h: hmUI.align.LEFT,
          type: hmUI.data_type.WEATHER_HIGH,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        ve = hmUI.createWidget(hmUI.widget.IMG, {  // 天氣的直隔線 (第二根)
          x: 70, y: 203,
          w: 1, h: 94,
          src: "0185.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        Ne = hmUI.createWidget(hmUI.widget.IMG, {  // 天氣的直隔線 (第一根)
          x: 12, y: 203,
          w: 1, h: 94,
          src: "0185.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        Oe = hmUI.createWidget(hmUI.widget.IMG, {  // 天氣的直隔線 (第三根)
          x: 127, y: 203,
          w: 1, h: 94,
          src: "0185.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        for (let e = 0; e < W.length; e++) {
          W[e] = hmUI.createWidget(hmUI.widget.IMG, {  // 天氣的直隔線
            x: 30 + e * 12, y: 203,
            w: 12, h: 21,
            enable: false,
            show_level: hmUI.show_level.ONLY_NORMAL
          });
        }

        for (let e = 0; e < Y.length; e++) {
          Y[e] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 86 + e * 12, y: 203,
            w: 12, h: 21,
            enable: false,
            show_level: hmUI.show_level.ONLY_NORMAL
          });
        }

        for (let e = 0; e < S.length; e++) {
          S[e] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 146 + e * 12, y: 203,
            w: 12, h: 21,
            enable: false,
            show_level: hmUI.show_level.ONLY_NORMAL
          });
        }

        for (let e = 0; e < b.length; e++) {
          b[e] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 200 + e * 12, y: 203,
            w: 12, h: 21,
            enable: false,
            show_level: hmUI.show_level.ONLY_NORMAL
          });
        }

        Ee = hmUI.createWidget(hmUI.widget.IMG, {   // 天氣的直隔線 (第四根)
          x: 185, y: 203,
          w: 1, h: 94,
          src: "0185.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        xe = hmUI.createWidget(hmUI.widget.IMG, {  // 天氣的直隔線 (第五根)
          x: 243, y: 203,
          w: 1, h: 94,
          src: "0185.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        C = hmUI.createWidget(hmUI.widget.IMG, {  // 彎月 (第一天)
          x: 25, y: 232,
          w: 25, h: 232,
          src: "0226.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        k = hmUI.createWidget(hmUI.widget.IMG, {  // 彎月 (第二天)
          x: 82, y: 232,
          w: 82, h: 232,
          src: "0226.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        H = hmUI.createWidget(hmUI.widget.IMG, {  // 彎月 (第三天)
          x: 142, y: 232,
          w: 142, h: 232,
          src: "0226.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        B = hmUI.createWidget(hmUI.widget.IMG, {  // 彎月 (第四天)
          x: 197, y: 232,
          w: 197, h: 232,
          src: "0226.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        Se = hmUI.createWidget(hmUI.widget.IMG_WEEK, {   //星期幾的文字
          x: 21, y: 280,
          week_en: ["0227.png", "0228.png", "0229.png", "0230.png", "0231.png", "0232.png", "0233.png"],
          week_tc: ["0227.png", "0228.png", "0229.png", "0230.png", "0231.png", "0232.png", "0233.png"],
          week_sc: ["0227.png", "0228.png", "0229.png", "0230.png", "0231.png", "0232.png", "0233.png"],
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        Te = hmUI.createWidget(hmUI.widget.IMG_WEEK, {  //星期幾的文字
          x: 76, y: 280,
          week_en: ["0234.png", "0235.png", "0236.png", "0237.png", "0238.png", "0239.png", "0240.png"],
          week_tc: ["0234.png", "0235.png", "0236.png", "0237.png", "0238.png", "0239.png", "0240.png"],
          week_sc: ["0234.png", "0235.png", "0236.png", "0237.png", "0238.png", "0239.png", "0240.png"],
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        be = hmUI.createWidget(hmUI.widget.IMG_WEEK, {  //星期幾的文字
          x: 134, y: 280,
          week_en: ["0235.png", "0236.png", "0237.png", "0238.png", "0239.png", "0240.png", "0234.png"],
          week_tc: ["0235.png", "0236.png", "0237.png", "0238.png", "0239.png", "0240.png", "0234.png"],
          week_sc: ["0235.png", "0236.png", "0237.png", "0238.png", "0239.png", "0240.png", "0234.png"],
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        Pe = hmUI.createWidget(hmUI.widget.IMG_WEEK, {  //星期幾的文字
          x: 192, y: 280,
          week_en: ["0236.png", "0237.png", "0238.png", "0239.png", "0240.png", "0234.png", "0235.png"],
          week_tc: ["0236.png", "0237.png", "0238.png", "0239.png", "0240.png", "0234.png", "0235.png"],
          week_sc: ["0236.png", "0237.png", "0238.png", "0239.png", "0240.png", "0234.png", "0235.png"],
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        Ce = hmUI.createWidget(hmUI.widget.IMG_STATUS, {  //鬧鐘圖案
          x: 12, y: 80,
          w: 22, h: 23,
          type: hmUI.system_status.CLOCK,
          src: "0241.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });
 
        ke = hmUI.createWidget(hmUI.widget.TEXT_IMG, {  //生物能量的文字
          x: 179, y: 466,
          font_array: ["0242.png", "0243.png", "0244.png", "0245.png", "0246.png", "0247.png", "0248.png", "0249.png", "0250.png", "0251.png"],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.BIO_CHARGE,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        He = hmUI.createWidget(hmUI.widget.IMG_CLICK, {  //顯示睡眠时長
          x: 49, y: 418,
          w: 81, h: 83,
          src: "",
          type: hmUI.data_type.SLEEP,
          show_level: hmUI.show_level.ONLY_NORMAL        });

        Be = hmUI.createWidget(hmUI.widget.BUTTON, {  //點擊運動清單
          x: 9, y: 310,
          w: 86, h: 89,
          text: "",
          normal_src: "",
          press_src: "",
          click_func: () => {
            hmApp.startApp({ url: "SportListScreen", native: true });
          },
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        Ve = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 282, y: 219,
          w: 83, h: 86,
          text: "",
          normal_src: "",
          press_src: "",
          click_func: () => {
            hmApp.startApp({ url: "ScheduleCalScreen", native: true });
          },
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        Fe = hmUI.createWidget(hmUI.widget.IMG_CLICK, {  //點擊天氣功能
          x: 22, y: 194,
          w: 111, h: 114,
          src: "",
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        Xe = hmUI.createWidget(hmUI.widget.IMG_CLICK, {//叫出天氣功能
          x: 125, y: 194,
          w: 111, h: 114,
          src: "",
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        De = hmUI.createWidget(hmUI.widget.BUTTON, {  //點擊尋找手机圖
          x: 186, y: 323,
          w: 58, h: 59,
          text: "",
          normal_src: "",
          press_src: "",
          click_func: () => {
            hmApp.startApp({ url: "FindPhoneScreen", native: true });
          },
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        Ke = hmUI.createWidget(hmUI.widget.IMG, {  // 長方黑框
          x: 176, y: 312,
          w: 78, h: 80,
          src: "0252.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        je = hmUI.createWidget(hmUI.widget.IMG, {  //雷達圖
          x: 181, y: 316,
          w: 69, h: 71,
          src: "0253.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        function p() { // 類比時鐘 Circle Clock
          if (d) {
            d.setProperty(hmUI.prop.ANGLE, 0 + parseInt(e.hour % 12 || 12) * 30 + e.minute / 60 * 30);
          }
          if (y) {
            y.setProperty(hmUI.prop.ANGLE, 0 + e.minute * 6);
          }
          if (L) {
            L.setProperty(hmUI.prop.ANGLE, 0 + e.second * 6);
          }
          N.setProperty(hmUI.prop.MORE, {
            src: $[e.format_hour.toString().length == 2 ? e.format_hour.toString().charAt(0) : 0]
          });
          O.setProperty(hmUI.prop.MORE, {
            src: z[e.format_hour.toString().length == 2 ? e.format_hour.toString().charAt(1) : e.format_hour.toString().charAt(0)]
          });
          M.setProperty(hmUI.prop.MORE, {
            src: q[e.minute.toString().length == 2 ? e.minute.toString().charAt(0) : 0]
          });
          f.setProperty(hmUI.prop.MORE, {
            src: J[e.minute.toString().length == 2 ? e.minute.toString().charAt(1) : e.minute.toString().charAt(0)]
          });
        }

        function t() { // 
          x.setProperty(hmUI.prop.TEXT, v.getForecastWeather().cityName);
          let e = v.getForecastWeather().forecastData;
          let g = typeof e.data[1] != "undefined" ? e.data[1].high : 0;
          g = g.toString();
          let p = W.length - 1;
          if (Me) {
            g = g.padStart(p, "0");
          }
          if (g.length > p) {
            g = g.slice(0, p);
          }
          let t = g.length;
          let l = 30;
          for (let n = 0; n < p; n++) {
            if (n >= t) {
              W[n].setProperty(hmUI.prop.VISIBLE, false);
            } else {
              W[n].setProperty(hmUI.prop.VISIBLE, true);
              W[n].setProperty(hmUI.prop.MORE, { x: l + 12 * n });
              let e = isNaN(parseInt(g.charAt(n))) ? 10 : g.charAt(n);
              W[n].setProperty(hmUI.prop.SRC, G[e]);
            }
          }
          W[p].setProperty(hmUI.prop.VISIBLE, true);
          W[p].setProperty(hmUI.prop.MORE, { x: l + 12 * t });
          W[p].setProperty(hmUI.prop.SRC, G[11]);

          let h = typeof e.data[2] != "undefined" ? e.data[2].high : 0;
          h = h.toString();
          let a = Y.length - 1;
          if (fe) {
            h = h.padStart(a, "0");
          }
          if (h.length > a) {
            h = h.slice(0, a);
          }
          let r = h.length;
          let s = 86;
          for (let n = 0; n < a; n++) {
            if (n >= r) {
              Y[n].setProperty(hmUI.prop.VISIBLE, false);
            } else {
              Y[n].setProperty(hmUI.prop.VISIBLE, true);
              Y[n].setProperty(hmUI.prop.MORE, { x: s + 12 * n });
              let e = isNaN(parseInt(h.charAt(n))) ? 10 : h.charAt(n);
              Y[n].setProperty(hmUI.prop.SRC, u[e]);
            }
          }
          Y[a].setProperty(hmUI.prop.VISIBLE, true);
          Y[a].setProperty(hmUI.prop.MORE, { x: s + 12 * r });
          Y[a].setProperty(hmUI.prop.SRC, u[11]);

          let o = typeof e.data[3] != "undefined" ? e.data[3].high : 0;
          o = o.toString();
          let _ = S.length - 1;
          if (Ae) {
            o = o.padStart(_, "0");
          }
          if (o.length > _) {
            o = o.slice(0, _);
          }
          let m = o.length;
          let i = 146;
          for (let n = 0; n < _; n++) {
            if (n >= m) {
              S[n].setProperty(hmUI.prop.VISIBLE, false);
            } else {
              S[n].setProperty(hmUI.prop.VISIBLE, true);
              S[n].setProperty(hmUI.prop.MORE, { x: i + 12 * n });
              let e = isNaN(parseInt(o.charAt(n))) ? 10 : o.charAt(n);
              S[n].setProperty(hmUI.prop.SRC, T[e]);
            }
          }
          S[_].setProperty(hmUI.prop.VISIBLE, true);
          S[_].setProperty(hmUI.prop.MORE, { x: i + 12 * m });
          S[_].setProperty(hmUI.prop.SRC, T[11]);

          let U = typeof e.data[4] != "undefined" ? e.data[4].high : 0;
          U = U.toString();
          let d = b.length - 1;
          if (Re) {
            U = U.padStart(d, "0");
          }
          if (U.length > d) {
            U = U.slice(0, d);
          }
          let c = U.length;
          let y = 200;
          for (let n = 0; n < d; n++) {
            if (n >= c) {
              b[n].setProperty(hmUI.prop.VISIBLE, false);
            } else {
              b[n].setProperty(hmUI.prop.VISIBLE, true);
              b[n].setProperty(hmUI.prop.MORE, { x: y + 12 * n });
              let e = isNaN(parseInt(U.charAt(n))) ? 10 : U.charAt(n);
              b[n].setProperty(hmUI.prop.SRC, P[e]);
            }
          }
          b[d].setProperty(hmUI.prop.VISIBLE, true);
          b[d].setProperty(hmUI.prop.MORE, { x: y + 12 * c });
          b[d].setProperty(hmUI.prop.SRC, P[11]);

          C.setProperty(hmUI.prop.MORE, {
            src: We[typeof e.data[1] != "undefined" ? e.data[1].index : 25]
          });
          k.setProperty(hmUI.prop.MORE, {
            src: Ge[typeof e.data[2] != "undefined" ? e.data[2].index : 25]
          });
          H.setProperty(hmUI.prop.MORE, {
            src: Ye[typeof e.data[3] != "undefined" ? e.data[3].index : 25]
          });
          B.setProperty(hmUI.prop.MORE, {
            src: ue[typeof e.data[4] != "undefined" ? e.data[4].index : 0]
          });
        }

        function l() {
          A.setProperty(hmUI.prop.MORE, {
            src: Ie[Math.floor(n.getTotalTime() / 60).toString().padStart(2, "0").charAt(0)]
          });
          R.setProperty(hmUI.prop.MORE, {
            src: oe[Math.floor(n.getTotalTime() / 60).toString().padStart(2, "0").charAt(1)]
          });
          E.setProperty(hmUI.prop.MORE, {
            src: me[Math.floor(n.getTotalTime() % 60).toString().padStart(2, "0").charAt(0)]
          });
        }

        e.addEventListener(hmSensor.event.CHANGE, function() { p(); });
        v.addEventListener(hmSensor.event.CHANGE, function() { t(); });
        n.addEventListener(hmSensor.event.CHANGE, function() { l(); });

        const h = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function() {
            p();
            t();
            l();
            c = setInterval(p, 1000);
          },
          pause_call: function() {
            clearInterval(c);
          }
        });
      },

      onInit() {
        console.log("index page.js on init invoke");
        this.init_view();
      },

      onReady() {
        console.log("index page.js on ready invoke");
      },

      onShow() {
        console.log("index page.js on show invoke");
      },

      onHide() {
        console.log("index page.js on hide invoke");
      },

      onDestroy() {
        console.log("index page.js on destroy invoke");
      }
    });
  })();
} catch (e) {
  console.log(e);
}