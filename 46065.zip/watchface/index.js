﻿    /*
    ** Watch_Face_Editor tool v 18.2
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_step_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_alarm_clock_icon_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'background_a971a089.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 102,
              y: 91,
              week_en: ["chars_A0BFFAB0_000.png","chars_A0BFFAB0_001.png","chars_A0BFFAB0_002.png","chars_A0BFFAB0_003.png","chars_A0BFFAB0_004.png","chars_A0BFFAB0_005.png","chars_A0BFFAB0_006.png"],
              week_tc: ["chars_A0BFFAB0_000.png","chars_A0BFFAB0_001.png","chars_A0BFFAB0_002.png","chars_A0BFFAB0_003.png","chars_A0BFFAB0_004.png","chars_A0BFFAB0_005.png","chars_A0BFFAB0_006.png"],
              week_sc: ["chars_A0BFFAB0_000.png","chars_A0BFFAB0_001.png","chars_A0BFFAB0_002.png","chars_A0BFFAB0_003.png","chars_A0BFFAB0_004.png","chars_A0BFFAB0_005.png","chars_A0BFFAB0_006.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 68,
              day_startY: 89,
              day_sc_array: ["chars_52A7F972_000.png","chars_52A7F972_001.png","chars_52A7F972_002.png","chars_52A7F972_003.png","chars_52A7F972_004.png","chars_52A7F972_005.png","chars_52A7F972_006.png","chars_52A7F972_007.png","chars_52A7F972_008.png","chars_52A7F972_009.png"],
              day_tc_array: ["chars_52A7F972_000.png","chars_52A7F972_001.png","chars_52A7F972_002.png","chars_52A7F972_003.png","chars_52A7F972_004.png","chars_52A7F972_005.png","chars_52A7F972_006.png","chars_52A7F972_007.png","chars_52A7F972_008.png","chars_52A7F972_009.png"],
              day_en_array: ["chars_52A7F972_000.png","chars_52A7F972_001.png","chars_52A7F972_002.png","chars_52A7F972_003.png","chars_52A7F972_004.png","chars_52A7F972_005.png","chars_52A7F972_006.png","chars_52A7F972_007.png","chars_52A7F972_008.png","chars_52A7F972_009.png"],
              day_zero: 1,
              day_space: -4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 157,
              y: 98,
              image_array: ["set_8_55x55_h0s0b80_meteo_1.png","set_8_55x55_h0s0b80_meteo_2.png","set_8_55x55_h0s0b80_meteo_3.png","set_8_55x55_h0s0b80_meteo_4.png","set_8_55x55_h0s0b80_meteo_5.png","set_8_55x55_h0s0b80_meteo_6.png","set_8_55x55_h0s0b80_meteo_7.png","set_8_55x55_h0s0b80_meteo_8.png","set_8_55x55_h0s0b80_meteo_9.png","set_8_55x55_h0s0b80_meteo_10.png","set_8_55x55_h0s0b80_meteo_11.png","set_8_55x55_h0s0b80_meteo_12.png","set_8_55x55_h0s0b80_meteo_13.png","set_8_55x55_h0s0b80_meteo_14.png","set_8_55x55_h0s0b80_meteo_15.png","set_8_55x55_h0s0b80_meteo_16.png","set_8_55x55_h0s0b80_meteo_17.png","set_8_55x55_h0s0b80_meteo_18.png","set_8_55x55_h0s0b80_meteo_19.png","set_8_55x55_h0s0b80_meteo_20.png","set_8_55x55_h0s0b80_meteo_21.png","set_8_55x55_h0s0b80_meteo_22.png","set_8_55x55_h0s0b80_meteo_23.png","set_8_55x55_h0s0b80_meteo_24.png","set_8_55x55_h0s0b80_meteo_25.png","set_8_55x55_h0s0b80_meteo_26.png","set_8_55x55_h0s0b80_meteo_27.png","set_8_55x55_h0s0b80_meteo_28.png","set_8_55x55_h0s0b80_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 91,
              font_array: ["chars_52A7F972_000.png","chars_52A7F972_001.png","chars_52A7F972_002.png","chars_52A7F972_003.png","chars_52A7F972_004.png","chars_52A7F972_005.png","chars_52A7F972_006.png","chars_52A7F972_007.png","chars_52A7F972_008.png","chars_52A7F972_009.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'chars_DD8664A8_011.png',
              unit_tc: 'chars_DD8664A8_011.png',
              unit_en: 'chars_DD8664A8_011.png',
              negative_image: 'chars_DD8664A8_010.png',
              invalid_image: 'chars_DD8664A8_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 290,
              y: 136,
              w: 37,
              h: 35,
              text_size: 30,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 106,
              y: 137,
              w: 37,
              h: 35,
              text_size: 30,
              char_space: 0,
              color: 0xFF59ACFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 167,
              y: 396,
              font_array: ["chars_55E24236_000.png","chars_55E24236_001.png","chars_55E24236_002.png","chars_55E24236_003.png","chars_55E24236_004.png","chars_55E24236_005.png","chars_55E24236_006.png","chars_55E24236_007.png","chars_55E24236_008.png","chars_55E24236_009.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 136,
              y: 390,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 315,
              y: 365,
              src: 'alarm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointers_pointer_set_46_h_594752D9.png',
              center_x: 122,
              center_y: 259,
              x: 20,
              y: 70,
              start_angle: 32,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 112,
              y: 279,
              src: 'puls.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 106,
              y: 213,
              w: 38,
              h: 35,
              text_size: 30,
              char_space: 0,
              color: 0xFFE5E5E5,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointers_pointer_set_46_h_59393B58.png',
              center_x: 311,
              center_y: 255,
              x: 20,
              y: 69,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 294,
              y: 280,
              src: 'bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 292,
              y: 213,
              w: 38,
              h: 35,
              text_size: 30,
              char_space: 0,
              color: 0xFFE7E7E7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'pointers_hour_set_42_h_474DB52B.png',
              hour_centerX: 216,
              hour_centerY: 257,
              hour_posX: 29,
              hour_posY: 161,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'pointers_minute_set_42_m_8378BD5D.png',
              minute_centerX: 216,
              minute_centerY: 257,
              minute_posX: 24,
              minute_posY: 212,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'pointers_second_set_35_s_F7B9B099.png',
              second_centerX: 216,
              second_centerY: 257,
              second_posX: 15,
              second_posY: 217,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 133,
              y: 326,
              w: 165,
              h: 57,
              text_size: 57,
              char_space: 0,
              color: 0xFFCDCDCD,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 164,
              y: 393,
              w: 100,
              h: 45,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 73,
              y: 209,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 179,
              y: 118,
              w: 75,
              h: 75,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 298,
              y: 77,
              w: 100,
              h: 61,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 168,
              y: 330,
              w: 100,
              h: 51,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 286,
              y: 358,
              w: 100,
              h: 51,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr.padStart(2, '0');
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0');
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}