﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_moon_image_progress_img_level = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 14;
        let normal_calorie_TextCircle_img_height = 19;
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 14;
        let normal_heart_rate_TextCircle_img_height = 19;
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_step_circle_scale = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 14;
        let normal_step_TextCircle_img_height = 19;
        let normal_battery_image_progress_img_level = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 14;
        let normal_battery_TextCircle_img_height = 19;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 16;
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 320,
              // h: 369,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: '1.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: '120.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: '121.png' },
              ],
              count: 3,
              default_id: 1,
              fg: '.png',
              tips_bg: '119.png',
              tips_x: 1,
              tips_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 55,
              y: 170,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 97,
              y: 326,
              src: 'calories_41.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 160,
              // center_y: 185,
              // start_angle: 203,
              // end_angle: 247,
              // radius: 171,
              // line_width: 13,
              // line_cap: Rounded,
              // color: 0xFF408080,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 160,
              center_y: 185,
              start_angle: 203,
              end_angle: 247,
              radius: 165,
              line_width: 13,
              corner_flag: 0,
              color: 0xFF408080,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 160,
              // circle_center_Y: 185,
              // font_array: ["90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png"],
              // radius: 176,
              // angle: -142,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = '90.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = '91.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = '92.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = '93.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = '94.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = '95.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = '96.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = '97.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = '98.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = '99.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 320,
                h: 380,
                center_x: 160,
                center_y: 185,
                pos_x: 160 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 185 - 195,
                src: '90.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 130,
              y: 4,
              src: 'pulse_39.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 160,
              // center_y: 184,
              // start_angle: -59,
              // end_angle: -12,
              // radius: 175,
              // line_width: 13,
              // line_cap: Rounded,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 160,
              center_y: 184,
              start_angle: -59,
              end_angle: -12,
              radius: 169,
              line_width: 13,
              corner_flag: 0,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 160,
              // circle_center_Y: 185,
              // font_array: ["90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png"],
              // radius: 183,
              // angle: -39,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = '90.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = '91.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = '92.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = '93.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = '94.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = '95.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = '96.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = '97.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = '98.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = '99.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 320,
                h: 380,
                center_x: 160,
                center_y: 185,
                pos_x: 160 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 185 - 202,
                src: '90.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 154,
              y: 234,
              image_array: ["W_Weather_icons_01.png","W_Weather_icons_02.png","W_Weather_icons_03.png","W_Weather_icons_04.png","W_Weather_icons_05.png","W_Weather_icons_06.png","W_Weather_icons_07.png","W_Weather_icons_08.png","W_Weather_icons_09.png","W_Weather_icons_10.png","W_Weather_icons_11.png","W_Weather_icons_12.png","W_Weather_icons_13.png","W_Weather_icons_14.png","W_Weather_icons_15.png","W_Weather_icons_16.png","W_Weather_icons_17.png","W_Weather_icons_18.png","W_Weather_icons_19.png","W_Weather_icons_20.png","W_Weather_icons_21.png","W_Weather_icons_22.png","W_Weather_icons_23.png","W_Weather_icons_24.png","W_Weather_icons_25.png","W_Weather_icons_26.png","W_Weather_icons_27.png","W_Weather_icons_28.png","W_Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 252,
              font_array: ["Act_white_small_0.png","Act_white_small_1.png","Act_white_small_2.png","Act_white_small_3.png","Act_white_small_4.png","Act_white_small_5.png","Act_white_small_6.png","Act_white_small_7.png","Act_white_small_8.png","Act_white_small_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_Symbo_W1.png',
              unit_tc: 'Weather_Symbo_W1.png',
              unit_en: 'Weather_Symbo_W1.png',
              negative_image: 'Weather_Symbo_W2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 183,
              y: 208,
              week_en: ["Week_W_1.png","Week_W_2.png","Week_W_3.png","Week_W_4.png","Week_W_5.png","Week_W_6.png","Week_W_7.png"],
              week_tc: ["Week_W_1.png","Week_W_2.png","Week_W_3.png","Week_W_4.png","Week_W_5.png","Week_W_6.png","Week_W_7.png"],
              week_sc: ["Week_W_1.png","Week_W_2.png","Week_W_3.png","Week_W_4.png","Week_W_5.png","Week_W_6.png","Week_W_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 228,
              day_startY: 173,
              day_sc_array: ["15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              day_tc_array: ["15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              day_en_array: ["15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 160,
              // center_y: 185,
              // start_angle: 157,
              // end_angle: 118,
              // radius: 171,
              // line_width: 13,
              // line_cap: Rounded,
              // color: 0xFFD3D2C5,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 160,
              center_y: 185,
              start_angle: 157,
              end_angle: 118,
              radius: 165,
              line_width: 13,
              corner_flag: 0,
              color: 0xFFD3D2C5,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 160,
              // circle_center_Y: 185,
              // font_array: ["90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png"],
              // radius: 184,
              // angle: 153,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = '90.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = '91.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = '92.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = '93.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = '94.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = '95.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = '96.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = '97.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = '98.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = '99.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 320,
                h: 380,
                center_x: 160,
                center_y: 185,
                pos_x: 160 - normal_step_TextCircle_img_width / 2,
                pos_y: 185 + 175,
                src: '90.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 188,
              y: 11,
              image_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 160,
              // circle_center_Y: 185,
              // font_array: ["90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png"],
              // radius: 186,
              // angle: 35,
              // char_space_angle: 0,
              // unit: '100.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = '90.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = '91.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = '92.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = '93.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = '94.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = '95.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = '96.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = '97.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = '98.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = '99.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 320,
                h: 380,
                center_x: 160,
                center_y: 185,
                pos_x: 160 - normal_battery_TextCircle_img_width / 2,
                pos_y: 185 - 195,
                src: '90.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 320,
              h: 380,
              center_x: 160,
              center_y: 185,
              pos_x: 160 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 185 - 195,
              src: '100.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '2.png',
              hour_centerX: 160,
              hour_centerY: 185,
              hour_posX: 24,
              hour_posY: 94,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '3.png',
              minute_centerX: 160,
              minute_centerY: 185,
              minute_posX: 23,
              minute_posY: 147,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '4.png',
              second_centerX: 160,
              second_centerY: 186,
              second_posX: 11,
              second_posY: 143,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 91,
              hour_startY: 99,
              hour_array: ["Time_W_Font_0.png","Time_W_Font_1.png","Time_W_Font_2.png","Time_W_Font_3.png","Time_W_Font_4.png","Time_W_Font_5.png","Time_W_Font_6.png","Time_W_Font_7.png","Time_W_Font_8.png","Time_W_Font_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 165,
              minute_startY: 99,
              minute_array: ["Time_W_Font_0.png","Time_W_Font_1.png","Time_W_Font_2.png","Time_W_Font_3.png","Time_W_Font_4.png","Time_W_Font_5.png","Time_W_Font_6.png","Time_W_Font_7.png","Time_W_Font_8.png","Time_W_Font_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 154,
              y: 100,
              src: 'Time_w_Dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 144,
              day_startY: 223,
              day_sc_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              day_tc_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              day_en_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '2.png',
              hour_centerX: 160,
              hour_centerY: 185,
              hour_posX: 24,
              hour_posY: 93,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '3.png',
              minute_centerX: 160,
              minute_centerY: 185,
              minute_posX: 24,
              minute_posY: 148,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '4.png',
              second_centerX: 160,
              second_centerY: 185,
              second_posX: 11,
              second_posY: 142,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 167,
              y: 312,
              w: 100,
              h: 56,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 14,
              y: 13,
              w: 66,
              h: 69,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 47,
              y: 161,
              w: 40,
              h: 43,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 109,
              y: 227,
              w: 100,
              h: 50,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 16,
              y: 289,
              w: 100,
              h: 63,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 16,
              y: 8,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: '39.png',
              normal_src: '39.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 222,
              y: 8,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: '39.png',
              normal_src: '39.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 119,
              y: 189,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: '39.png',
              normal_src: '39.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 222,
              y: 287,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: '39.png',
              normal_src: '39.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -142;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 176));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 160 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_calorie_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -39;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 183));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 160 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 333;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 184));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 160 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 35;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 186));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 186));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + (normal_battery_TextCircle_img_angle + normal_battery_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 160 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 160,
                      center_y: 185,
                      start_angle: 203,
                      end_angle: 247,
                      radius: 165,
                      line_width: 13,
                      corner_flag: 0,
                      color: 0xFF408080,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 160,
                      center_y: 184,
                      start_angle: -59,
                      end_angle: -12,
                      radius: 169,
                      line_width: 13,
                      corner_flag: 0,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 160,
                      center_y: 185,
                      start_angle: 157,
                      end_angle: 118,
                      radius: 165,
                      line_width: 13,
                      corner_flag: 0,
                      color: 0xFFD3D2C5,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}