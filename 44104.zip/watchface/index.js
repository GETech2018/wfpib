﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bg_00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 269,
              y: 3,
              src: 'sta00.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 3,
              src: 'sta01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 307,
              month_startY: 324,
              month_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              month_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              month_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              month_zero: 1,
              month_space: -13,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 212,
              day_startY: 324,
              day_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_zero: 1,
              day_space: -13,
              day_unit_sc: 'num_13.png',
              day_unit_tc: 'num_13.png',
              day_unit_en: 'num_13.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 15,
              y: 324,
              week_en: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png"],
              week_tc: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png"],
              week_sc: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 14,
              y: 144,
              image_array: ["wea_00.png","wea_01.png","wea_02.png","wea_03.png","wea_04.png","wea_05.png","wea_06.png","wea_07.png","wea_08.png","wea_09.png","wea_10.png","wea_11.png","wea_12.png","wea_13.png","wea_14.png","wea_15.png","wea_16.png","wea_17.png","wea_18.png","wea_19.png","wea_20.png","wea_21.png","wea_22.png","wea_23.png","wea_24.png","wea_25.png","wea_26.png","wea_27.png","wea_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 56,
              y: 111,
              font_array: ["nub_00.png","nub_01.png","nub_02.png","nub_03.png","nub_04.png","nub_05.png","nub_06.png","nub_07.png","nub_08.png","nub_09.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'nub_11.png',
              unit_tc: 'nub_11.png',
              unit_en: 'nub_11.png',
              imperial_unit_sc: 'nub_11.png',
              imperial_unit_tc: 'nub_11.png',
              imperial_unit_en: 'nub_11.png',
              negative_image: 'nub_12.png',
              invalid_image: 'nub_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 32,
              y: 111,
              src: 'nub_15.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 56,
                y: 111,
                font_array: ["nub_00.png","nub_01.png","nub_02.png","nub_03.png","nub_04.png","nub_05.png","nub_06.png","nub_07.png","nub_08.png","nub_09.png"],
                padding: false,
                h_space: -1,
                unit_sc: 'nub_11.png',
                unit_tc: 'nub_11.png',
                unit_en: 'nub_11.png',
                imperial_unit_sc: 'nub_11.png',
                imperial_unit_tc: 'nub_11.png',
                imperial_unit_en: 'nub_11.png',
                negative_image: 'nub_12.png',
                invalid_image: 'nub_14.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 56,
              y: 288,
              font_array: ["nub_00.png","nub_01.png","nub_02.png","nub_03.png","nub_04.png","nub_05.png","nub_06.png","nub_07.png","nub_08.png","nub_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'nub_11.png',
              unit_tc: 'nub_11.png',
              unit_en: 'nub_11.png',
              imperial_unit_sc: 'nub_11.png',
              imperial_unit_tc: 'nub_11.png',
              imperial_unit_en: 'nub_11.png',
              negative_image: 'nub_12.png',
              invalid_image: 'nub_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 32,
              y: 288,
              src: 'nub_16.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 56,
                y: 288,
                font_array: ["nub_00.png","nub_01.png","nub_02.png","nub_03.png","nub_04.png","nub_05.png","nub_06.png","nub_07.png","nub_08.png","nub_09.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'nub_11.png',
                unit_tc: 'nub_11.png',
                unit_en: 'nub_11.png',
                imperial_unit_sc: 'nub_11.png',
                imperial_unit_tc: 'nub_11.png',
                imperial_unit_en: 'nub_11.png',
                negative_image: 'nub_12.png',
                invalid_image: 'nub_14.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 35,
              y: 224,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -13,
              unit_sc: 'num_10.png',
              unit_tc: 'num_10.png',
              unit_en: 'num_10.png',
              imperial_unit_sc: 'num_10.png',
              imperial_unit_tc: 'num_10.png',
              imperial_unit_en: 'num_10.png',
              negative_image: 'num_12.png',
              invalid_image: 'num_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 35,
                y: 224,
                font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
                padding: false,
                h_space: -13,
                unit_sc: 'num_10.png',
                unit_tc: 'num_10.png',
                unit_en: 'num_10.png',
                imperial_unit_sc: 'num_10.png',
                imperial_unit_tc: 'num_10.png',
                imperial_unit_en: 'num_10.png',
                negative_image: 'num_12.png',
                invalid_image: 'num_11.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 339,
              font_array: ["nub_00.png","nub_01.png","nub_02.png","nub_03.png","nub_04.png","nub_05.png","nub_06.png","nub_07.png","nub_08.png","nub_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ico_02.png',
              unit_tc: 'ico_02.png',
              unit_en: 'ico_02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 232,
              y: 400,
              font_array: ["nub_00.png","nub_01.png","nub_02.png","nub_03.png","nub_04.png","nub_05.png","nub_06.png","nub_07.png","nub_08.png","nub_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ico_00.png',
              unit_tc: 'ico_00.png',
              unit_en: 'ico_00.png',
              imperial_unit_sc: 'ico_00.png',
              imperial_unit_tc: 'ico_00.png',
              imperial_unit_en: 'ico_00.png',
              dot_image: 'nub_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 400,
              font_array: ["nub_00.png","nub_01.png","nub_02.png","nub_03.png","nub_04.png","nub_05.png","nub_06.png","nub_07.png","nub_08.png","nub_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ico_01.png',
              unit_tc: 'ico_01.png',
              unit_en: 'ico_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 58,
              font_array: ["nub_00.png","nub_01.png","nub_02.png","nub_03.png","nub_04.png","nub_05.png","nub_06.png","nub_07.png","nub_08.png","nub_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ico_03.png',
              unit_tc: 'ico_03.png',
              unit_en: 'ico_03.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 42,
              y: 12,
              image_array: ["hea_00.png","hea_01.png","hea_02.png","hea_03.png","hea_04.png","hea_05.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 172,
              hour_startY: 51,
              hour_array: ["hou_00.png","hou_01.png","hou_02.png","hou_03.png","hou_04.png","hou_05.png","hou_06.png","hou_07.png","hou_08.png","hou_09.png"],
              hour_zero: 1,
              hour_space: -7,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 172,
              minute_startY: 189,
              minute_array: ["min_00.png","min_01.png","min_02.png","min_03.png","min_04.png","min_05.png","min_06.png","min_07.png","min_08.png","min_09.png"],
              minute_zero: 1,
              minute_space: -7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}