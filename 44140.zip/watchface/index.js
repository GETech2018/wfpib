﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// запуск приложения с заданным appId (если оно установлено) или системного приложения
function launchAppOrAppId(url, appId, page = 'page/index') {
 let appInstalled = false;
 try {
  const id16 = appId.toString(16).padStart(8, "0"); // переводим appId в 16-ричный формат
  const [fs_stat, err] = hmFS.stat_asset(`../../../js_apps/${id16}/app.json`); // проверяем наличие файла 'app.json' в папке приложения
  if (err == 0) { //  если файл есть,  то приложение установлено
   appInstalled = true;
  } else {
   console.log("err:", err);
  }
 } catch (error) {
  console.log("error:", error);
  console.log("FAIL: No access to hmFS.");
 }
 if (appInstalled) hmApp.startApp({
  appid: appId,
  url: page
 })
 else hmApp.startApp({
  url: url,
  native: true
 });
}

   const baro = hmSensor.createSensor(hmSensor.id.BARO);
    const pressureValue = baro.pressure;
    const altitudeValue = baro.altitude;

      const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
    //  const battery = hmSensor.createSensor(hmSensor.id.BATTERY)
     // const step = hmSensor.createSensor(hmSensor.id.STEP);
      const heart_rate = hmSensor.createSensor(hmSensor.id.HEART); //heart_rate.last
      const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
      const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
     // const stand = hmSensor.createSensor(hmSensor.id.STAND)
     // const pai = hmSensor.createSensor(hmSensor.id.PAI);
     // const fatburn = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
//      const spo2 = hmSensor.createSensor(hmSensor.id.SPO2);
//      const stress = hmSensor.createSensor(hmSensor.id.STRESS);



let normal_altitude_target_text_font = ''
let idle_altitude_target_text_font = ''
let normal_distance_current_text_font = ''
let idle_distance_current_text_font = ''
let normal_stress_current_text_font = ''
let idle_stress_current_text_font = ''
let normal_fat_burning_current_text_font = ''
let idle_fat_burning_current_text_font = ''
let normal_temperature_current_text_font = ''
let idle_temperature_current_text_font = ''
let normal_heart_rate_text_font = ''
let idle_heart_rate_text_font = ''
let normal_altimeter_current_text_font = ''
let idle_altimeter_current_text_font = ''
let normal_time_second_text_font = ''
let idle_time_second_text_font = ''

let normal_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
let normal_Month_Array = ['ЯНВ', 'ФЕВ', 'МАР', 'АПР', 'МАЙ', 'ИЮН', 'ИЮЛ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК', ];
let normal_time_hour_min_text_font = ''
let normal_timerTimeUpdate = undefined;
let normal_day_text_font = ''
let idle_time_hour_min_text_font = ''
let idle_timerTimeUpdate = undefined;
let idle_day_text_font = ''		
		
function app_update() {
	
//let distanceCurrent = distance.current;
	let pressureValue = baro.pressure;
	let altitudeValue = baro.altitude;

normal_altitude_target_text_font.setProperty(hmUI.prop.TEXT, altitudeValue + " М");
idle_altitude_target_text_font.setProperty(hmUI.prop.TEXT, altitudeValue + " М");

}


      const windDirectionStr = [
       ['Северный', 'N', 'СЕВ'], // 0
       ['Сев-Вос', 'NE', 'С-В'], // 1
       ['Восточный', 'E', 'ВОС'], // 2
       ['Юго-Вос', 'SE', 'Ю-В'], // 3
       ['Южный', 'S', 'ЮЖ'], // 4
       ['Юго-Зап', 'SW', 'Ю-З'], // 5
       ['Западный', 'W', 'ЗАП'], // 6
       ['Сев-Зап', 'NW', 'С-З'], // 7
      ];

function getWindDescription(angle, lang) {
    const normalizedAngle = parseFloat(angle) % 360;
    const index = Math.floor((normalizedAngle + 22.5) / 45) % 8;
    return windDirectionStr[index][lang];
} 

/********  класс Провайдер погоды  ********/
/******				v1.4			*******/
/******		2025 © leXxiR [4pda]	*******/

	class WeatherProvider {
	  constructor(props = {}) {
		this.props = {
			night_icons: [],											// индексы иконок для замены день-ночь
			index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,		// текущий индекс провайдера (сохраняется и считывается из памяти)
			show_toast: true,											// показывать всплывающее сообщение при переключении провайдера
			temp_widget: null,											// виджет TEXT для отображения температуры
			temp_max_widget: null,										// виджет TEXT для отображения максимальной температуры
			temp_min_widget: null,										// виджет TEXT для отображения минимальной температуры
			temp_feels_widget: null,									// виджет TEXT для отображения ощущаемой температуры
chance_Of_Rain: null,									// виджет TEXT для отображения осадков            
			description_widget: null,									// виджет TEXT для отображения текстового описания текущей погоды
			cityName_widget: null,										// виджет TEXT для отображения названия города
			windDirection_widget: null,										// виджет TEXT для отображения направления ветра
			windSpeed_widget: null,										// виджет TEXT для отображения скорости ветра
			icon_widget: null,											// виджет IMG для отображения значка погоды
			time_sensor: null,											// сенсор времени, если не задан, то создается новый
			weather_sensor: null,										// сенсор погоды, если не задан, то создается новый
			file_name: 'weather.json',									// имя файла с погодными данными
			auto_update: true,											// автоматическое обновление погоды (нет необходимости добавлять weatherProvider.update() в event.MINUTEEND и WIDGET_DELEGATE)
			lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
			...props,
		};

		this.providers = [
						{name: ['Zepp', 'Zepp'], appId: null},							// 0
						{name: ['Погодный сервис', 'Weather service'], appId: 1065824},	// 1
						{name: ['RuWeather', 'RWeather'], appId: 1066654},				// 2
					]

		this.description = [
				['Облачно', 'Временами дождь', 'Временами снег', 'Ясно', 'Пасмурно', 'Слабый дождь', 'Слабый снег', 'Умеренный дождь', 'Умеренный снег', 'Сильный снегопад', 'Сильный дождь', 'Песчаная буря', 'Мокрый снег', 'Туман', 'Дымка', 'Дождь с грозой', 'Метель', 'Пыльно', 'Ливень', 'Дождь с градом', 'Сильный дождь с градом', 'Сильный дождь', 'Пыльная буря', 'Сильная песчаная буря', 'Сильный дождь', 'Обновите погоду', 'Облачно ночью', 'Дождливо ночью', 'Ясно ночью'],
				['Cloudy', 'Showers', 'Snow Showers', 'Sunny', 'Overcast', 'Light Rain', 'Light Snow', 'Moderate Rain', 'Moderate Snow', 'Heavy Snow', 'Heavy Rain', 'Sandstorm', 'Rain and Snow', 'Fog', 'Hazy', 'T-Storms', 'Snowstorm', 'Floating dust', 'Very Heavy Rainstorm', 'Rain and Hail', 'T-Storms and Hail', 'Heavy Rainstorm', 'Dust', 'Heavy sand storm', 'Rainstorm', 'Unknown', 'Cloudy Nighttime', 'Showers Nighttime', 'Sunny Nighttime'],
			]

		this.last = {
			weatherIcon: 25,
			weatherDescription:  'Нет данных',
			temperature: '--',
			temperatureFeels: '--',
			chanceOfRain: '--',
			temperatureMax: '--',
			temperatureMin: '--',
			cityName: '--',
            windDirection: 0,
        windSpeed: '--',
            modTime: null,
		}

		if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
		if (!this.props.weather_sensor) this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
		if (isFinite(props.index)) hmFS.SysProSetInt('WeatherProviderIndex', props.index);
		if (this.props.auto_update) this.createHandlers();
	  }

	// создание обработчиков автоматического обновления погоды
		createHandlers() {
			this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

			this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
			  resume_call: ( () => this.update() )
			})
		}

	// служебные функции
		arrayBufferToCyrillic(buffer) {
		  let result = '';
		  const bytes = new Uint8Array(buffer);

		  let i = 0;
		  while (i < bytes.length) {
			let byte1 = bytes[i++];
			
			if (byte1 < 0x80) {								// Обработка 1-байтовых символов (ASCII)
			  result += String.fromCharCode(byte1);
			} else if (byte1 >= 0xC0 && byte1 < 0xE0) {		// Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
			  let byte2 = bytes[i++];
			  let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
			  result += String.fromCharCode(charCode);
			} else if (byte1 >= 0xE0 && byte1 < 0xF0) {		// Обработка 3-байтовых символов (например, для UTF-8)
			  let byte2 = bytes[i++];
			  let byte3 = bytes[i++];
			  let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
			  result += String.fromCharCode(charCode);
			}
		  }

		  return result
		}

	// чтение погодных данных из файла
		readFile(app_id) {
		  if (!app_id) return null				
		  let str_result = "";
		  try {
			const [fs_stat, err] = hmFS.stat(this.props.file_name, {
			  appid: app_id,
			});
			if (err == 0) {
			  const fh = hmFS.open(this.props.file_name, hmFS.O_RDONLY, {
				appid: app_id,
			  });

			  const len = fs_stat.size;
			  let array_buffer = new ArrayBuffer(len);
			  hmFS.read(fh, array_buffer, 0, len);
			  hmFS.close(fh);
			  str_result = this.arrayBufferToCyrillic(array_buffer);

			  return str_result;
			} else {
			  console.log("err:", err);
			}
		  } catch (error) {
			console.log("error:", error);
			console.log("FAIL: No access to hmFS.");
		  }
		  return null;
		}

	// получить время последнего изменеия файла
		getFileModTime(app_id) {
		  if (!app_id) return null
		  try {
			const [fs_stat, err] = hmFS.stat(this.props.file_name, {
			  appid: app_id,
			});
			
			if (err == 0) {
			  return fs_stat.mtime
			} else {
			  console.log("ModTime err:", err);
			}
		  } catch (error) {
			console.log("ModTime error:", error);
			console.log("FAIL: No access to hmFS.");
		  }
			return null
		}

	// проверка времени суток: возвращает true, если сейчас день
		isDayNow() {
			const sunData = this.props.weather_sensor.getForecastWeather().tideData;
			let sunriseMins = 8 * 60;			// время восхода
			let sunsetMins = 20 * 60;			// и заката по умолчанию

			if (sunData.count > 0){
				const today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			}

			const curMins = curTime.hour * 60 + curTime.minute;
			const nowIsDay = (curMins >= sunriseMins) && (curMins < sunsetMins);

			return nowIsDay
		}


	// сопоставление индекса иконки погоды из приложений WeatherService и RuWeather с иконками погоды от Zepp 
		getZeppIconIndex(index, app_id = null) {
			
			if (!app_id)  return index;			//	если нет app_id, то не меняем индекс иконки

			let newIndex = 25;
			
			if (app_id == 1065824) {					// WeatherService
				switch(index) {
				   case 1:
						newIndex = 3;
					break;
				   case 2:
						newIndex = 0;
					break;
				   case 3:
				   case 4:
						newIndex = 4;
					break;
				   case 5:
						newIndex = 1;
					break;
				   case 6:
						newIndex = 5;
					break;
				   case 7:
						newIndex = 10;
					break;
				   case 8:
						newIndex = 15;
					break;
				   case 9:
						newIndex = 6;
					break;
				   case 10:
						newIndex = 8;
					break;
				   case 11:
						newIndex = 9;
					break;
				   case 12:
						newIndex = 12;
					break;
				   case 13:
						newIndex = 13;
					break;
				   case 14:
						newIndex = 17;
					break;
				   default:
						newIndex = 25;
					break;
				}
			} else if (app_id == 1066654) {					// RuWeather
				newIndex = index - 1;
			}

			return newIndex
		}

	// температура со знаком
		tempWithSign(val){
			val = parseFloat(val);
			if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
			val = Math.round(val);
			if (val > 0) val = '+' + val;
			val += '°';
			
			return val
		}
        
		tempWithSign0(val){
			val = parseFloat(val);
			if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
			val = Math.round(val);
			if (val > 0) val = '' + val;
			val += '';
			
			return val
		}
        
        
		
		rainWithSign(val){
			val = parseFloat(val);
			if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
//			val = Math.round(val);
//			if (val > 0) val = '+' + val;
			val += '';
			
			return val
		}
		

	//получение погодных данных из Zepp
		getZeppWeatherData() {
			const iconIndex = this.props.weather_sensor.curAirIconIndex ?? 25;
			const data = {
				weatherIcon: iconIndex,
				weatherDescription:  this.description[this.props.lang][iconIndex],
				temperature: this.props.weather_sensor.current ?? '--',
				temperatureFeels: '--',
				chanceOfRain: '--',
                windDirection: 0,
                windSpeed: '--',
				temperatureMax: this.props.weather_sensor.high ?? '--',
				temperatureMin: this.props.weather_sensor.low ?? '--',
				cityName: this.props.weather_sensor.getForecastWeather().cityName ?? '--',
			}

			return data
		}

	//получение погодных данных из файла приложения
		getAppWeatherData(app_id) {
			const data = {
				weatherIcon: 25,
				weatherDescription:  'Нет данных',
				temperature: '--',
				temperatureFeels: '--',
				chanceOfRain: '--',
                windDirection: 0,
                windSpeed: '--',
				temperatureMax: '--',
				temperatureMin: '--',
				cityName: '--',
			}

			// читаем данные из файла данных приложения
			let weather_str = this.readFile(app_id);
			let weatherJson = JSON.parse(weather_str);
	  
			if (weatherJson) {
				if (isFinite(weatherJson.weatherIcon)) {		// считываем индекс иконки погоды и сразу переводим в нумерацию Zepp
				  data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon), app_id);
				}

				if (weatherJson?.weatherDescriptionExtended?.length) {
				  data.weatherDescription = weatherJson.weatherDescriptionExtended;
				  data.weatherDescription = data.weatherDescription.replace(data.weatherDescription[0], data.weatherDescription[0].toUpperCase());

				} else data.weatherDescription = this.description[data.weatherIcon];

				if (isFinite(weatherJson.temperature)) {
				  data.temperature = parseFloat(weatherJson.temperature);
				  data.temperature = Math.round(data.temperature);
				}
				
				if (isFinite(weatherJson.temperatureFeels)){
					data.temperatureFeels = parseFloat(weatherJson.temperatureFeels);
					data.temperatureFeels = Math.round(data.temperatureFeels);
				}
					
				if (isFinite(weatherJson.chanceOfRain)){
					data.chanceOfRain = parseFloat(weatherJson.chanceOfRain);
					data.chanceOfRain = Math.round(data.chanceOfRain);
				}
					
				  
				if (isFinite(weatherJson.temperatureMax)){
					data.temperatureMax = parseFloat(weatherJson.temperatureMax);
					data.temperatureMax = Math.round(data.temperatureMax);
				}
				  
				if (isFinite(weatherJson.temperatureMin)){
					data.temperatureMin = parseFloat(weatherJson.temperatureMin);
					data.temperatureMin = Math.round(data.temperatureMin);
				}
                
				if (isFinite(weatherJson.windDirection)){
					data.windDirection = parseFloat(weatherJson.windDirection);
					//data.windDirection = Math.round(data.windDirection);
				}
                
        if (isFinite(weatherJson.windSpeed)) {
         data.windSpeed = parseFloat(weatherJson.windSpeed);
         data.windSpeed > 10 ? data.windSpeed = Math.round(data.windSpeed) : data.windSpeed = data.windSpeed.toFixed(1);
        }
                
                
				
				if (weatherJson.city) {
				  data.cityName = weatherJson.city;
				}
			}
			
			return data
		}

	//получение погодных данных из файла приложения или Zepp
		getWeatherData(app_id = null) {
			if (!app_id) return this.getZeppWeatherData()		// если нет app_id, то получаем данные от Zepp
			else return this.getAppWeatherData(app_id);			// иначе читаем данные из файла данных приложения
		}

	// обновить виджеты, используя данные текущего провайдера
		update() {
			let curIcon = parseInt(this.last.weatherIcon);				// текущий индекс значка погоды без учета времени суток (т.е. число без "n")

			const modTime = this.getFileModTime(this.providers[this.props.index].appId);		// время изменеия файла с данными
			
			if (!modTime || this.last.modTime != modTime){										// если не получено время изменеия или оно отличается от последнего времени изменеия
				const newData = this.getWeatherData(this.providers[this.props.index].appId);	// тогда читаем новые данные из файла
				this.last.modTime = modTime;

				let val = this.tempWithSign0(newData.temperature);
				if (val != this.last.temperature){
					this.last.temperature = val;
					if (this.props.temp_widget) this.props.temp_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.tempWithSign0(newData.temperatureMax);
				if (val != this.last.temperatureMax){
					this.last.temperatureMax = val;
					if (this.props.temp_max_widget) this.props.temp_max_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.tempWithSign0(newData.temperatureMin);
				if (val != this.last.temperatureMin){
					this.last.temperatureMin = val;
					if (this.props.temp_min_widget) this.props.temp_min_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = this.tempWithSign(newData.temperatureFeels);
				if (val != this.last.temperatureFeels){
					this.last.temperatureFeels = val;
					if (this.props.temp_feels_widget) this.props.temp_feels_widget.setProperty(hmUI.prop.TEXT, val);
				}
					
					val = this.rainWithSign(newData.chanceOfRain);
					if (val != this.last.chanceOfRain){
						this.last.chanceOfRain = val;
						if (this.props.chance_Of_Rain) this.props.chance_Of_Rain.setProperty(hmUI.prop.TEXT, val);
					}	
                    
				val = newData.windDirection;
				if (val != this.last.windDirection){
					this.last.windDirection = val;
					if (this.props.windDirection_widget) this.props.windDirection_widget.setProperty(hmUI.prop.TEXT, val);
				}
                
                
				val = newData.windSpeed;
				if (val != this.last.windSpeed){
					this.last.windSpeed = val;
					if (this.props.windSpeed_widget) this.props.windSpeed_widget.setProperty(hmUI.prop.TEXT, val);
				}
                

				val = newData.cityName;
				if (val != this.last.cityName){
					this.last.cityName = val;
					if (this.props.cityName_widget) this.props.cityName_widget.setProperty(hmUI.prop.TEXT, val);
				}

				val = newData.weatherDescription;
				if (val != this.last.weatherDescription){
					this.last.weatherDescription = val;
					if (this.props.description_widget) this.props.description_widget.setProperty(hmUI.prop.TEXT, val);
				}

				
				curIcon = newData.weatherIcon;						// получаем текущий индекс значка погоды
			}

			if (this.props.night_icons.includes(curIcon) && !this.isDayNow()){		// если он в списке ночных иконок и сейчас "ночь", то добавляем суффикс 'n'
				curIcon += 'n';
			}

			if (curIcon != this.last.weatherIcon){
				this.last.weatherIcon = curIcon;
				if (this.props.icon_widget) this.props.icon_widget.setProperty(hmUI.prop.SRC, 'w_${curIcon}.png');
			}
		}

	// переключить на следующего провайдера
		next(show_toast = this.props.show_toast) {
			const v = (this.props.index + 1) % this.providers.length;
			this.provider = v;
			if (show_toast) hmUI.showToast({text: this.name});
		}

	// переключить на предыдующего провайдера
		prev(show_toast = this.props.show_toast) {
			const v = (this.props.index - 1 + this.providers.length) % this.providers.length;
			this.provider = v;
			if (show_toast) hmUI.showToast({text: this.name});
		}

	// переключить назад или вперед
		toggle(dir, show_toast = this.props.show_toast) {
			if (dir > 0) this.next(show_toast)
			else this.prev(show_toast);
		}
		
	// установить провайдера по индексу
		set provider(v) {
			this.props.index = v;
			hmFS.SysProSetInt('WeatherProviderIndex', v);
			this.update();
		}

	// получить индекс текущего провайдера
		get index() {
			return this.props.index
		}

	// получить название текущего провайдера
		get name() {
			return this.providers[this.props.index].name[this.props.lang]
		}
        
	// получить название города
		get cityName() {
			return this.last.cityName
		}

	// получить напрвление ветра
		get windDirection() {
			return this.last.windDirection
		}
        
	// получить скорость ветра
		get windSpeed() {
			return this.last.windSpeed
		}

	// получить текущую температуру
		get temperature() {
			return this.last.temperature
		}

	// получить максимальную температуру
		get temperatureMax() {
			return this.last.temperatureMax
		}

	// получить минимальную температуру
		get temperatureMin() {
			return this.last.temperatureMin
		}

	// получить ощущаемую температуру
		get temperatureFeels() {
			return this.last.temperatureFeels
		}
			
		get chanceOfRain() {
			return this.last.chanceOfRain
		}
			

	// получить описание погоды
		get weatherDescription() {
			return this.last.weatherDescription
		}

	// удалить
	  delete() {
		this.providers = null;
		this.props = null;
		this.last = null;
		this.description = null;
		if (this.widgetDelegate) {
			hmUI.deleteWidget(this.widgetDelegate);
			this.widgetDelegate = null;
		}
	  }

	}	


// Глобальные константы
const SUNRISE_DEFAULT = 360;    // 6:00
const SUNSET_DEFAULT = 1080;     // 18:00
const MOONRISE_DEFAULT = 1080;  // 18:00
const MOONSET_DEFAULT = 360;    // 6:00

let isDayIcons = true;
let shotWeaterhNames = [];

function getSunTimes(weatherData) {
  const tide = weatherData.tideData.data[0];
  
  // Коррекция и нормализация времени
  const normalize = (hour, minute) => {
    let total = hour * 60 + minute;
    total = total % 1440; // Нормализация в пределах суток
    if (total < 0) total += 1440;
    return total;
  };
  // Вычисление значений
  const sunsetMins = normalize(tide.sunset.hour, tide.sunset.minute);
  const sunriseMins = normalize(tide.sunrise.hour, tide.sunrise.minute);
  const moonsetMins = normalize(tide.moonset.hour, tide.moonset.minute);
  const moonriseMins = normalize(tide.moonrise.hour, tide.moonrise.minute);

  return {
    sunsetMins,
    sunriseMins,
    moonsetMins,
    moonriseMins
  };
}

		
function autoToggleWeatherIcons() {
//const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
  const weatherData = weatherSensor.getForecastWeather();
  const {
    sunsetMins,
    sunriseMins,
    moonsetMins,
    moonriseMins
  } = getSunTimes(weatherData);
	
  const curMins = timeSensor.hour * 60 + timeSensor.minute;

  // Определение видимости солнца
  const isDayNow = (sunsetMins > sunriseMins) 
    ? (curMins >= sunriseMins && curMins < sunsetMins)
    : (curMins >= sunriseMins || curMins < sunsetMins);
	
  // Обновление флагов
  isDayIcons = isDayNow;
	

  let current = weatherSensor.current;
  let curAirIconIndex = weatherSensor.curAirIconIndex;

  let temperature_current_temp = -100;
  if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
   temperature_current_temp = weatherSensor.current;
  }; // end currentWeather; 
	
	shotWeaterhNames = isDayIcons ? ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"]:["Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью", "Пасмурно ночью", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"]	
	
  normal_temperature_current_text_font.setProperty(hmUI.prop.TEXT, temperature_current_temp + "° " + shotWeaterhNames[curAirIconIndex]);
  idle_temperature_current_text_font.setProperty(hmUI.prop.TEXT, temperature_current_temp + "° " + shotWeaterhNames[curAirIconIndex]);
	
	

  }

let sleep_time_txt = ''
let sleep_start_time_txt = ''
let sleep_end_time_txt = ''
let sleep_score_txt = ''
let wake_time_txt

const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
let sleepInfo = sleep.getBasicInfo();

let sleepTotalTime = sleep.getTotalTime();
let sleepStartTime = sleepInfo.startTime;
let sleepEndTime = sleepInfo.endTime + 1;
let sleepScore = sleepInfo.score;

//-----------  время пробуждений ------------------		
let sleepStageArray = sleep.getSleepStageData();
const modelData = sleep.getSleepStageModel();
//-------------------------------------------------	

 function updateSleep() {
  //-----------  сон------------------
  sleepTotalTime = sleep.getTotalTime();
  sleepInfo = sleep.getBasicInfo();
  sleepStartTime = sleepInfo.startTime;
  if (sleepStartTime >= 24 * 60) {
   sleepStartTime -= 24 * 60
  }

  sleepEndTime = sleepInfo.endTime + 1;
  if (sleepEndTime >= 24 * 60) {
   sleepEndTime -= 24 * 60
  }

  //-----------  время пробуждений ------------------
  let wakeTime = 0;
  sleepStageArray = sleep.getSleepStageData();

  for (let i = 0; i < sleepStageArray.length; i++) {
   let data = sleepStageArray[i];
   if (data.model == modelData.WAKE_STAGE) {
    wakeTime += data.stop + 1 - data.start;
   }

  }

  sleepTotalTime -= wakeTime;
  //-------------------------------------------------

  //-------------------------------------------------
	 
normal_heart_rate_text_font.setProperty(hmUI.prop.TEXT, heart_rate.last + " ЧСС / " + calorie.current + " ККАЛ / " +  Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0") + " СОН");	
idle_heart_rate_text_font.setProperty(hmUI.prop.TEXT, heart_rate.last + " ЧСС / " + calorie.current + " ККАЛ / " +  Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0") + " СОН");	
	 
 }


function read_pressure() {
 console.log("read_pressure()");
 const file_name_alt = "../../../baro_altim/pressure.dat";
 const [fs_stat, err] = hmFS.stat(file_name_alt);
 if (err == 0) {
  let file_size = fs_stat.size;
  const len = file_size / 4;
  console.log(`size_alt: ${file_size}, lenght: ${len}`)
  const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

  let array_buffer = new Float32Array(len);
  hmFS.read(fh, array_buffer.buffer, 0, file_size);
  hmFS.close(fh);
  console.log(`value ${array_buffer[array_buffer.length -1]}`);
  return array_buffer;
 } else {
  console.log('err:', err)
 }
 return null;
}

function getPressureValue(pressure_array) {
 console.log("getPressureValue()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
 }
 return 0;
}

function changesPressure(pressure_array) {
 console.log("changesPressure()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 let value = pressure_array[start_index];
 let result = 0;
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  let element = pressure_array[index];
  if (element != 0) {
   if (Math.abs(value - element) > 10) { // учитываем только если разниза больше 0,1 hPa
    value = value - element;
    console.log(`element = ${element}`);
    console.log(`pressere_changes = ${value}`);
    return value;
   }
  }
 }
 return result;
}

function hPa_To_mmHg(hPa_value = 0) {
 let mmHg = Math.round(hPa_value * 0.750064);
 return mmHg;
}
//#endregion

let text_pressere; // отображаем давление
let text_pressere_changes; // отображаем изменение давления 


 function updatePressere() {
  let pressure_array = read_pressure();
  let value = getPressureValue(pressure_array);
  value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.


  let pressere_changes_str = "=";
  //let color_pressere = 0x00ff00;
  let color_pressere_0 = value < 760 ? 0xffff00 : value > 760 ? 0xff0000 : 0x00ff00;

  let pressere_changes = changesPressure(pressure_array);
  if (pressere_changes < 0) {
   pressere_changes_str = "↓"; /*color_pressere = 0xffff00;*/
  }
  if (pressere_changes > 0) {
   pressere_changes_str = "↑"; /*color_pressere = 0xff0000;*/
  }
  //text_pressere_changes.setProperty(hmUI.prop.TEXT, pressere_changes_str);

  let value_str = value == 0 ? "--" : value + pressere_changes_str;
  normal_altimeter_current_text_font.setProperty(hmUI.prop.TEXT, value_str);
  normal_altimeter_current_text_font.setProperty(hmUI.prop.COLOR, color_pressere_0);
  idle_altimeter_current_text_font.setProperty(hmUI.prop.TEXT, value_str);
  idle_altimeter_current_text_font.setProperty(hmUI.prop.COLOR, color_pressere_0);
 
 }

           function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str + "  " + normal_dayStr  + "  " + normal_Month_Str);
                idle_day_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str + "  " + normal_dayStr  + "  " + normal_Month_Str);
              };

              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr.padStart(2, '0');
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0')
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

            };


        // end user_functions.js

        let normal_background_bg = ''
        let normal_battery_text_text_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_hrv_icon_img = ''
        let normal_hrv_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_city_name_text = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_high_text_font = ''
        let normal_stand_current_text_font = ''
        let normal_humidity_current_text_font = ''
        let normal_floor_current_text_font = ''
        let normal_uvi_current_text_font = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_alarm_clock_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_low_text_font = ''
        let normal_sun_high_text_font = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg = ''
        let idle_battery_text_text_img = ''
        let idle_fat_burning_icon_img = ''
        let idle_hrv_icon_img = ''
        let idle_hrv_current_text_font = ''
        let idle_step_current_text_font = ''
        let idle_city_name_text = ''
        let idle_temperature_low_text_font = ''
        let idle_temperature_high_text_font = ''
        let idle_stand_current_text_font = ''
        let idle_humidity_current_text_font = ''
        let idle_floor_current_text_font = ''
        let idle_uvi_current_text_font = ''
        let idle_alarm_clock_current_text_font = ''
        let idle_alarm_clock_text_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_sun_low_text_font = ''
        let idle_sun_high_text_font = ''
        let idle_system_disconnect_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_Switch_BG_Color = ''

        let bgColorIndex = 0;
        let bgColorList = [0xFF80FF00, 0xFFFF8C00, 0xFF00FFFF, 0xFFFFFFFF, 0xFFFF0000, 0xFFFFFF00, 0xFF0080FF, 0xFF00FF80, 0xFFFF80FF];
        let bgColorToastList = ['Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Bebas11.ttf; FontSize: 33
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 330,
              h: 48,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Bebas11.ttf; FontSize: 56
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 554,
              h: 80,
              text_size: 56,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Bebas11.ttf; FontSize: 32; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 38,
              h: 38,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Bebas11.ttf; FontSize: 31
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 309,
              h: 44,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js


            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 428,
              h: 45,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
    text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 428,
              h: 45,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
    text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/↓↑",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 409,
              h: 58,
              text_size: 41,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Bebas11.ttf; FontSize: 137
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 1271,
              h: 196,
              text_size: 137,
              char_space: -3,
              line_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Bebas11.ttf; FontSize: 51; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 61,
              h: 61,
              text_size: 51,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // end user_script_start.js

            //#region SwitchBG_Color
            console.log('SwitchBG_Color');
            function switchBG_Color() {
              bgColorIndex++;
              if (bgColorIndex >= bgColorList.length) bgColorIndex = 0;
              hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
              let toastText = bgColorToastList[bgColorIndex].replace('%s', `${bgColorIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
              vibro(28);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF80FF00',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 359,
              font_array: ["bat_0.png","bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'bat_14.png',
              unit_tc: 'bat_14.png',
              unit_en: 'bat_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 339,
              y: 378,
              src: 'ic_HRV.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 289,
              y: 342,
              w: 126,
              h: 40,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 112,
              y: 339,
              w: 126,
              h: 70,
              text_size: 56,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 112,
              y: 153,
              w: 166,
              h: 40,
              text_size: 32,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -17,
              y: 58,
              w: 126,
              h: 40,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 285,
              y: 58,
              w: 126,
              h: 40,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 222,
              y: 218,
              w: 126,
              h: 40,
              text_size: 32,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 43,
              y: 257,
              w: 126,
              h: 40,
              text_size: 32,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 43,
              y: 223,
              w: 126,
              h: 40,
              text_size: 32,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.FLOOR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 43,
              y: 191,
              w: 126,
              h: 40,
              text_size: 32,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -87,
              y: 16,
              w: 390,
              h: 40,
              text_size: 31,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 19,
              font_array: ["AL_0.png","AL_1.png","AL_2.png","AL_3.png","AL_4.png","AL_5.png","AL_6.png","AL_7.png","AL_8.png","AL_9.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'AL_v.png',
              dot_image: 'AL_d2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 23,
              y: 352,
              image_array: ["moon_0.png","moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 201,
              y: 153,
              w: 142,
              h: 40,
              text_size: 32,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 47,
              y: 153,
              w: 142,
              h: 40,
              text_size: 32,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 52,
              y: 19,
              src: 'NoBT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF80FF00',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 359,
              font_array: ["bat_0.png","bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'bat_14.png',
              unit_tc: 'bat_14.png',
              unit_en: 'bat_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_hrv_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 339,
              y: 378,
              src: 'ic_HRV.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_hrv_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 289,
              y: 342,
              w: 126,
              h: 40,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 112,
              y: 339,
              w: 126,
              h: 70,
              text_size: 56,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 112,
              y: 153,
              w: 166,
              h: 40,
              text_size: 32,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -17,
              y: 58,
              w: 126,
              h: 40,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 285,
              y: 58,
              w: 126,
              h: 40,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 222,
              y: 218,
              w: 126,
              h: 40,
              text_size: 32,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 43,
              y: 257,
              w: 126,
              h: 40,
              text_size: 32,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_floor_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 43,
              y: 223,
              w: 126,
              h: 40,
              text_size: 32,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.FLOOR,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 43,
              y: 191,
              w: 126,
              h: 40,
              text_size: 32,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -87,
              y: 16,
              w: 390,
              h: 40,
              text_size: 31,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 19,
              font_array: ["AL_0.png","AL_1.png","AL_2.png","AL_3.png","AL_4.png","AL_5.png","AL_6.png","AL_7.png","AL_8.png","AL_9.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'AL_v.png',
              dot_image: 'AL_d2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 23,
              y: 352,
              image_array: ["moon_0.png","moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 201,
              y: 153,
              w: 142,
              h: 40,
              text_size: 32,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 47,
              y: 153,
              w: 142,
              h: 40,
              text_size: 32,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 52,
              y: 19,
              src: 'NoBT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

            normal_altitude_target_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 132,
              y: 16,
              w: 200,
              h: 40,
              text_size: 31,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
             // type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 398,
              w: 390,
              h: 40,
              text_size: 31,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF00FFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              //unit_type: 1,
              //type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 222,
              y: 188,
              w: 126,
              h: 40,
              text_size: 32,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
             // type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 289,
              y: 352,
              w: 126,
              h: 40,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
             // type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 10,
              y: 110,
              w: 370,
              h: 40,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              //unit_type: 1,
              //type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 301,
              w: 390,
              h: 40,
              text_size: 37,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              //unit_type: 1,
              //type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 16,
              w: 390,
              h: 40,
              text_size: 31,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
             // type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            idle_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 16,
              w: 390,
              h: 40,
              text_size: 31,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              //type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 301,
              w: 390,
              h: 40,
              text_size: 37,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
//              unit_type: 1,
//              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 222,
              y: 188,
              w: 126,
              h: 40,
              text_size: 32,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
             // type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            idle_altitude_target_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 132,
              y: 16,
              w: 200,
              h: 40,
              text_size: 31,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              //type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 398,
              w: 390,
              h: 40,
              text_size: 31,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF00FFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
             // unit_type: 1,
              //type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 289,
              y: 352,
              w: 126,
              h: 40,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 10,
              y: 110,
              w: 370,
              h: 40,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
             // unit_type: 1,
              //type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 285,
              y: 249,
              w: 126,
              h: 50,
              text_size: 41,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
               padding: true,
              type: hmUI.data_type.SECOND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            idle_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 285,
              y: 249,
              w: 126,
              h: 50,
              text: '88',
			  text_size: 41,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
//               padding: true,
//              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 47,
              w: 390,
              h: 70,
              text_size: 51,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 47,
              w: 390,
              h: 70,
              text_size: 51,
              char_space: 0,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 31,
              y: 174,
              w: 335,
              h: 150,
              text_size: 137,
              char_space: -3,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 31,
              y: 174,
              w: 335,
              h: 150,
              text_size: 137,
              char_space: -3,
              font: 'fonts/Bebas11.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });


      const weatherProvider = new WeatherProvider({
       index: 1, // текущий индекс провайдера (сохраняется и считывается из памяти)
      });  


            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 25,
              y: 187,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 263,
              y: 187,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 71,
              y: 51,
              w: 246,
              h: 51,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                launchAppOrAppId('ScheduleCalScreen', 1057409);
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 71,
              y: 103,
              w: 246,
              h: 51,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                launchAppOrAppId('WeatherScreen', 1051195);
vibro(28);

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBG_Color');
            // Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.SwitchBG_Color, {
              // x: 147,
              // y: 187,
              // w: 100,
              // h: 100,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'AL_0.png',
              // normal_src: 'AL_0.png',
              // color_list: 0xFF80FF00|0xFFFF8C00|0xFF00FFFF|0xFFFFFFFF|0xFFFF0000|0xFFFFFF00|0xFF0080FF|0xFF00FF80|0xFFFF80FF,
              // toast_list: Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s,
              // use_crown: False,
              // use_in_AOD: True,
              // vibro: True,
            // });

            Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 147,
              y: 187,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                switchBG_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_cityNameStr = normal_cityNameStr.toUpperCase();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

              console.log('Weather city name');
              let idle_cityNameStr = weatherData.cityName;
              idle_cityNameStr = idle_cityNameStr.toUpperCase();
              idle_city_name_text.setProperty(hmUI.prop.TEXT, idle_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();

                //SwitchBgColor
                if (hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`) === undefined) {
                  bgColorIndex = 0;
                  hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
                } else {
                  bgColorIndex = hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg) normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
                if (screenType == hmSetting.screen_type.AOD && idle_background_bg) idle_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
                console.log('resume_call.js');
                // start resume_call.js

                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType



app_update();
autoToggleWeatherIcons();
updateSleep();
updatePressere();

let Direction = weatherProvider.windDirection
let distanceCurrent = distance.current;
normal_distance_current_text_font.setProperty(hmUI.prop.TEXT, (distanceCurrent / 1000).toFixed(2) + " КМ / " + getWindDescription(Direction, 2) + " " + weatherProvider.windSpeed + ' м/с');
idle_distance_current_text_font.setProperty(hmUI.prop.TEXT, (distanceCurrent / 1000).toFixed(2) + " КМ / " + getWindDescription(Direction, 2) + " " + weatherProvider.windSpeed + ' м/с');

normal_stress_current_text_font.setProperty(hmUI.prop.TEXT, weatherProvider.chanceOfRain);
idle_stress_current_text_font.setProperty(hmUI.prop.TEXT, weatherProvider.chanceOfRain);

//let Direction = weatherProvider.windDirection
//normal_fat_burning_current_text_font.setProperty(hmUI.prop.TEXT, getWindDescription(Direction, 2));
//idle_fat_burning_current_text_font.setProperty(hmUI.prop.TEXT, getWindDescription(Direction, 2));


                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');

                console.log('pause_call.js');
                // start pause_call.js

                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}