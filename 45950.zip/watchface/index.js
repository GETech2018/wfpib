﻿    /*
    ** Watch_Face_Editor tool v 18.3
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_stand_current_text_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_bio_charge_text_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_linear_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_min_text_font = ''
        let normal_heart_rate_max_text_font = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let idle_background_bg_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_stand_current_text_img = ''
        let idle_fat_burning_current_text_img = ''
        let idle_bio_charge_text_text_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_step_current_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_battery_linear_scale = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_heart_rate_min_text_font = ''
        let idle_heart_rate_max_text_font = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let normal_cal_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 271,
              y: 11,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 459,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 459,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 440,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'Error_24.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 52,
              y: 374,
              src: 'System_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 19,
              y: 374,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 78,
              y: 374,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 411,
              y: 112,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 394,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_KM.png',
              unit_tc: 'Act_KM.png',
              unit_en: 'Act_KM.png',
              imperial_unit_sc: 'Act_MI.png',
              imperial_unit_tc: 'Act_MI.png',
              imperial_unit_en: 'Act_MI.png',
              dot_image: 'Act_Dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 119,
              y: 360,
              image_array: ["Steps_image_1.png","Steps_image_2.png","Steps_image_3.png","Steps_image_4.png","Steps_image_5.png","Steps_image_6.png","Steps_image_7.png","Steps_image_8.png"],
              image_length: 8,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 301,
              y: 331,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 333,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_Symbo_02.png',
              unit_tc: 'Weather_Symbo_02.png',
              unit_en: 'Weather_Symbo_02.png',
              negative_image: 'Weather_Symbo_01.png',
              invalid_image: 'Weather_Symbo_03.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 67,
              y: 289,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 382,
              // start_y: 172,
              // color: 0xFF00B4FF,
              // lenght: -131,
              // line_width: 8,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 256,
              y: 172,
              src: 'Top_battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 188,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 264,
              y: 267,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 140,
              y: 324,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 159,
              y: 280,
              w: 38,
              h: 24,
              text_size: 20,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
              // type: hmUI.data_type.HEART_MIN,
            });

            normal_heart_rate_max_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 159,
              y: 243,
              w: 38,
              h: 24,
              text_size: 20,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
              // type: hmUI.data_type.HEART_MAX,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 35,
              y: 188,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 46,
              y: 174,
              image_array: ["Cal_image_1.png","Cal_image_2.png","Cal_image_3.png","Cal_image_4.png","Cal_image_5.png","Cal_image_6.png","Cal_image_7.png"],
              image_length: 7,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 160,
              day_startY: 17,
              day_sc_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              day_tc_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              day_en_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 86,
              y: 17,
              week_en: ["WeekDay_01.png","WeekDay_02.png","WeekDay_03.png","WeekDay_04.png","WeekDay_05.png","WeekDay_06.png","WeekDay_07.png"],
              week_tc: ["WeekDay_01.png","WeekDay_02.png","WeekDay_03.png","WeekDay_04.png","WeekDay_05.png","WeekDay_06.png","WeekDay_07.png"],
              week_sc: ["WeekDay_01.png","WeekDay_02.png","WeekDay_03.png","WeekDay_04.png","WeekDay_05.png","WeekDay_06.png","WeekDay_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: -8,
              month_startY: 81,
              month_sc_array: ["Month_image_01.png","Month_image_02.png","Month_image_03.png","Month_image_04.png","Month_image_05.png","Month_image_06.png","Month_image_07.png","Month_image_08.png","Month_image_09.png","Month_image_10.png","Month_image_11.png","Month_image_12.png"],
              month_tc_array: ["Month_image_01.png","Month_image_02.png","Month_image_03.png","Month_image_04.png","Month_image_05.png","Month_image_06.png","Month_image_07.png","Month_image_08.png","Month_image_09.png","Month_image_10.png","Month_image_11.png","Month_image_12.png"],
              month_en_array: ["Month_image_01.png","Month_image_02.png","Month_image_03.png","Month_image_04.png","Month_image_05.png","Month_image_06.png","Month_image_07.png","Month_image_08.png","Month_image_09.png","Month_image_10.png","Month_image_11.png","Month_image_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 375,
              second_startY: 124,
              second_array: ["Time_Sec_Font_0.png","Time_Sec_Font_1.png","Time_Sec_Font_2.png","Time_Sec_Font_3.png","Time_Sec_Font_4.png","Time_Sec_Font_5.png","Time_Sec_Font_6.png","Time_Sec_Font_7.png","Time_Sec_Font_8.png","Time_Sec_Font_9.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 233,
              minute_startY: 68,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 68,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 71,
              y: 107,
              src: 'Top_time.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 368,
              am_y: 82,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 368,
              pm_y: 82,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 271,
              y: 11,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 459,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 459,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 440,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'Error_24.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 52,
              y: 374,
              src: 'System_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 19,
              y: 374,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 78,
              y: 374,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 411,
              y: 112,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 394,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_KM.png',
              unit_tc: 'Act_KM.png',
              unit_en: 'Act_KM.png',
              imperial_unit_sc: 'Act_MI.png',
              imperial_unit_tc: 'Act_MI.png',
              imperial_unit_en: 'Act_MI.png',
              dot_image: 'Act_Dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 119,
              y: 360,
              image_array: ["Steps_image_1.png","Steps_image_2.png","Steps_image_3.png","Steps_image_4.png","Steps_image_5.png","Steps_image_6.png","Steps_image_7.png","Steps_image_8.png"],
              image_length: 8,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 301,
              y: 331,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 333,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_Symbo_02.png',
              unit_tc: 'Weather_Symbo_02.png',
              unit_en: 'Weather_Symbo_02.png',
              negative_image: 'Weather_Symbo_01.png',
              invalid_image: 'Weather_Symbo_03.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 67,
              y: 289,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 382,
              // start_y: 172,
              // color: 0xFF00B4FF,
              // lenght: -131,
              // line_width: 8,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 256,
              y: 172,
              src: 'Top_battery.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 188,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 264,
              y: 267,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 140,
              y: 324,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 159,
              y: 280,
              w: 38,
              h: 24,
              text_size: 20,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
              // type: hmUI.data_type.HEART_MIN,
            });

            idle_heart_rate_max_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 159,
              y: 243,
              w: 38,
              h: 24,
              text_size: 20,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
              // type: hmUI.data_type.HEART_MAX,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 35,
              y: 188,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 46,
              y: 174,
              image_array: ["Cal_image_1.png","Cal_image_2.png","Cal_image_3.png","Cal_image_4.png","Cal_image_5.png","Cal_image_6.png","Cal_image_7.png"],
              image_length: 7,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 160,
              day_startY: 17,
              day_sc_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              day_tc_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              day_en_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 86,
              y: 17,
              week_en: ["WeekDay_01.png","WeekDay_02.png","WeekDay_03.png","WeekDay_04.png","WeekDay_05.png","WeekDay_06.png","WeekDay_07.png"],
              week_tc: ["WeekDay_01.png","WeekDay_02.png","WeekDay_03.png","WeekDay_04.png","WeekDay_05.png","WeekDay_06.png","WeekDay_07.png"],
              week_sc: ["WeekDay_01.png","WeekDay_02.png","WeekDay_03.png","WeekDay_04.png","WeekDay_05.png","WeekDay_06.png","WeekDay_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: -8,
              month_startY: 81,
              month_sc_array: ["Month_image_01.png","Month_image_02.png","Month_image_03.png","Month_image_04.png","Month_image_05.png","Month_image_06.png","Month_image_07.png","Month_image_08.png","Month_image_09.png","Month_image_10.png","Month_image_11.png","Month_image_12.png"],
              month_tc_array: ["Month_image_01.png","Month_image_02.png","Month_image_03.png","Month_image_04.png","Month_image_05.png","Month_image_06.png","Month_image_07.png","Month_image_08.png","Month_image_09.png","Month_image_10.png","Month_image_11.png","Month_image_12.png"],
              month_en_array: ["Month_image_01.png","Month_image_02.png","Month_image_03.png","Month_image_04.png","Month_image_05.png","Month_image_06.png","Month_image_07.png","Month_image_08.png","Month_image_09.png","Month_image_10.png","Month_image_11.png","Month_image_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 233,
              minute_startY: 68,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 68,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 71,
              y: 107,
              src: 'Top_time.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 368,
              am_y: 82,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 368,
              pm_y: 82,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 163,
              w: 94,
              h: 98,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 256,
              y: 166,
              w: 167,
              h: 43,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 232,
              y: 8,
              w: 123,
              h: 39,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 312,
              y: 444,
              w: 103,
              h: 61,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 184,
              y: 443,
              w: 104,
              h: 63,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 108,
              y: 84,
              w: 72,
              h: 45,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 275,
              y: 73,
              w: 123,
              h: 74,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 410,
              y: 75,
              w: 37,
              h: 84,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 49,
              y: 288,
              w: 73,
              h: 78,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 204,
              w: 44,
              h: 57,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 262,
              y: 260,
              w: 61,
              h: 58,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 293,
              y: 331,
              w: 81,
              h: 51,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 6,
              y: 59,
              w: 55,
              h: 95,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 170,
              y: 386,
              w: 179,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 29,
              y: 425,
              w: 130,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

/*
    IMAGE MOVING ANIMATION
    ZeppOS Watch Face

    LOOP_MODE:
    "BACK_FORTH" = Move forward and backward
    "ONE_WAY"    = Move forward, then restart
*/

// ---------------------------------
// Animation Settings
// ---------------------------------


const X1_XY = 139;
const Y1_XY = 170;

const X2_XY = 139;
const Y2_XY = 320;


// Animation Mode
// const LOOP_MODE_XY = "ONE_WAY";
const LOOP_MODE_XY = "BACK_FORTH";

// Time per direction (ms)
const DURATION_XY = 2000;

// Frames per second
const FPS_XY = 30;


// ---------------------------------
// Image Settings
// ---------------------------------

const IMAGE_SRC_XY = "Scan_0.png";

const IMAGE_W_XY = 174;
const IMAGE_H_XY = 40;


// ---------------------------------
// Create Image Widget
// ---------------------------------

const movingImage_XY = hmUI.createWidget(
    hmUI.widget.IMG,
    {
        x: X1_XY,
        y: Y1_XY,
        w: IMAGE_W_XY,
        h: IMAGE_H_XY,
        src: IMAGE_SRC_XY,
        show_level: hmUI.show_level.ONLY_NORMAL
    }
);


// ---------------------------------
// Animation Variables
// ---------------------------------

let progress_XY = 0;
let direction_XY = 1;

const FRAME_TIME_XY = Math.floor(1000 / FPS_XY);
const STEP_XY = FRAME_TIME_XY / DURATION_XY;


// ---------------------------------
// Animation Timer
// ---------------------------------

let animationTimer_XY = timer.createTimer(
    0,
    FRAME_TIME_XY,
    function () {

        // Update progress
        progress_XY += STEP_XY * direction_XY;


        // ---------------------------------
        // BACK_FORTH Mode
        // ---------------------------------

        if (LOOP_MODE_XY === "BACK_FORTH") {

            if (progress_XY >= 1) {
                progress_XY = 1;
                direction_XY = -1;
            }

            if (progress_XY <= 0) {
                progress_XY = 0;
                direction_XY = 1;
            }
        }


        // ---------------------------------
        // ONE_WAY Mode
        // ---------------------------------

        else if (LOOP_MODE_XY === "ONE_WAY") {

            if (progress_XY >= 1) {
                progress_XY = 0;
            }

            direction_XY = 1;
        }


        // ---------------------------------
        // Calculate Position
        // ---------------------------------

        const currentX_XY = Math.round(
            X1_XY + (X2_XY - X1_XY) * progress_XY
        );

        const currentY_XY = Math.round(
            Y1_XY + (Y2_XY - Y1_XY) * progress_XY
        );


        // ---------------------------------
        // Update Image Position
        // ---------------------------------

        movingImage_XY.setProperty(
            hmUI.prop.X,
            currentX_XY
        );

        movingImage_XY.setProperty(
            hmUI.prop.Y,
            currentY_XY
        );

    }
);









// HEART HISTORY GRAPH - Bip Max

// Heart Sensor
const heart = hmSensor.createSensor(hmSensor.id.HEART);

// Graph Settings
const HEART_X = 343;
const HEART_Y = 256;
const HEART_W = 64;
const HEART_H = 45;

const BAR_COUNT = 16;
const BAR_GAP = 2;

const BAR_WIDTH = Math.floor(
    (HEART_W - (BAR_COUNT - 1) * BAR_GAP) / BAR_COUNT
);

let heartBars = [];
let hourlyMax = new Array(BAR_COUNT).fill(0);
let heartBarsCreated = false;

// Heart Color
function getHeartColor(bpm) {
    if (bpm < 60) return 0xFF2196FF;
    if (bpm < 80) return 0xFF00BCD4;
    if (bpm < 100) return 0xFF4CAF50;
    if (bpm < 120) return 0xFFFFEB3B;
    if (bpm < 140) return 0xFFFF9800;
    return 0xFFF44336;
}

// Create Bars
function createHeartBars() {

    if (heartBarsCreated) return;

    for (let i = 0; i < BAR_COUNT; i++) {

        heartBars[i] = hmUI.createWidget(hmUI.widget.FILL_RECT, {
            x: HEART_X + i * (BAR_WIDTH + BAR_GAP),
            y: HEART_Y + HEART_H,
            w: BAR_WIDTH,
            h: 0,
            color: 0xFF555555,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
    }

    heartBarsCreated = true;
}

// Draw Heart History
function drawHeartHistory() {

    const data = heart.today;

    if (!data || !data.length) return;

    // Collect valid heart-rate values
    let validData = [];

    for (let i = 0; i < data.length; i++) {

        let value = data[i];

        if (value > 30 && value < 250) {
            validData.push(value);
        }
    }

    if (validData.length === 0) return;

    // Distribute available data into 30 positions
    for (let i = 0; i < BAR_COUNT; i++) {

        let bpm = 0;

        if (validData.length === 1) {

            bpm = validData[0];

        } else {

            let pos = i * (validData.length - 1) / (BAR_COUNT - 1);

            let left = Math.floor(pos);
            let right = Math.min(validData.length - 1, left + 1);

            let fraction = pos - left;

            // Linear interpolation
            bpm = Math.round(
                validData[left] +
                (validData[right] - validData[left]) * fraction
            );
        }

        hourlyMax[i] = bpm;
    }

    // Find Min / Max BPM
    let minBPM = 250;
    let maxBPM = 0;

    for (let i = 0; i < BAR_COUNT; i++) {

        let bpm = hourlyMax[i];

        if (bpm > 0) {
            if (bpm < minBPM) minBPM = bpm;
            if (bpm > maxBPM) maxBPM = bpm;
        }
    }

    const span = Math.max(1, maxBPM - minBPM);

    // Draw 30 Bars
    for (let i = 0; i < BAR_COUNT; i++) {

        let bpm = hourlyMax[i];

        let barHeight = Math.round(
            6 + ((bpm - minBPM) / span) * (HEART_H - 6)
        );

        barHeight = Math.max(6, Math.min(HEART_H, barHeight));

        let barColor = getHeartColor(bpm);

        heartBars[i].setProperty(hmUI.prop.MORE, {
            x: HEART_X + i * (BAR_WIDTH + BAR_GAP),
            y: HEART_Y + HEART_H - barHeight,
            w: BAR_WIDTH,
            h: barHeight,
            color: barColor
        });
    }
}

// Initial creation and drawing
    createHeartBars();
    drawHeartHistory();

            // end user_script_end.js

            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text HEART max/min');
              let heartArr = hmSensor.createSensor(hmSensor.id.HEART).today;
              let heartArrValid = heartArr ? heartArr.filter(v => v > 0 && v < 255) : [];
              let max_heart = heartArrValid.length > 0 ? Math.max(...heartArrValid) : undefined;
              let min_heart = heartArrValid.length > 0 ? Math.min(...heartArrValid) : undefined;

              if (screenType != hmSetting.screen_type.AOD) {
                let normal_heart_rate_min_text_font_value = '--';
                if (min_heart != undefined) {
                  normal_heart_rate_min_text_font_value = String(min_heart);
                };
                normal_heart_rate_min_text_font.setProperty(hmUI.prop.TEXT, normal_heart_rate_min_text_font_value);
              };

              if (screenType != hmSetting.screen_type.AOD) {
                let normal_heart_rate_max_text_font_value = '--';
                if (max_heart != undefined) {
                  normal_heart_rate_max_text_font_value = String(max_heart);
                };
                normal_heart_rate_max_text_font.setProperty(hmUI.prop.TEXT, normal_heart_rate_max_text_font_value);
              };

              if (screenType == hmSetting.screen_type.AOD) {
                let idle_heart_rate_min_text_font_value = '--';
                if (min_heart != undefined) {
                  idle_heart_rate_min_text_font_value = String(min_heart);
                };
                idle_heart_rate_min_text_font.setProperty(hmUI.prop.TEXT, idle_heart_rate_min_text_font_value);
              };

              if (screenType == hmSetting.screen_type.AOD) {
                let idle_heart_rate_max_text_font_value = '--';
                if (max_heart != undefined) {
                  idle_heart_rate_max_text_font_value = String(max_heart);
                };
                idle_heart_rate_max_text_font.setProperty(hmUI.prop.TEXT, idle_heart_rate_max_text_font_value);
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 382;
                  let start_y_normal_battery = 172;
                  let lenght_ls_normal_battery = -131;
                  let line_width_ls_normal_battery = 8;
                  let color_ls_normal_battery = 0xFF00B4FF;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 382;
                  let start_y_idle_battery = 172;
                  let lenght_ls_idle_battery = -131;
                  let line_width_ls_idle_battery = 8;
                  let color_ls_idle_battery = 0xFF00B4FF;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();

                console.log('resume_call.js');
                // start resume_call.js

drawHeartHistory();
                // end resume_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}