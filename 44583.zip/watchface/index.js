/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
** Copyright © SashaCX75. All Rights Reserved
*/

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const { px } = __$$app$$__.__globals__;
    //const logger = Logger.getLogger('watchface_SashaCX75');
    const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
    //end of ignored block

    //dynamic modify start


    let normal_background_bg_img = ''
    let normal_weather_image_progress_img_level = ''
    let normal_temperature_current_text_img = ''
    let normal_system_lock_img = ''
    let normal_system_dnd_img = ''
    let normal_system_disconnect_img = ''
    let normal_system_clock_img = ''
    let normal_date_img_date_year = ''
    let normal_date_img_date_month = ''
    let normal_date_img_date_day = ''
    let normal_step_current_text_img = ''
    let normal_step_image_progress_img_progress = ''
    let normal_distance_text_text_img = ''
    let normal_heart_rate_text_text_img = ''
    let normal_heart_rate_image_progress_img_level = ''
    let normal_calorie_current_text_img = ''
    let normal_calorie_image_progress_img_level = ''
    let normal_date_img_date_week_img = ''
    let normal_battery_text_text_img = ''
    let normal_digital_clock_img_time_AmPm = ''
    let normal_digital_clock_img_time = ''
    let normal_frame_animation_1 = ''
    let idle_background_bg = ''
    let idle_digital_clock_img_time_AmPm = ''
    let idle_digital_clock_img_time = ''
    let normal_step_jumpable_img_click = ''
    let normal_battery_jumpable_img_click = ''
    let Button_1 = ''
    let Button_2 = ''
    let Button_3 = ''
    let Button_4 = ''
    let Button_5 = ''
    let Button_6 = ''
    let Button_7 = ''
    let Button_8 = ''


    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start


        console.log('Watch_Face.ScreenNormal');
        normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: '0000.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 273,
          y: 72,
          image_array: ["wet01_0.png", "wet01_1.png", "wet01_2.png", "wet01_3.png", "wet01_4.png", "wet01_5.png", "wet01_6.png", "wet01_7.png", "wet01_8.png", "wet01_9.png", "wet01_10.png", "wet01_11.png", "wet01_12.png", "wet01_13.png", "wet01_14.png", "wet01_15.png", "wet01_16.png", "wet01_17.png", "wet01_18.png", "wet01_19.png", "wet01_20.png", "wet01_21.png", "wet01_22.png", "wet01_23.png", "wet01_24.png", "wet01_25.png", "wet01_26.png", "wet01_27.png", "wet01_28.png"],
          image_length: 29,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 321,
          y: 77,
          font_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          padding: false,
          h_space: 0,
          unit_sc: '0058.png',
          unit_tc: '0058.png',
          unit_en: '0058.png',
          imperial_unit_sc: '0058.png',
          imperial_unit_tc: '0058.png',
          imperial_unit_en: '0058.png',
          negative_image: '0059.png',
          invalid_image: '0060.png',
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        const temperatureUnit = hmSetting.getTemperatureUnit();
        //start of ignored block
        if (temperatureUnit == 1) {
          normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
            x: 321,
            y: 77,
            font_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
            padding: false,
            h_space: 0,
            unit_sc: '0058.png',
            unit_tc: '0058.png',
            unit_en: '0058.png',
            imperial_unit_sc: '0058.png',
            imperial_unit_tc: '0058.png',
            imperial_unit_en: '0058.png',
            negative_image: '0059.png',
            invalid_image: '0060.png',
            align_h: hmUI.align.RIGHT,
            type: hmUI.data_type.WEATHER_CURRENT,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
        };
        //end of ignored block

        normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 348,
          y: 342,
          src: 'lock_on.png',
          type: hmUI.system_status.LOCK,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 262,
          y: 346,
          src: '0072.png',
          type: hmUI.system_status.DISTURB,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 284,
          y: 344,
          src: '0071.png',
          type: hmUI.system_status.DISCONNECT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 299,
          y: 346,
          src: '0074.png',
          type: hmUI.system_status.CLOCK,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          year_startX: 106,
          year_startY: 77,
          year_sc_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          year_tc_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          year_en_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          year_zero: 1,
          year_space: 0,
          year_align: hmUI.align.RIGHT,
          year_is_character: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 74,
          month_startY: 77,
          month_sc_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          month_tc_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          month_en_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          month_zero: 1,
          month_space: -2,
          month_align: hmUI.align.RIGHT,
          month_is_character: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 41,
          day_startY: 77,
          day_sc_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          day_tc_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          day_en_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          day_zero: 1,
          day_space: 0,
          day_align: hmUI.align.LEFT,
          day_is_character: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 163,
          y: 355,
          font_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_step_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
          x: [228, 219, 210, 201, 192, 183, 174, 165, 156, 156],
          y: [332, 332, 332, 332, 332, 332, 332, 332, 332, 332],
          image_array: ["0061.png", "0062.png", "0063.png", "0064.png", "0065.png", "0066.png", "0067.png", "0068.png", "0069.png", "0070.png"],
          image_length: 10,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 2,
          y: 264,
          font_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          padding: false,
          h_space: 0,
          dot_image: '0031.png',
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.DISTANCE,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 4,
          y: 206,
          font_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          padding: false,
          h_space: 1,
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 53,
          y: 215,
          image_array: ["3000.png", "3001.png", "3002.png", "3003.png", "3004.png", "3005.png"],
          image_length: 6,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 5,
          y: 145,
          font_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 68,
          y: 155,
          image_array: ["3000.png", "3001.png", "3002.png", "3003.png", "3004.png", "3005.png"],
          image_length: 6,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 108,
          y: 14,
          week_en: ["0012.png", "0013.png", "0014.png", "0015.png", "0016.png", "0017.png", "0018.png"],
          week_tc: ["0012.png", "0013.png", "0014.png", "0015.png", "0016.png", "0017.png", "0018.png"],
          week_sc: ["0012.png", "0013.png", "0014.png", "0015.png", "0016.png", "0017.png", "0018.png"],
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 51,
          y: 362,
          font_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          padding: false,
          h_space: 0,
          unit_sc: '0089.png',
          unit_tc: '0089.png',
          unit_en: '0089.png',
          align_h: hmUI.align.LEFT,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          am_x: 312,
          am_y: 348,
          am_sc_path: '0019.png',
          am_en_path: '0019.png',
          pm_x: 312,
          pm_y: 348,
          pm_sc_path: '0020.png',
          pm_en_path: '0020.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_startX: 278,
          hour_startY: 120,
          hour_array: ["0090.png", "0091.png", "0092.png", "0093.png", "0094.png", "0095.png", "0096.png", "0097.png", "0098.png", "0099.png"],
          hour_zero: 1,
          hour_space: 3,
          hour_angle: 0,
          hour_align: hmUI.align.LEFT,

          minute_startX: 278,
          minute_startY: 231,
          minute_array: ["0090.png", "0091.png", "0092.png", "0093.png", "0094.png", "0095.png", "0096.png", "0097.png", "0098.png", "0099.png"],
          minute_zero: 1,
          minute_space: 3,
          minute_angle: 0,
          minute_follow: 0,
          minute_align: hmUI.align.LEFT,

          second_startX: 321,
          second_startY: 329,
          second_array: ["0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png"],
          second_zero: 1,
          second_space: 0,
          second_angle: 0,
          second_follow: 0,
          second_align: hmUI.align.LEFT,

          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
          x: 153,
          y: 110,
          anim_path: "animation",
          anim_ext: "png",
          anim_prefix: "anim",
          anim_fps: 10,
          anim_size: 8,
          repeat_count: 0,
          anim_repeat: true,
          anim_status: hmUI.anim_status.START,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


        // vibration when connecting or disconnecting

        function checkConnection() {
          console.log('checkConnection()');
          hmBle.removeListener;
          hmBle.addListener(function (status) {
            if (!status) {
              hmUI.showToast({ text: "Disconnected" });
              vibro(9);
            }
            if (status) {
              hmUI.showToast({ text: "Connected" });
              vibro(9);
            }
          });
        }

        // end vibration when connecting or disconnecting
        // vibrate function

        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let timer_StopVibrate = null;


        function vibro(scene = 25) {
          let stopDelay = 50;
          stopVibro();
          vibrate.stop();
          vibrate.scene = scene;
          if (scene < 23 || scene > 25) stopDelay = 1300;
          vibrate.start();
          if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
        }

        function stopVibro() {
          vibrate.stop();
          if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
        }

        // end vibrate function
        console.log('Watch_Face.Shortcuts');

        normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 141,
          y: 302,
          w: 100,
          h: 80,
          src: 'z_Empty.png',
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 11,
          y: 317,
          w: 100,
          h: 80,
          src: 'z_Empty.png',
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        console.log('Watch_Face.Buttons');
        Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 13,
          y: 108,
          w: 100,
          h: 60,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'z_Empty.png',
          normal_src: 'z_Empty.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'activityAppScreen', native: true });
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 15,
          y: 181,
          w: 100,
          h: 60,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'z_Empty.png',
          normal_src: 'z_Empty.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'heart_app_Screen', native: true });
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 18,
          y: 246,
          w: 100,
          h: 60,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'z_Empty.png',
          normal_src: 'z_Empty.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'SportListScreen', native: true });
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 287,
          y: 48,
          w: 100,
          h: 60,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'z_Empty.png',
          normal_src: 'z_Empty.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'WeatherScreen', native: true });
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 281,
          y: 343,
          w: 100,
          h: 60,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'z_Empty.png',
          normal_src: 'z_Empty.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'AlarmInfoScreen', native: true });
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 27,
          y: 26,
          w: 100,
          h: 60,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'z_Empty.png',
          normal_src: 'z_Empty.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 280,
          y: 226,
          w: 100,
          h: 100,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'z_Empty.png',
          normal_src: 'z_Empty.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'CountdownAppScreen', native: true });
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 285,
          y: 127,
          w: 100,
          h: 90,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'z_Empty.png',
          normal_src: 'z_Empty.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'MusicCommonScreen', native: true });
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        console.log('Watch_Face.ScreenAOD');
        idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          color: '0xFF000000',
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          am_x: 312,
          am_y: 348,
          am_sc_path: '0019.png',
          am_en_path: '0019.png',
          pm_x: 312,
          pm_y: 348,
          pm_sc_path: '0020.png',
          pm_en_path: '0020.png',
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_startX: 278,
          hour_startY: 120,
          hour_array: ["0090.png", "0091.png", "0092.png", "0093.png", "0094.png", "0095.png", "0096.png", "0097.png", "0098.png", "0099.png"],
          hour_zero: 1,
          hour_space: 3,
          hour_angle: 0,
          hour_align: hmUI.align.LEFT,

          minute_startX: 278,
          minute_startY: 231,
          minute_array: ["0090.png", "0091.png", "0092.png", "0093.png", "0094.png", "0095.png", "0096.png", "0097.png", "0098.png", "0099.png"],
          minute_zero: 1,
          minute_space: 3,
          minute_angle: 0,
          minute_follow: 0,
          minute_align: hmUI.align.LEFT,

          show_level: hmUI.show_level.ONLY_AOD,
        });

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            console.log('resume_call()');
            normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
            checkConnection();
            stopVibro();

          }),
          pause_call: (function () {
            console.log('pause_call()');
            normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
            stopVibro();

          }),
        });

        //dynamic modify end
      },
      onInit() {
        logger.log('index page.js on init invoke');
      },
      build() {
        this.init_view();
        logger.log('index page.js on ready invoke');
      },
      onDestroy() {
        logger.log('index page.js on destroy invoke');
      }
    });
    ;
  })();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
  ;
}
