# Copper Dial — Amazfit Bip Max watch face

A hybrid watch face for the **Amazfit Bip Max** (2.07" AMOLED, 432 × 514 px, Zepp OS). It has a copper analog dial with red minute ticks, big digital time with red seconds, steps, weather, battery and date.

## What's live on the watch

| Element | Source |
|---|---|
| Analog hour / minute / second hands | System time |
| Big digital time `10:09` + red seconds | System time, follows 12/24 h setting |
| `18 OCT` in the dial, `SUN`, `18.10`, weekday strip | System date |
| Battery % and battery icon (10 levels, red below 20 %) | Battery |
| Steps (room for 5 digits, up to 99 999) | Step counter |
| Weather icon (all 29 Zepp OS conditions), current temp °C/°F | Weather |
| HI / LO / HUM | Today's forecast + humidity |
| Tap steps / weather / battery | Opens the matching app |
| Always-On Display | Dimmed hour markers, outline hands, digital time (~5 % lit pixels) |

## Build the installable file

You need [Node.js](https://nodejs.org) (LTS) on your computer.

```bash
npm install -g @zeppos/zeus-cli
cd CopperDial
zeus build
```

The finished package appears in `CopperDial/dist/` as a `.zab` file.

## Install on the watch

1. In the Zepp phone app, go to **Profile → Settings → About**. Tap the Zepp logo 7 times to turn on Developer Mode.
2. On the computer, in the `CopperDial` folder, run:
   ```bash
   zeus login
   zeus preview
   ```
   Pick **bip-max** when asked. A QR code appears.
3. In the Zepp app, go to **Profile → Developer Mode → Scan** and scan the QR code. The face installs on the watch.

## Notes

- If something on the face fails to load, a short red error message appears on the watch instead of a black screen. Send me that text and I can fix it.

- Device IDs in `app.json`: `11206915` is the confirmed Bip Max ID. `11206912` and `11206913` are included for the other regional variants.
- If `zeus preview` reports that the `appId` belongs to someone else, replace `appId` in `app.json` with an ID from your Zepp developer account, or run `zeus create` once and copy its ID.
- Layout: all coordinates in `watchface/index.js` are device pixels. All images are in `assets/bip-max/`.
