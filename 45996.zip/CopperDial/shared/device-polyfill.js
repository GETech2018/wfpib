// Minimal device polyfill (same role as the one in the Zeus watch face template).
// Keeps Promise-based code and timers safe on older watch-face runtimes.
if (typeof Promise !== 'undefined' && typeof Promise._setScheduler === 'function') {
  Promise._setScheduler(function (flush) { flush && flush() })
}
