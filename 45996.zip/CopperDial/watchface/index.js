/*
 * Copper Dial - watch face for Amazfit Bip Max (432 x 514, Zepp OS)
 * Generated layout: every coordinate below is in device pixels.
 */
import '../shared/device-polyfill'

const CX = 216
const CY = 180
const ERRORS = []

// create one widget; a bad widget is skipped instead of blanking the whole face
function mk(type, opts) {
  try {
    return hmUI.createWidget(type, opts)
  } catch (e) {
    ERRORS.push(String(e))
    return null
  }
}

function drawFace() {
    const NORMAL = hmUI.show_level.ONLY_NORMAL
    const AOD = hmUI.show_level.ONAL_AOD
    // ---------- background: dial, ticks, frame, labels, pills ----------
    mk(hmUI.widget.IMG, { x: 0, y: 0, w: 432, h: 514, src: 'bg.png', show_level: NORMAL })

    // ---------- date inside the dial: "18 OCT" ----------
    mk(hmUI.widget.IMG_DATE, {
      day_startX: 177,
      day_startY: 131,
      day_sc_array: ["dial_day/0.png", "dial_day/1.png", "dial_day/2.png", "dial_day/3.png", "dial_day/4.png", "dial_day/5.png", "dial_day/6.png", "dial_day/7.png", "dial_day/8.png", "dial_day/9.png"],
      day_tc_array: ["dial_day/0.png", "dial_day/1.png", "dial_day/2.png", "dial_day/3.png", "dial_day/4.png", "dial_day/5.png", "dial_day/6.png", "dial_day/7.png", "dial_day/8.png", "dial_day/9.png"],
      day_en_array: ["dial_day/0.png", "dial_day/1.png", "dial_day/2.png", "dial_day/3.png", "dial_day/4.png", "dial_day/5.png", "dial_day/6.png", "dial_day/7.png", "dial_day/8.png", "dial_day/9.png"],
      day_zero: 1,
      day_space: 0,
      day_align: hmUI.align.LEFT,
      day_is_character: false,
      month_startX: 203,
      month_startY: 131,
      month_sc_array: ["month/0.png", "month/1.png", "month/2.png", "month/3.png", "month/4.png", "month/5.png", "month/6.png", "month/7.png", "month/8.png", "month/9.png", "month/10.png", "month/11.png"],
      month_tc_array: ["month/0.png", "month/1.png", "month/2.png", "month/3.png", "month/4.png", "month/5.png", "month/6.png", "month/7.png", "month/8.png", "month/9.png", "month/10.png", "month/11.png"],
      month_en_array: ["month/0.png", "month/1.png", "month/2.png", "month/3.png", "month/4.png", "month/5.png", "month/6.png", "month/7.png", "month/8.png", "month/9.png", "month/10.png", "month/11.png"],
      month_is_character: true,
      month_follow: 0,
      show_level: NORMAL
    })

    // ---------- battery ----------
    // battery percent
    mk(hmUI.widget.TEXT_IMG, {
      x: 176,
      y: 251,
      w: 80,
      h: 13,
      font_array: ["batt/0.png", "batt/1.png", "batt/2.png", "batt/3.png", "batt/4.png", "batt/5.png", "batt/6.png", "batt/7.png", "batt/8.png", "batt/9.png"],
      h_space: 1,
      align_h: hmUI.align.CENTER_H,
      type: hmUI.data_type.BATTERY,
      show_level: NORMAL,
      unit_en: 'batt/pct.png',
      unit_sc: 'batt/pct.png',
      unit_tc: 'batt/pct.png'
    })

    mk(hmUI.widget.IMG_LEVEL, {
      x: 201,
      y: 274,
      image_array: ["batt_lvl/0.png", "batt_lvl/1.png", "batt_lvl/2.png", "batt_lvl/3.png", "batt_lvl/4.png", "batt_lvl/5.png", "batt_lvl/6.png", "batt_lvl/7.png", "batt_lvl/8.png", "batt_lvl/9.png"],
      image_length: 10,
      type: hmUI.data_type.BATTERY,
      show_level: NORMAL
    })

    // ---------- steps (room for 5 digits) ----------
    // steps
    mk(hmUI.widget.TEXT_IMG, {
      x: 64,
      y: 294,
      w: 84,
      h: 19,
      font_array: ["steps/0.png", "steps/1.png", "steps/2.png", "steps/3.png", "steps/4.png", "steps/5.png", "steps/6.png", "steps/7.png", "steps/8.png", "steps/9.png"],
      h_space: 1,
      align_h: hmUI.align.LEFT,
      type: hmUI.data_type.STEP,
      show_level: NORMAL
    })

    // ---------- weather ----------
    mk(hmUI.widget.IMG_LEVEL, {
      x: 298,
      y: 286,
      image_array: ["weather/0.png", "weather/1.png", "weather/2.png", "weather/3.png", "weather/4.png", "weather/5.png", "weather/6.png", "weather/7.png", "weather/8.png", "weather/9.png", "weather/10.png", "weather/11.png", "weather/12.png", "weather/13.png", "weather/14.png", "weather/15.png", "weather/16.png", "weather/17.png", "weather/18.png", "weather/19.png", "weather/20.png", "weather/21.png", "weather/22.png", "weather/23.png", "weather/24.png", "weather/25.png", "weather/26.png", "weather/27.png", "weather/28.png"],
      image_length: 29,
      type: hmUI.data_type.WEATHER_CURRENT,
      show_level: NORMAL
    })
    // current temperature
    mk(hmUI.widget.TEXT_IMG, {
      x: 338,
      y: 293,
      w: 68,
      h: 20,
      font_array: ["temp/0.png", "temp/1.png", "temp/2.png", "temp/3.png", "temp/4.png", "temp/5.png", "temp/6.png", "temp/7.png", "temp/8.png", "temp/9.png"],
      h_space: 1,
      align_h: hmUI.align.CENTER_H,
      type: hmUI.data_type.WEATHER_CURRENT,
      show_level: NORMAL,
      unit_en: 'temp/degc.png',
      unit_sc: 'temp/degc.png',
      unit_tc: 'temp/degc.png',
      imperial_unit_en: 'temp/degf.png',
      imperial_unit_sc: 'temp/degf.png',
      imperial_unit_tc: 'temp/degf.png',
      negative_image: 'temp/minus.png',
      invalid_image: 'temp/none.png'
    })

    // today high
    mk(hmUI.widget.TEXT_IMG, {
      x: 85,
      y: 332,
      w: 50,
      h: 15,
      font_array: ["small/0.png", "small/1.png", "small/2.png", "small/3.png", "small/4.png", "small/5.png", "small/6.png", "small/7.png", "small/8.png", "small/9.png"],
      h_space: 1,
      align_h: hmUI.align.LEFT,
      type: hmUI.data_type.WEATHER_HIGH,
      show_level: NORMAL,
      unit_en: 'small/deg.png',
      unit_sc: 'small/deg.png',
      unit_tc: 'small/deg.png',
      imperial_unit_en: 'small/deg.png',
      imperial_unit_sc: 'small/deg.png',
      imperial_unit_tc: 'small/deg.png',
      negative_image: 'small/minus.png',
      invalid_image: 'small/none.png'
    })

    // today low
    mk(hmUI.widget.TEXT_IMG, {
      x: 219,
      y: 332,
      w: 50,
      h: 15,
      font_array: ["small/0.png", "small/1.png", "small/2.png", "small/3.png", "small/4.png", "small/5.png", "small/6.png", "small/7.png", "small/8.png", "small/9.png"],
      h_space: 1,
      align_h: hmUI.align.LEFT,
      type: hmUI.data_type.WEATHER_LOW,
      show_level: NORMAL,
      unit_en: 'small/deg.png',
      unit_sc: 'small/deg.png',
      unit_tc: 'small/deg.png',
      imperial_unit_en: 'small/deg.png',
      imperial_unit_sc: 'small/deg.png',
      imperial_unit_tc: 'small/deg.png',
      negative_image: 'small/minus.png',
      invalid_image: 'small/none.png'
    })

    // humidity
    mk(hmUI.widget.TEXT_IMG, {
      x: 345,
      y: 332,
      w: 46,
      h: 15,
      font_array: ["small/0.png", "small/1.png", "small/2.png", "small/3.png", "small/4.png", "small/5.png", "small/6.png", "small/7.png", "small/8.png", "small/9.png"],
      h_space: 1,
      align_h: hmUI.align.LEFT,
      type: hmUI.data_type.HUMIDITY,
      show_level: NORMAL,
      unit_en: 'small/pct.png',
      unit_sc: 'small/pct.png',
      unit_tc: 'small/pct.png',
      invalid_image: 'small/none.png'
    })

    // ---------- weekday + date, bottom left: "SUN" / "18.10" ----------
    mk(hmUI.widget.IMG_WEEK, {
      x: 371,
      y: 366,
      week_en: ["wday/0.png", "wday/1.png", "wday/2.png", "wday/3.png", "wday/4.png", "wday/5.png", "wday/6.png"],
      week_tc: ["wday/0.png", "wday/1.png", "wday/2.png", "wday/3.png", "wday/4.png", "wday/5.png", "wday/6.png"],
      week_sc: ["wday/0.png", "wday/1.png", "wday/2.png", "wday/3.png", "wday/4.png", "wday/5.png", "wday/6.png"],
      show_level: NORMAL
    })
    mk(hmUI.widget.IMG_DATE, {
      day_startX: 371,
      day_startY: 384,
      day_sc_array: ["date/0.png", "date/1.png", "date/2.png", "date/3.png", "date/4.png", "date/5.png", "date/6.png", "date/7.png", "date/8.png", "date/9.png"],
      day_tc_array: ["date/0.png", "date/1.png", "date/2.png", "date/3.png", "date/4.png", "date/5.png", "date/6.png", "date/7.png", "date/8.png", "date/9.png"],
      day_en_array: ["date/0.png", "date/1.png", "date/2.png", "date/3.png", "date/4.png", "date/5.png", "date/6.png", "date/7.png", "date/8.png", "date/9.png"],
      day_zero: 1,
      day_space: 0,
      day_is_character: false,
      month_startX: 403,
      month_startY: 384,
      month_sc_array: ["date/0.png", "date/1.png", "date/2.png", "date/3.png", "date/4.png", "date/5.png", "date/6.png", "date/7.png", "date/8.png", "date/9.png"],
      month_tc_array: ["date/0.png", "date/1.png", "date/2.png", "date/3.png", "date/4.png", "date/5.png", "date/6.png", "date/7.png", "date/8.png", "date/9.png"],
      month_en_array: ["date/0.png", "date/1.png", "date/2.png", "date/3.png", "date/4.png", "date/5.png", "date/6.png", "date/7.png", "date/8.png", "date/9.png"],
      month_zero: 1,
      month_space: 0,
      month_is_character: false,
      month_follow: 0,
      show_level: NORMAL
    })
    mk(hmUI.widget.IMG, { x: 397, y: 384, src: 'date/dot.png', show_level: NORMAL })

    // ---------- weekday strip M T W T F S S ----------
    mk(hmUI.widget.IMG_WEEK, {
      x: 110,
      y: 486,
      week_en: ["week/0.png", "week/1.png", "week/2.png", "week/3.png", "week/4.png", "week/5.png", "week/6.png"],
      week_tc: ["week/0.png", "week/1.png", "week/2.png", "week/3.png", "week/4.png", "week/5.png", "week/6.png"],
      week_sc: ["week/0.png", "week/1.png", "week/2.png", "week/3.png", "week/4.png", "week/5.png", "week/6.png"],
      show_level: NORMAL
    })

    // ---------- big digital time + red seconds ----------
    mk(hmUI.widget.IMG_TIME, {
      hour_zero: 1,
      hour_startX: 8,
      hour_startY: 362,
      hour_array: ["hour/0.png", "hour/1.png", "hour/2.png", "hour/3.png", "hour/4.png", "hour/5.png", "hour/6.png", "hour/7.png", "hour/8.png", "hour/9.png"],
      hour_space: 0,
      hour_align: hmUI.align.LEFT,
      minute_zero: 1,
      minute_startX: 205,
      minute_startY: 363,
      minute_array: ["min/0.png", "min/1.png", "min/2.png", "min/3.png", "min/4.png", "min/5.png", "min/6.png", "min/7.png", "min/8.png", "min/9.png"],
      minute_space: 0,
      minute_follow: 0,
      minute_align: hmUI.align.LEFT,
      second_zero: 1,
      second_startX: 371,
      second_startY: 438,
      second_array: ["sec/0.png", "sec/1.png", "sec/2.png", "sec/3.png", "sec/4.png", "sec/5.png", "sec/6.png", "sec/7.png", "sec/8.png", "sec/9.png"],
      second_space: 0,
      second_follow: 0,
      second_align: hmUI.align.LEFT,
      show_level: NORMAL
    })

    // ---------- analog hands ----------
    mk(hmUI.widget.TIME_POINTER, {
      hour_centerX: CX,
      hour_centerY: CY,
      hour_posX: 11,
      hour_posY: 93,
      hour_path: 'hands/hour.png',
      minute_centerX: CX,
      minute_centerY: CY,
      minute_posX: 10,
      minute_posY: 143,
      minute_path: 'hands/minute.png',
      second_centerX: CX,
      second_centerY: CY,
      second_posX: 7,
      second_posY: 140,
      second_path: 'hands/second.png',
      show_level: NORMAL
    })
    mk(hmUI.widget.IMG, { x: 202, y: 166, src: 'hands/cap.png', show_level: NORMAL | AOD })

    // ---------- tap zones: open Steps, Weather, Battery apps ----------
    mk(hmUI.widget.IMG_CLICK, { x: 22, y: 282, w: 132, h: 42, src: 'click.png', type: hmUI.data_type.STEP })
    mk(hmUI.widget.IMG_CLICK, { x: 294, y: 282, w: 116, h: 42, src: 'click.png', type: hmUI.data_type.WEATHER_CURRENT })
    mk(hmUI.widget.IMG_CLICK, { x: 176, y: 236, w: 80, h: 72, src: 'click.png', type: hmUI.data_type.BATTERY })

    // ---------- always-on display ----------
    mk(hmUI.widget.IMG, { x: 0, y: 0, w: 432, h: 514, src: 'aod/dial.png', show_level: AOD })
    mk(hmUI.widget.IMG, { x: 187, y: 387, src: 'aod/colon.png', show_level: AOD })
    mk(hmUI.widget.IMG_TIME, {
      hour_zero: 1,
      hour_startX: 8,
      hour_startY: 362,
      hour_array: ["hour/0.png", "hour/1.png", "hour/2.png", "hour/3.png", "hour/4.png", "hour/5.png", "hour/6.png", "hour/7.png", "hour/8.png", "hour/9.png"],
      hour_space: 0,
      hour_align: hmUI.align.LEFT,
      minute_zero: 1,
      minute_startX: 205,
      minute_startY: 363,
      minute_array: ["min/0.png", "min/1.png", "min/2.png", "min/3.png", "min/4.png", "min/5.png", "min/6.png", "min/7.png", "min/8.png", "min/9.png"],
      minute_space: 0,
      minute_follow: 0,
      minute_align: hmUI.align.LEFT,
      show_level: AOD
    })
    mk(hmUI.widget.TIME_POINTER, {
      hour_centerX: CX,
      hour_centerY: CY,
      hour_posX: 8,
      hour_posY: 90,
      hour_path: 'aod/hour.png',
      minute_centerX: CX,
      minute_centerY: CY,
      minute_posX: 7,
      minute_posY: 140,
      minute_path: 'aod/minute.png',
      show_level: AOD
    })
}

WatchFace({
  build() {
    try {
      drawFace()
    } catch (e) {
      ERRORS.push(String(e))
    }
    if (ERRORS.length) {
      // visible diagnostics instead of a black screen
      try {
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 20, y: 20, w: 392, h: 200, color: 0xff4040, text_size: 18,
          text_style: hmUI.text_style.WRAP, text: 'Copper Dial error: ' + ERRORS.join(' | ')
        })
      } catch (e) {}
    }
  },

  onInit() {},
  onDestroy() {}
})
