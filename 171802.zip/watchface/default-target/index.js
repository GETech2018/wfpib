try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_75c409f92d3f4ad3b6d92006d387ab1a = '';
        let normal$_$text_444ad8447581407c9c3bcc4508bdf177 = '';
        let normal$_$text_cea2a7f600944760b29b638993ebdc5c = '';
        let normal$_$text_03df237cc21a47e5adc01698ebd5331b = '';
        let normal$_$text_baf487d9589f4bb284bf0aaefe1ae01f = '';
        const WEEK_EN_S = function (val) {
            const valueMap = {
                '1': 'Mon',
                '2': 'Tue',
                '3': 'Wed',
                '4': 'Thu',
                '5': 'Fri',
                '6': 'Sat',
                '7': 'Sun'
            };
            return valueMap[val];
        };
        let normal$_$text_3c9f5c3cc8cc4d41b39c68b51f17587f = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let calorieSensor = '';
        let stepSensor = '';
        let batterySensor = '';
        let timeSensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 432,
                    h: 514,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_75c409f92d3f4ad3b6d92006d387ab1a = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 166,
                    y: 362,
                    w: 100,
                    h: 40,
                    text: '[CAL]',
                    color: '0xFF470b0b',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_444ad8447581407c9c3bcc4508bdf177 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 231,
                    y: 246,
                    w: 100,
                    h: 40,
                    text: '[CAL]',
                    color: '0xFF470b0b',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_cea2a7f600944760b29b638993ebdc5c = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 154,
                    y: 342,
                    w: 124,
                    h: 40,
                    text: '[SC]',
                    color: '0xFF470b0b',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_03df237cc21a47e5adc01698ebd5331b = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 117,
                    y: 246,
                    w: 69,
                    h: 34,
                    text: '[BATT_PER]%',
                    color: '0xFF470b0b',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_baf487d9589f4bb284bf0aaefe1ae01f = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 181,
                    y: 166,
                    w: 69,
                    h: 34,
                    text: '[WEEK_EN_S]',
                    color: '0xFF470b0b',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_3c9f5c3cc8cc4d41b39c68b51f17587f = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 166,
                    y: 184,
                    w: 100,
                    h: 40,
                    text: '[DAY_Z]/[MON_Z]',
                    color: '0xFF470b0b',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 218,
                    hour_centerY: 259,
                    hour_posX: 32,
                    hour_posY: 208,
                    hour_path: '3.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 218,
                    minute_centerY: 259,
                    minute_posX: 32,
                    minute_posY: 208,
                    minute_path: '4.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 218,
                    second_centerY: 259,
                    second_posX: 32,
                    second_posY: 208,
                    second_path: '5.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!calorieSensor) {
                    calorieSensor = hmSensor.createSensor(hmSensor.id.CALORIE);
                }
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                calorieSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_75c409f92d3f4ad3b6d92006d387ab1a.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current }` });
                    normal$_$text_444ad8447581407c9c3bcc4508bdf177.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current }` });
                }), stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_cea2a7f600944760b29b638993ebdc5c.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_03df237cc21a47e5adc01698ebd5331b.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                }), timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    normal$_$text_baf487d9589f4bb284bf0aaefe1ae01f.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_3c9f5c3cc8cc4d41b39c68b51f17587f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_3c9f5c3cc8cc4d41b39c68b51f17587f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_3c9f5c3cc8cc4d41b39c68b51f17587f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_75c409f92d3f4ad3b6d92006d387ab1a.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current }` });
                        normal$_$text_444ad8447581407c9c3bcc4508bdf177.setProperty(hmUI.prop.MORE, { text: `${ calorieSensor.current }` });
                        normal$_$text_cea2a7f600944760b29b638993ebdc5c.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        normal$_$text_03df237cc21a47e5adc01698ebd5331b.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                        normal$_$text_baf487d9589f4bb284bf0aaefe1ae01f.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_3c9f5c3cc8cc4d41b39c68b51f17587f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_3c9f5c3cc8cc4d41b39c68b51f17587f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_3c9f5c3cc8cc4d41b39c68b51f17587f.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }/${ String(timeSensor.day).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}