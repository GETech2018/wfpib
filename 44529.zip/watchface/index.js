﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js


        // Switch Step/calories
        let elementnumber_2 = 1
        let total_elemente2 = 2
        let cc = 0

        function click_StepsCal() {
            if(elementnumber_2==total_elemente2) {
            elementnumber_2=1;
                UpdateElemente2One();
                }
            else {
                elementnumber_2=elementnumber_2+1;
                if(elementnumber_2==2) {
                  UpdateElemente2Two();
                }

            }
            if(elementnumber_2==1) hmUI.showToast({text: 'STEPS'});
            if(elementnumber_2==2) hmUI.showToast({text: 'CALORIES'});
        }

        //STEPS
        function UpdateElemente2One(){
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);

        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);



        }

        //CALORIES
        function UpdateElemente2Two(){
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);


        }




///////////
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 33,
              y: 18,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 353,
              y: 368,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 367,
              y: 336,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 131,
              y: 275,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png","Week_1.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 292,
              font_array: ["Temp_0.png","Temp_1.png","Temp_2.png","Temp_3.png","Temp_4.png","Temp_5.png","Temp_6.png","Temp_7.png","Temp_8.png","Temp_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'Temp_unit.png',
              unit_tc: 'Temp_unit.png',
              unit_en: 'Temp_unit.png',
              imperial_unit_sc: 'Temp_unit.png',
              imperial_unit_tc: 'Temp_unit.png',
              imperial_unit_en: 'Temp_unit.png',
              negative_image: 'Temp_error.png',
              invalid_image: 'Temp_error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 175,
                y: 292,
                font_array: ["Temp_0.png","Temp_1.png","Temp_2.png","Temp_3.png","Temp_4.png","Temp_5.png","Temp_6.png","Temp_7.png","Temp_8.png","Temp_9.png"],
                padding: false,
                h_space: -4,
                unit_sc: 'Temp_unit.png',
                unit_tc: 'Temp_unit.png',
                unit_en: 'Temp_unit.png',
                imperial_unit_sc: 'Temp_unit.png',
                imperial_unit_tc: 'Temp_unit.png',
                imperial_unit_en: 'Temp_unit.png',
                negative_image: 'Temp_error.png',
                invalid_image: 'Temp_error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 280,
              font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              padding: false,
              h_space: -7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 8,
              y: 227,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 179,
              month_startY: 226,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 97,
              day_startY: 220,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: -6,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 14,
              // start_y: 320,
              // color: 0xFF77E86C,
              // lenght: 54,
              // line_width: 4,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 42,
              y: 285,
              font_array: ["Power_0.png","Power_1.png","Power_2.png","Power_3.png","Power_4.png","Power_5.png","Power_6.png","Power_7.png","Power_8.png","Power_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Power_unit.png',
              unit_tc: 'Power_unit.png',
              unit_en: 'Power_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 336,
              font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 307,
              y: 343,
              src: 'icon_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 336,
              font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 302,
              y: 347,
              src: 'icon_Steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 397,
              font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 199,
              am_y: 10,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 199,
              pm_y: 10,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
// ===== Ball Time Watch : Ball + Digits Locked Together (RECT BOUNDARY) =====

//const screenType = hmSetting.getScreenType()
if (screenType != hmSetting.screen_type.AOD) {

  const W = 390;
  const H = 218;
  const CX = W / 2;
  const CY = H / 2;

  const BALL_R = 27;
  const BALL_FILES = ["ball_hour.png","ball_min.png","ball_sec.png"];
  const BALL_COUNT = 3;
  let balls = [], ballWidgets = [];

  const ROT_BOXES = [123, 80, 69]; // H, M, S
  const DIGIT_GAPS = [-45,-24,-22];

  let digitGroups = [];

  const DIGIT_SETS = ["digit_h/","digit_m/","digit_s/"];

  const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

  function setTwoDigits(group, value, setIndex){
    const v = value < 10 ? "0"+value : ""+value;
    const base = DIGIT_SETS[setIndex];
    group.imgs[0].setProperty(hmUI.prop.SRC, base + v[0] + ".png");
    group.imgs[1].setProperty(hmUI.prop.SRC, base + v[1] + ".png");
  }

  function createDigitGroup(setIndex){
    let size = ROT_BOXES[setIndex];
    let g = { imgs: [], kick:0, angle:0, cx:0, cy:0, size:size };

    for(let i=0;i<2;i++){
      let img = hmUI.createWidget(hmUI.widget.IMG,{
        x:0,y:0,w:size,h:size,src:DIGIT_SETS[setIndex] + "0.png"
      });
      img.setProperty(hmUI.prop.CENTER_X, size/2);
      img.setProperty(hmUI.prop.CENTER_Y, size/2);
      g.imgs.push(img);
    }
    return g;
  }

  function initBalls(){
    balls=[];
    for(let i=0;i<BALL_COUNT;i++){
      let pa=Math.random()*Math.PI*2;
      let va=Math.random()*Math.PI*2;
      let speed=i===0?0.5:(i===1?0.8:1.1);
      balls.push({
        x:CX+Math.cos(pa)*80,
        y:CY+Math.sin(pa)*80,
        vx:Math.cos(va)*speed,
        vy:Math.sin(va)*speed,
        angle:0,
        spin:0
      });
    }
  }

  // === Rect boundary for ball ===
  function bounceRect(obj, radius){
    const left   = radius;
    const right  = W - radius;
    const top    = radius;
    const bottom = H - radius;

    if (obj.x <= left){
      obj.x = left;
      obj.vx = Math.abs(obj.vx);
      obj.spin += 8*(Math.random()-0.5);
    } else if (obj.x >= right){
      obj.x = right;
      obj.vx = -Math.abs(obj.vx);
      obj.spin += 8*(Math.random()-0.5);
    }

    if (obj.y <= top){
      obj.y = top;
      obj.vy = Math.abs(obj.vy);
      obj.spin += 8*(Math.random()-0.5);
    } else if (obj.y >= bottom){
      obj.y = bottom;
      obj.vy = -Math.abs(obj.vy);
      obj.spin += 8*(Math.random()-0.5);
    }
  }

  // === Rect boundary for digit ===
  function bounceDigitOnRect(g, index){
    const margin = g.size * 0.3;
    const left   = margin;
    const right  = W - margin;
    const top    = margin;
    const bottom = H - margin;

    if (g.cx <= left){
      g.cx = left;
      let k = 20*(Math.random()-0.5);
      g.kick += k;
      balls[index].vx = Math.abs(balls[index].vx);
    } else if (g.cx >= right){
      g.cx = right;
      let k = 20*(Math.random()-0.5);
      g.kick += k;
      balls[index].vx = -Math.abs(balls[index].vx);
    }

    if (g.cy <= top){
      g.cy = top;
      let k = 20*(Math.random()-0.5);
      g.kick += k;
      balls[index].vy = Math.abs(balls[index].vy);
    } else if (g.cy >= bottom){
      g.cy = bottom;
      let k = 20*(Math.random()-0.5);
      g.kick += k;
      balls[index].vy = -Math.abs(balls[index].vy);
    }
  }

  function collideDigits(a, b){
    let dx = b.cx - a.cx;
    let dy = b.cy - a.cy;
    let dist = Math.sqrt(dx*dx + dy*dy);
    let minDist = (a.size + b.size) * 0.6;

    if(dist > 0 && dist < minDist){
      dx /= dist;
      dy /= dist;

      let push = (minDist - dist) * 0.5;

      a.cx -= dx * push;
      a.cy -= dy * push;
      b.cx += dx * push;
      b.cy += dy * push;

      let k = 18 * (Math.random()-0.5);
      a.kick += k;
      b.kick -= k;
    }
  }

  function collideBalls(a,b){
    let dx=b.x-a.x, dy=b.y-a.y;
    let dist=Math.sqrt(dx*dx+dy*dy), minDist=BALL_R*2;
    if(dist>0 && dist<minDist){
      dx/=dist; dy/=dist;
      let pa=a.vx*dx+a.vy*dy, pb=b.vx*dx+b.vy*dy;
      a.vx+=(pb-pa)*dx; a.vy+=(pb-pa)*dy;
      b.vx+=(pa-pb)*dx; b.vy+=(pa-pb)*dy;
      let overlap=(minDist-dist)/2;
      a.x-=dx*overlap; a.y-=dy*overlap;
      b.x+=dx*overlap; b.y+=dy*overlap;
      let s=12*(Math.random()-0.523);
      a.spin+=s; b.spin-=s;
    }
  }

  function updateAll(){
    for(let i=0;i<BALL_COUNT;i++){
      let b=balls[i];

      b.x+=b.vx; 
      b.y+=b.vy;

      if(Math.abs(b.spin)>0.01){ 
        b.angle+=b.spin; 
        b.spin*=0.9 
      } else b.spin=0;

      bounceRect(b,BALL_R);
      for(let j=i+1;j<BALL_COUNT;j++) collideBalls(b,balls[j]);

      ballWidgets[i].setProperty(hmUI.prop.X,b.x-BALL_R);
      ballWidgets[i].setProperty(hmUI.prop.Y,b.y-BALL_R);
      ballWidgets[i].setProperty(hmUI.prop.ROTATE,b.angle);

      let g = digitGroups[i];
      let gap = DIGIT_GAPS[i];

      g.angle += g.kick;
      g.kick *= 0.82;

      let bx = b.x + BALL_R + 6;
      let by = b.y - g.size/2;

      g.cx = bx + g.size;
      g.cy = by + g.size/2;

      g.imgs[0].setProperty(hmUI.prop.X,bx);
      g.imgs[0].setProperty(hmUI.prop.Y,by);
      g.imgs[1].setProperty(hmUI.prop.X,bx + g.size + gap);
      g.imgs[1].setProperty(hmUI.prop.Y,by);

      g.imgs[0].setProperty(hmUI.prop.ROTATE,g.angle);
      g.imgs[1].setProperty(hmUI.prop.ROTATE,g.angle);

      bounceDigitOnRect(g, i);
    }

    for (let i = 0; i < digitGroups.length; i++) {
      for (let j = i + 1; j < digitGroups.length; j++) {
        collideDigits(digitGroups[i], digitGroups[j]);
      }
    }
  }

function updateTime(){
  let h = timeSensor.hour; // 0–23 เสมอ

  // ตรวจรูปแบบเวลาของระบบ
 
   let time2412 = hmSensor.createSensor(hmSensor.id.TIME);

if (!time2412.is24Hour){
    if (h === 0) h = 12;        // 00:xx -> 12:xx AM
    else if (h > 12) h -= 12;  // 13–23 -> 1–11 PM
  }

  setTwoDigits(digitGroups[0], h,               0);
  setTwoDigits(digitGroups[1], timeSensor.minute, 1);
  setTwoDigits(digitGroups[2], timeSensor.second, 2);
}

  initBalls();

  for(let i=0;i<BALL_COUNT;i++){
    let w=hmUI.createWidget(hmUI.widget.IMG,{
      x:balls[i].x-BALL_R,
      y:balls[i].y-BALL_R,
      w:BALL_R*2,
      h:BALL_R*2,
      src:BALL_FILES[i]
    });
    w.setProperty(hmUI.prop.CENTER_X,BALL_R);
    w.setProperty(hmUI.prop.CENTER_Y,BALL_R);
    ballWidgets.push(w);
  }

  digitGroups.push(createDigitGroup(0));
  digitGroups.push(createDigitGroup(1));
  digitGroups.push(createDigitGroup(2));

  updateTime();
  timer.createTimer(0,30,updateAll);
  timer.createTimer(0,1000,updateTime);
}
            // end user_script.js


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 205,
              minute_startY: 167,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: -18,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 10,
              hour_startY: 167,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: -18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 188,
              y: 145,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 101,
              y: 338,
              w: 175,
              h: 38,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 271,
              y: 279,
              w: 54,
              h: 40,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 100,
              y: 337,
              w: 175,
              h: 39,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 132,
              y: 280,
              w: 46,
              h: 46,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 28,
              y: 14,
              w: 64,
              h: 61,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 279,
              w: 55,
              h: 48,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 337,
              y: 278,
              w: 52,
              h: 41,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 201,
              y: 9,
              w: 50,
              h: 50,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 304,
              y: 9,
              w: 50,
              h: 50,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 357,
              y: 336,
              w: 38,
              h: 52,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 299,
              y: 344,
              w: 38,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_StepsCal()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 6,
              y: 278,
              w: 117,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 5,
              y: 224,
              w: 272,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 6,
              y: 349,
              w: 74,
              h: 32,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if ( cc == 0) {
UpdateElemente2One()
cc = 1
}
            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 14;
                  let start_y_normal_battery = 320;
                  let lenght_ls_normal_battery = 54;
                  let line_width_ls_normal_battery = 4;
                  let color_ls_normal_battery = 0xFF77E86C;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}