﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let normal_heart_rate_linear_scale = ''
    let idle_heart_rate_linear_scale = ''
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_bio_charge_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_pai_day_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_bio_charge_text_text_img = ''
        let idle_spo2_text_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_linear_scale = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_pai_day_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 10,
              y: 167,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 9,
              y: 121,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 359,
              y: 123,
              font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'unit_small_bpm.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 123,
              font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'unit_small_bpm.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 349,
              y: 39,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 169,
              y: 474,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'pointer_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 202,
              y: 41,
              image_array: ["Weather_image_01.png","Weather_image_02.png","Weather_image_03.png","Weather_image_04.png","Weather_image_05.png","Weather_image_06.png","Weather_image_07.png","Weather_image_08.png","Weather_image_09.png","Weather_image_10.png","Weather_image_11.png","Weather_image_12.png","Weather_image_13.png","Weather_image_14.png","Weather_image_15.png","Weather_image_16.png","Weather_image_17.png","Weather_image_18.png","Weather_image_19.png","Weather_image_20.png","Weather_image_21.png","Weather_image_22.png","Weather_image_23.png","Weather_image_24.png","Weather_image_25.png","Weather_image_26.png","Weather_image_27.png","Weather_image_28.png","Weather_image_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 56,
              font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_unit.png',
              unit_tc: 'Temp_unit.png',
              unit_en: 'Temp_unit.png',
              imperial_unit_sc: 'Temp_unit.png',
              imperial_unit_tc: 'Temp_unit.png',
              imperial_unit_en: 'Temp_unit.png',
              negative_image: 'Temp_minus.png',
              invalid_image: 'unit_small_bpm.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 260,
                y: 56,
                font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Temp_unit.png',
                unit_tc: 'Temp_unit.png',
                unit_en: 'Temp_unit.png',
                imperial_unit_sc: 'Temp_unit.png',
                imperial_unit_tc: 'Temp_unit.png',
                imperial_unit_en: 'Temp_unit.png',
                negative_image: 'Temp_minus.png',
                invalid_image: 'unit_small_bpm.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 17,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 285,
              // start_y: 22,
              // color: 0xFFFFFFFF,
              // lenght: 18,
              // line_width: 7,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 201,
              month_startY: 10,
              month_sc_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              month_tc_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              month_en_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 186,
              y: 9,
              src: 'pointer_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 140,
              day_startY: 10,
              day_sc_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              day_tc_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              day_en_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 50,
              y: 16,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 319,
              y: 419,
              font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 419,
              font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 162,
              y: 419,
              font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 151,
              y: 453,
              image_array: ["img_step_1.png","img_step_2.png","img_step_3.png","img_step_4.png","img_step_5.png","img_step_6.png","img_step_7.png","img_step_8.png","img_step_9.png","img_step_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 248,
              y: 177,
              font_array: ["num_bpm_0.png","num_bpm_1.png","num_bpm_2.png","num_bpm_3.png","num_bpm_4.png","num_bpm_5.png","num_bpm_6.png","num_bpm_7.png","num_bpm_8.png","num_bpm_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'unit_bpm.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 35,
              minute_startY: 133,
              minute_array: ["Time_M_Font_0.png","Time_M_Font_1.png","Time_M_Font_2.png","Time_M_Font_3.png","Time_M_Font_4.png","Time_M_Font_5.png","Time_M_Font_6.png","Time_M_Font_7.png","Time_M_Font_8.png","Time_M_Font_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 34,
              hour_startY: 41,
              hour_array: ["Time_H_Font_0.png","Time_H_Font_1.png","Time_H_Font_2.png","Time_H_Font_3.png","Time_H_Font_4.png","Time_H_Font_5.png","Time_H_Font_6.png","Time_H_Font_7.png","Time_H_Font_8.png","Time_H_Font_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 10,
              y: 167,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 9,
              y: 121,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 359,
              y: 123,
              font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'unit_small_bpm.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 123,
              font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'unit_small_bpm.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 349,
              y: 39,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 169,
              y: 474,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'pointer_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 202,
              y: 41,
              image_array: ["Weather_image_01.png","Weather_image_02.png","Weather_image_03.png","Weather_image_04.png","Weather_image_05.png","Weather_image_06.png","Weather_image_07.png","Weather_image_08.png","Weather_image_09.png","Weather_image_10.png","Weather_image_11.png","Weather_image_12.png","Weather_image_13.png","Weather_image_14.png","Weather_image_15.png","Weather_image_16.png","Weather_image_17.png","Weather_image_18.png","Weather_image_19.png","Weather_image_20.png","Weather_image_21.png","Weather_image_22.png","Weather_image_23.png","Weather_image_24.png","Weather_image_25.png","Weather_image_26.png","Weather_image_27.png","Weather_image_28.png","Weather_image_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 56,
              font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_unit.png',
              unit_tc: 'Temp_unit.png',
              unit_en: 'Temp_unit.png',
              imperial_unit_sc: 'Temp_unit.png',
              imperial_unit_tc: 'Temp_unit.png',
              imperial_unit_en: 'Temp_unit.png',
              negative_image: 'Temp_minus.png',
              invalid_image: 'unit_small_bpm.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 260,
                y: 56,
                font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Temp_unit.png',
                unit_tc: 'Temp_unit.png',
                unit_en: 'Temp_unit.png',
                imperial_unit_sc: 'Temp_unit.png',
                imperial_unit_tc: 'Temp_unit.png',
                imperial_unit_en: 'Temp_unit.png',
                negative_image: 'Temp_minus.png',
                invalid_image: 'unit_small_bpm.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 17,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 285,
              // start_y: 22,
              // color: 0xFFFFFFFF,
              // lenght: 18,
              // line_width: 7,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 201,
              month_startY: 10,
              month_sc_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              month_tc_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              month_en_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 186,
              y: 9,
              src: 'pointer_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 140,
              day_startY: 10,
              day_sc_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              day_tc_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              day_en_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 50,
              y: 16,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 319,
              y: 419,
              font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 419,
              font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 162,
              y: 419,
              font_array: ["small_bpm_0.png","small_bpm_1.png","small_bpm_2.png","small_bpm_3.png","small_bpm_4.png","small_bpm_5.png","small_bpm_6.png","small_bpm_7.png","small_bpm_8.png","small_bpm_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 151,
              y: 453,
              image_array: ["img_step_1.png","img_step_2.png","img_step_3.png","img_step_4.png","img_step_5.png","img_step_6.png","img_step_7.png","img_step_8.png","img_step_9.png","img_step_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 248,
              y: 177,
              font_array: ["num_bpm_0.png","num_bpm_1.png","num_bpm_2.png","num_bpm_3.png","num_bpm_4.png","num_bpm_5.png","num_bpm_6.png","num_bpm_7.png","num_bpm_8.png","num_bpm_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'unit_bpm.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 35,
              minute_startY: 133,
              minute_array: ["Time_M_Font_0.png","Time_M_Font_1.png","Time_M_Font_2.png","Time_M_Font_3.png","Time_M_Font_4.png","Time_M_Font_5.png","Time_M_Font_6.png","Time_M_Font_7.png","Time_M_Font_8.png","Time_M_Font_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 34,
              hour_startY: 41,
              hour_array: ["Time_H_Font_0.png","Time_H_Font_1.png","Time_H_Font_2.png","Time_H_Font_3.png","Time_H_Font_4.png","Time_H_Font_5.png","Time_H_Font_6.png","Time_H_Font_7.png","Time_H_Font_8.png","Time_H_Font_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 395,
              w: 127,
              h: 99,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 37,
              y: 395,
              w: 88,
              h: 85,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 194,
              y: 168,
              w: 227,
              h: 54,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 309,
              y: 393,
              w: 92,
              h: 97,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 281,
              y: 2,
              w: 145,
              h: 35,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 350,
              y: 40,
              w: 48,
              h: 50,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 259,
              y: 48,
              w: 72,
              h: 49,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 191,
              y: 107,
              w: 110,
              h: 49,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 64,
              y: 145,
              w: 74,
              h: 65,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 63,
              y: 54,
              w: 72,
              h: 70,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 1,
              y: 82,
              w: 41,
              h: 106,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 38,
              y: 0,
              w: 227,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 307,
              y: 109,
              w: 123,
              h: 51,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if (normal_heart_rate_linear_scale) {
          normal_heart_rate_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
        }

        if (idle_heart_rate_linear_scale) {
          idle_heart_rate_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
        }

        const customHeartRate = hmSensor.createSensor(hmSensor.id.HEART);

        // =========================
        // CONFIG & OPTIMIZATION FOR REAL WATCH
        // =========================
        const heartCurveColor = 0xFFFE575E;
        const heartFillColor = 0x652225;         

        const heartCurveX = 59;
        const heartCurveY = 231;
        const heartCurveHeight = 120;

        const heartCurveCount = 34;
        const heartCurveStep = 10;
        const heartCurvePointSize = 6;
        const heartLineWidth = 4;

        let heartCurveHistory = [];
        let lastDrawnHeartRate = null; // เก็บค่าที่วาดไปล่าสุดเพื่อเช็กค่าซ้ำ

        // =========================
        // CREATE MINIMAL WIDGETS
        // =========================
        // 1. Points
        let heartCurvePoints = [];
        for (let i = 0; i < heartCurveCount; i++) {
          const point = hmUI.createWidget(hmUI.widget.FILL_RECT, {
            x: heartCurveX + i * heartCurveStep,
            y: heartCurveY + heartCurveHeight,
            w: heartCurvePointSize,
            h: heartCurvePointSize,
            color: heartCurveColor,
              alpha: 90,
            show_level: hmUI.show_level.ONLY_NORMAL
          });
          point.setProperty(hmUI.prop.VISIBLE, false);
          heartCurvePoints.push(point);
        }

        // 2. Lines (2 slices/segment)
        const lineSlicesPerSegment = 3;
        let heartCurveLines = [];
        for (let i = 0; i < heartCurveCount - 1; i++) {
          let segment = [];
          for (let s = 0; s < lineSlicesPerSegment; s++) {
            const line = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: heartCurveX + i * heartCurveStep,
              y: heartCurveY + heartCurveHeight,
              w: 5,
              h: heartLineWidth,
              color: heartCurveColor,
              show_level: hmUI.show_level.ONLY_NORMAL
            });
            line.setProperty(hmUI.prop.VISIBLE, false);
            segment.push(line);
          }
          heartCurveLines.push(segment);
        }

        // 3. Fills (2 slices/segment)
        let heartCurveFills = [];
        for (let i = 0; i < heartCurveCount - 1; i++) {
          let segment = [];
          for (let s = 0; s < lineSlicesPerSegment; s++) {
            const fill = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: heartCurveX + i * heartCurveStep,
              y: heartCurveY + heartCurveHeight,
              w: 5,
              h: 1,
              color: heartFillColor,
              alpha: 90,
              show_level: hmUI.show_level.ONLY_NORMAL
            });
            fill.setProperty(hmUI.prop.VISIBLE, false);
            segment.push(fill);
          }
          heartCurveFills.push(segment);
        }

        // 4. Marker
        const heartCurveMarker = hmUI.createWidget(hmUI.widget.IMG, {
          x: heartCurveX + (heartCurveCount - 1) * heartCurveStep - 8,
          y: heartCurveY + heartCurveHeight - 8,
          src: 'heart_marker.png',
          show_level: hmUI.show_level.ONLY_NORMAL
        });
        heartCurveMarker.setProperty(hmUI.prop.VISIBLE, false);

        function getHeartY(heartRate) {
          const normalizedValue = Math.max(0, Math.min(1, heartRate / 180));
          return (
            heartCurveY +
            heartCurveHeight -
            Math.round(normalizedValue * heartCurveHeight)
          );
        }

        function updateHeartCurve() {
          let currentHeartRate = customHeartRate.current || customHeartRate.last;

          if (!currentHeartRate || currentHeartRate <= 0) {
            if (typeof customHeartRate.getToday === 'function') {
              const todayData = customHeartRate.getToday();
              if (todayData && todayData.length > 0) {
                currentHeartRate = todayData[todayData.length - 1];
              }
            }
          }

          if (!currentHeartRate || currentHeartRate <= 0) {
            return;
          }

          // ----------------------------------------------------
          // CHECK DUPLICATE: ถ้าค่าเท่าเดิม ให้ข้ามการวาดทันที
          // ----------------------------------------------------
          if (currentHeartRate === lastDrawnHeartRate) {
            return;
          }

          // อัปเดตค่าล่าสุดไว้สำหรับเช็กครั้งถัดไป
          lastDrawnHeartRate = currentHeartRate;

          heartCurveHistory.push(currentHeartRate);

          if (heartCurveHistory.length > heartCurveCount) {
            heartCurveHistory.shift();
          }

          const historyLen = heartCurveHistory.length;

          // Hide All
          for (let i = 0; i < heartCurveCount; i++) {
            heartCurvePoints[i].setProperty(hmUI.prop.VISIBLE, false);
          }
          for (let i = 0; i < heartCurveCount - 1; i++) {
            for (let s = 0; s < lineSlicesPerSegment; s++) {
              heartCurveLines[i][s].setProperty(hmUI.prop.VISIBLE, false);
              heartCurveFills[i][s].setProperty(hmUI.prop.VISIBLE, false);
            }
          }

          // Draw Points
          for (let i = 0; i < historyLen; i++) {
            const slotIndex = (heartCurveCount - historyLen) + i;
            const heartRate = heartCurveHistory[i];
            const pointY = getHeartY(heartRate);
            const pointX = heartCurveX + slotIndex * heartCurveStep;

            const point = heartCurvePoints[slotIndex];
            point.setProperty(hmUI.prop.MORE, {
              x: pointX,
              y: pointY,
              w: heartCurvePointSize,
              h: heartCurvePointSize,
              color: heartCurveColor
            });
            point.setProperty(hmUI.prop.VISIBLE, true);
          }

          // Draw Lines & Fills
          for (let i = 0; i < historyLen - 1; i++) {
            const slotIndex = (heartCurveCount - historyLen) + i;
            const y1 = getHeartY(heartCurveHistory[i]);
            const y2 = getHeartY(heartCurveHistory[i + 1]);
            const x1 = heartCurveX + slotIndex * heartCurveStep;
            const dy = y2 - y1;
            const bottom = heartCurveY + heartCurveHeight;

            for (let s = 0; s < lineSlicesPerSegment; s++) {
              const progress = s / (lineSlicesPerSegment - 1);
              const x = x1 + Math.round(progress * heartCurveStep);
              const y = y1 + Math.round(progress * dy);

              const line = heartCurveLines[slotIndex][s];
              line.setProperty(hmUI.prop.MORE, {
                x: x,
                y: y - Math.floor(heartLineWidth / 2),
                w: 6,
                h: heartLineWidth,
                color: heartCurveColor
              });
              line.setProperty(hmUI.prop.VISIBLE, true);

              const fillHeight = bottom - y;
              if (fillHeight > 0) {
                const fill = heartCurveFills[slotIndex][s];
                fill.setProperty(hmUI.prop.MORE, {
                  x: x,
                  y: y,
                  w: 6,
                  h: fillHeight,
                  color: heartFillColor
                });
                fill.setProperty(hmUI.prop.VISIBLE, true);
              }
            }
          }

          // Draw Marker
          if (historyLen > 0) {
            const lastHeartRate = heartCurveHistory[historyLen - 1];
            const markerY = getHeartY(lastHeartRate);
            const markerX = heartCurveX + (heartCurveCount - 1) * heartCurveStep - 8;

            heartCurveMarker.setProperty(hmUI.prop.MORE, {
              x: markerX,
              y: markerY - 8
            });
            heartCurveMarker.setProperty(hmUI.prop.VISIBLE, true);
          }
        }

        // Event Listener
        customHeartRate.addEventListener(
          hmSensor.event.CHANGE,
          function () {
            updateHeartCurve();
          }
        );

        // Initial Exec
        updateHeartCurve();
            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 285;
                  let start_y_normal_battery = 22;
                  let lenght_ls_normal_battery = 18;
                  let line_width_ls_normal_battery = 7;
                  let color_ls_normal_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 285;
                  let start_y_idle_battery = 22;
                  let lenght_ls_idle_battery = 18;
                  let line_width_ls_idle_battery = 7;
                  let color_ls_idle_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();

                console.log('resume_call.js');
                // start resume_call.js

updateHeartCurve();
                // end resume_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}