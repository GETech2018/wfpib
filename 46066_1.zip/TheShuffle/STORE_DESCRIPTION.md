The Shuffle: a newspaper for your wrist.

Every day the paper renames itself (Monday Mumble, Friday Flyer, Saturday Shuffle...), writes a headline from your own data ("Big effort reported: heart at 158", "Resident sleeps 8:25, wakes legendary"), and prints a hopeful quote from a different tradition.

• Weather photo that changes with the weather, high/low, condition, moon
• Time with seconds, week line that fills through the day
• Hybrid Charge, zone-coloured heart rate, sleep incl. naps, stress
• Steps + distance, PAI with today's gain, VO₂ max, calories, fat burn
• Humidity, UV, air quality, next sunrise/sunset
• Days left in the month and year
• Alarm and a 5-segment battery that drains smoothly within each segment (yellow at 40%, red at 20%)
• Full-screen layout, plus an always-on display that mirrors the page
• Taps: weather photo or weather box → Weather · Moon or sunset/sunrise → Sun & Moon · Charge → Hybrid Charge · Heart → Heart rate · Slept → Sleep · Stress → Stress · Steps → Steps · PAI → PAI · VO₂ → VO₂ max · Calories → Calories · Alarm → Alarms · Battery → Battery

Made for Amazfit Bip 6.
