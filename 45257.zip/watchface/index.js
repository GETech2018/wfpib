try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var e = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );

    "use strict";

    // Widget variables
    let h = "";   // IMG widget (x:16)
    let a = "";   // IMG widget (x:129)
    let _ = "";   // IMG widget (x:185)
    let s = "";   // IMG widget (x:242)
    let r = "";   // IMG widget (x:299)
    let o = "";   // IMG widget (x:355)
    let I = "";   // IMG_TIME - hour
    let m = "";   // IMG_TIME - minute
    let i = "";   // IMG_TIME - second
    let w = "";   // IMG separator
    let c = "";   // IMG_WEEK
    let U = "";   // IMG_DATE - month
    let d = "";   // IMG_DATE - day
    let L = "";   // TEXT_IMG - step count
    let v = "";   // IMG_LEVEL - step
    let y = "";   // IMG - step bg
    let N = "";   // IMG - step icon
    let M = "";   // TEXT_IMG - distance
    let O = "";   // IMG - distance level img
    let A = [     // Step level images
      "0067.png", "0068.png", "0069.png", "0070.png", "0071.png",
      "0072.png", "0073.png", "0074.png", "0075.png", "0076.png", "0077.png"
    ];
    let f = "";   // IMG - distance bg
    let u = "";   // IMG - distance icon
    let x = "";   // TEXT_IMG - calories
    let E = "";   // IMG_LEVEL - calories
    let R = "";   // IMG - calories bg
    let Y = "";   // IMG - calories icon
    let G = "";   // TEXT_IMG - battery
    let W = "";   // IMG_LEVEL - battery
    let T = "";   // IMG - battery bg
    let b = "";   // IMG - battery icon
    let S = "";   // IMG - second hand
    let D;        // Interval ID
    let F = "";   // IMG - clock bg outer
    let X = "";   // IMG - clock bg inner
    let k = "";   // IMG - minute hand
    let C = "";   // IMG - hour hand
    let P = "";   // BUTTON - calendar
    let j = "";   // BUTTON - sport list

    const n = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

      init_view() {
        const e = hmSensor.createSensor(hmSensor.id.TIME);
        const n = hmSensor.createSensor(hmSensor.id.DISTANCE);
        let g = hmSetting.getScreenType();

        // ── Decorative bar widgets ──────────────────────────────────────
        h = hmUI.createWidget(hmUI.widget.IMG, {
          x: 16, y: 189, w: 52, h: 13,
          src: "0002.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        a = hmUI.createWidget(hmUI.widget.IMG, {
          x: 129, y: 189, w: 52, h: 13,
          src: "0002.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        _ = hmUI.createWidget(hmUI.widget.IMG, {
          x: 185, y: 189, w: 52, h: 13,
          src: "0003.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        s = hmUI.createWidget(hmUI.widget.IMG, {
          x: 242, y: 189, w: 52, h: 13,
          src: "0004.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        r = hmUI.createWidget(hmUI.widget.IMG, {
          x: 299, y: 189, w: 52, h: 13,
          src: "0005.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        o = hmUI.createWidget(hmUI.widget.IMG, {
          x: 355, y: 189, w: 52, h: 13,
          src: "0006.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        // ── Time display ────────────────────────────────────────────────
        I = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_startX: 64,
          hour_startY: 51,
          hour_array: [
            "0007.png", "0008.png", "0009.png", "0010.png", "0011.png",
            "0012.png", "0013.png", "0014.png", "0015.png", "0016.png"
          ],
          hour_zero: true,
          hour_space: -2,
          hour_align: hmUI.align.LEFT,
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        m = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          minute_startX: 192,
          minute_startY: 51,
          minute_array: [
            "0007.png", "0008.png", "0009.png", "0010.png", "0011.png",
            "0012.png", "0013.png", "0014.png", "0015.png", "0016.png"
          ],
          minute_zero: true,
          minute_space: -2,
          minute_align: hmUI.align.LEFT,
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        i = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          second_startX: 305,
          second_startY: 97,
          second_array: [
            "0017.png", "0018.png", "0019.png", "0020.png", "0021.png",
            "0022.png", "0023.png", "0024.png", "0025.png", "0026.png"
          ],
          second_zero: true,
          second_space: 0,
          second_align: hmUI.align.LEFT,
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        // ── Separator image ─────────────────────────────────────────────
        w = hmUI.createWidget(hmUI.widget.IMG, {
          x: 165, y: 40, w: 28, h: 119,
          src: "0027.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        // ── Weekday ─────────────────────────────────────────────────────
        c = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 74, y: 181,
          week_en: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
          week_tc: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
          week_sc: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        // ── Date ────────────────────────────────────────────────────────
        U = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 11,
          month_startY: 233,
          month_sc_array: [
            "0035.png","0036.png","0037.png","0038.png","0039.png","0040.png",
            "0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"
          ],
          month_tc_array: [
            "0035.png","0036.png","0037.png","0038.png","0039.png","0040.png",
            "0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"
          ],
          month_en_array: [
            "0035.png","0036.png","0037.png","0038.png","0039.png","0040.png",
            "0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"
          ],
          month_is_character: true,
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        d = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 114,
          day_startY: 234,
          day_sc_array: [
            "0047.png","0048.png","0049.png","0050.png","0051.png",
            "0052.png","0053.png","0054.png","0055.png","0056.png"
          ],
          day_tc_array: [
            "0047.png","0048.png","0049.png","0050.png","0051.png",
            "0052.png","0053.png","0054.png","0055.png","0056.png"
          ],
          day_en_array: [
            "0047.png","0048.png","0049.png","0050.png","0051.png",
            "0052.png","0053.png","0054.png","0055.png","0056.png"
          ],
          day_zero: true,
          day_space: -4,
          day_align: hmUI.align.LEFT,
          day_is_character: false,
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        // ── Step count ──────────────────────────────────────────────────
        L = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 68, y: 315,
          font_array: [
            "0057.png","0058.png","0059.png","0060.png","0061.png",
            "0062.png","0063.png","0064.png","0065.png","0066.png"
          ],
          padding: false,
          h_space: -3,
          align_h: hmUI.align.LEFT,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        v = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 128, y: 329,
          image_array: A,
          image_length: 11,
          type: hmUI.data_type.STEP,
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        y = hmUI.createWidget(hmUI.widget.IMG, {
          x: 128, y: 329, w: 67, h: 11,
          src: "0078.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        N = hmUI.createWidget(hmUI.widget.IMG, {
          x: 30, y: 316, w: 27, h: 23,
          src: "0079.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        // ── Distance ────────────────────────────────────────────────────
        M = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 68, y: 354,
          font_array: [
            "0080.png","0081.png","0082.png","0083.png","0084.png",
            "0085.png","0086.png","0087.png","0088.png","0089.png"
          ],
          padding: false,
          h_space: -3,
          dot_image: "0090.png",
          align_h: hmUI.align.LEFT,
          type: hmUI.data_type.DISTANCE,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        O = hmUI.createWidget(hmUI.widget.IMG, {
          x: 128, y: 367, w: 128, h: 367,
          src: "0077.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        f = hmUI.createWidget(hmUI.widget.IMG, {
          x: 128, y: 367, w: 67, h: 11,
          src: "0078.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        u = hmUI.createWidget(hmUI.widget.IMG, {
          x: 34, y: 355, w: 19, h: 26,
          src: "0091.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        // ── Calories ────────────────────────────────────────────────────
        x = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 68, y: 393,
          font_array: [
            "0080.png","0081.png","0082.png","0083.png","0084.png",
            "0085.png","0086.png","0087.png","0088.png","0089.png"
          ],
          padding: false,
          h_space: -3,
          align_h: hmUI.align.LEFT,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        E = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 128, y: 406,
          image_array: A,
          image_length: 11,
          type: hmUI.data_type.CAL,
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        R = hmUI.createWidget(hmUI.widget.IMG, {
          x: 128, y: 406, w: 67, h: 11,
          src: "0078.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        Y = hmUI.createWidget(hmUI.widget.IMG, {
          x: 29, y: 393, w: 27, h: 27,
          src: "0092.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        // ── Battery ─────────────────────────────────────────────────────
        G = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 68, y: 432,
          font_array: [
            "0080.png","0081.png","0082.png","0083.png","0084.png",
            "0085.png","0086.png","0087.png","0088.png","0089.png"
          ],
          padding: false,
          h_space: -3,
          unit_sc: "0093.png",
          unit_tc: "0093.png",
          unit_en: "0093.png",
          align_h: hmUI.align.LEFT,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        W = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 128, y: 445,
          image_array: A,
          image_length: 11,
          type: hmUI.data_type.BATTERY,
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        T = hmUI.createWidget(hmUI.widget.IMG, {
          x: 128, y: 445, w: 67, h: 11,
          src: "0078.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        b = hmUI.createWidget(hmUI.widget.IMG, {
          x: 27, y: 431, w: 30, h: 30,
          src: "0094.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        // ── Analog clock hands ──────────────────────────────────────────
        S = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0, y: 0, w: 433, h: 502,
          center_x: 321, center_y: 367,
          pos_x: 310, pos_y: 457,
          src: "0095.png",
          enable: false,
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        F = hmUI.createWidget(hmUI.widget.IMG, {
          x: 232, y: 278, w: 178, h: 178,
          src: "0096.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        X = hmUI.createWidget(hmUI.widget.IMG, {
          x: 283, y: 330, w: 74, h: 74,
          src: "0097.png",
          enable: false,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        k = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0, y: 0, w: 433, h: 502,
          center_x: 321, center_y: 367,
          pos_x: 310, pos_y: 260,
          src: "0098.png",
          enable: false,
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        C = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0, y: 0, w: 433, h: 502,
          center_x: 321, center_y: 367,
          pos_x: 310, pos_y: 274,
          src: "0099.png",
          enable: false,
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        // ── Tap buttons ─────────────────────────────────────────────────
        P = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 27, y: 174, w: 125, h: 125,
          text: "",
          normal_src: "",
          press_src: "",
          click_func: () => {
            hmApp.startApp({ url: "ScheduleCalScreen", native: true });
          },
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        j = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 36, y: 309, w: 165, h: 165,
          text: "",
          normal_src: "",
          press_src: "",
          click_func: () => {
            hmApp.startApp({ url: "SportListScreen", native: true });
          },
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        // ── Clock hand rotation ─────────────────────────────────────────
        function t() {
          if (S) S.setProperty(hmUI.prop.ANGLE, 0 + e.second * (6 * 1));
          if (k) k.setProperty(hmUI.prop.ANGLE, 0 + e.minute * (6 * 1));
          if (C) C.setProperty(
            hmUI.prop.ANGLE,
            0 + parseInt(e.hour % 12 || 12) * (30 * 1) + e.minute / 60 * (30 * 1)
          );
        }

        // ── Step level image update ─────────────────────────────────────
        function l() {
          O.setProperty(hmUI.prop.MORE, {
            src: A[Math.floor(A.length * (n.current / (isNaN(n.target) ? 1e4 : n.target)))]
          });
        }

        // ── Sensor listeners ────────────────────────────────────────────
        e.addEventListener(hmSensor.event.CHANGE, function () { t(); });
        n.addEventListener(hmSensor.event.CHANGE, function () { l(); });

        // ── Resume / pause delegate ─────────────────────────────────────
        const p = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: function () {
            t();
            l();
            D = setInterval(t, 1e3);
          },
          pause_call: function () {
            clearInterval(D);
          }
        });
      },

      onInit()    { console.log("index page.js on init invoke");    this.init_view(); },
      onReady()   { console.log("index page.js on ready invoke");   },
      onShow()    { console.log("index page.js on show invoke");    },
      onHide()    { console.log("index page.js on hide invoke");    },
      onDestroy() { console.log("index page.js on destroy invoke"); }
    });
  })();
} catch (e) {
  console.log(e);
}