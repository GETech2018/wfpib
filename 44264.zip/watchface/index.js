﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */

    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start


        let normal_background_bg = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_pai_day_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start


            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 380,
              font_array: ["f27_0.png","f27_1.png","f27_2.png","f27_3.png","f27_4.png","f27_5.png","f27_6.png","f27_7.png","f27_8.png","f27_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 84,
              y: 380,
              src: 'f27_colon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 19,
              y: 380,
              font_array: ["f27_0.png","f27_1.png","f27_2.png","f27_3.png","f27_4.png","f27_5.png","f27_6.png","f27_7.png","f27_8.png","f27_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 315,
              font_array: ["f27_0.png","f27_1.png","f27_2.png","f27_3.png","f27_4.png","f27_5.png","f27_6.png","f27_7.png","f27_8.png","f27_9.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'f27_km.png',
              unit_tc: 'f27_km.png',
              unit_en: 'f27_km.png',
              dot_image: 'f27_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 38,
              y: 315,
              font_array: ["f27_0.png","f27_1.png","f27_2.png","f27_3.png","f27_4.png","f27_5.png","f27_6.png","f27_7.png","f27_8.png","f27_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 163,
              y: 315,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              y: 248,
              font_array: ["f27_0.png","f27_1.png","f27_2.png","f27_3.png","f27_4.png","f27_5.png","f27_6.png","f27_7.png","f27_8.png","f27_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'f27_colon.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 178,
              y: 248,
              src: 'sun.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 248,
              font_array: ["f27_0.png","f27_1.png","f27_2.png","f27_3.png","f27_4.png","f27_5.png","f27_6.png","f27_7.png","f27_8.png","f27_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'f27_colon.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 25,
              hour_startY: 143,
              hour_array: ["f70_0.png","f70_1.png","f70_2.png","f70_3.png","f70_4.png","f70_5.png","f70_6.png","f70_7.png","f70_8.png","f70_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 160,
              minute_startY: 143,
              minute_array: ["f70_0.png","f70_1.png","f70_2.png","f70_3.png","f70_4.png","f70_5.png","f70_6.png","f70_7.png","f70_8.png","f70_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 285,
              second_startY: 166,
              second_array: ["f46_0.png","f46_1.png","f46_2.png","f46_3.png","f46_4.png","f46_5.png","f46_6.png","f46_7.png","f46_8.png","f46_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 135,
              y: 143,
              src: 'f70_colon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 269,
              y: 82,
              week_en: ["f27_week0.png","f27_week1.png","f27_week2.png","f27_week3.png","f27_week4.png","f27_week5.png","f27_week6.png"],
              week_tc: ["f27_week0.png","f27_week1.png","f27_week2.png","f27_week3.png","f27_week4.png","f27_week5.png","f27_week6.png"],
              week_sc: ["f27_week0.png","f27_week1.png","f27_week2.png","f27_week3.png","f27_week4.png","f27_week5.png","f27_week6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 138,
              year_startY: 82,
              year_sc_array: ["f27_0.png","f27_1.png","f27_2.png","f27_3.png","f27_4.png","f27_5.png","f27_6.png","f27_7.png","f27_8.png","f27_9.png"],
              year_tc_array: ["f27_0.png","f27_1.png","f27_2.png","f27_3.png","f27_4.png","f27_5.png","f27_6.png","f27_7.png","f27_8.png","f27_9.png"],
              year_en_array: ["f27_0.png","f27_1.png","f27_2.png","f27_3.png","f27_4.png","f27_5.png","f27_6.png","f27_7.png","f27_8.png","f27_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 85,
              month_startY: 82,
              month_sc_array: ["f27_0.png","f27_1.png","f27_2.png","f27_3.png","f27_4.png","f27_5.png","f27_6.png","f27_7.png","f27_8.png","f27_9.png"],
              month_tc_array: ["f27_0.png","f27_1.png","f27_2.png","f27_3.png","f27_4.png","f27_5.png","f27_6.png","f27_7.png","f27_8.png","f27_9.png"],
              month_en_array: ["f27_0.png","f27_1.png","f27_2.png","f27_3.png","f27_4.png","f27_5.png","f27_6.png","f27_7.png","f27_8.png","f27_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 127,
              y: 82,
              src: 'f27_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 33,
              day_startY: 82,
              day_sc_array: ["f27_0.png","f27_1.png","f27_2.png","f27_3.png","f27_4.png","f27_5.png","f27_6.png","f27_7.png","f27_8.png","f27_9.png"],
              day_tc_array: ["f27_0.png","f27_1.png","f27_2.png","f27_3.png","f27_4.png","f27_5.png","f27_6.png","f27_7.png","f27_8.png","f27_9.png"],
              day_en_array: ["f27_0.png","f27_1.png","f27_2.png","f27_3.png","f27_4.png","f27_5.png","f27_6.png","f27_7.png","f27_8.png","f27_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 75,
              y: 82,
              src: 'f27_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 15,
              font_array: ["f27_0.png","f27_1.png","f27_2.png","f27_3.png","f27_4.png","f27_5.png","f27_6.png","f27_7.png","f27_8.png","f27_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 253,
              y: 15,
              src: 'power.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 15,
              font_array: ["f27_0.png","f27_1.png","f27_2.png","f27_3.png","f27_4.png","f27_5.png","f27_6.png","f27_7.png","f27_8.png","f27_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 56,
              y: 15,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            // customization => paste after the code generated by Watchface editor

            function create_graph(x, y, max_length, color) {  // create an empty (zero-value) horizontal bar graph
              const height = 10;
              const radius = 4;
              // A) draw full-length basic gray bar => reprezents max value
              hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: x,
                y: y,
                w: max_length,
                h: height,
                radius: radius,
                color: 0x7f7f7f
              });
              // B) create colored bar for the real value
              let graph = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: x,
                y: y,
                w: 0,
                h: height,
                radius: radius,
                color: color
              });
              return graph;
            };
            function update_graph(graph, max_length, value, max_value) {  // update a horizontal bar graph
              let val = Math.min(value, max_value);  // normalization: value may be bigger than max_value (eg. steps)
              let length = val * max_length / max_value;
              graph.setProperty(hmUI.prop.W, length);
            };

            function update_pai_bar(pai_bars, daysback, value, max_value) {  // update a single vertical bar for daily PAI; daysback = 0-6
              // basic params for PAI graph
              const width = 10;
              const space = 10;
              const max_height = 65;
              const bottom_offset = 5;
              const right_offset = 70;
              const screen_height = 450;
              const screen_width = 390;
              // compute bar position: based on the right bottom corner
              let x = screen_width - right_offset - (daysback * (width+space)) - width;
              let height = Math.max(3, max_height * value / max_value);  // always draw at least 3 px high graph (even for zero)
              let y = screen_height - bottom_offset - height;
              // draw colored bar for the current value
              pai_bars[daysback].setProperty(hmUI.prop.MORE, {
                x: x,
                y: y,
                w: width,
                h: height,
                radius: 2,
                color: 0xd653ff
              });
            };

            function draw_gray_line(x, y, rightx) {  // horizontal line, 1px width
              hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: x,
                y: y,
                w: rightx - x,
                h: 1,
                radius: 0,
                color: 0x7f7f7f
              });
            };

            // lines around clock
            draw_gray_line(10, 133, 380);
            draw_gray_line(10, 222, 380);

            // battery graph
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            const battery_graph = create_graph(250, 47, 115, 0x00eb00);
            function update_battery_graph() {
              update_graph(battery_graph, 115, battery.current, 100);
            };
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              update_battery_graph();
            });
            update_battery_graph();

            // steps graph
            const steps = hmSensor.createSensor(hmSensor.id.STEP);
            const steps_graph = create_graph(35, 302, 125, 0x66cacf);
            function update_steps_graph() {
              update_graph(steps_graph, 125, steps.current, steps.target);
            };
            steps.addEventListener(hmSensor.event.CHANGE, function() {
              update_steps_graph();
            });
            update_steps_graph();

            // create PAI graph
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            const pai_bars = [
              hmUI.createWidget(hmUI.widget.FILL_RECT, {x: 0, y: 0, w: 1, h: 1}),
              hmUI.createWidget(hmUI.widget.FILL_RECT, {x: 0, y: 0, w: 1, h: 1}),
              hmUI.createWidget(hmUI.widget.FILL_RECT, {x: 0, y: 0, w: 1, h: 1}),
              hmUI.createWidget(hmUI.widget.FILL_RECT, {x: 0, y: 0, w: 1, h: 1}),
              hmUI.createWidget(hmUI.widget.FILL_RECT, {x: 0, y: 0, w: 1, h: 1}),
              hmUI.createWidget(hmUI.widget.FILL_RECT, {x: 0, y: 0, w: 1, h: 1}),
              hmUI.createWidget(hmUI.widget.FILL_RECT, {x: 0, y: 0, w: 1, h: 1})
            ];
            const pai_scale = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 380  ,
              font_array: ["f27_0.png","f27_1.png","f27_2.png","f27_3.png","f27_4.png","f27_5.png","f27_6.png","f27_7.png","f27_8.png","f27_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL
            });
            // horizontal separating line
            draw_gray_line(185, 375, 380);
            // update PAI graph
            function update_pai_graph() {
              let max_daily_pai = Math.max(1, pai.prepai0, pai.prepai1, pai.prepai2, pai.prepai3, pai.prepai4, pai.prepai5, pai.prepai6);
              pai_scale.setProperty(hmUI.prop.TEXT, max_daily_pai.toString() );  // does not work without conversion to string
              update_pai_bar(pai_bars, 0, pai.prepai6, max_daily_pai);
              update_pai_bar(pai_bars, 1, pai.prepai5, max_daily_pai);
              update_pai_bar(pai_bars, 2, pai.prepai4, max_daily_pai);
              update_pai_bar(pai_bars, 3, pai.prepai3, max_daily_pai);
              update_pai_bar(pai_bars, 4, pai.prepai2, max_daily_pai);
              update_pai_bar(pai_bars, 5, pai.prepai1, max_daily_pai);
              update_pai_bar(pai_bars, 6, pai.prepai0, max_daily_pai);
            };
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              update_pai_graph();
            });
            update_pai_graph();

            // click on date to open the Calendar app
            function open_calendar() {
              hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true });
            };
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 72,
              text: '',
              w: 390,
              h: 60,
              normal_src: 'transparent_img.png',
              press_src: 'transparent_img.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
              click_func: () => {
                open_calendar();
              }
            });
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 10,
              y: 135,
              w: 130,
              h: 82,
              src: 'transparent_img.png',
              type: hmUI.data_type.ALARM_CLOCK
              //Must write.The action to jump.
            })
            // click on hour to open the Alarm app
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 10,
              y: 135,
              w: 130,
              h: 82,
              src: 'transparent_img.png',
              type: hmUI.data_type.ALARM_CLOCK
              //Must write.The action to jump.
            })
            // click on minute to open the Countdown app
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 135,
              w: 110,
              h: 82,
              src: 'transparent_img.png',
              type: hmUI.data_type.COUNT_DOWN
              //Must write.The action to jump.
            })
            // click on second to open the Stopwatch app
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 280,
              y: 133,
              w: 160,
              h: 85,
              src: 'transparent_img.png',
              type: hmUI.data_type.STOP_WATCH
              //Must write.The action to jump.
            })
            // click on sunrize / sunset to open the Sun & Moon app
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 235,
              w: 390,
              h: 80,
              src: 'transparent_img.png',
              type: hmUI.data_type.SUN_RISE
              //Must write.The action to jump.
            })
            // click on PAI to open the PAI app
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 375,
              w: 390,
              h: 75,
              src: 'transparent_img.png',
              type: hmUI.data_type.PAI_DAILY
              //Must write.The action to jump.
            })

            // update all graphs on resume (return to watch from app/widget, CHANGE events may be missed)
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                update_battery_graph();
                update_steps_graph();
                update_pai_graph();
              }),
            });

            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}