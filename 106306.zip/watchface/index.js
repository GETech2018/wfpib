
/*
** huamiOS bundle tool v1.0.17
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/

try {

  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    //drink is a name,can modify
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    'use strict';
    let bg = null;
    let editGroup = null;
    let topText = null;
    let timePointer = null;
    let maskFg = null;
    let maskCover = null;
    let rootPath = "images/";
    let iconPath = rootPath + "icon/";
    let fontArray = [
      rootPath + "font/data_num_0.png",
      rootPath + "font/data_num_1.png",
      rootPath + "font/data_num_2.png",
      rootPath + "font/data_num_3.png",
      rootPath + "font/data_num_4.png",
      rootPath + "font/data_num_5.png",
      rootPath + "font/data_num_6.png",
      rootPath + "font/data_num_7.png",
      rootPath + "font/data_num_8.png",
      rootPath + "font/data_num_9.png",
    ];
    const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");
    let edit_list_config = {
      title_font_size: 34,  // 标题字号的大小
      title_align_h: hmUI.align.CENTER_H,  //标题位置样式(左对齐，居中，右对齐)
      list_item_vspace: 8, // 列表子元素的行间距
      list_tips_text_font_size: 32, //子元素的字号大小
      list_tips_text_align_h: hmUI.align.LEFT, //子元素位置样式(左对齐，居中，右对齐)
    };

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

      init_view() {
        var screenType = hmSetting.getScreenType();
        var nomalModel = screenType == hmSetting.screen_type.APP || screenType == hmSetting.screen_type.WATCHFACE;
        var aodModel = screenType == hmSetting.screen_type.AOD;
        if (nomalModel) {
          bg = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
            x: 0,
            y: 0,
            w: 390,
            h: 450,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            anim_path: rootPath + "anim",
            anim_prefix: "anim",
            anim_ext: "png",
            anim_fps: 20,
            anim_size: 110,
            anim_repeat: false,
            repeat_count: 1,
            anim_status: 1,
            display_on_restart: true,
          });
        } else if (aodModel) {
          bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
            x: 0,
            y: 0,
            w: 390,
            h: 450,
            color: 0x000000,
          });
        }
        let weekPath = ``;
        const language = hmSetting.getLanguage();
        if (language == 1 | language == 0) {
          weekPath = "preview/weekSc.png";
        } else {
          weekPath = "preview/week.png";
        }
        var editConfig = [
          { type: hmUI.edit_type.HEART, preview: rootPath + "preview/heart.png" },
          { type: hmUI.edit_type.PAI_WEEKLY, preview: rootPath + "preview/pai.png", },
          { type: hmUI.edit_type.STEP, preview: rootPath + "preview/step.png" },
          { type: hmUI.edit_type.CAL, preview: rootPath + "preview/cal.png" },
          { type: hmUI.edit_type.SPO2, preview: rootPath + "preview/spo2.png" },
          { type: hmUI.edit_type.WEEK, preview: rootPath + weekPath },
          // { type: hmUI.edit_type.SLEEP, preview: rootPath + "preview/sleep.png" },
          // { type: hmUI.edit_type.TIME, preview: rootPath + "preview/time.png" },
        ];
        editGroup = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
          show_level: hmUI.show_level.ALL,
          edit_id: 101,
          x: 127,
          y: 12,
          w: 136,
          h: 44,
          select_image: rootPath + "edit/select.png",
          un_select_image: rootPath + "edit/select.png",
          default_type: hmUI.edit_type.HEART,
          optional_types: editConfig,
          count: editConfig.length,
          tips_BG: rootPath + "edit/tag.png",
          tips_x: 2,
          tips_y: 60 - 12,
          tips_width: 132,
          tips_margin: 10,
          select_list: edit_list_config
        });
        var editType = editGroup.getProperty(hmUI.prop.CURRENT_TYPE);

        var topProp = {
          x: 0,
          y: 20,
          w: 390,
          h: 28,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          icon_space: 8,
          font_array: fontArray,
        };

        // function jumpApp(type, x = 0, y = 0, w = 133, h = 57) {
        //   hmUI.createWidget(hmUI.widget.IMG_CLICK, {
        //     type,x, y, w, h, //type必写 跳转的action
        //     show_level: hmUI.show_level.ONLY_NORMAL,
        //   });
        // }

        switch (editType) {
          case hmUI.edit_type.HEART:
            topProp.invalid_image = iconPath + "data_none.png";
            topProp.type = hmUI.data_type.HEART;
            topProp.icon = iconPath + "heart.png";
            topText = hmUI.createWidget(hmUI.widget.TEXT_IMG, topProp);
            break;
          case hmUI.edit_type.PAI_WEEKLY:
            topProp.type = hmUI.data_type.PAI_WEEKLY;
            topProp.icon = iconPath + "pai.png";
            topText = hmUI.createWidget(hmUI.widget.TEXT_IMG, topProp);
            break;
          case hmUI.edit_type.STEP:
            topProp.type = hmUI.data_type.STEP;
            topProp.icon = iconPath + "step.png";
            topText = hmUI.createWidget(hmUI.widget.TEXT_IMG, topProp);
            break;
          case hmUI.edit_type.CAL:
            topProp.type = hmUI.data_type.CAL;
            topProp.icon = iconPath + "cal.png";
            topText = hmUI.createWidget(hmUI.widget.TEXT_IMG, topProp);
            break;
          case hmUI.edit_type.SPO2:
            topProp.invalid_image = iconPath + "data_none.png";
            topProp.type = hmUI.data_type.SPO2;
            topProp.icon = iconPath + "spo2.png";
            topProp.unit_en = iconPath + "unit.png";
            topProp.unit_sc = iconPath + "unit.png";
            topProp.unit_tc = iconPath + "unit.png";
            topText = hmUI.createWidget(hmUI.widget.TEXT_IMG, topProp);
            break;
          case hmUI.edit_type.WEEK:
            weekScArray = [
              rootPath + "week_cn/week_1.png",
              rootPath + "week_cn/week_2.png",
              rootPath + "week_cn/week_3.png",
              rootPath + "week_cn/week_4.png",
              rootPath + "week_cn/week_5.png",
              rootPath + "week_cn/week_6.png",
              rootPath + "week_cn/week_7.png",
            ];
            weekEnArray = [
              rootPath + "week_en/week_1.png",
              rootPath + "week_en/week_2.png",
              rootPath + "week_en/week_3.png",
              rootPath + "week_en/week_4.png",
              rootPath + "week_en/week_5.png",
              rootPath + "week_en/week_6.png",
              rootPath + "week_en/week_7.png",
            ];
            var week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              show_level: hmUI.show_level.ALL,
              x: 157,
              y: 20,
              week_tc: weekScArray,
              week_sc: weekScArray,
              week_en: weekEnArray,

            });
            break;
          // case hmUI.edit_type.SLEEP:
          //   topProp.type = hmUI.data_type.SLEEP;
          //   topProp.icon = iconPath + "sleep.png";
          //   topProp.dot_image = iconPath + "dot.png";
          //   topProp.unit_en = iconPath + "h.png";
          //   topProp.unit_sc = iconPath + "h.png";
          //   topProp.unit_tc = iconPath + "h.png";
          //   topProp.invalid_image = iconPath + "data_none.png";
          //   topText = hmUI.createWidget(hmUI.widget.TEXT_IMG, topProp);
          //   break
          // case hmUI.edit_type.TIME:

          //   let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          //     hour_zero: 1,
          //     hour_startX: 152,
          //     hour_startY: 12,
          //     hour_array: fontArray,
          //     hour_space: 0,
          //     hour_unit_sc: iconPath + "time_sp.png",
          //     hour_unit_tc: iconPath + "time_sp.png",
          //     hour_unit_en: iconPath + "time_sp.png",
          //     minute_zero: 1,
          //     minute_startX: 202,
          //     minute_startY: 12,
          //     minute_array: fontArray,
          //     minute_space: 0,
          //   });
          // break
        }
        maskCover = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: rootPath + "edit/mask_100.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });
        var centerY = 225;
        var centerX = 195;
        var timeProp = {
          hour_centerX: centerX,
          hour_centerY: centerY,
          hour_posX: 27,
          hour_posY: 148,
          hour_path: rootPath + "hand/hour.png",
          minute_centerX: centerX,
          minute_centerY: centerY,
          minute_posX: 29,
          minute_posY: 201,
          minute_path: rootPath + "hand/min.png",
        };
        if (!aodModel) {
          timeProp.second_centerX = centerX;
          timeProp.second_centerY = centerY;
          timeProp.second_posX = 29;
          timeProp.second_posY = 210;
          timeProp.second_path = rootPath + "hand/sec.png";
        }
        timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, timeProp);
        maskFg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: rootPath + "edit/mask_70.png",
          show_level: hmUI.show_level.ONLY_EDIT,
        });

        if (topProp.type) {
          hmUI.createWidget(hmUI.widget.IMG_CLICK, {
            type: topProp.type,
            x: 131, y: 0, w: 133, h: 57, //type必写 跳转的action
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
        }


      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();

      },

      onReady() {
        console.log('index page.js on ready invoke');
      },

      onShow() {
        console.log('index page.js on show invoke');
      },

      onHide() {
        console.log('index page.js on hide invoke');
      },

      onDestory() {
        console.log('index page.js on destory invoke');
      },
    });

  })();
} catch (e) {
  console.log(e);
}
