try{(()=>{var __$$app$$__=__$$hmAppManager$$__.currentApp;var __$$module$$__=__$$app$$__.current;var e=new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__,__$$module$$__),"modular");"use strict";
__$$module$$__.module=DeviceRuntimeCore.WatchFace({
init_view(){
const N=hmUI.show_level.ONLY_NORMAL, AOD=hmUI.show_level.ONLY_AOD, L=hmUI.align.LEFT, C=hmUI.align.CENTER_H;
const safe=(f)=>{try{f()}catch(err){console.log(err)}};
const img=(x,y,w,h,src,lv)=>safe(()=>hmUI.createWidget(hmUI.widget.IMG,{x:x,y:y,w:w,h:h,src:src,show_level:lv||N}));
const lvl=(x,y,arr,type)=>safe(()=>hmUI.createWidget(hmUI.widget.IMG_LEVEL,{x:x,y:y,image_array:arr,image_length:arr.length,type:type,show_level:N}));
const num=(x,y,w,h,arr,type)=>safe(()=>hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:x,y:y,w:w,h:h,font_array:arr,h_space:0,align_h:C,type:type,show_level:N}));
const dt=hmUI.data_type;
img(0,0,390,450,"0001.png");
lvl(155,58,["0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png", "0012.png", "0013.png"],dt.BATTERY);
lvl(266,56,["0014.png", "0015.png", "0016.png", "0017.png", "0018.png", "0019.png", "0020.png", "0021.png", "0022.png", "0023.png", "0024.png"],dt.CAL);
lvl(276,66,["0025.png", "0026.png", "0027.png", "0028.png", "0029.png", "0030.png", "0031.png", "0032.png", "0033.png", "0034.png", "0035.png"],dt.STEP);
lvl(157,334,["0036.png", "0037.png", "0038.png", "0039.png", "0040.png", "0041.png", "0042.png", "0043.png", "0044.png", "0045.png", "0046.png", "0047.png", "0048.png"],dt.STAND);
num(52,82,60,30,["0069.png", "0070.png", "0071.png", "0072.png", "0073.png", "0074.png", "0075.png", "0076.png", "0077.png", "0078.png"],dt.HEART);
num(170,87,50,22,["0079.png", "0080.png", "0081.png", "0082.png", "0083.png", "0084.png", "0085.png", "0086.png", "0087.png", "0088.png"],dt.BATTERY);
num(50,367,100,26,["0089.png", "0090.png", "0091.png", "0092.png", "0093.png", "0094.png", "0095.png", "0096.png", "0097.png", "0098.png"],dt.STEP);
num(170,360,50,24,["0099.png", "0100.png", "0101.png", "0102.png", "0103.png", "0104.png", "0105.png", "0106.png", "0107.png", "0108.png"],dt.STAND);
safe(()=>hmUI.createWidget(hmUI.widget.IMG_TIME,{hour_zero:1,hour_startX:61,hour_startY:140,hour_array:["0049.png", "0050.png", "0051.png", "0052.png", "0053.png", "0054.png", "0055.png", "0056.png", "0057.png", "0058.png"],hour_space:0,hour_align:L,minute_zero:1,minute_startX:205,minute_startY:140,minute_array:["0049.png", "0050.png", "0051.png", "0052.png", "0053.png", "0054.png", "0055.png", "0056.png", "0057.png", "0058.png"],minute_space:0,minute_align:L,show_level:N}));
safe(()=>hmUI.createWidget(hmUI.widget.IMG_WEEK,{x:290,y:345,week_en:["0129.png", "0130.png", "0131.png", "0132.png", "0133.png", "0134.png", "0135.png"],week_tc:["0129.png", "0130.png", "0131.png", "0132.png", "0133.png", "0134.png", "0135.png"],week_sc:["0129.png", "0130.png", "0131.png", "0132.png", "0133.png", "0134.png", "0135.png"],show_level:N}));
safe(()=>hmUI.createWidget(hmUI.widget.IMG_DATE,{day_startX:292,day_startY:366,day_sc_array:["0109.png", "0110.png", "0111.png", "0112.png", "0113.png", "0114.png", "0115.png", "0116.png", "0117.png", "0118.png"],day_tc_array:["0109.png", "0110.png", "0111.png", "0112.png", "0113.png", "0114.png", "0115.png", "0116.png", "0117.png", "0118.png"],day_en_array:["0109.png", "0110.png", "0111.png", "0112.png", "0113.png", "0114.png", "0115.png", "0116.png", "0117.png", "0118.png"],day_zero:0,day_space:0,day_align:L,show_level:N}));
safe(()=>hmUI.createWidget(hmUI.widget.IMG_WEEK,{x:64,y:274,week_en:["0136.png", "0137.png", "0138.png", "0139.png", "0140.png", "0141.png", "0142.png"],week_tc:["0136.png", "0137.png", "0138.png", "0139.png", "0140.png", "0141.png", "0142.png"],week_sc:["0136.png", "0137.png", "0138.png", "0139.png", "0140.png", "0141.png", "0142.png"],show_level:N}));
safe(()=>hmUI.createWidget(hmUI.widget.IMG_DATE,{day_startX:186,day_startY:274,day_sc_array:["0119.png", "0120.png", "0121.png", "0122.png", "0123.png", "0124.png", "0125.png", "0126.png", "0127.png", "0128.png"],day_tc_array:["0119.png", "0120.png", "0121.png", "0122.png", "0123.png", "0124.png", "0125.png", "0126.png", "0127.png", "0128.png"],day_en_array:["0119.png", "0120.png", "0121.png", "0122.png", "0123.png", "0124.png", "0125.png", "0126.png", "0127.png", "0128.png"],day_zero:0,day_space:0,day_align:L,month_startX:224,month_startY:274,month_sc_array:["0143.png", "0144.png", "0145.png", "0146.png", "0147.png", "0148.png", "0149.png", "0150.png", "0151.png", "0152.png", "0153.png", "0154.png"],month_tc_array:["0143.png", "0144.png", "0145.png", "0146.png", "0147.png", "0148.png", "0149.png", "0150.png", "0151.png", "0152.png", "0153.png", "0154.png"],month_en_array:["0143.png", "0144.png", "0145.png", "0146.png", "0147.png", "0148.png", "0149.png", "0150.png", "0151.png", "0152.png", "0153.png", "0154.png"],month_is_character:true,show_level:N}));
img(0,0,390,450,"0002.png",AOD);
safe(()=>hmUI.createWidget(hmUI.widget.IMG_TIME,{hour_zero:1,hour_startX:61,hour_startY:140,hour_array:["0059.png", "0060.png", "0061.png", "0062.png", "0063.png", "0064.png", "0065.png", "0066.png", "0067.png", "0068.png"],hour_space:0,hour_align:L,minute_zero:1,minute_startX:205,minute_startY:140,minute_array:["0059.png", "0060.png", "0061.png", "0062.png", "0063.png", "0064.png", "0065.png", "0066.png", "0067.png", "0068.png"],minute_space:0,minute_align:L,show_level:AOD}));
},
onInit(){this.init_view()},onReady(){},onShow(){},onHide(){},onDestroy(){}
})})()}catch(e){console.log(e)}
