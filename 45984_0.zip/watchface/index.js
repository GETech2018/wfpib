try { (() => {
  const module = __$$hmAppManager$$__.currentApp.current;
  module.module = DeviceRuntimeCore.WatchFace({
    init_view() {
      const N = hmUI.show_level.ONLY_NORMAL, A = hmUI.show_level.ONLY_AOD;
      const clock = Array.from({length:10}, (_,i) => `neon4_digit_${i}.png`);
      const small = Array.from({length:10}, (_,i) => `${String(86+i).padStart(4,'0')}.png`);
      const seconds = Array.from({length:10}, (_,i) => `neon4_second_${i}.png`);
      const week = ["0045.png", "0046.png", "0047.png", "0048.png", "0049.png", "0050.png", "0051.png"];
      const weather = Array.from({length:29}, (_,i) => `${String(53+i).padStart(4,'0')}.png`);
      for (const level of [N,A]) {
        hmUI.createWidget(hmUI.widget.FILL_RECT, {x:0,y:0,w:390,h:450,color:0x000000,show_level:level});
        hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_startX:13,hour_startY:73,hour_array:clock,hour_zero:true,hour_space:-14,hour_align:hmUI.align.LEFT,
          minute_startX:190,minute_startY:73,minute_array:clock,minute_zero:true,minute_space:-14,minute_follow:0,minute_align:hmUI.align.LEFT,
          show_level:level
        });
        hmUI.createWidget(hmUI.widget.IMG_LEVEL, {x:103,y:7,image_array:weather,image_length:29,type:hmUI.data_type.WEATHER_CURRENT,show_level:level});
        hmUI.createWidget(hmUI.widget.TEXT_IMG, {x:30,y:19,font_array:small,padding:false,h_space:0,unit_sc:'0097.png',unit_tc:'0097.png',unit_en:'0097.png',imperial_unit_sc:'0097.png',imperial_unit_tc:'0097.png',imperial_unit_en:'0097.png',negative_image:'0096.png',invalid_image:'0098.png',align_h:hmUI.align.CENTER_H,type:hmUI.data_type.WEATHER_CURRENT,show_level:level});
        hmUI.createWidget(hmUI.widget.IMG_WEEK, {x:217,y:18,week_en:week,week_sc:week,week_tc:week,show_level:level});
      }
      hmUI.createWidget(hmUI.widget.IMG_DATE, {day_startX:308,day_startY:19,day_sc_array:small,day_tc_array:small,day_en_array:small,day_zero:true,day_space:0,day_align:hmUI.align.LEFT,day_is_character:false,show_level:N});
      hmUI.createWidget(hmUI.widget.IMG_TIME, {second_startX:334,second_startY:280,second_array:seconds,second_zero:true,second_space:0,second_follow:0,second_align:hmUI.align.LEFT,show_level:N});
      const cells=[
        {x:20,panel:'panel_battery.png',iconX:41,icon:'badge_battery_0.png',font:'battery',type:hmUI.data_type.BATTERY},
        {x:90,panel:'panel_steps.png',iconX:99,icon:'badge_steps.png',font:'step',type:hmUI.data_type.STEP},
        {x:161,panel:'panel_heart.png',iconX:174,icon:'badge_heart.png',font:'heart',type:hmUI.data_type.HEART},
        {x:232,panel:'panel_calories.png',iconX:250,icon:'badge_calories.png',font:'metric',type:hmUI.data_type.CAL},
        {x:302,panel:'panel_distance.png',iconX:315,icon:'badge_distance.png',font:'metric',type:hmUI.data_type.DISTANCE}
      ];
      let batteryIcon;
      for (const item of cells) {
        hmUI.createWidget(hmUI.widget.IMG,{x:item.x,y:324,src:item.panel,show_level:N});
        const icon=hmUI.createWidget(hmUI.widget.IMG,{x:item.iconX,y:328,src:item.icon,show_level:N});
        if(item.font==='battery') batteryIcon=icon;
        const digits=Array.from({length:10},(_,i)=>`${item.font}_${i}.png`);
        const props={x:item.x,y:380,w:68,h:27,font_array:digits,padding:false,h_space:0,align_h:hmUI.align.CENTER_H,type:item.type,show_level:N};
        if(item.font==='battery') {props.unit_sc='battery_pct.png';props.unit_tc='battery_pct.png';props.unit_en='battery_pct.png';}
        if(item.type===hmUI.data_type.DISTANCE) props.dot_image='metric_dot.png';
        hmUI.createWidget(hmUI.widget.TEXT_IMG,props);
      }
      let battery;
      function updateBattery(){
        try {
          const raw=typeof battery.getCurrent==='function'?battery.getCurrent():battery.current;
          if (raw===undefined || raw===null || !Number.isFinite(Number(raw))) return;
          const percent=Math.max(0,Math.min(100,Number(raw)));
          const frame=Math.max(0,Math.min(10,Math.round(percent/10)));
          batteryIcon.setProperty(hmUI.prop.MORE,{src:`badge_battery_${frame}.png`});
        } catch(e) {}
      }
      try {battery=hmSensor.createSensor(hmSensor.id.BATTERY);battery.addEventListener(hmSensor.event.CHANGE,updateBattery);updateBattery();} catch(e) {}
      hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE,{resume_call(){updateBattery()},pause_call(){}});
      const routes=[
        [0,0,170,72,'WeatherScreen'],[210,0,165,72,'ScheduleCalScreen'],
        [13,73,166,247,'CountdownAppScreen'],[190,73,166,247,'CountdownAppScreen'],[334,280,42,40,'CountdownAppScreen'],
        [20,324,68,95,'Settings_batteryManagerScreen'],[90,324,68,95,'activityAppScreen'],
        [161,324,68,95,'heart_app_Screen'],[232,324,68,95,'activityAppScreen'],[302,324,68,95,'activityAppScreen']
      ];
      for(const [x,y,w,h,url] of routes) hmUI.createWidget(hmUI.widget.BUTTON,{x,y,w,h,text:'',normal_src:'0003.png',press_src:'0003.png',show_level:N,click_func:()=>hmApp.startApp({url,native:true})});
    },
    onInit(){this.init_view()},onReady(){},onShow(){},onHide(){},onDestroy(){}
  });
})()} catch(e) {console.log(e)}
