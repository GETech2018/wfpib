﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_pai_weekly_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_battery_text_text_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bk_03.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 33,
              font_array: ["HPA001.png","HPA002.png","HPA003.png","HPA004.png","HPA005.png","HPA006.png","HPA007.png","HPA008.png","HPA009.png","HPA010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 155,
              y: 306,
              week_en: ["DD01.png","DD02.png","DD03.png","DD04.png","DD05.png","DD06.png","DD07.png"],
              week_tc: ["DD01.png","DD02.png","DD03.png","DD04.png","DD05.png","DD06.png","DD07.png"],
              week_sc: ["DD01.png","DD02.png","DD03.png","DD04.png","DD05.png","DD06.png","DD07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 162,
              day_startY: 274,
              day_sc_array: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png","day008.png","day009.png","day010.png"],
              day_tc_array: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png","day008.png","day009.png","day010.png"],
              day_en_array: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png","day008.png","day009.png","day010.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 9,
              y: 213,
              src: 'blck.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 173,
              y: 405,
              src: 'bt23.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 357,
              y: 213,
              src: 'blal.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 294,
              font_array: ["up001.png","up002.png","up003.png","up004.png","up005.png","up006.png","up007.png","up008.png","up009.png","up010.png"],
              padding: false,
              h_space: -2,
              dot_image: 'up011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 251,
              y: 294,
              font_array: ["up001.png","up002.png","up003.png","up004.png","up005.png","up006.png","up007.png","up008.png","up009.png","up010.png"],
              padding: false,
              h_space: -2,
              dot_image: 'up011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 150,
              font_array: ["up001.png","up002.png","up003.png","up004.png","up005.png","up006.png","up007.png","up008.png","up009.png","up010.png"],
              padding: false,
              h_space: -2,
              dot_image: 'up012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 150,
              font_array: ["up001.png","up002.png","up003.png","up004.png","up005.png","up006.png","up007.png","up008.png","up009.png","up010.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 72,
              font_array: ["down001.png","down002.png","down003.png","down004.png","down005.png","down006.png","down007.png","down008.png","down009.png","down010.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'down012.png',
              unit_tc: 'down012.png',
              unit_en: 'down012.png',
              negative_image: 'down011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 72,
              font_array: ["down001.png","down002.png","down003.png","down004.png","down005.png","down006.png","down007.png","down008.png","down009.png","down010.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'down012.png',
              unit_tc: 'down012.png',
              unit_en: 'down012.png',
              negative_image: 'down011.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 153,
              y: 71,
              font_array: ["dwnBLCK001.png","dwnBLCK002.png","dwnBLCK003.png","dwnBLCK004.png","dwnBLCK005.png","dwnBLCK006.png","dwnBLCK007.png","dwnBLCK008.png","dwnBLCK009.png","dwnBLCK010.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'dwnBLCK012.png',
              unit_tc: 'dwnBLCK012.png',
              unit_en: 'dwnBLCK012.png',
              negative_image: 'dwnBLCK011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 160,
              y: 101,
              image_array: ["w072.png","w073.png","w074.png","w075.png","w076.png","w077.png","w078.png","w079.png","w080.png","w081.png","w082.png","w083.png","w084.png","w085.png","w086.png","w087.png","w088.png","w089.png","w090.png","w091.png","w092.png","w093.png","w094.png","w095.png","w096.png","w097.png","w098.png","w099.png","w100.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 370,
              font_array: ["down001.png","down002.png","down003.png","down004.png","down005.png","down006.png","down007.png","down008.png","down009.png","down010.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 370,
              font_array: ["down001.png","down002.png","down003.png","down004.png","down005.png","down006.png","down007.png","down008.png","down009.png","down010.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 58,
              y: 370,
              font_array: ["down001.png","down002.png","down003.png","down004.png","down005.png","down006.png","down007.png","down008.png","down009.png","down010.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 178,
              am_y: 185,
              am_sc_path: '0003.png',
              am_en_path: '0003.png',
              pm_x: 178,
              pm_y: 185,
              pm_sc_path: '0004.png',
              pm_en_path: '0004.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 206,
              hour_array: ["hrs001.png","hrs002.png","hrs003.png","hrs004.png","hrs005.png","hrs006.png","hrs007.png","hrs008.png","hrs009.png","hrs010.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 217,
              minute_startY: 206,
              minute_array: ["hrs001.png","hrs002.png","hrs003.png","hrs004.png","hrs005.png","hrs006.png","hrs007.png","hrs008.png","hrs009.png","hrs010.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'AOD2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 155,
              y: 354,
              week_en: ["DD01.png","DD02.png","DD03.png","DD04.png","DD05.png","DD06.png","DD07.png"],
              week_tc: ["DD01.png","DD02.png","DD03.png","DD04.png","DD05.png","DD06.png","DD07.png"],
              week_sc: ["DD01.png","DD02.png","DD03.png","DD04.png","DD05.png","DD06.png","DD07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 163,
              day_startY: 323,
              day_sc_array: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png","day008.png","day009.png","day010.png"],
              day_tc_array: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png","day008.png","day009.png","day010.png"],
              day_en_array: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png","day008.png","day009.png","day010.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 178,
              am_y: 185,
              am_sc_path: '0003.png',
              am_en_path: '0003.png',
              pm_x: 178,
              pm_y: 185,
              pm_sc_path: '0004.png',
              pm_en_path: '0004.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 206,
              hour_array: ["hrs001.png","hrs002.png","hrs003.png","hrs004.png","hrs005.png","hrs006.png","hrs007.png","hrs008.png","hrs009.png","hrs010.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 217,
              minute_startY: 206,
              minute_array: ["hrs001.png","hrs002.png","hrs003.png","hrs004.png","hrs005.png","hrs006.png","hrs007.png","hrs008.png","hrs009.png","hrs010.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 164,
              y: 78,
              font_array: ["down001.png","down002.png","down003.png","down004.png","down005.png","down006.png","down007.png","down008.png","down009.png","down010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 230,
              y: 190,
              w: 156,
              h: 76,
              src: '150.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 280,
              y: 86,
              w: 121,
              h: 102,
              src: '150.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 67,
              y: 190,
              w: 160,
              h: 76,
              src: '150.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 69,
              y: 268,
              w: 315,
              h: 56,
              src: '150.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 178,
              y: 31,
              w: 100,
              h: 154,
              src: '150.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 258,
              y: 326,
              w: 133,
              h: 100,
              src: '150.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 64,
              y: 326,
              w: 133,
              h: 100,
              src: '150.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 56,
              y: 88,
              w: 121,
              h: 100,
              src: '150.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}