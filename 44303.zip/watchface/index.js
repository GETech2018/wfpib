﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_minute_separator_img = ''
        let idle_background_bg = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'background_ai_darker.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 42,
              hour_posY: 108,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_minute.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 37,
              minute_posY: 153,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_second.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 9,
              second_posY: 160,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 134,
              y: 12,
              image_array: ["battery_bar_01.png","battery_bar_02.png","battery_bar_03.png","battery_bar_04.png","battery_bar_05.png","battery_bar_06.png","battery_bar_07.png","battery_bar_08.png","battery_bar_09.png","battery_bar_10.png","battery_bar_11.png","battery_bar_12.png","battery_bar_13.png","battery_bar_14.png","battery_bar_15.png","battery_bar_16.png","battery_bar_17.png","battery_bar_18.png","battery_bar_19.png","battery_bar_20.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 156,
              month_startY: 359,
              month_sc_array: ["num_sml_0.png","num_sml_1.png","num_sml_2.png","num_sml_3.png","num_sml_4.png","num_sml_5.png","num_sml_6.png","num_sml_7.png","num_sml_8.png","num_sml_9.png"],
              month_tc_array: ["num_sml_0.png","num_sml_1.png","num_sml_2.png","num_sml_3.png","num_sml_4.png","num_sml_5.png","num_sml_6.png","num_sml_7.png","num_sml_8.png","num_sml_9.png"],
              month_en_array: ["num_sml_0.png","num_sml_1.png","num_sml_2.png","num_sml_3.png","num_sml_4.png","num_sml_5.png","num_sml_6.png","num_sml_7.png","num_sml_8.png","num_sml_9.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 100,
              day_startY: 359,
              day_sc_array: ["num_sml_0.png","num_sml_1.png","num_sml_2.png","num_sml_3.png","num_sml_4.png","num_sml_5.png","num_sml_6.png","num_sml_7.png","num_sml_8.png","num_sml_9.png"],
              day_tc_array: ["num_sml_0.png","num_sml_1.png","num_sml_2.png","num_sml_3.png","num_sml_4.png","num_sml_5.png","num_sml_6.png","num_sml_7.png","num_sml_8.png","num_sml_9.png"],
              day_en_array: ["num_sml_0.png","num_sml_1.png","num_sml_2.png","num_sml_3.png","num_sml_4.png","num_sml_5.png","num_sml_6.png","num_sml_7.png","num_sml_8.png","num_sml_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 136,
              y: 359,
              src: 'num_sml_slash.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 39,
              y: 359,
              week_en: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              week_tc: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              week_sc: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 42,
              hour_startY: 390,
              hour_array: ["num_big_0.png","num_big_1.png","num_big_2.png","num_big_3.png","num_big_4.png","num_big_5.png","num_big_6.png","num_big_7.png","num_big_8.png","num_big_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 132,
              minute_startY: 390,
              minute_array: ["num_big_0.png","num_big_1.png","num_big_2.png","num_big_3.png","num_big_4.png","num_big_5.png","num_big_6.png","num_big_7.png","num_big_8.png","num_big_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 112,
              y: 390,
              src: 'num_big_colon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 42,
              hour_posY: 108,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_minute.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 37,
              minute_posY: 153,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}