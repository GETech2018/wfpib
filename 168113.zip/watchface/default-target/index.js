try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 432,
                    h: 514,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 215,
                    hour_centerY: 250,
                    hour_posX: 34,
                    hour_posY: 249,
                    hour_path: '3.png',
                    hour_cover_x: 0,
                    hour_cover_y: 178,
                    minute_centerX: 215,
                    minute_centerY: 250,
                    minute_posX: 34,
                    minute_posY: 249,
                    minute_path: '4.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 215,
                    second_centerY: 250,
                    second_posX: 34,
                    second_posY: 249,
                    second_path: '5.png',
                    second_cover_x: 178,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 178,
                    hour_centerY: 0,
                    hour_posX: 0,
                    hour_posY: 0,
                    hour_path: '7.png',
                    hour_cover_path: '6.png',
                    hour_cover_x: 178,
                    hour_cover_y: 0,
                    minute_centerX: 178,
                    minute_centerY: 0,
                    minute_posX: 0,
                    minute_posY: 0,
                    minute_path: '9.png',
                    minute_cover_path: '8.png',
                    minute_cover_x: 178,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}