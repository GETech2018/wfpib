try {
    ((() => {
        const {beforeModuleCreate = () => {
            }, afterModuleCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforeModuleCreate();
        const {beforePageCreate = () => {
            }, afterPageCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforePageCreate();
        const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__;
        !function (context) {
            with (context) {
                const __$$RQR$$__ = __$$R$$__;
                const utils = __$$RQR$$__('@zos/utils');
                const hmUI = __$$RQR$$__('@zos/ui');
                const _interopDefaultCompat = e => e && typeof e === 'object' && 'default' in e ? e : { default: e };
                const hmUI__default = _interopDefaultCompat(hmUI);
                const logger = utils.log.getLogger('watchface');
                let normal$_$text_a396c184964c457ea1d3060920feb08f = '';
                let normal$_$text_53d8d26fc4c3467eb4d798daedc4778b = '';
                __$$module$$__.module = WatchFace({
                    initView() {
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_TIME, {
                            hour_zero: 1,
                            hour_startX: 179,
                            hour_startY: 31,
                            hour_array: [
                                '2.png',
                                '3.png',
                                '4.png',
                                '5.png',
                                '6.png',
                                '7.png',
                                '8.png',
                                '9.png',
                                '10.png',
                                '11.png'
                            ],
                            hour_space: 0,
                            hour_align: hmUI__default.default.align.LEFT,
                            minute_zero: 1,
                            minute_startX: 179,
                            minute_startY: 148,
                            minute_array: [
                                '12.png',
                                '13.png',
                                '14.png',
                                '15.png',
                                '16.png',
                                '17.png',
                                '18.png',
                                '19.png',
                                '20.png',
                                '21.png'
                            ],
                            minute_space: 0,
                            minute_align: hmUI__default.default.align.LEFT,
                            minute_follow: 0,
                            enable: false,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_LEVEL, {
                            x: 25,
                            y: 308,
                            image_array: [
                                '22.png',
                                '23.png',
                                '24.png',
                                '25.png',
                                '26.png',
                                '27.png',
                                '28.png',
                                '29.png',
                                '30.png',
                                '31.png',
                                '32.png',
                                '33.png',
                                '34.png',
                                '35.png',
                                '36.png',
                                '37.png',
                                '38.png',
                                '39.png',
                                '40.png',
                                '41.png',
                                '42.png',
                                '43.png',
                                '44.png',
                                '45.png',
                                '46.png',
                                '47.png',
                                '48.png',
                                '49.png',
                                '50.png',
                                '51.png'
                            ],
                            image_length: 30,
                            type: hmUI__default.default.data_type.STEP,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG, {
                            x: 3,
                            y: 0,
                            src: '52.png',
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_LEVEL, {
                            x: 25,
                            y: 308,
                            image_array: [
                                '53.png',
                                '54.png',
                                '55.png',
                                '56.png',
                                '57.png',
                                '58.png',
                                '59.png',
                                '60.png',
                                '61.png',
                                '62.png',
                                '63.png',
                                '64.png'
                            ],
                            image_length: 12,
                            type: hmUI__default.default.data_type.STAND,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_LEVEL, {
                            x: 281,
                            y: 348,
                            image_array: [
                                '65.png',
                                '66.png',
                                '67.png',
                                '68.png',
                                '69.png'
                            ],
                            image_length: 5,
                            type: hmUI__default.default.data_type.UVI,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 317,
                            y: 376,
                            type: hmUI__default.default.data_type.UVI,
                            font_array: [
                                '70.png',
                                '71.png',
                                '72.png',
                                '73.png',
                                '74.png',
                                '75.png',
                                '76.png',
                                '77.png',
                                '78.png',
                                '79.png'
                            ],
                            align_h: hmUI__default.default.align.LEFT,
                            h_space: 0,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            invalid_image: '80.png',
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_LEVEL, {
                            x: 25,
                            y: 308,
                            image_array: [
                                '81.png',
                                '82.png',
                                '83.png',
                                '84.png',
                                '85.png',
                                '86.png',
                                '87.png',
                                '88.png',
                                '89.png',
                                '90.png',
                                '91.png',
                                '92.png',
                                '93.png',
                                '94.png',
                                '95.png',
                                '96.png',
                                '97.png',
                                '98.png',
                                '99.png',
                                '100.png'
                            ],
                            image_length: 20,
                            type: hmUI__default.default.data_type.PAI_DAILY,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 115,
                            y: 183,
                            type: hmUI__default.default.data_type.CAL,
                            font_array: [
                                '70.png',
                                '71.png',
                                '72.png',
                                '73.png',
                                '74.png',
                                '75.png',
                                '76.png',
                                '77.png',
                                '78.png',
                                '79.png'
                            ],
                            align_h: hmUI__default.default.align.CENTER_H,
                            h_space: 0,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 66,
                            y: 102,
                            type: hmUI__default.default.data_type.BIO_CHARGE,
                            font_array: [
                                '101.png',
                                '102.png',
                                '103.png',
                                '104.png',
                                '105.png',
                                '106.png',
                                '107.png',
                                '108.png',
                                '109.png',
                                '110.png'
                            ],
                            align_h: hmUI__default.default.align.LEFT,
                            h_space: -12,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            invalid_image: '111.png',
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 37,
                            y: 183,
                            type: hmUI__default.default.data_type.PAI_WEEKLY,
                            font_array: [
                                '70.png',
                                '71.png',
                                '72.png',
                                '73.png',
                                '74.png',
                                '75.png',
                                '76.png',
                                '77.png',
                                '78.png',
                                '79.png'
                            ],
                            align_h: hmUI__default.default.align.CENTER_H,
                            h_space: 0,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 73,
                            y: 31,
                            type: hmUI__default.default.data_type.HEART,
                            font_array: [
                                '101.png',
                                '102.png',
                                '103.png',
                                '104.png',
                                '105.png',
                                '106.png',
                                '107.png',
                                '108.png',
                                '109.png',
                                '110.png'
                            ],
                            align_h: hmUI__default.default.align.LEFT,
                            h_space: -12,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            invalid_image: '112.png',
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 108,
                            y: 264,
                            type: hmUI__default.default.data_type.RECOVERY_TIME,
                            font_array: [
                                '113.png',
                                '114.png',
                                '115.png',
                                '116.png',
                                '117.png',
                                '118.png',
                                '119.png',
                                '120.png',
                                '121.png',
                                '122.png'
                            ],
                            align_h: hmUI__default.default.align.RIGHT,
                            h_space: -2,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            invalid_image: '123.png',
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 194,
                            y: 343,
                            type: hmUI__default.default.data_type.WEATHER_CURRENT,
                            font_array: [
                                '124.png',
                                '125.png',
                                '126.png',
                                '127.png',
                                '128.png',
                                '129.png',
                                '130.png',
                                '131.png',
                                '132.png',
                                '133.png'
                            ],
                            align_h: hmUI__default.default.align.RIGHT,
                            h_space: -1,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            negative_image: '135.png',
                            invalid_image: '134.png',
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_DATE, {
                            month_startX: 324,
                            month_startY: 272,
                            month_sc_array: [
                                '136.png',
                                '137.png',
                                '138.png',
                                '139.png',
                                '140.png',
                                '141.png',
                                '142.png',
                                '143.png',
                                '144.png',
                                '145.png'
                            ],
                            month_tc_array: [
                                '136.png',
                                '137.png',
                                '138.png',
                                '139.png',
                                '140.png',
                                '141.png',
                                '142.png',
                                '143.png',
                                '144.png',
                                '145.png'
                            ],
                            month_en_array: [
                                '136.png',
                                '137.png',
                                '138.png',
                                '139.png',
                                '140.png',
                                '141.png',
                                '142.png',
                                '143.png',
                                '144.png',
                                '145.png'
                            ],
                            month_align: hmUI__default.default.align.LEFT,
                            month_zero: 1,
                            month_follow: 0,
                            month_space: -7,
                            month_is_character: false,
                            day_startX: 266,
                            day_startY: 272,
                            day_sc_array: [
                                '136.png',
                                '137.png',
                                '138.png',
                                '139.png',
                                '140.png',
                                '141.png',
                                '142.png',
                                '143.png',
                                '144.png',
                                '145.png'
                            ],
                            day_tc_array: [
                                '136.png',
                                '137.png',
                                '138.png',
                                '139.png',
                                '140.png',
                                '141.png',
                                '142.png',
                                '143.png',
                                '144.png',
                                '145.png'
                            ],
                            day_en_array: [
                                '136.png',
                                '137.png',
                                '138.png',
                                '139.png',
                                '140.png',
                                '141.png',
                                '142.png',
                                '143.png',
                                '144.png',
                                '145.png'
                            ],
                            day_align: hmUI__default.default.align.LEFT,
                            day_zero: 1,
                            day_follow: 0,
                            day_space: -7,
                            day_is_character: false,
                            enable: false,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_LEVEL, {
                            x: 306,
                            y: 403,
                            image_array: [
                                '146.png',
                                '147.png',
                                '148.png',
                                '149.png',
                                '150.png',
                                '151.png',
                                '152.png',
                                '153.png',
                                '154.png',
                                '155.png',
                                '156.png',
                                '157.png',
                                '158.png',
                                '159.png',
                                '160.png',
                                '161.png',
                                '162.png',
                                '163.png',
                                '164.png',
                                '165.png',
                                '166.png',
                                '167.png',
                                '168.png',
                                '169.png',
                                '170.png',
                                '171.png',
                                '172.png',
                                '173.png',
                                '174.png'
                            ],
                            image_length: 29,
                            type: hmUI__default.default.data_type.WEATHER_CURRENT,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        normal$_$text_a396c184964c457ea1d3060920feb08f = hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT, {
                            x: 307,
                            y: 269,
                            w: 46,
                            h: 37,
                            text: '/',
                            color: '0xFFffffff',
                            text_size: 32,
                            text_style: hmUI__default.default.text_style.NONE,
                            align_h: hmUI__default.default.align.LEFT,
                            align_v: hmUI__default.default.align.TOP,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        normal$_$text_53d8d26fc4c3467eb4d798daedc4778b = hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT, {
                            x: 277,
                            y: 326,
                            w: 91,
                            h: 37,
                            text: 'o',
                            color: '0xFFffffff',
                            text_size: 22,
                            text_style: hmUI__default.default.text_style.NONE,
                            align_h: hmUI__default.default.align.LEFT,
                            align_v: hmUI__default.default.align.TOP,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.WIDGET_DELEGATE, {
                            resume_call: function () {
                                normal$_$text_a396c184964c457ea1d3060920feb08f.setProperty(hmUI__default.default.prop.MORE, { text: `/` });
                                normal$_$text_53d8d26fc4c3467eb4d798daedc4778b.setProperty(hmUI__default.default.prop.MORE, { text: `o` });
                            }
                        });
                    },
                    onInit() {
                        logger.log('index page.js on init invoke');
                    },
                    build() {
                        logger.log('index page.js on build invoke');
                        this.initView();
                    },
                    onDestroy() {
                        logger.log('index page.js on destroy invoke');
                    }
                });
                ;
            }
        }.bind(__$$G$$__)(__$$G$$__);
        afterPageCreate();
        afterModuleCreate();
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}