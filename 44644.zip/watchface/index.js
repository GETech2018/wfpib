﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//////Vibration feedback for buttons
const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
let timer_StopVibrate = null;

function makeVibrate(level = 1) {
  stopVibrate();

  //The values are used as follows: 1 for buttons, 2 for open settings menu, 3 for close settings menu
  const levelToScene = {
    1: 26,
    2: 27,
    3: 29
  };

  let scene = levelToScene[level] || 25;
  let stopDelay = scene > 25 ? 1300 : 50;

  vibrate.scene = scene;
  vibrate.start();

  timer_StopVibrate = timer.createTimer(stopDelay, 0, stopVibrate, {});
}

function stopVibrate() {
  vibrate.stop();
  if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
  timer_StopVibrate = null;
}

//////Watchface Language Sets (Uppercase)
const watchfaceLangs = {
  EN:{
    WEEKDAYS_SHORT: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
    WEEKDAYS_FULL:  ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"],
    MONTHS_SHORT:   ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"],
    MONTHS_FULL:    ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"],

    STEPSLABEL: "STEPS",
    BATTERYLABEL: "BATTERY",
    HEARTRATELABEL: "LAST MEASURE: ",
    CALORIESLABEL: "CALORIES",
  },

  ES:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MIÉ", "JUE", "VIE", "SÁB", "DOM"],
    WEEKDAYS_FULL:  ["LUNES", "MARTES", "MIÉRCOLES", "JUEVES", "VIERNES", "SÁBADO", "DOMINGO"],
    MONTHS_SHORT:   ["ENE", "FEB", "MAR", "ABR", "MAY", "JUN", "JUL", "AGO", "SEP", "OCT", "NOV", "DIC"],
    MONTHS_FULL:    ["ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"],

    STEPSLABEL: "PASOS",
    BATTERYLABEL: "BATERÍA",
    HEARTRATELABEL: "ÚLT. MEDICIÓN: ",
    CALORIESLABEL: "CALORÍAS",
  },

  IT:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MER", "GIO", "VEN", "SAB", "DOM"],
    WEEKDAYS_FULL:  ["LUNEDÌ", "MARTEDÌ", "MERCOLEDÌ", "GIOVEDÌ", "VENERDÌ", "SABATO", "DOMENICA"],
    MONTHS_SHORT:   ["GEN", "FEB", "MAR", "APR", "MAG", "GIU", "LUG", "AGO", "SET", "OTT", "NOV", "DIC"],
    MONTHS_FULL:    ["GENNAIO", "FEBBRAIO", "MARZO", "APRILE", "MAGGIO", "GIUGNO", "LUGLIO", "AGOSTO", "SETTEMBRE", "OTTOBRE", "NOVEMBRE", "DICEMBRE"],

    STEPSLABEL: "PASSI",
    BATTERYLABEL: "BATTERIA",
    HEARTRATELABEL: "ULT. MISURAZIONE: ",
    CALORIESLABEL: "CALORIE",
  },

  PT:{
    WEEKDAYS_SHORT: ["SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM"],
    WEEKDAYS_FULL:  ["SEGUNDA-FEIRA", "TERÇA-FEIRA", "QUARTA-FEIRA", "QUINTA-FEIRA", "SEXTA-FEIRA", "SÁBADO", "DOMINGO"],
    MONTHS_SHORT:   ["JAN", "FEV", "MAR", "ABR", "MAI", "JUN", "JUL", "AGO", "SET", "OUT", "NOV", "DEZ"],
    MONTHS_FULL:    ["JANEIRO", "FEVEREIRO", "MARÇO", "ABRIL", "MAIO", "JUNHO", "JULHO", "AGOSTO", "SETEMBRO", "OUTUBRO", "NOVEMBRO", "DEZEMBRO"],

    STEPSLABEL: "PASSOS",
    BATTERYLABEL: "BATERIA",
    HEARTRATELABEL: "ÚLT. MEDIÇÃO: ",
    CALORIESLABEL: "CALORIAS",
  },

  FR:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MER", "JEU", "VEN", "SAM", "DIM"],
    WEEKDAYS_FULL:  ["LUNDI", "MARDI", "MERCREDI", "JEUDI", "VENDREDI", "SAMEDI", "DIMANCHE"],
    MONTHS_SHORT:   ["JAN", "FÉV", "MAR", "AVR", "MAI", "JUN", "JUI", "AOÛ", "SEP", "OCT", "NOV", "DÉC"],
    MONTHS_FULL:    ["JANVIER", "FÉVRIER", "MARS", "AVRIL", "MAI", "JUIN", "JUILLET", "AOÛT", "SEPTEMBRE", "OCTOBRE", "NOVEMBRE", "DÉCEMBRE"],

    STEPSLABEL: "PAS",
    BATTERYLABEL: "BATTERIE",
    HEARTRATELABEL: "ERN. MESURE: ",
    CALORIESLABEL: "CALORIES",
  },

  DE:{
    WEEKDAYS_SHORT: ["MON", "DIE", "MIT", "DON", "FRE", "SAM", "SON"],
    WEEKDAYS_FULL:  ["MONTAG", "DIENSTAG", "MITTWOCH", "DONNERSTAG", "FREITAG", "SAMSTAG", "SONNTAG"],
    MONTHS_SHORT:   ["JAN", "FEB", "MÄR", "APR", "MAI", "JUN", "JUL", "AUG", "SEP", "OKT", "NOV", "DEZ"],
    MONTHS_FULL:    ["JANUAR", "FEBRUAR", "MÄRZ", "APRIL", "MAI", "JUNI", "JULI", "AUGUST", "SEPTEMBER", "OKTOBER", "NOVEMBER", "DEZEMBER"],

    STEPSLABEL: "SCHRITTE",
    BATTERYLABEL: "BATTERIE",
    HEARTRATELABEL: "LETZTE MESSUNG: ",
    CALORIESLABEL: "KALORIEN",
  },
};
let currWatchfaceLang;
let currLangCode;

let graphHRM;
let maxHRMText;
let minHRMText;
let currHRMText;
let heart = hmSensor.createSensor(hmSensor.id.HEART);

let monthFormatDate = false;
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_uvi_pointer_progress_img_pointer = ''
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_battery_circle_scale = ''
        let normal_battery_current_text_font = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_font = ''
        let normal_calorie_circle_scale = ''
        let normal_pai_circle_scale = ''
        let normal_stand_circle_scale = ''
        let idle_background_bg = ''
        let idle_time_hour_min_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SF-Compact-Rounded-Medium_compressed.ttf; FontSize: 18
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 214,
              h: 25,
              text_size: 18,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
              color: 0xFFF74A3C,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF-Compact-Rounded-Medium_compressed.ttf; FontSize: 34
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 432,
              h: 48,
              text_size: 34,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF-Compact-Rounded-Regular_compressed.ttf; FontSize: 96
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 1227,
              h: 136,
              text_size: 96,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Regular_compressed.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF-Compact-Rounded-Medium_compressed.ttf; FontSize: 38; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 45,
              h: 45,
              text_size: 38,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF-Compact-Rounded-Medium_compressed.ttf; FontSize: 28
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 358,
              h: 40,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

//////Function to detect current language from system
function detectLanguage() {
    const zeppAvailableLangs = [
        "ZH", // 0  Chinese (Simplified)
        "ZH", // 1  Chinese (Traditional)
        "EN", // 2  English
        "ES", // 3  Spanish
        "RU", // 4  Russian
        "KO", // 5  Korean
        "FR", // 6  French
        "DE", // 7  German
        "ID", // 8  Indonesian
        "PL", // 9  Polish
        "IT", // 10 Italian
        "JA", // 11 Japanese
        "TH", // 12 Thai
        "AR", // 13 Arabic
        "VI", // 14 Vietnamese
        "PT", // 15 Portuguese (Portugal)
        "NL", // 16 Dutch
        "TR", // 17 Turkish
        "UK", // 18 Ukrainian
        "HE", // 19 Hebrew
        "PT", // 20 Portuguese (Brazil)
        "RO", // 21 Romanian
        "CS", // 22 Czech
        "EL", // 23 Greek
        "SR", // 24 Serbian
        "CA", // 25 Catalan
        "FI", // 26 Finnish
        "NO", // 27 Norwegian
        "DA", // 28 Danish
        "SV", // 29 Swedish
        "HU", // 30 Hungarian
        "MS", // 31 Malay
        "SK", // 32 Slovak
        "HI"  // 33 Hindi
    ];
    let langCode = zeppAvailableLangs[hmSetting.getLanguage()]; //Get current language on watch

    currLangCode = watchfaceLangs[langCode] ? langCode : "EN";
    currWatchfaceLang = watchfaceLangs[currLangCode];
}
detectLanguage();
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 1,
              y: 142,
              w: 94,
              h: 30,
              text_size: 18,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
              color: 0xFFF74A3C,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 44,
              y: 142,
              w: 150,
              h: 30,
              text_size: 18,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
              color: 0xFFD9E13C,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 30,
              y: 94,
              w: 80,
              h: 50,
              text_size: 34,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'INDICATOR.png',
              center_x: 69,
              center_y: 116,
              x: 10,
              y: 50,
              start_angle: -125,
              end_angle: 125,
              invalid_visible: false,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 75,
              y: 70,
              w: 300,
              h: 130,
              text_size: 96,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Regular_compressed.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 223,
              y: 42,
              w: 150,
              h: 50,
              text_size: 38,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 73,
              // center_y: 387,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 44,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFF06DB71,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 73,
              center_y: 387,
              start_angle: 0,
              end_angle: 360,
              radius: 40,
              line_width: 8,
              corner_flag: 0,
              color: 0xFF06DB71,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 38,
              y: 370,
              w: 70,
              h: 50,
              text_size: 28,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 387,
              // start_angle: -150,
              // end_angle: 150,
              // radius: 44,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFFFF9808,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 387,
              start_angle: -150,
              end_angle: 150,
              radius: 40,
              line_width: 8,
              corner_flag: 0,
              color: 0xFFFF9808,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 146,
              y: 375,
              w: 98,
              h: 40,
              text_size: 18,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 316,
              // center_y: 387,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 44,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFFFF2D55,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 316,
              center_y: 387,
              start_angle: 0,
              end_angle: 360,
              radius: 40,
              line_width: 8,
              corner_flag: 0,
              color: 0xFFFF2D55,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 316,
              // center_y: 387,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 33,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFF34C759,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 316,
              center_y: 387,
              start_angle: 0,
              end_angle: 360,
              radius: 29,
              line_width: 8,
              corner_flag: 0,
              color: 0xFF34C759,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 316,
              // center_y: 387,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 21,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFF5AC8FA,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 316,
              center_y: 387,
              start_angle: 0,
              end_angle: 360,
              radius: 17,
              line_width: 8,
              corner_flag: 0,
              color: 0xFF5AC8FA,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 75,
              y: 70,
              w: 300,
              h: 130,
              text_size: 96,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Regular_compressed.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 223,
              y: 42,
              w: 150,
              h: 50,
              text_size: 38,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

let idle_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
    x: 223,
    y: 42,
    w: 150,
    h: 50,
    text_size: 38,
    char_space: 0,
    font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
    color: 0xFFFFFFFF,
    line_space: 0,
    align_v: hmUI.align.TOP,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.RIGHT,
    // unit_string: JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC,
    show_level: hmUI.show_level.ONLY_AOD,
});

idle_dow_text_font.setProperty(hmUI.prop.VISIBLE, hmFS.SysProGetBool('weekdayDateAOD') ?? true);
idle_month_font.setProperty(hmUI.prop.VISIBLE, hmFS.SysProGetBool('monthDateAOD') ?? false);

graphHRM = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE,{
    x: 61,
    y: 218,
    w: 313,
    h: 110,
    line_color: 0xFFFFFF,
    line_width: 4,
    type: hmUI.data_type.HEART,
    color_from: 0xFFFFFF,
    color_to: 0xFFFFFF,
    curve_style: true,
    show_level: hmUI.show_level.ONLY_NORMAL
});

maxHRMText = hmUI.createWidget(hmUI.widget.TEXT, {
    x: 12,
    y: 218,
    w: 150,
    h: 30,
    text_size: 22,
    char_space: 0,
    font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
    color: 0xFFFFFFFF,
    line_space: 0,
    align_v: hmUI.align.TOP,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

minHRMText = hmUI.createWidget(hmUI.widget.TEXT, {
    x: 12,
    y: 301,
    w: 150,
    h: 30,
    text_size: 22,
    char_space: 0,
    font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
    color: 0xFFFFFFFF,
    line_space: 0,
    align_v: hmUI.align.TOP,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

currHRMText = hmUI.createWidget(hmUI.widget.TEXT, {
    x: 38,
    y: 179,
    w: 350,
    h: 30,
    text_size: 24,
    char_space: 0,
    font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
    color: 0xFFFFFFFF,
    line_space: 0,
    align_v: hmUI.align.TOP,
    text_style: hmUI.text_style.ELLIPSIS,
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

function updateHRM(){
    let currHRM = currWatchfaceLang.HEARTRATELABEL + heart.last + " BPM";
    let heartArr = heart.today;
    let maxHRM = Math.max(...heartArr);
    let minHRM = Math.min(...heartArr);

    maxHRMText.setProperty(hmUI.prop.TEXT, String(maxHRM));
    minHRMText.setProperty(hmUI.prop.TEXT, String(minHRM));
    currHRMText.setProperty(hmUI.prop.TEXT, currHRM);
}

heart.addEventListener(hmSensor.event.CHANGE, function() {
    updateHRM();
});
            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 145,
              y: 20,
              w: 245,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                makeVibrate(1)
changeFormatDate()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 24,
              y: 71,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 140,
              y: 85,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 270,
              y: 85,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 5,
              y: 183,
              w: 150,
              h: 150,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 34,
              y: 350,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 156,
              y: 350,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 277,
              y: 350,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

function changeFormatDate(){
    monthFormatDate = !monthFormatDate;
    if (monthFormatDate){
        hmFS.SysProSetBool('monthDateAOD', true)
        hmFS.SysProSetBool('weekdayDateAOD', false)
    }else{
        hmFS.SysProSetBool('monthDateAOD', false)
        hmFS.SysProSetBool('weekdayDateAOD', true)     
    }
    time_update(true, true);
}
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0');
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              console.log('full date font normal and idle');
              if (updateHour) {
                let currFormatDate
                let normal_idle_Month_Str = currWatchfaceLang.MONTHS_SHORT[timeSensor.month-1];
                let normal_idle_DOW_Str = currWatchfaceLang.WEEKDAYS_SHORT[timeSensor.week-1];
                let normal_idle_dayStr = timeSensor.day.toString();

                if (monthFormatDate){
                  currFormatDate = normal_idle_Month_Str;
                }else{
                  currFormatDate = normal_idle_DOW_Str;
                }

                normal_dow_text_font.setProperty(hmUI.prop.TEXT, currFormatDate + " " + normal_idle_dayStr);
                idle_month_font.setProperty(hmUI.prop.TEXT, normal_idle_Month_Str + " " + normal_idle_dayStr);
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, normal_idle_DOW_Str + " " + normal_idle_dayStr);
              };

              console.log('hour:min font');
              if (updateMinute) {
                let idle_HourMinStr = format_hour.toString();
                idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0');
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr );
              };
            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 73,
                      center_y: 387,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF06DB71,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 387,
                      start_angle: -150,
                      end_angle: 150,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFFFF9808,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 316,
                      center_y: 387,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFFFF2D55,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_cs_normal_pai = progressPAI;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_pai_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_pai * 100);
                  if (normal_pai_circle_scale) {
                    normal_pai_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 316,
                      center_y: 387,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 29,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF34C759,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 316,
                      center_y: 387,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 17,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF5AC8FA,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

updateHRM();
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}