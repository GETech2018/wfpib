﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_current_text_font = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_distance_icon_img = ''
        let normal_distance_current_text_font = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_timeDifference_gmt_text = ''
        let worldClockIndex = 0
        let normal_cityName_gmt_text = ''
        let normal_time_gmt_text = ''
        let idle_background_bg = ''
        let idle_time_hour_min_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let GMT_Button_NextSity = ''
        let GMT_Button_PreviewSity = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = '';
        let worldClock = '';
        worldClockIndex = hmFS.SysProGetInt('worldClockIndex') ?? 0;;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Carson.ttf; FontSize: 50
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 522,
              h: 74,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Carson.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Carson.ttf; FontSize: 60
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 625,
              h: 90,
              text_size: 60,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Carson.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Carson.ttf; FontSize: 50; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 60,
              h: 60,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Carson.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Carson.ttf; FontSize: 220
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 2245,
              h: 327,
              text_size: 220,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Carson.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Carson.ttf; FontSize: 40; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 48,
              h: 48,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Carson.ttf',
              color: 0xFFFF0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Carson.ttf; FontSize: 90; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 108,
              h: 108,
              text_size: 90,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Carson.ttf',
              color: 0xFF80FF00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 22,
              y: 270,
              src: 'battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 67,
              // center_y: 315,
              // start_angle: -128,
              // end_angle: 139,
              // radius: 45,
              // line_width: 18,
              // line_cap: Rounded,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 67,
              center_y: 315,
              start_angle: 139,
              end_angle: -128,
              radius: 36,
              line_width: 18,
              corner_flag: 0,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -8,
              y: 281,
              w: 150,
              h: 55,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Carson.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 339,
              y: 27,
              src: 'Logo-Heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 183,
              y: 7,
              w: 150,
              h: 65,
              text_size: 60,
              char_space: 0,
              font: 'fonts/Carson.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 176,
              y: 406,
              src: 'Logo-Distance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 195,
              y: 390,
              w: 150,
              h: 55,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Carson.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              unit_type: 2,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 26,
              y: 404,
              src: 'Logo-Step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 63,
              y: 390,
              w: 150,
              h: 60,
              text_size: 50,
              char_space: 0,
              font: 'fonts/Carson.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 30,
              y: 23,
              image_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 97,
              y: 10,
              w: 150,
              h: 70,
              text_size: 60,
              char_space: 0,
              font: 'fonts/Carson.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 8,
              y: 35,
              w: 369,
              h: 232,
              text_size: 220,
              char_space: 0,
              font: 'fonts/Carson.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              // unit_end: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            if (!worldClock) {
              worldClock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
              worldClock.init();
            };

            normal_timeDifference_gmt_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 252,
              y: 290,
              w: 150,
              h: 45,
              text_size: 40,
              char_space: 0,
              font: 'fonts/Carson.ttf',
              color: 0xFFFF0000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region updateTimeDifferenceGMT
            function updateTimeDifferenceGMT() {
              console.log('updateTimeDifferenceGMT()');
              let normal_timeDifferenceStr = '±-:--';
              let count = worldClock.getWorldClockCount();
              if (count > 0) {
                if (worldClockIndex >= count) worldClockIndex = count-1;
                let worldData = worldClock.getWorldClockInfo(worldClockIndex);
                let timeZoneHour = parseInt(worldData.timeZoneHour);
                let timeZoneHourStr = timeZoneHour.toString();
                let timeZoneMinute = parseInt(worldData.timeZoneMinute);
                let timeZoneMinuteStr = timeZoneMinute.toString().padStart(2, '0');
                if (timeZoneHour > 0) timeZoneHourStr = '+' + timeZoneHourStr;
                else if (timeZoneHour == 0) {
                  if (timeZoneMinute > 0)  timeZoneHourStr = '+' + timeZoneHourStr;
                  else if (timeZoneMinute == 0)  timeZoneHourStr = '±' + timeZoneHourStr;
                  else timeZoneHourStr = '-' + timeZoneHour;
                };
                normal_timeDifferenceStr = timeZoneHourStr + ':' + timeZoneMinuteStr;
              } // count
              if (normal_timeDifference_gmt_text) normal_timeDifference_gmt_text.setProperty(hmUI.prop.TEXT, normal_timeDifferenceStr);
            };
            updateTimeDifferenceGMT();
            //#endregion
            
            if (!worldClock) {
              worldClock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
              worldClock.init();
            };

            normal_cityName_gmt_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 77,
              y: 352,
              w: 236,
              h: 46,
              text_size: 40,
              char_space: 0,
              font: 'fonts/Carson.ttf',
              color: 0xFFFF0000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region updateSityNameGMT
            function updateSityNameGMT() {
              console.log('updateSityNameGMT()');
              let normal_cityNameStr = '---';
              let count = worldClock.getWorldClockCount();
              if (count > 0) {
                if (worldClockIndex >= count) worldClockIndex = count-1;
                let worldData = worldClock.getWorldClockInfo(worldClockIndex);
                normal_cityNameStr = worldData.city;
              } // count
              if (normal_cityName_gmt_text) normal_cityName_gmt_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);
            };
            updateSityNameGMT();
            //#endregion
            
            if (!worldClock) {
              worldClock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
              worldClock.init();
            };

            normal_time_gmt_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 127,
              y: 253,
              w: 175,
              h: 96,
              text_size: 90,
              char_space: 0,
              font: 'fonts/Carson.ttf',
              color: 0xFF80FF00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              // unit_type: 1,
              // unit_end: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region updateTimeGMT
            function updateTimeGMT() {
              console.log('updateTimeGMT()');
              let normal_timeStr = '--:--';
              let count = worldClock.getWorldClockCount();
              if (count > 0) {
                if (worldClockIndex >= count) worldClockIndex = count-1;
                let worldData = worldClock.getWorldClockInfo(worldClockIndex);
                let hour = worldData.hour;
                let minute = worldData.minute;
                if (!timeSensor.is24Hour) hour = hour % 12 || 12;
                let normal_hourStr = hour.toString().padStart(2, '0');
                let normal_minuteStr = minute.toString().padStart(2, '0');
                normal_timeStr = normal_hourStr + ':' + normal_minuteStr;
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_timeStr = normal_timeStr + ' Pm';
                  else normal_timeStr = normal_timeStr + ' Am';
                };
              } // count
              if (normal_time_gmt_text) normal_time_gmt_text.setProperty(hmUI.prop.TEXT, normal_timeStr);
            };
            //#endregion

            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 12,
              y: 80,
              w: 360,
              h: 232,
              text_size: 220,
              char_space: 0,
              font: 'fonts/Carson.ttf',
              color: 0xFF808080,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              // unit_end: 1,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            GMT_Button_NextSity = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 127,
              y: 272,
              w: 66,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                toggleWorldClock(1);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            GMT_Button_PreviewSity = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 211,
              y: 272,
              w: 66,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                toggleWorldClock(-1);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region toggleWorldClock
            function toggleWorldClock(step = 1) {
              const count = worldClock.getWorldClockCount();
              if (count) {
                worldClockIndex += step;
                worldClockIndex = worldClockIndex < 0 ? count + worldClockIndex : worldClockIndex % count;
                updateWorldTime(true);
                hmFS.SysProSetInt('worldClockIndex', worldClockIndex);
              }
            };
            //#endregion

            //#region updateWorldTime
            function updateWorldTime(updateSity = false) {
              updateTimeGMT();
              if (updateSity) updateSityNameGMT();
              updateTimeDifferenceGMT();
            };
            //#endregion

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 341,
              y: 81,
              w: 142,
              h: 72,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 341,
              y: 315,
              w: 100,
              h: 72,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 13,
              y: 281,
              w: 100,
              h: 72,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 17,
              y: 402,
              w: 142,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 269,
              y: 14,
              w: 100,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 37,
              y: 14,
              w: 100,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 16,
              y: 87,
              w: 132,
              h: 180,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr.padStart(2, '0');
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0');
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_HourMinStr = normal_HourMinStr + ' pm';
                  else normal_HourMinStr = normal_HourMinStr + ' am';
                };
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let idle_HourMinStr = format_hour.toString();
                idle_HourMinStr = idle_HourMinStr.padStart(2, '0');
                idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0');
                if (!timeSensor.is24Hour) {
                  if (hour > 11) idle_HourMinStr = idle_HourMinStr + ' pm';
                  else idle_HourMinStr = idle_HourMinStr + ' am';
                };
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr );
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 67,
                      center_y: 315,
                      start_angle: 139,
                      end_angle: -128,
                      radius: 36,
                      line_width: 18,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                updateWorldTime();
                setTimeout(() => {
                  if (worldClock) {
                    worldClock.uninit();
                    worldClock.init();
                  };
                }, 500);
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                worldClock.uninit();
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}