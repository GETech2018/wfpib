﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_stress_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_vo2max_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_bio_charge_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_stand_circle_scale = ''
        let normal_stand_target_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_vo2max_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 221,
              year_startY: 267,
              year_sc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              year_tc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              year_en_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 176,
              month_startY: 267,
              month_sc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              month_tc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              month_en_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '034.png',
              month_unit_tc: '034.png',
              month_unit_en: '034.png',
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 132,
              day_startY: 267,
              day_sc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              day_tc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              day_en_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '034.png',
              day_unit_tc: '034.png',
              day_unit_en: '034.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 409,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 409,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              unit_sc: '051.png',
              unit_tc: '051.png',
              unit_en: '051.png',
              invalid_image: '048.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 409,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              invalid_image: '048.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 409,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              unit_sc: '051.png',
              unit_tc: '051.png',
              unit_en: '051.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 14,
              y: 274,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              dot_image: '046.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 274,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              dot_image: '046.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 203,
              y: 311,
              image_array: ["w00.png","w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 355,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              unit_sc: '050.png',
              unit_tc: '050.png',
              unit_en: '050.png',
              imperial_unit_sc: '049.png',
              imperial_unit_tc: '049.png',
              imperial_unit_en: '049.png',
              negative_image: '047.png',
              invalid_image: '048.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 328,
                y: 355,
                font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
                padding: false,
                h_space: 1,
                unit_sc: '049.png',
                unit_tc: '049.png',
                unit_en: '049.png',
                imperial_unit_sc: '050.png',
                imperial_unit_tc: '050.png',
                imperial_unit_en: '050.png',
                negative_image: '047.png',
                invalid_image: '048.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 320,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              unit_sc: '050.png',
              unit_tc: '050.png',
              unit_en: '050.png',
              imperial_unit_sc: '049.png',
              imperial_unit_tc: '049.png',
              imperial_unit_en: '049.png',
              negative_image: '047.png',
              invalid_image: '048.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 328,
                y: 320,
                font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
                padding: false,
                h_space: 1,
                unit_sc: '049.png',
                unit_tc: '049.png',
                unit_en: '049.png',
                imperial_unit_sc: '050.png',
                imperial_unit_tc: '050.png',
                imperial_unit_en: '050.png',
                negative_image: '047.png',
                invalid_image: '048.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 359,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              unit_sc: '050.png',
              unit_tc: '050.png',
              unit_en: '050.png',
              imperial_unit_sc: '049.png',
              imperial_unit_tc: '049.png',
              imperial_unit_en: '049.png',
              negative_image: '047.png',
              invalid_image: '048.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 200,
                y: 359,
                font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
                padding: false,
                h_space: 1,
                unit_sc: '049.png',
                unit_tc: '049.png',
                unit_en: '049.png',
                imperial_unit_sc: '050.png',
                imperial_unit_tc: '050.png',
                imperial_unit_en: '050.png',
                negative_image: '047.png',
                invalid_image: '048.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 126,
              y: 352,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              y: 356,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              invalid_image: '048.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              y: 320,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              invalid_image: '048.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 85,
              // center_y: 97,
              // start_angle: -91,
              // end_angle: 1,
              // radius: 25,
              // line_width: 13,
              // line_cap: Flat,
              // color: 0xFF75BAFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 85,
              center_y: 97,
              start_angle: -91,
              end_angle: 1,
              radius: 19,
              line_width: 13,
              corner_flag: 3,
              color: 0xFF75BAFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 80,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 85,
              // center_y: 97,
              // start_angle: -90,
              // end_angle: 0,
              // radius: 44,
              // line_width: 14,
              // line_cap: Flat,
              // color: 0xFFFF8C00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 85,
              center_y: 97,
              start_angle: -90,
              end_angle: 0,
              radius: 37,
              line_width: 14,
              corner_flag: 3,
              color: 0xFFFF8C00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 55,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 82,
              // center_y: 94,
              // start_angle: -93,
              // end_angle: 3,
              // radius: 60,
              // line_width: 14,
              // line_cap: Flat,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 82,
              center_y: 94,
              start_angle: -93,
              end_angle: 3,
              radius: 53,
              line_width: 14,
              corner_flag: 3,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_stand_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 31,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 31,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: true,
              h_space: 1,
              unit_sc: '052.png',
              unit_tc: '052.png',
              unit_en: '052.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 21,
              y: 228,
              week_en: ["053.png","054.png","055.png","056.png","057.png","058.png","059.png"],
              week_tc: ["053.png","054.png","055.png","056.png","057.png","058.png","059.png"],
              week_sc: ["053.png","054.png","055.png","056.png","057.png","058.png","059.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 331,
              // center_y: 51,
              // start_angle: -181,
              // end_angle: 181,
              // radius: 21,
              // line_width: 4,
              // line_cap: Rounded,
              // color: 0xFF95CDEE,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 331,
              center_y: 51,
              start_angle: -181,
              end_angle: 181,
              radius: 19,
              line_width: 4,
              corner_flag: 0,
              color: 0xFF95CDEE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 79,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              unit_sc: '051.png',
              unit_tc: '051.png',
              unit_en: '051.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 7,
              hour_startY: 121,
              hour_array: ["014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 179,
              minute_startY: 121,
              minute_array: ["014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 323,
              second_startY: 139,
              second_array: ["004.png","005.png","006.png","007.png","008.png","009.png","010.png","011.png","012.png","013.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 221,
              year_startY: 267,
              year_sc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              year_tc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              year_en_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 176,
              month_startY: 267,
              month_sc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              month_tc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              month_en_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '034.png',
              month_unit_tc: '034.png',
              month_unit_en: '034.png',
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 132,
              day_startY: 267,
              day_sc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              day_tc_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              day_en_array: ["024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png","033.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '034.png',
              day_unit_tc: '034.png',
              day_unit_en: '034.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 21,
              y: 228,
              week_en: ["053.png","054.png","055.png","056.png","057.png","058.png","059.png"],
              week_tc: ["053.png","054.png","055.png","056.png","057.png","058.png","059.png"],
              week_sc: ["053.png","054.png","055.png","056.png","057.png","058.png","059.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 331,
              // center_y: 51,
              // start_angle: -181,
              // end_angle: 181,
              // radius: 21,
              // line_width: 4,
              // line_cap: Rounded,
              // color: 0xFF95CDEE,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 331,
              center_y: 51,
              start_angle: -181,
              end_angle: 181,
              radius: 19,
              line_width: 4,
              corner_flag: 0,
              color: 0xFF95CDEE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 79,
              font_array: ["035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png","043.png","044.png"],
              padding: false,
              h_space: 1,
              unit_sc: '051.png',
              unit_tc: '051.png',
              unit_en: '051.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 31,
              hour_startY: 121,
              hour_array: ["014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png"],
              hour_zero: 1,
              hour_space: 9,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 221,
              minute_startY: 121,
              minute_array: ["014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png"],
              minute_zero: 1,
              minute_space: 9,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 16,
              y: 311,
              w: 90,
              h: 36,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 115,
              y: 311,
              w: 62,
              h: 70,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 259,
              y: 27,
              w: 113,
              h: 78,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 5,
              y: 264,
              w: 113,
              h: 37,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 99,
              y: 27,
              w: 144,
              h: 25,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 111,
              y: 399,
              w: 95,
              h: 54,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 27,
              y: 399,
              w: 83,
              h: 54,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 311,
              y: 126,
              w: 78,
              h: 68,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 207,
              y: 399,
              w: 74,
              h: 54,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 99,
              y: 52,
              w: 144,
              h: 25,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 185,
              y: 311,
              w: 194,
              h: 72,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 99,
              y: 78,
              w: 144,
              h: 25,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 119,
              y: 228,
              w: 150,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: 'z_empty.png',
              normal_src: 'z_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 271,
              y: 264,
              w: 116,
              h: 37,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: 'z_empty.png',
              normal_src: 'z_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 16,
              y: 348,
              w: 90,
              h: 37,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: 'z_empty.png',
              normal_src: 'z_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 282,
              y: 399,
              w: 90,
              h: 54,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: 'z_empty.png',
              normal_src: 'z_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 85,
                      center_y: 97,
                      start_angle: -91,
                      end_angle: 1,
                      radius: 19,
                      line_width: 13,
                      corner_flag: 3,
                      color: 0xFF75BAFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 85,
                      center_y: 97,
                      start_angle: -90,
                      end_angle: 0,
                      radius: 37,
                      line_width: 14,
                      corner_flag: 3,
                      color: 0xFFFF8C00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 82,
                      center_y: 94,
                      start_angle: -93,
                      end_angle: 3,
                      radius: 53,
                      line_width: 14,
                      corner_flag: 3,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 331,
                      center_y: 51,
                      start_angle: -181,
                      end_angle: 181,
                      radius: 19,
                      line_width: 4,
                      corner_flag: 0,
                      color: 0xFF95CDEE,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 331,
                      center_y: 51,
                      start_angle: -181,
                      end_angle: 181,
                      radius: 19,
                      line_width: 4,
                      corner_flag: 0,
                      color: 0xFF95CDEE,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}