﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_heart_rate_text_text_img = ''
        let normal_system_clock_img = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 136,
              y: 412,
              src: 'BATTERYBAR_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 136,
              y: 412,
              image_array: ["BATTERYBAR_10.png","BATTERYBAR_20.png","BATTERYBAR_30.png","BATTERYBAR_40.png","BATTERYBAR_50.png","BATTERYBAR_60.png","BATTERYBAR_70.png","BATTERYBAR_80.png","BATTERYBAR_90.png","BATTERYBAR_100.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 345,
              font_array: ["NUMBER_RED_0.png","NUMBER_RED_1.png","NUMBER_RED_2.png","NUMBER_RED_3.png","NUMBER_RED_4.png","NUMBER_RED_5.png","NUMBER_RED_6.png","NUMBER_RED_7.png","NUMBER_RED_8.png","NUMBER_RED_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 280,
              font_array: ["NUMBER_GREY_0.png","NUMBER_GREY_1.png","NUMBER_GREY_2.png","NUMBER_GREY_3.png","NUMBER_GREY_4.png","NUMBER_GREY_5.png","NUMBER_GREY_6.png","NUMBER_GREY_7.png","NUMBER_GREY_8.png","NUMBER_GREY_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 215,
              font_array: ["NUMBER_GREY_0.png","NUMBER_GREY_1.png","NUMBER_GREY_2.png","NUMBER_GREY_3.png","NUMBER_GREY_4.png","NUMBER_GREY_5.png","NUMBER_GREY_6.png","NUMBER_GREY_7.png","NUMBER_GREY_8.png","NUMBER_GREY_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'DEGREE_GREY.png',
              unit_tc: 'DEGREE_GREY.png',
              unit_en: 'DEGREE_GREY.png',
              invalid_image: 'NODATA.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 241,
              month_startY: 150,
              month_sc_array: ["NUMBER_GREY_0.png","NUMBER_GREY_1.png","NUMBER_GREY_2.png","NUMBER_GREY_3.png","NUMBER_GREY_4.png","NUMBER_GREY_5.png","NUMBER_GREY_6.png","NUMBER_GREY_7.png","NUMBER_GREY_8.png","NUMBER_GREY_9.png"],
              month_tc_array: ["NUMBER_GREY_0.png","NUMBER_GREY_1.png","NUMBER_GREY_2.png","NUMBER_GREY_3.png","NUMBER_GREY_4.png","NUMBER_GREY_5.png","NUMBER_GREY_6.png","NUMBER_GREY_7.png","NUMBER_GREY_8.png","NUMBER_GREY_9.png"],
              month_en_array: ["NUMBER_GREY_0.png","NUMBER_GREY_1.png","NUMBER_GREY_2.png","NUMBER_GREY_3.png","NUMBER_GREY_4.png","NUMBER_GREY_5.png","NUMBER_GREY_6.png","NUMBER_GREY_7.png","NUMBER_GREY_8.png","NUMBER_GREY_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 115,
              day_startY: 150,
              day_sc_array: ["NUMBER_GREY_0.png","NUMBER_GREY_1.png","NUMBER_GREY_2.png","NUMBER_GREY_3.png","NUMBER_GREY_4.png","NUMBER_GREY_5.png","NUMBER_GREY_6.png","NUMBER_GREY_7.png","NUMBER_GREY_8.png","NUMBER_GREY_9.png"],
              day_tc_array: ["NUMBER_GREY_0.png","NUMBER_GREY_1.png","NUMBER_GREY_2.png","NUMBER_GREY_3.png","NUMBER_GREY_4.png","NUMBER_GREY_5.png","NUMBER_GREY_6.png","NUMBER_GREY_7.png","NUMBER_GREY_8.png","NUMBER_GREY_9.png"],
              day_en_array: ["NUMBER_GREY_0.png","NUMBER_GREY_1.png","NUMBER_GREY_2.png","NUMBER_GREY_3.png","NUMBER_GREY_4.png","NUMBER_GREY_5.png","NUMBER_GREY_6.png","NUMBER_GREY_7.png","NUMBER_GREY_8.png","NUMBER_GREY_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'DOT_GREY.png',
              day_unit_tc: 'DOT_GREY.png',
              day_unit_en: 'DOT_GREY.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 241,
              minute_startY: 85,
              minute_array: ["NUMBER_WHITE_0.png","NUMBER_WHITE_1.png","NUMBER_WHITE_2.png","NUMBER_WHITE_3.png","NUMBER_WHITE_4.png","NUMBER_WHITE_5.png","NUMBER_WHITE_6.png","NUMBER_WHITE_7.png","NUMBER_WHITE_8.png","NUMBER_WHITE_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 115,
              hour_startY: 85,
              hour_array: ["NUMBER_WHITE_0.png","NUMBER_WHITE_1.png","NUMBER_WHITE_2.png","NUMBER_WHITE_3.png","NUMBER_WHITE_4.png","NUMBER_WHITE_5.png","NUMBER_WHITE_6.png","NUMBER_WHITE_7.png","NUMBER_WHITE_8.png","NUMBER_WHITE_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'CLOCK_SEPARATOR_WHITE.png',
              hour_unit_tc: 'CLOCK_SEPARATOR_WHITE.png',
              hour_unit_en: 'CLOCK_SEPARATOR_WHITE.png',
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 20,
              font_array: ["NUMBER_RED_0.png","NUMBER_RED_1.png","NUMBER_RED_2.png","NUMBER_RED_3.png","NUMBER_RED_4.png","NUMBER_RED_5.png","NUMBER_RED_6.png","NUMBER_RED_7.png","NUMBER_RED_8.png","NUMBER_RED_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ICON_HRM.png',
              unit_tc: 'ICON_HRM.png',
              unit_en: 'ICON_HRM.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 270,
              y: 355,
              src: 'ICON_ALARM.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 310,
              y: 355,
              src: 'ICON_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 241,
              minute_startY: 85,
              minute_array: ["NUMBER_WHITE_0.png","NUMBER_WHITE_1.png","NUMBER_WHITE_2.png","NUMBER_WHITE_3.png","NUMBER_WHITE_4.png","NUMBER_WHITE_5.png","NUMBER_WHITE_6.png","NUMBER_WHITE_7.png","NUMBER_WHITE_8.png","NUMBER_WHITE_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 115,
              hour_startY: 85,
              hour_array: ["NUMBER_WHITE_0.png","NUMBER_WHITE_1.png","NUMBER_WHITE_2.png","NUMBER_WHITE_3.png","NUMBER_WHITE_4.png","NUMBER_WHITE_5.png","NUMBER_WHITE_6.png","NUMBER_WHITE_7.png","NUMBER_WHITE_8.png","NUMBER_WHITE_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'CLOCK_SEPARATOR_WHITE.png',
              hour_unit_tc: 'CLOCK_SEPARATOR_WHITE.png',
              hour_unit_en: 'CLOCK_SEPARATOR_WHITE.png',
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: DESCONECTADO,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: CONECTADO,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "DESCONECTADO"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "CONECTADO"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 110,
              y: 275,
              w: 220,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 110,
              y: 15,
              w: 220,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 110,
              y: 80,
              w: 220,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 110,
              y: 145,
              w: 220,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 110,
              y: 210,
              w: 220,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}