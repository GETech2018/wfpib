﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_cal_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 320,
              h: 380,
              src: '106EN.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 219,
              y: 308,
              image_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 126,
              y: 315,
              font_array: ["n_0012.png","n_0013.png","n_0014.png","n_0015.png","n_0016.png","n_0017.png","n_0018.png","n_0019.png","n_0020.png","n_0021.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'w_0066.png',
              unit_tc: 'w_0066.png',
              unit_en: 'w_0066.png',
              negative_image: '0065.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 314,
              font_array: ["n_0012.png","n_0013.png","n_0014.png","n_0015.png","n_0016.png","n_0017.png","n_0018.png","n_0019.png","n_0020.png","n_0021.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'w_0066.png',
              unit_tc: 'w_0066.png',
              unit_en: 'w_0066.png',
              negative_image: '0065.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 272,
              font_array: ["n_0068.png","n_0069.png","n_0070.png","n_0071.png","n_0072.png","n_0073.png","n_0074.png","n_0075.png","n_0076.png","n_0077.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'w_0066.png',
              unit_tc: 'w_0066.png',
              unit_en: 'w_0066.png',
              negative_image: '0065.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 66,
              // center_y: 192,
              // start_angle: 0,
              // end_angle: 357,
              // radius: 15,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFF0080FF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 66,
              center_y: 192,
              start_angle: 0,
              end_angle: 357,
              radius: 13,
              line_width: 5,
              corner_flag: 0,
              color: 0xFF0080FF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 221,
              font_array: ["n_0012.png","n_0013.png","n_0014.png","n_0015.png","n_0016.png","n_0017.png","n_0018.png","n_0019.png","n_0020.png","n_0021.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 66,
              // center_y: 193,
              // start_angle: 0,
              // end_angle: 359,
              // radius: 28,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFF00FF00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 66,
              center_y: 193,
              start_angle: 0,
              end_angle: 359,
              radius: 26,
              line_width: 5,
              corner_flag: 0,
              color: 0xFF00FF00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 196,
              font_array: ["n_0012.png","n_0013.png","n_0014.png","n_0015.png","n_0016.png","n_0017.png","n_0018.png","n_0019.png","n_0020.png","n_0021.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 66,
              // center_y: 192,
              // start_angle: 0,
              // end_angle: 377,
              // radius: 39,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFFFF0080,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 66,
              center_y: 192,
              start_angle: 0,
              end_angle: 377,
              radius: 37,
              line_width: 5,
              corner_flag: 0,
              color: 0xFFFF0080,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 173,
              font_array: ["n_0012.png","n_0013.png","n_0014.png","n_0015.png","n_0016.png","n_0017.png","n_0018.png","n_0019.png","n_0020.png","n_0021.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 25,
              y: 41,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 257,
              day_startY: 32,
              day_sc_array: ["n_0068.png","n_0069.png","n_0070.png","n_0071.png","n_0072.png","n_0073.png","n_0074.png","n_0075.png","n_0076.png","n_0077.png"],
              day_tc_array: ["n_0068.png","n_0069.png","n_0070.png","n_0071.png","n_0072.png","n_0073.png","n_0074.png","n_0075.png","n_0076.png","n_0077.png"],
              day_en_array: ["n_0068.png","n_0069.png","n_0070.png","n_0071.png","n_0072.png","n_0073.png","n_0074.png","n_0075.png","n_0076.png","n_0077.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 181,
              y: 34,
              week_en: ["day_0026.png","day_0027.png","day_0028.png","day_0029.png","day_0030.png","day_0031.png","day_0038.png"],
              week_tc: ["day_0026.png","day_0027.png","day_0028.png","day_0029.png","day_0030.png","day_0031.png","day_0038.png"],
              week_sc: ["day_0026.png","day_0027.png","day_0028.png","day_0029.png","day_0030.png","day_0031.png","day_0038.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 132,
              hour_startY: 68,
              hour_array: ["n_0002.png","n_0003.png","n_0004.png","n_0005.png","n_0006.png","n_0007.png","n_0008.png","n_0009.png","n_0010.png","n_0011.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 228,
              minute_startY: 68,
              minute_array: ["n_0002.png","n_0003.png","n_0004.png","n_0005.png","n_0006.png","n_0007.png","n_0008.png","n_0009.png","n_0010.png","n_0011.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 209,
              y: 74,
              src: 'se.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 14,
              y: 139,
              w: 100,
              h: 100,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 18,
              y: 30,
              w: 69,
              h: 78,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 183,
              y: 257,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 120,
              y: 139,
              w: 100,
              h: 100,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 60,
              y: 252,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 66,
                      center_y: 192,
                      start_angle: 0,
                      end_angle: 357,
                      radius: 13,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFF0080FF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 66,
                      center_y: 193,
                      start_angle: 0,
                      end_angle: 359,
                      radius: 26,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFF00FF00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 66,
                      center_y: 192,
                      start_angle: 0,
                      end_angle: 377,
                      radius: 37,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFFFF0080,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}