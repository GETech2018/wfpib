﻿
    try {
     (() => {
      //start of ignored block
      const __$$app$$__ = __$$hmAppManager$$__.currentApp;

      function getApp() {
       return __$$app$$__.app;
      }

      function getCurrentPage() {
       return __$$app$$__.current && __$$app$$__.current.module;
      }
      const __$$module$$__ = __$$app$$__.current;
      const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
      const {
       px
      } = __$$app$$__.__globals__;
      //const logger = Logger.getLogger('watchface_SashaCX75');
      const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
      //end of ignored block

      const {
       width: D_W,
       height: D_H
      } = hmSetting.getDeviceInfo();

      let groupSetting = ''
      let groupPogoda = ''
      let groupTap = ''
      let groupVremya = ''
      let btn_left_up = ''
      let btn_right_up = ''
      let text_main = ''
	  
      let Button_block_off = ''
      let block = ''
      let btn_str = ''
      let btn_Set_on = ''
      let btn_Set_off = ''
      let btn_tip_grafik = ''
      let btn_Pogoda_off = ''
      let FILL_RECT_progress_bg = ''
      let FILL_RECT_progress = ''
      let FILL_RECT_0 = ''
      let FILL_RECT_1 = ''
      let FILL_RECT_2 = ''
      let FILL_RECT_3 = ''
      let FILL_RECT_4 = ''
      let btn_left_dw = ''
      let btn_right_dw = ''
      let ic_graf_img = ''

      //dynamic modify start

      let len_month = [93, 115, 80, 94, 51, 70, 70, 106, 120, 106, 92, 111];
      let len_week = [177, 108, 78, 101, 112, 107, 165];
      let len_data = 76;


      let normal_background_bg = ''
      let normal_image_img = ''
      let normal_second_circle_scale = ''
      let normal_timerUpdateSec = undefined;
      let normal_hrv_icon_img = ''
      let normal_stand_icon_img = ''
      let normal_step_linear_scale = ''
      let normal_step_current_text_font = ''
      let normal_battery_linear_scale = ''
      let normal_month_name_font = ''
      let normal_Month_Array = ['ЯНВАРЯ', 'ФЕВРАЛЯ', 'МАРТА', 'АПРЕЛЯ', 'МАЯ', 'ИЮНЯ', 'ИЮЛЯ', 'АВГУСТА', 'СЕНТЯБРЯ', 'ОКТЯБРЯ', 'НОЯБРЯ', 'ДЕКАБРЯ', ];
      let normal_day_text_font = ''
      let normal_dow_text_font = ''
      let normal_DOW_Array = ['ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА', 'ВОСКРЕСЕНЬЕ'];
      let normal_date_img_date_week_img = ''
      let normal_time_hour_text_font = ''
      let normal_timerTimeUpdate = undefined;
        let idle_timerTimeUpdate = undefined;
      let normal_time_minute_text_font = ''
      let normal_system_disconnect_img = ''
      let normal_system_clock_img = ''
      let timeSensor = '';
      let bg_week = [];
      let idle_bg_week = [];


      let Button_1 = ''
      let Button_2 = ''

      let bg_bat_circ = ''
      let bg_step_circ = ''
      let bg_bat_0 = ''
      let bg_step_0 = ''
      let bg_bat = ''
      let bg_step = ''
      let bg_line = ''
      
      
        let idle_time_hour_text_font = ''
        let idle_time_minute_text_font = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''      
        let idle_day_text_font = ''
        let idle_month_name_font = ''
        let idle_dow_text_font = ''
        let idle_background_bg = ''
        let idle_select_week = ''
      let idle_step_linear_scale = ''
      let idle_battery_linear_scale = ''
      
        let idle_image_img = ''
        let idle_second_circle_scale = ''
        let idle_bg_bat_circ = ''
        let idle_bg_step_circ = ''
        let idle_bg_bat_0 = ''
        let idle_bg_step_0 = ''
        let idle_bg_bat = ''
        let idle_bg_step = ''
        
        let idle_stand_icon_img = ''
        let idle_bg_line = ''

/*        let idle_text_up_left = ''
        let idle_text_up_right = ''
        let idle_text_dw_left = ''
        let idle_text_dw_right = ''
*/        
        let normal_text_up_left = ''
        let normal_text_up_right = ''
        let normal_text_dw_left = ''
        let normal_text_dw_right = ''
        
      

      // Добавьте эти объявления в раздел с другими переменными
      let select_week = '';
      
      
      let canvas = '';
      let normal_image_tap_img = '';

      const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
      let stopVibro_Timer = null;

      function vibro(scene = 25) {
       let stopDelay = 50;
       vibrate.stop();
       vibrate.scene = scene;
       if (scene < 23 || scene > 25) stopDelay = 1220;
       vibrate.start();
       stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
      }

      function stopVibro() {
       vibrate.stop();
       timer.stopTimer(stopVibro_Timer);
      }

      function click_block_on() {
       Button_block_off.setProperty(hmUI.prop.VISIBLE, true);
       block.setProperty(hmUI.prop.VISIBLE, true);
       normal_text_up_left.setProperty(hmUI.prop.ALPHA, 128);
       normal_text_up_right.setProperty(hmUI.prop.ALPHA, 128);
       normal_text_dw_left.setProperty(hmUI.prop.TEXT, "ОТКР");
       normal_text_dw_right.setProperty(hmUI.prop.ALPHA, 128);
      }

      function click_block_off() {
       Button_block_off.setProperty(hmUI.prop.VISIBLE, false);
       block.setProperty(hmUI.prop.VISIBLE, false);
       normal_text_up_left.setProperty(hmUI.prop.ALPHA, 255);
       normal_text_up_right.setProperty(hmUI.prop.ALPHA, 255);
       normal_text_dw_left.setProperty(hmUI.prop.TEXT, "БЛОК");
       normal_text_dw_right.setProperty(hmUI.prop.ALPHA, 255);

      }


      function click_tap_on() {
       groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       groupTap.setProperty(hmUI.prop.VISIBLE, true);

       for (let i = 0; i < 6; i++) {
        tap_IMG_run[i].setProperty(hmUI.prop.MORE, {
         x: i < 3 ? 10 + 6 + i * 124 : 10 + 6 + (i - 3) * 124,
         y: i < 3 ? 94 + 6 : 94 + 6 + 137,
         //src: apps[i][2],
         src: apps[CONF_TAP[i].id][2],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_tap_run[i].setProperty(hmUI.prop.MORE, {
         x: i < 3 ? 10 + i * 124 : 10 + (i - 3) * 124,
         y: i < 3 ? 94 : 94 + 137,
         w: 125,
         h: 125,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          // crow_tap = i 
          const app = apps[CONF_TAP[i].id];
          hmApp.startApp({
           appid: app[3] === 0 ? '' : app[1],
           url: app[3] === 0 ? app[1] : app[4],
           native: app[3] === 0,
           params: app[3] === 0 ? null : {
            from_wf: true
           },
          });

         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button
       }; // end button 


       //vibro();	
      }


      function loadSettings() {

       if (hmFS.SysProGetInt('OMG_218_bip_6_tip_grafik') === undefined) {
        tip_grafik = 0;
        hmFS.SysProSetInt('OMG_218_bip_6_tip_grafik', tip_grafik);
       } else {
        tip_grafik = hmFS.SysProGetInt('OMG_218_bip_6_tip_grafik');
       }
       if (hmFS.SysProGetInt('OMG_218_bip_6_crown') === undefined) {
        crown = 0;
        hmFS.SysProSetInt('OMG_218_bip_6_crown', crown);
       } else {
        crown = hmFS.SysProGetInt('OMG_218_bip_6_crown');
       }

       for (let i = 0; i < CONF_MAIN.length; i++) {
        const defaultValue = CONF_MAIN[i].id; // Берём значение из CONF_MAIN
        CONF_MAIN[i].id = hmFS.SysProGetInt('OMG_218_bip_6_mum_' + i) === undefined
         ? (hmFS.SysProSetInt('OMG_218_bip_6_mum_' + i, defaultValue), defaultValue)
         : hmFS.SysProGetInt('OMG_218_bip_6_mum_' + i);
       }

       for (let i = 0; i < CONF_TAP.length; i++) {
        const defaultValue2 = CONF_TAP[i].id; // Берём значение из CONF_MAIN
        CONF_TAP[i].id = hmFS.SysProGetInt('OMG_218_bip_6_crow_tap_' + i) === undefined
         ? (hmFS.SysProSetInt('OMG_218_bip_6_crow_tap_' + i, defaultValue2), defaultValue2)
         : hmFS.SysProGetInt('OMG_218_bip_6_crow_tap_' + i);
       }

      }

      let color_bg = [0xFF0000, 0xFF4500, 0xDC143C, 0xFF69B4, 0xFF1493, 0xFF8C00, 0xFFA500, 0xFFD700, 0xFFFF00, 0x228B22, 0x9bfc00, 0x00FF00, 0x98FF98, 0x50C878, 0x00FFFF, 0x00CED1, 0x40E0D0, 0x7FFFD4, 0x00bff0, 0x1E90FF, 0x007FFF, 0x00008B, 0x4B0082, 0x800080, 0x9932CC, 0x8A2BE2, 0xDA70D6, 0xA52A2A, 0xD2691E, 0x8B4513, 0x926226, 0xFFFFFF, 0xD3D3D3, 0x808080, 0x505050];

      // let color_bg = [0xFF0000, 0xFFFF00, 0xFFFFFF, 0x0000FF, 0x00FFFF];


      const battery = hmSensor.createSensor(hmSensor.id.BATTERY)
      //const step = hmSensor.createSensor(hmSensor.id.STEP);
      const heart_rate = hmSensor.createSensor(hmSensor.id.HEART); //heart_rate.last
      const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
      const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
      const stand = hmSensor.createSensor(hmSensor.id.STAND)
      const pai = hmSensor.createSensor(hmSensor.id.PAI);
      const fatburn = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
      const spo2 = hmSensor.createSensor(hmSensor.id.SPO2);
      const stress = hmSensor.createSensor(hmSensor.id.STRESS);

      let app_ACR_text = []

      let app_text_arr = [
       ['ШАГИ', hmUI.data_type.STEP, false, 0, 1], //0
       ['ПУЛЬС', hmUI.data_type.HEART, false, 0, 1], //1
       ['КАЛОРИИ', hmUI.data_type.CAL, false, 0, 1], //2
       ['ЗАРЯД', hmUI.data_type.BATTERY, false, 1, 1], //3
       ['КМ', hmUI.data_type.DISTANCE, false, 0, 1], //4
       // ['ММ.РТ.СТ', hmUI.data_type.ALTIMETER, false, 0, 1], //5
       // ['ВЫСОТА', hmUI.data_type.ALTITUDE, false, 0, 0], //6
       ['ВЛАЖНОСТЬ', hmUI.data_type.HUMIDITY, false, 1, 0], //5
       ['ПОГОДА', hmUI.data_type.WEATHER_HIGH_LOW, false, 0, 1], //6
       ['ВОС/ЗАК', hmUI.data_type.SUN_RISE, false, 0, 1], //7
       ['ГОРОД', hmUI.data_type.SUN_SET, false, 0, 1], //8
       ['СТРЕСС', hmUI.data_type.STRESS, false, 0, 0], //9
       ['КИСЛОРОД', hmUI.data_type.SPO2, false, 0, 1], //10
       ['PAI', hmUI.data_type.PAI_DAILY, false, 0, 1], //11
       ['ЖИР', hmUI.data_type.FAT_BURNING, false, 0, 1], //12
       ['УФ', hmUI.data_type.UVI, false, 0, 0], //13
       ['РАЗМИНКА', hmUI.data_type.STAND, false, 0, 1], //14
       ['БУДИЛЬНИК', hmUI.data_type.ALARM_CLOCK, true, 0, 0], //15
       ['ТАЙМЕР', hmUI.data_type.COUNT_DOWN, true, 0, 0], //16
       ['СОН', hmUI.data_type.FLOOR, false, 0, 1], //17
       ['HRV', hmUI.data_type.HRV, false, 0, 0], //18
       ['ГОТОВНОСТЬ', hmUI.data_type.READINESS, false, 0, 0], //19
      ];

      let apps = [
       ['Нет действия', '-', `tap/i_tap_pusto.png`, 0, 'page/index'],
       ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`, 0, 'page/index'],
       ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`, 0, 'page/index'],
       ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`, 0, 'page/index'],
       ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`, 0, 'page/index'],
       ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`, 0, 'page/index'],
       ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`, 0, 'page/index'],
       ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`, 0, 'page/index'],
       ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`, 0, 'page/index'],
       ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`, 0, 'page/index'],
       ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`, 0, 'page/index'],
       ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`, 0, 'page/index'],
       ['Музыка', 'LocalMusicScreen', `tap/i_tap_musik.png`, 0, 'page/index'], //'PhoneMusicCtrlScreen'
       ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`, 0, 'page/index'],
       ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`, 0, 'page/index'],
       ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`, 0, 'page/index'],
       ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`, 0, 'page/index'],
       ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`, 0, 'page/index'],
       ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`, 0, 'page/index'],
       ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`, 0, 'page/index'],
       ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`, 0, 'page/index'],
       ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`, 0, 'page/index'],
       ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`, 0, 'page/index'],
       ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`, 0, 'page/index'],
       ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`, 0, 'page/index'],
       ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`, 0, 'page/index'],
       ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`, 0, 'page/index'],
       ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`, 0, 'page/index'],
       ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`, 0, 'page/index'],
       ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`, 0, 'page/index'],
       ['Погода LeXxiR', '1051195', `tap/i_tap_LeXxiR.png`, 1, 'page/index'],
       //['Календарь Sasha', '1057409', `tap/i_tap_calen_Sasha.png`, 1, 'page/index'],
       ['Flow', '1038314', `tap/i_tap_flow.png`, 1, 'page/gtr/home/index.page'],
       ['Ночной режим', 'Settings_nsModeHomeScreen', `tap/i_tap_night_Mode_Screen.png`, 0, 'page/index'],
       ['Говорящие часы', '1066653', `tap/i_tap_talking_watch.png`, 1, 'page/index.page'],
       ['Перезагрузка', 'HmReStartScreen', `tap/i_tap_restart.png`, 0, 'page/index'],
      ];


      let CONF_MAIN = [{ // 0. Вертикальный градиент (3 цвета)
       name: 'ЦВЕТ', // кнопка
       id: 10, // при старте
       len: color_bg.length, // длина
       type: 0, // цвет или данные
      }, { // 1. Горизонтальный градиент (2 цвета)
       name: 'APP', // кнопка
       id: 0,
       len: app_text_arr.length, // длина
       type: 1,
      }, { // 2. Одноцветный прямоугольник
       name: 'ЯРЛЫКИ', // кнопка
       id: 31,
       len: apps.length, // длина
       type: 2,
      }, ]

      let crow_tap = 0;

      let CONF_TAP = [{ // 0. Вертикальный градиент (3 цвета)
        name: 'ЦВЕТ', // кнопка
        id: 19, // при старте
        len: apps.length, // длина
        type: 1, // цвет или данные
       }, { // 1. Горизонтальный градиент (2 цвета)
        name: 'APP', // кнопка
        id: 20,
        len: apps.length, // длина
        type: 1,
       }, { // 2. Одноцветный прямоугольник
        name: 'ЯРЛЫКИ', // кнопка
        id: 24,
        len: apps.length, // длина
        type: 1,
       }, { // 2. Одноцветный прямоугольник
        name: 'ЯРЛЫКИ', // кнопка
        id: 11,
        len: apps.length, // длина
        type: 1,
       }, { // 2. Одноцветный прямоугольник
        name: 'ЯРЛЫКИ', // кнопка
        id: 34,
        len: apps.length, // длина
        type: 1,
       }, { // 2. Одноцветный прямоугольник
        name: 'ЯРЛЫКИ', // кнопка
        id: 0,
        len: apps.length, // длина
        type: 1,
       },

      ]


      let tap_circ_ = []
      let tap_text_tips_ = []
      let tap_IMG_run = []
      let tap_IMG_ = []

      let tap_IMG_tips_ = []
	let tap_IMG_tips_X = [0, 96, 195, 0, 96, 195,]	
      let btn_tap_ = []
      let btn_tap_run = []


      function select() {

       FILL_RECT_0.setProperty(hmUI.prop.VISIBLE, crown == 0);
       FILL_RECT_1.setProperty(hmUI.prop.VISIBLE, crown == 0);
       FILL_RECT_2.setProperty(hmUI.prop.VISIBLE, crown == 0);
       FILL_RECT_3.setProperty(hmUI.prop.VISIBLE, crown == 0);
       FILL_RECT_4.setProperty(hmUI.prop.VISIBLE, crown == 0);

       for (let i = 0; i < 6; i++) {
        tap_circ_[i].setProperty(hmUI.prop.VISIBLE, crown == 2);
        tap_circ_[i].setProperty(hmUI.prop.COLOR, crow_tap == i ? 0xff0000 : 0x00ff00);
        tap_text_tips_[i].setProperty(hmUI.prop.VISIBLE, crown == 2 && crow_tap == i);
        tap_text_tips_[i].setProperty(hmUI.prop.TEXT, apps[CONF_TAP[crow_tap].id][0]);
        if (crow_tap == i) tap_IMG_[i].setProperty(hmUI.prop.SRC, apps[CONF_TAP[crow_tap].id][2]);
        tap_IMG_[i].setProperty(hmUI.prop.VISIBLE, crown == 2);
        tap_IMG_tips_[i].setProperty(hmUI.prop.VISIBLE, crown == 2 && crow_tap == i);
        btn_tap_[i].setProperty(hmUI.prop.VISIBLE, crown == 2);
       };


       let color_0 = (CONF_MAIN[crown].id - 2 + color_bg.length) % color_bg.length;
       let color_1 = (CONF_MAIN[crown].id - 1 + color_bg.length) % color_bg.length;
       let color_3 = (CONF_MAIN[crown].id + 1 + color_bg.length) % color_bg.length;
       let color_4 = (CONF_MAIN[crown].id + 2 + color_bg.length) % color_bg.length;
       FILL_RECT_0.setProperty(hmUI.prop.COLOR, color_bg[color_0]);
       FILL_RECT_1.setProperty(hmUI.prop.COLOR, color_bg[color_1]);
       FILL_RECT_2.setProperty(hmUI.prop.COLOR, color_bg[CONF_MAIN[crown].id]);
       FILL_RECT_3.setProperty(hmUI.prop.COLOR, color_bg[color_3]);
       FILL_RECT_4.setProperty(hmUI.prop.COLOR, color_bg[color_4]);


       for (let i = 0; i < app_text_arr.length; i++) {
        app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, crown == 1);
        if (crown == 1) app_ACR_text[i].setProperty(hmUI.prop.COLOR, CONF_MAIN[crown].id == i ? 0xff0000 : 0xffffff);
       };


       if (crown < 2) {
        let len_progress = 300 / CONF_MAIN[crown].len < 20 ? 20 : 300 / CONF_MAIN[crown].len;
        FILL_RECT_progress.setProperty(hmUI.prop.H, len_progress);
        FILL_RECT_progress.setProperty(hmUI.prop.Y, 75 + CONF_MAIN[crown].id * (300 - len_progress) / (CONF_MAIN[crown].len - 1));
       } else {
        let len_progress = 300 / CONF_TAP[crow_tap].len < 20 ? 20 : 300 / CONF_TAP[crow_tap].len;
        FILL_RECT_progress.setProperty(hmUI.prop.H, len_progress);
        FILL_RECT_progress.setProperty(hmUI.prop.Y, 75 + CONF_TAP[crow_tap].id * (300 - len_progress) / (CONF_TAP[crow_tap].len - 1));
       }

      }

      function click_tap(step) {
       CONF_TAP[crow_tap].id = (CONF_TAP[crow_tap].id + step + apps.length) % apps.length
       hmFS.SysProSetInt('OMG_218_bip_6_crow_tap_' + crow_tap, CONF_TAP[crow_tap].id);
       tap_IMG_[crow_tap].setProperty(hmUI.prop.SRC, apps[CONF_TAP[crow_tap].id][2]);
       tap_text_tips_[crow_tap].setProperty(hmUI.prop.TEXT, apps[CONF_TAP[crow_tap].id][0]);

       let len_progress = 300 / CONF_TAP[crow_tap].len < 20 ? 20 : 300 / CONF_TAP[crow_tap].len;
       FILL_RECT_progress.setProperty(hmUI.prop.H, len_progress);
       FILL_RECT_progress.setProperty(hmUI.prop.Y, 75 + CONF_TAP[crow_tap].id * (300 - len_progress) / (CONF_TAP[crow_tap].len - 1));

      }


      let step = 0;
      let btn_left = '';
      let btn_right = '';
      let btn_left_app = '';
      let btn_right_app = '';
      let color = 0;

      function click_color(step) {
       CONF_MAIN[crown].id = (CONF_MAIN[crown].id + step + color_bg.length) % color_bg.length
       wgt_start(CONF_MAIN[crown].id)
       hmFS.SysProSetInt('OMG_218_bip_6_mum_' + crown, CONF_MAIN[crown].id);

       select()


      }


      function wgt_start(color = CONF_MAIN[0].id) {
       normal_background_bg.setProperty(hmUI.prop.COLOR, color_bg[color]);
       bg_line.setProperty(hmUI.prop.COLOR, color_bg[color]);
       bg_bat.setProperty(hmUI.prop.COLOR, color_bg[color]);
       bg_step.setProperty(hmUI.prop.COLOR, color_bg[color]);
       bg_bat_circ.setProperty(hmUI.prop.COLOR, color_bg[color]);
       bg_step_circ.setProperty(hmUI.prop.COLOR, color_bg[color]);
       normal_dow_text_font.setProperty(hmUI.prop.COLOR, color_bg[color]);
       normal_time_minute_text_font.setProperty(hmUI.prop.COLOR, color_bg[color]);
       normal_battery_linear_scale.setProperty(hmUI.prop.COLOR, color_bg[color]);
       normal_step_linear_scale.setProperty(hmUI.prop.COLOR, color_bg[color]);
       normal_second_circle_scale.setProperty(hmUI.prop.MORE, {
        center_x: 195,
        center_y: 225,
        start_angle: 0,
        end_angle: 360,
        radius: 199,
        line_width: 85,
        corner_flag: 3,
        color: color_bg[color],
        show_level: hmUI.show_level.ONLY_NORMAL,
       });
       for (let i = 0; i < 7; i++) {
        bg_week[i].setProperty(hmUI.prop.COLOR, color_bg[color]);
       }
      }

      let crown = 0;

      function click_crown(step) {
       crown = (crown + step + CONF_MAIN.length) % CONF_MAIN.length
       hmFS.SysProSetInt('OMG_218_bip_6_crown', crown);
       text_main.setProperty(hmUI.prop.TEXT, CONF_MAIN[crown].name);
       select()
      }


      let normal_current_text_sensor = ''
      let idle_current_text_sensor = ''
      let normal_up_current_text_font = []
      let idle_up_current_text_font = []
      

      let app_text_num = 0;

      function click_app(step) {
       CONF_MAIN[crown].id = (CONF_MAIN[crown].id + step + app_text_arr.length) % app_text_arr.length
       hmFS.SysProSetInt('OMG_218_bip_6_mum_' + crown, CONF_MAIN[crown].id);

       app_text.setProperty(hmUI.prop.TEXT, app_text_arr[CONF_MAIN[crown].id][0]);
       normal_current_text_sensor.setProperty(hmUI.prop.MORE, {
        x: 105 - 38,
        y: 280 - 9,
        w: 256,
        h: 100,
        text: app_text_arr[CONF_MAIN[crown].id][1],
        text_size: CONF_MAIN[crown].id == 6 ? 39 : CONF_MAIN[crown].id == 8 ? 39 : 70, //70
        char_space: 0,
        line_space: -20,
        font: 'fonts/Bebas11.ttf',
        color: 0xFFFFFFFF,
        align_h: hmUI.align.CENTER_H,
        align_v: hmUI.align.CENTER_V,
        text_style: CONF_MAIN[crown].id == 8 ? hmUI.text_style.NONE : hmUI.text_style.WRAP,
        // text_style: hmUI.text_style.WRAP,//переносить текст
        // text_style: hmUI.text_style.NONE,//бегущая строка
        // padding: app_text_arr[i][2],
        // type: app_text_arr[i][1],
        // unit_type: app_text_arr[i][3],
        show_level: hmUI.show_level.ONLY_NORMAL,
       });

       normal_current_text_sensor.setProperty(hmUI.prop.VISIBLE, app_text_arr[CONF_MAIN[crown].id][4] == 1);

       for (var i = 0; i < app_text_arr.length; i++) {
        if (app_text_arr[i][4] == 0) {
         normal_up_current_text_font[i].setProperty(hmUI.prop.VISIBLE, i == CONF_MAIN[crown].id);
        }
       }


       select()


      }

      let app_text = '';
      let idle_app_text = '';

      function app_update() {
       let step = hmSensor.createSensor(hmSensor.id.STEP);

       let distanceCurrent = distance.current;
       app_text_arr[0][1] = String(step.current);
       app_text_arr[1][1] = String(heart_rate.last);
       app_text_arr[3][1] = battery.current + "%";
       app_text_arr[2][1] = String(calorie.current);
       app_text_arr[4][1] = (distanceCurrent / 1000).toFixed(2);
       app_text_arr[12][1] = String(fatburn.current);
       app_text_arr[11][1] = String(pai.totalpai);
       app_text_arr[10][1] = String(spo2.current);
       app_text_arr[14][1] = String(stand.current);


//       let screenType = hmSetting.getScreenType();
//       if (screenType == hmSetting.screen_type.WATCHFACE) {
           normal_current_text_sensor.setProperty(hmUI.prop.TEXT, app_text_arr[CONF_MAIN[1].id][1]);
           app_text.setProperty(hmUI.prop.TEXT, app_text_arr[CONF_MAIN[1].id][0]);
      // }

      // if (screenType == hmSetting.screen_type.AOD) {
           idle_current_text_sensor.setProperty(hmUI.prop.TEXT, app_text_arr[CONF_MAIN[1].id][1]);
           idle_app_text.setProperty(hmUI.prop.TEXT, app_text_arr[CONF_MAIN[1].id][0]);
     //  }


      }

      let tip_grafik = 0

      function click_tip_grafik() {
       tip_grafik = (tip_grafik + 1) % 2
       hmFS.SysProSetInt('OMG_218_bip_6_tip_grafik', tip_grafik);
       ic_graf_img.setProperty(hmUI.prop.SRC, "images/Grafik/ic_graf_" + tip_grafik + ".png");
       click_Pogoda_off();
       normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
       setTimeout(() => {
        click_Pogoda_on()
        tip()
       }, 350);
      }


      function click_Pogoda_on() {
       normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
       groupPogoda.setProperty(hmUI.prop.VISIBLE, true);
       updateGrafik();
      }

      function click_Pogoda_off() {
       normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);
       groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
       canvas.clear({
        x: 0,
        y: 0,
        w: D_W,
        h: D_H,
       })
      }


      const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
      let shotWeaterhNames = [];
      let weather_ic_array = []
      let weather_ic = []
      let DigDay = []
      let DigNight = []
      let yArrH = [];
      let arr_xH = [];
      let arr_yH = [];
      let arr_x = [];
      let arr_y = [];
      let arr_xL = [];
      let arr_yL = [];
      let yArrAll = [];
      let yArrL = [];
      let y_pogodaH = [];
      let y_pogodaL = [];
      let week_array = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
      let week_text = []
      let data_text = []
      const ROOTPATH = "images/"
      var shag = 46;
      var x0 = 35;
      let dney = 8;
      let isDayIcons = false

      let normal_city_name_text_0 = ''

      //массив иконок для графика       
      for (var i = 0; i <= 28; i++) {
       weather_ic_array.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28
      }

      function getSunTimes(weatherData) {
       let tideData = weatherData.tideData;

       let temperature_current_temp = -100;
       if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
        temperature_current_temp = weatherSensor.current;
       };
       //normal_temperature_current_text_font.setProperty(hmUI.prop.TEXT, temperature_current_temp + "°C");	
       //idle_temperature_current_text_font.setProperty(hmUI.prop.TEXT, temperature_current_temp + "°C");		 


       // Получение времени заката
       let sunset_hour = -1;
       let sunset_minute = -1;
       if (tideData.count > 0) {
        sunset_hour = tideData.data[0].sunset.hour;
        sunset_minute = tideData.data[0].sunset.minute;
       }

       let normal_sunset = undefined;
       if (sunset_hour >= 0 && sunset_minute >= 0) {
        normal_sunset = String(sunset_hour).padStart(2, '0') + ':' + String(sunset_minute).padStart(2, '0');
       }

       // Получение времени восхода
       let sunrise_hour = -1;
       let sunrise_minute = -1;
       if (tideData.count > 0) {
        sunrise_hour = tideData.data[0].sunrise.hour;
        sunrise_minute = tideData.data[0].sunrise.minute;
       }

       let normal_sunrise = undefined;
       if (sunrise_hour >= 0 && sunrise_minute >= 0) {
        normal_sunrise = String(sunrise_hour).padStart(2, '0') + ':' + String(sunrise_minute).padStart(2, '0');
       }

       return {
        normal_sunset_circle_string: normal_sunset,
        normal_sunrise_circle_string: normal_sunrise
       };
      }


      function autoToggleWeatherIcons() {

       let weatherData = weatherSensor.getForecastWeather();
       let tideData = weatherData.tideData;

       sunData = weatherData.tideData;
       if (sunData.count > 0) {
        today = sunData.data[0];
        sunriseMins = (today.sunrise.hour) * 60 + today.sunrise.minute;
        sunsetMins = (today.sunset.hour) * 60 + today.sunset.minute;
       } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
       }
       curMins = timeSensor.hour * 60 + timeSensor.minute;
       let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

       if (isDayNow) {
        if (!isDayIcons) {
         isDayIcons = true;
        }
       } else {
        if (isDayIcons) {
         isDayIcons = false;
        }
       }


       const {
        normal_sunset_circle_string,
        normal_sunrise_circle_string
       } = getSunTimes(weatherData);


       app_text_arr[7][1] = isDayIcons == false ? normal_sunrise_circle_string : normal_sunset_circle_string;
       app_text_arr[7][0] = isDayIcons == false ? "ВОСХОД" : "ЗАКАТ";


       let T_N = curMins;
       //       let T_V = sunrise_hour * 60 + sunrise_minute;
       //       let T_Z = sunset_hour * 60 + sunset_minute;

       // Получаем часы и минуты из строки формата "HH:MM"
       const [sunriseHours, sunriseMinutes] = normal_sunrise_circle_string.split(':').map(Number);
       const [sunsetHours, sunsetMinutes] = normal_sunset_circle_string.split(':').map(Number);


       if (isDayIcons) {
        shotWeaterhNames = ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];
//        weather_font = ["А", "Б", "В", "Г", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"];
       } else {
        shotWeaterhNames = ["Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью", "Пасмурно ночью", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];
       // weather_font = ["Ъ", "Ы", "Э", "Ь", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"];
       }

       let temperature_current_temp = -100;
       if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
        temperature_current_temp = weatherSensor.current;
       };

       // let current = weatherSensor.current;
       let curAirIconIndex = weatherSensor.curAirIconIndex;
       app_text_arr[6][1] = shotWeaterhNames[curAirIconIndex];

       let forecastData = weatherData.forecastData;

       app_text_arr[6][1] = shotWeaterhNames[curAirIconIndex];
       app_text_arr[6][0] = temperature_current_temp + "°С " + forecastData.data[0].high + "/" + forecastData.data[0].low;
       app_text_arr[8][1] = weatherData.cityName;
       app_text_arr[8][0] = temperature_current_temp + "°С " + forecastData.data[0].high + "/" + forecastData.data[0].low;

        let screenType = hmSetting.getScreenType();
if (screenType == hmSetting.screen_type.WATCHFACE) {
    normal_weather_text_font.setProperty(hmUI.prop.TEXT, temperature_current_temp + "° " + shotWeaterhNames[curAirIconIndex].toUpperCase());
    normal_city_name_text_0.setProperty(hmUI.prop.TEXT, normal_sunrise_circle_string + "   " + weatherData.cityName.toUpperCase() + "   " + normal_sunset_circle_string);
}

      }


      function updateGrafik() {

       let weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);


       autoToggleWeatherIcons()

       if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
       let day_num = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
       let year = timeSensor.year;
       if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) { // Високосный год
        day_num[2] = 29
       } else {
        day_num[2] = 28
       }

       let current = weatherSensor.current;
       let curAirIconIndex = weatherSensor.curAirIconIndex;

       let temperature_current_temp = -100;
       if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
        temperature_current_temp = weatherSensor.current;
       }; // end currentWeather; 

       let weatherData = weatherSensor.getForecastWeather();
       let forecastData = weatherData.forecastData;

       const {
        normal_sunset_circle_string,
        normal_sunrise_circle_string
       } = getSunTimes(weatherData);


       if (forecastData.count == 0) {
        for (let i = 0; i < dney; i++) {
         var invalidPath = "--";
         weather_ic[i].setProperty(hmUI.prop.SRC, ROOTPATH + "Grafik/weather/25.png");
        }
       } else {
        let weekDay = timeSensor.week - 1;
        let data_gr = timeSensor.day;
        let month_gr = timeSensor.month;

        for (let i = 0; i < dney; i++) {

         // let arr_y  = [252, 238, 252, 266, 238, 224, 308, 322];    

         yArrH[i] = forecastData.data[i].high;

         let element = forecastData.data[i];
         let iconIndex = element.index;
         weather_ic[i].setProperty(hmUI.prop.SRC, weather_ic_array[iconIndex]);
         let week2 = week_array[weekDay];
         week_text[i].setProperty(hmUI.prop.MORE, {
          color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
          text: week2,
         });
         data_text[i].setProperty(hmUI.prop.MORE, {
          color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
          text: data_gr,
         });
         weekDay = (weekDay + 1) % 7;
         data_gr = (data_gr + 1)
         if (data_gr > day_num[month_gr]) data_gr = 1
         if (i < dney - 1) yArrL[i] = forecastData.data[i].low;

        }
       }

       //  array_ic_weater = isDayIcons == false ?  ["Ъ", "Ы", "Э", "Ь", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"] : ["А", "Б", "В", "Г", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"];  

       // if (menu == 2) tip();
       tip();

      }

      function tip() {
       canvas.clear({
        x: 0,
        y: 0,
        w: D_W,
        h: D_H,
       })

       for (let i = 0; i < dney - 1; i++) {
        canvas.drawRect({
         x1: x0 + shag / 2 + shag * [i], //94
         y1: 93,
         x2: x0 + shag / 2 + shag * [i] + 1,
         y2: 351,
         color: 0xc0c0c0
        })
       }

       let maxH = Math.max(...yArrH)
       let maxL = Math.min(...yArrL)
       let delta = 120 / (maxL - maxH)
       let RedArray = [];
       let BlueArray = [];

       if (tip_grafik == 0) {
        for (let i = 0; i < dney; i++) {
         arr_x[i] = x0 + shag * [i];
         arr_y[i] = yArrH[i] * delta + 162 - maxH * delta;
        }
        // let n = arr_x.length;
        splain(dney)

        for (let i = 0; i < dney - 1; i++) {
         arr_x[i] = x0 + 23 + shag * [i];
         arr_y[i] = yArrL[i] * delta + 162 - maxH * delta;
        }
        // n = dney - 1;
        splain(dney - 1)
       }
       if (tip_grafik == 1) {
        let k = 0
        for (let i = 0; i < dney; i++) {

         yArrAll[k] = yArrH[i]
         k = k + 1
         yArrAll[k] = yArrL[i]
         k = k + 1
        }


        for (let i = 0; i < yArrAll.length; i++) {
         arr_x[i] = x0 + shag / 2 * [i];
         arr_y[i] = yArrAll[i] * delta + 162 - maxH * delta;
        }
        //n = yArrAll.length - 1;
        splain(yArrAll.length - 1)
       }


       for (let i = 0; i < dney; i++) {
        if (tip_grafik == 0) {
         canvas.drawCircle({
          center_x: x0 + shag * [i],
          center_y: yArrH[i] * delta + 162 - maxH * delta,
          radius: 5,
          color: 0xFF0000
         })
        }
        y_pogodaH[i] = (yArrH[i] * delta + 145 - maxH * delta) - 5;
        DigDay[i].setProperty(hmUI.prop.more, {
         x: x0 - 23 - 5 + i * 45 * 1.02,
         y: y_pogodaH[i] - 18, //120-7//120-7/- 38
         w: 50,
         h: 40,
         color: "0xFFffffff",
         text_size: 27,
         text: yArrH[i],
         text_style: hmUI.text_style.NONE,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         show_level: hmUI.show_level.ONLY_NORMAL
        });

        if (i < dney - 1) {
         if (tip_grafik == 0) {
          canvas.drawCircle({
           center_x: x0 + 23 + shag * [i],
           center_y: yArrL[i] * delta + 162 - maxH * delta,
           radius: 5,
           color: 0x00eaff
          })
         }
         y_pogodaL[i] = (yArrL[i] * delta + 145 - maxH * delta) - 5;;
         DigNight[i].setProperty(hmUI.prop.more, {
          x: x0 - 23 - 5 + 23 + i * 45 * 1.02,
          y: y_pogodaL[i] + 19, //120-7 / - 1  
          w: 50,
          h: 40,
          color: "0xFFffffff",
          text_size: 27,
          text: yArrL[i],
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });
        } //dney - 1
       }; //dney   
      }

      function splain(n) {
       let arr_a = new Array(n).fill().map(() => new Array(1));
       let arr_b = new Array(n - 1).fill().map(() => new Array(1));
       let arr_c = new Array(n).fill().map(() => new Array(1));
       let arr_d = new Array(n - 1).fill().map(() => new Array(1));

       let arr_h = new Array(n - 1).fill().map(() => new Array(1));
       let arr_alpha = new Array(n).fill().map(() => new Array(1));
       let arr_l = new Array(n).fill().map(() => new Array(1));
       let arr_mu = new Array(n).fill().map(() => new Array(1));
       let arr_z = new Array(n).fill().map(() => new Array(1));

       for (var i = 0; i < n - 1; i++) {
        arr_h[i] = arr_x[i + 1] - arr_x[i];
       }

       for (var i = 1; i < n - 1; i++) {
        arr_alpha[i] = 3 * ((arr_y[i + 1] - arr_y[i]) / arr_h[i] - (arr_y[i] - arr_y[i - 1]) / arr_h[i - 1]);
       }

       arr_l[0] = 1;
       arr_mu[0] = 0;
       arr_z[0] = 0;

       for (var i = 1; i < n - 1; i++) {
        arr_l[i] = 2 * (arr_x[i + 1] - arr_x[i - 1]) - arr_h[i - 1] * arr_mu[i - 1];
        arr_mu[i] = arr_h[i] / arr_l[i];
        arr_z[i] = (arr_alpha[i] - arr_h[i - 1] * arr_z[i - 1]) / arr_l[i];
       }

       arr_l[n - 1] = 1;
       arr_z[n - 1] = 0;
       arr_c[n - 1] = 0;

       for (var j = n - 2; j >= 0; j--) {
        arr_c[j] = arr_z[j] - arr_mu[j] * arr_c[j + 1];
        arr_b[j] = (arr_y[j + 1] - arr_y[j]) / arr_h[j] - arr_h[j] * (arr_c[j + 1] + 2 * arr_c[j]) / 3;
        arr_d[j] = (arr_c[j + 1] - arr_c[j]) / (3 * arr_h[j]);
        arr_a[j] = arr_y[j];
       }

       for (var i = 0; i < n - 1; i++) {
        for (xi = arr_x[i]; xi < arr_x[i + 1] - 1; xi += 5) {
         yi = arr_a[i] + arr_b[i] * (xi - arr_x[i]) + arr_c[i] * Math.pow((xi - arr_x[i]), 2) + arr_d[i] * Math.pow((xi - arr_x[i]), 3);

         if (tip_grafik == 0) {
          canvas.drawImage({
           x: xi,
           y: yi,
           w: 5,
           h: 310 - yi,
           alpha: 127,
           image: n == dney ? 'images/Grafik/line_day.png' : 'images/Grafik/line_night.png'
          })
         }

         canvas.drawLine({
          x1: xi,
          y1: yi,
          x2: xi + 5,
          y2: arr_a[i] + arr_b[i] * (xi + 5 - arr_x[i]) + arr_c[i] * Math.pow((xi + 5 - arr_x[i]), 2) + arr_d[i] * Math.pow((xi + 5 - arr_x[i]), 3),
          // color: n == dney ? 0xff0000 : 0x00eaff//0x009cff  yArrAll.length - 1
          color: n == dney ? 0xff0000 : n == dney - 1 ? 0x00eaff : 0x12a2fd //0x009cff
         })
        }
       }

      }
      
let sleep_time_txt = ''
let sleep_start_time_txt = ''
let sleep_end_time_txt = ''
let sleep_score_txt = ''
let wake_time_txt

const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
let sleepInfo = sleep.getBasicInfo();

let sleepTotalTime = sleep.getTotalTime();
let sleepStartTime = sleepInfo.startTime;
let sleepEndTime = sleepInfo.endTime + 1;
let sleepScore = sleepInfo.score;

//-----------  время пробуждений ------------------		
let sleepStageArray = sleep.getSleepStageData();
const modelData = sleep.getSleepStageModel();
//-------------------------------------------------	      
      
 function updateSleep() {
  //-----------  сон------------------
  sleepTotalTime = sleep.getTotalTime();
  sleepInfo = sleep.getBasicInfo();
  sleepStartTime = sleepInfo.startTime;
  if (sleepStartTime >= 24 * 60) {
   sleepStartTime -= 24 * 60
  }

  sleepEndTime = sleepInfo.endTime + 1;
  if (sleepEndTime >= 24 * 60) {
   sleepEndTime -= 24 * 60
  }

  //-----------  время пробуждений ------------------
  let wakeTime = 0;
  sleepStageArray = sleep.getSleepStageData();

  for (let i = 0; i < sleepStageArray.length; i++) {
   let data = sleepStageArray[i];
   if (data.model == modelData.WAKE_STAGE) {
    wakeTime += data.stop + 1 - data.start;
   }

  }

  sleepTotalTime -= wakeTime;
  //-------------------------------------------------

//  sleep_time_txt.setProperty(hmUI.prop.TEXT, 'СПАЛИ ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
//  sleep_start_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepStartTime / 60).toString().padStart(2, "0") + ':' + (sleepStartTime % 60).toString().padStart(2, "0"));
//  sleep_end_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepEndTime / 60).toString().padStart(2, "0") + ':' + (sleepEndTime % 60).toString().padStart(2, "0"));
//  wake_time_txt.setProperty(hmUI.prop.TEXT, 'ПРОСЫПАЛИСЬ ' + String(wakeTime) + ' мин.');
//  sleep_score_txt.setProperty(hmUI.prop.TEXT, 'КАЧЕСТВО ' + String(sleepScore) + ' %');
  //-------------------------------------------------
 // Line_arr[10][1] = Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0");
  
         app_text_arr[17][1] = Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0");

  
 }

      


      //dynamic modify end

      __$$module$$__.module = DeviceRuntimeCore.WatchFace({
       init_view() {
        //dynamic modify start
        loadSettings();

        // FontName: BebasNeue_Regular.ttf; FontSize: 70
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 388,
         y: 448,
         w: 710,
         h: 100,
         text_size: 70,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Bebas11.ttf; FontSize: 39; Cache: full
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 388,
         y: 448,
         w: 46,
         h: 46,
         text_size: 39,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 388,
         y: 448,
         w: 46,
         h: 46,
         text_size: 37,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 388,
         y: 448,
         w: 46,
         h: 46,
         text_size: 24,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 388,
         y: 448,
         w: 46,
         h: 46,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        // FontName: Bebas11.ttf; FontSize: 86
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 388,
         y: 448,
         w: 856,
         h: 123,
         text_size: 35,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Bebas11.ttf; FontSize: 86
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 388,
         y: 448,
         w: 856,
         h: 123,
         text_size: 86,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        // FontName: BebasNeue_Regular.ttf; FontSize: 138
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 388,
         y: 448,
         w: 1398,
         h: 200,
         text_size: 138,
         char_space: 0,
         line_space: 0,
         font: 'fonts/BebasNeue_Regular.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        console.log('Watch_Face.ScreenNormal');
        normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: 390,
         h: 450,
         color: '0xFFFFFF00',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: 'bg.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_second_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 195,
         center_y: 225,
         start_angle: 0,
         end_angle: 360,
         radius: 199,
         line_width: 85,
         corner_flag: 3,
         color: 0xFFFFFF00,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let screenType = hmSetting.getScreenType();
        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

        bg_bat_circ = hmUI.createWidget(hmUI.widget.CIRCLE, {
         center_x: 195,
         center_y: 49,
         radius: 16,
         color: 0xffff00,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        bg_step_circ = hmUI.createWidget(hmUI.widget.CIRCLE, {
         center_x: 195,
         center_y: 401,
         radius: 16,
         color: 0xffff00,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        bg_bat_0 = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 92,
         y: 9,
         w: 206,
         h: 20,
         radius: 9,
         color: 0x000000,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        bg_step_0 = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 92,
         y: 421,
         w: 206,
         h: 20,
         radius: 9,
         color: 0x000000,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        bg_bat = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 92,
         y: 9,
         w: 206,
         h: 20,
         radius: 9,
         color: 0xffff00,
         alpha: 128,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        bg_step = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 92,
         y: 421,
         w: 206,
         h: 20,
         radius: 9,
         color: 0xffff00,
         alpha: 128,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        if (screenType != hmSetting.screen_type.AOD) {
         normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
        };

        const step = hmSensor.createSensor(hmSensor.id.STEP);
        step.addEventListener(hmSensor.event.CHANGE, function () {
         scale_call();
        });

        if (screenType != hmSetting.screen_type.AOD) {
         normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
        };

        const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
        battery.addEventListener(hmSensor.event.CHANGE, function () {
         scale_call();
        });

        normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: 'cap.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        console.log('user_script.js');
        // start user_script.js

        for (let i = 0; i < 7; i++) {
         bg_week[i] = hmUI.createWidget(hmUI.widget.CIRCLE, {
          center_x: 113 + i * 27,
          center_y: 81,
          radius: 4,
          color: 0xffff00,
          alpha: 128,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });
        };

        bg_line = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 97 - 38,
         y: 292 - 9,
         w: 273,
         h: 3,
         //radius: 9,
         color: 0xffff00,
         //alpha: 128,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        app_text = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 370 - 10 - 9,
         w: 390,
         h: 42,
         // text: "--",
         text: "ШАГИ",
         text_size: 37, //70         
         char_space: 0,
         line_space: -20,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        for (var i = 0; i < app_text_arr.length; i++) {
         if (app_text_arr[i][4] == 0) {
          normal_up_current_text_font[i] = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
           x: 0,
           y: 280 - 9,
           w: 390,
           h: 100,
           text_size: 70,
           char_space: 0,
           line_space: 0,
           font: 'fonts/Bebas11.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.ELLIPSIS,
           padding: app_text_arr[i][2],
           type: app_text_arr[i][1],
           unit_type: app_text_arr[i][3],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_up_current_text_font[i].setProperty(hmUI.prop.VISIBLE, i == CONF_MAIN[1].id);
         }
        }

        normal_current_text_sensor = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 105 - 38,
         y: 280 - 9,
         w: 256,
         h: 100,
         text: "--",
         text: app_text_arr[CONF_MAIN[1].id][1],
         text_size: CONF_MAIN[1].id == 6 ? 39 : CONF_MAIN[1].id == 8 ? 39 : 70, //70
         char_space: 0,
         line_space: -20,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: CONF_MAIN[1].id == 8 ? hmUI.text_style.NONE : hmUI.text_style.WRAP,
         // text_style: hmUI.text_style.NONE,//бегущая строка
         // padding: app_text_arr[i][2],
         // type: app_text_arr[i][1],
         // unit_type: app_text_arr[i][3],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_current_text_sensor.setProperty(hmUI.prop.VISIBLE, app_text_arr[CONF_MAIN[1].id][4] == 1);
        // end user_script.js

        timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
         time_update(true);
        });

      normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 145,
         y: 76 - 9,
         w: 246,
         h: 100,
         text_size: 39,
         char_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         line_space: 0,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         align_h: hmUI.align.LEFT,
         // unit_string: ЯНВАРЯ, ФЕВРАЛЯ, МАРТА, АПРЕЛЯ, МАЯ, ИЮНЯ, ИЮЛЯ, АВГУСТА, СЕНТЯБРЯ, ОКТЯБРЯ, НОЯБРЯ, ДЕКАБРЯ,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 54,
         y: 95 - 9,
         w: 100,
         h: 100,
         text_size: 86,
         char_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         line_space: 0,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         align_h: hmUI.align.CENTER_H,
         // padding: true,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 145,
         y: 110 - 9,
         w: 246,
         h: 100,
         text_size: 39,
         char_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFF00,
         line_space: 0,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         align_h: hmUI.align.LEFT,
         // unit_string: ПОНЕДЕЛЬНИК, ВОРНИК, СРЕДА, ЧЕТВЕРГ, ПЯТНИЦА, СУББОТА, ВОСКРЕСЕНЬЕ,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        select_week = hmUI.createWidget(hmUI.widget.CIRCLE, {
         center_x: 113,
         center_y: 81,
         radius: 5,
         color: 0xffffff,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 50,
         y: 168 - 3 - 9,
         w: 150,
         h: 150,
         text_size: 138,
         char_space: 0,
         font: 'fonts/BebasNeue_Regular.ttf',
         color: 0xFFFFFFFF,
         line_space: 0,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         align_h: hmUI.align.CENTER_H,
         // padding: true,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 190,
         y: 168 - 3 - 9,
         w: 150,
         h: 150,
         text_size: 138,
         char_space: 0,
         font: 'fonts/BebasNeue_Regular.ttf',
         color: 0xFFFFFF00,
         line_space: 0,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         align_h: hmUI.align.CENTER_H,
         // padding: true,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

         normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
         x: 35,
         y: 188 - 9,
         src: 'stat_B_off.png',
         type: hmUI.system_status.DISCONNECT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
         x: 327,
         y: 187 - 9,
         src: 'stat_H_on.png',
         type: hmUI.system_status.CLOCK,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_text_up_left = hmUI.createWidget(hmUI.widget.TEXT, {
         x: -19,
         y: -2,
         w: 220,
         h: 220,
         text: 'ЯРЛЫКИ',
         text_size: 24,
         char_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         // use_text_circle: true,
         start_angle: -52,
         end_angle: 90,
         mode: 0,
         // radius: 110,
         align_h: hmUI.align.LEFT,
         // unit_string: ПОНЕДЕЛЬНИК, ВОРНИК, СРЕДА, ЧЕТВЕРГ, НАСТР, СУББОТА, ВОСКРЕСЕНЬЕ,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_text_up_right = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 189,
         y: -2,
         w: 220,
         h: 220,
         text: 'НАСТР',
         text_size: 24,
         char_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         // use_text_circle: true,
         start_angle: 8,
         end_angle: 180,
         mode: 0,
         // radius: 110,
         align_h: hmUI.align.LEFT,
         // unit_string: ПОНЕДЕЛЬНИК, ВОРНИК, СРЕДА, ЧЕТВЕРГ, НАСТР, СУББОТА, ВОСКРЕСЕНЬЕ,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_text_dw_left = hmUI.createWidget(hmUI.widget.TEXT, {
         x: -27,
         y: 228,
         w: 224,
         h: 224,
         text: 'БЛОК',
         text_size: 24,
         char_space: 3,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         // use_text_circle: true,
         start_angle: 180,
         end_angle: 250,
         mode: 1,
         // radius: 110,
         align_h: hmUI.align.RIGHT,
         // unit_string: ПОНЕДЕЛЬНИК, ВОРНИК, СРЕДА, ЧЕТВЕРГ, НАСТР, СУББОТА, ВОСКРЕСЕНЬЕ,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_text_dw_right = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 187,
         y: 228,
         w: 224,
         h: 224,
         text: 'ПОГОДА',
         text_size: 24,
         char_space: 3,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         // use_text_circle: true,
         start_angle: 90,
         end_angle: 173,
         mode: 1,
         // radius: 110,
         align_h: hmUI.align.LEFT,
         // unit_string: ПОНЕДЕЛЬНИК, ВОРНИК, СРЕДА, ЧЕТВЕРГ, НАСТР, СУББОТА, ВОСКРЕСЕНЬЕ,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        
        
        
        
        
        
       idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: 390,
         h: 450,
         color: color_bg[CONF_MAIN[0].id],
         show_level: hmUI.show_level.ONLY_AOD,
        });

       idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: 'bg.png',
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_second_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 195,
         center_y: 225,
         start_angle: 0,
         end_angle: 360,
         radius: 199,
         line_width: 85,
         corner_flag: 3,
         color: color_bg[CONF_MAIN[0].id],
         show_level: hmUI.show_level.ONLY_AOD,
        });

//        let screenType = hmSetting.getScreenType();
//        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

        idle_bg_bat_circ = hmUI.createWidget(hmUI.widget.CIRCLE, {
         center_x: 195,
         center_y: 49,
         radius: 16,
         color: color_bg[CONF_MAIN[0].id],
         alpha: 255,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_bg_step_circ = hmUI.createWidget(hmUI.widget.CIRCLE, {
         center_x: 195,
         center_y: 401,
         radius: 16,
         color: color_bg[CONF_MAIN[0].id],
         alpha: 255,
         show_level: hmUI.show_level.ONLY_AOD,
        });

       idle_bg_bat_0 = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 92,
         y: 9,
         w: 206,
         h: 20,
         radius: 9,
         color: 0x000000,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_bg_step_0 = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 92,
         y: 421,
         w: 206,
         h: 20,
         radius: 9,
         color: 0x000000,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_bg_bat = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 92,
         y: 9,
         w: 206,
         h: 20,
         radius: 9,
         color: color_bg[CONF_MAIN[0].id],
         alpha: 128,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_bg_step = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 92,
         y: 421,
         w: 206,
         h: 20,
         radius: 9,
         color: color_bg[CONF_MAIN[0].id],
         alpha: 128,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        if (screenType == hmSetting.screen_type.AOD) {
         idle_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
        };

       // const step = hmSensor.createSensor(hmSensor.id.STEP);
//        step.addEventListener(hmSensor.event.CHANGE, function () {
//         scale_call();
//        });

        if (screenType == hmSetting.screen_type.AOD) {
         idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
        };

       // const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
//        battery.addEventListener(hmSensor.event.CHANGE, function () {
//         scale_call();
//        });

        idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: 'cap.png',
         show_level: hmUI.show_level.ONLY_AOD,
        });


      for (let i = 0; i < 7; i++) {
         idle_bg_week[i] = hmUI.createWidget(hmUI.widget.CIRCLE, {
          center_x: 113 + i * 27,
          center_y: 81,
          radius: 4,
         color: color_bg[CONF_MAIN[0].id],
          alpha: 128,
          show_level: hmUI.show_level.ONLY_AOD,
         });
        };

        idle_bg_line = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 97 - 38,
         y: 292 - 9,
         w: 273,
         h: 3,
         //radius: 9,
         color: color_bg[CONF_MAIN[0].id],
         //alpha: 128,
         show_level: hmUI.show_level.ONLY_AOD,
        });
        
        
        idle_app_text = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 370 - 10 - 9,
         w: 390,
         h: 42,
         // text: "--",
         text: "ШАГИ",
         text_size: 37, //70         
         char_space: 0,
         line_space: -20,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        for (var i = 0; i < app_text_arr.length; i++) {
         if (app_text_arr[i][4] == 0) {
          idle_up_current_text_font[i] = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
           x: 0,
           y: 280 - 9,
           w: 390,
           h: 100,
           text_size: 70,
           char_space: 0,
           line_space: 0,
           font: 'fonts/Bebas11.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.ELLIPSIS,
           padding: app_text_arr[i][2],
           type: app_text_arr[i][1],
           unit_type: app_text_arr[i][3],
           show_level: hmUI.show_level.ONLY_AOD,
          });
          idle_up_current_text_font[i].setProperty(hmUI.prop.VISIBLE, i == CONF_MAIN[1].id);
         }
        }

        idle_current_text_sensor = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 105 - 38,
         y: 280 - 9,
         w: 256,
         h: 100,
         text: "--",
         text: app_text_arr[CONF_MAIN[1].id][1],
         text_size: CONF_MAIN[1].id == 6 ? 39 : CONF_MAIN[1].id == 8 ? 39 : 70, //70
         char_space: 0,
         line_space: -20,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: CONF_MAIN[1].id == 8 ? hmUI.text_style.NONE : hmUI.text_style.WRAP,
         // text_style: hmUI.text_style.NONE,//бегущая строка
         // padding: app_text_arr[i][2],
         // type: app_text_arr[i][1],
         // unit_type: app_text_arr[i][3],
         show_level: hmUI.show_level.ONLY_AOD,
        });
        idle_current_text_sensor.setProperty(hmUI.prop.VISIBLE, app_text_arr[CONF_MAIN[1].id][4] == 1);
        
        
        idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 145,
         y: 76 - 9,
         w: 246,
         h: 100,
         text_size: 39,
         char_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         line_space: 0,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         align_h: hmUI.align.LEFT,
         // unit_string: ЯНВАРЯ, ФЕВРАЛЯ, МАРТА, АПРЕЛЯ, МАЯ, ИЮНЯ, ИЮЛЯ, АВГУСТА, СЕНТЯБРЯ, ОКТЯБРЯ, НОЯБРЯ, ДЕКАБРЯ,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 54,
         y: 95 - 9,
         w: 100,
         h: 100,
         text_size: 86,
         char_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         line_space: 0,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         align_h: hmUI.align.CENTER_H,
         // padding: true,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 145,
         y: 110 - 9,
         w: 246,
         h: 100,
         text_size: 39,
         char_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: color_bg[CONF_MAIN[0].id],
         line_space: 0,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         align_h: hmUI.align.LEFT,
         // unit_string: ПОНЕДЕЛЬНИК, ВОРНИК, СРЕДА, ЧЕТВЕРГ, ПЯТНИЦА, СУББОТА, ВОСКРЕСЕНЬЕ,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_select_week = hmUI.createWidget(hmUI.widget.CIRCLE, {
         center_x: 113,
         center_y: 81,
         radius: 5,
         color: 0xffffff,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_AOD,
        });
        

        idle_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 50,
         y: 168 - 3 - 9,
         w: 150,
         h: 150,
         //text: '88',
         text_size: 138,
         char_space: 0,
         font: 'fonts/BebasNeue_Regular.ttf',
         color: 0xFFFFFFFF,
         line_space: 0,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         align_h: hmUI.align.CENTER_H,
         // padding: true,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 190,
         y: 168 - 3 - 9,
         w: 150,
         h: 150,
         text_size: 138,
         char_space: 0,
         font: 'fonts/BebasNeue_Regular.ttf',
         color: color_bg[CONF_MAIN[0].id],
         line_space: 0,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         align_h: hmUI.align.CENTER_H,
         // padding: true,
         show_level: hmUI.show_level.ONLY_AOD,
        });
        
        

        idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
         x: 35,
         y: 188 - 9,
         src: 'stat_B_off.png',
         type: hmUI.system_status.DISCONNECT,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
         x: 327,
         y: 187 - 9,
         src: 'stat_H_on.png',
         type: hmUI.system_status.CLOCK,
         show_level: hmUI.show_level.ONLY_AOD,
        });

/*        idle_text_up_left = hmUI.createWidget(hmUI.widget.TEXT, {
         x: -19,
         y: -2,
         w: 220,
         h: 220,
         text: 'ЯРЛЫКИ',
         text_size: 24,
         char_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         // use_text_circle: true,
         start_angle: -52,
         end_angle: 90,
         mode: 0,
         // radius: 110,
         align_h: hmUI.align.LEFT,
         // unit_string: ПОНЕДЕЛЬНИК, ВОРНИК, СРЕДА, ЧЕТВЕРГ, НАСТР, СУББОТА, ВОСКРЕСЕНЬЕ,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_text_up_right = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 189,
         y: -2,
         w: 220,
         h: 220,
         text: 'НАСТР',
         text_size: 24,
         char_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         // use_text_circle: true,
         start_angle: 8,
         end_angle: 180,
         mode: 0,
         // radius: 110,
         align_h: hmUI.align.LEFT,
         // unit_string: ПОНЕДЕЛЬНИК, ВОРНИК, СРЕДА, ЧЕТВЕРГ, НАСТР, СУББОТА, ВОСКРЕСЕНЬЕ,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_text_dw_left = hmUI.createWidget(hmUI.widget.TEXT, {
         x: -27,
         y: 228,
         w: 224,
         h: 224,
         text: 'БЛОК',
         text_size: 24,
         char_space: 3,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         // use_text_circle: true,
         start_angle: 180,
         end_angle: 250,
         mode: 1,
         // radius: 110,
         align_h: hmUI.align.RIGHT,
         // unit_string: ПОНЕДЕЛЬНИК, ВОРНИК, СРЕДА, ЧЕТВЕРГ, НАСТР, СУББОТА, ВОСКРЕСЕНЬЕ,
         show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_text_dw_right = hmUI.createWidget(hmUI.widget.TEXT, {
         x: 187,
         y: 228,
         w: 224,
         h: 224,
         text: 'ПОГОДА',
         text_size: 24,
         char_space: 3,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         // use_text_circle: true,
         start_angle: 90,
         end_angle: 173,
         mode: 1,
         // radius: 110,
         align_h: hmUI.align.LEFT,
         // unit_string: ПОНЕДЕЛЬНИК, ВОРНИК, СРЕДА, ЧЕТВЕРГ, НАСТР, СУББОТА, ВОСКРЕСЕНЬЕ,
         show_level: hmUI.show_level.ONLY_AOD,
        });        
*/        
        
        
   if (screenType == hmSetting.screen_type.WATCHFACE) {     

        

        groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        }); // 				

        groupSetting = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        }); // 

        groupSetting.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
         // radius: 9,
         color: 0x000000,
         // alpha: 128,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        FILL_RECT_0 = groupSetting.createWidget(hmUI.widget.FILL_RECT, {
         x: 19,
         y: 166,
         w: 60,
         h: 60,
         radius: 10,
         color: 0xffffff,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        FILL_RECT_1 = groupSetting.createWidget(hmUI.widget.FILL_RECT, {
         x: 82,
         y: 161,
         w: 70,
         h: 70,
         radius: 10,
         color: 0xffffff,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        FILL_RECT_2 = groupSetting.createWidget(hmUI.widget.FILL_RECT, {
         x: 155,
         y: 156,
         w: 80,
         h: 80,
         radius: 10,
         color: 0xffffff,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        FILL_RECT_3 = groupSetting.createWidget(hmUI.widget.FILL_RECT, {
         x: 237,
         y: 161,
         w: 70,
         h: 70,
         radius: 10,
         color: 0xffffff,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        FILL_RECT_4 = groupSetting.createWidget(hmUI.widget.FILL_RECT, {
         x: 310,
         y: 166,
         w: 60,
         h: 60,
         radius: 10,
         color: 0xffffff,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

	
	for (let i = 0; i < 6; i++) {
         tap_circ_[i] = groupSetting.createWidget(hmUI.widget.STROKE_RECT, {
          x: i < 3 ? 10 + i * 124 : 10 + (i - 3) * 124,
          y: i < 3 ? 94 : 94 + 137,
          w: 125,
          h: 125,
          radius: 125 / 2,
          line_width: 6,
          color: 0x00ff00,
          alpha: 255,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });

         tap_IMG_[i] = groupSetting.createWidget(hmUI.widget.IMG, {
          x: i < 3 ? 10 + 6 + i * 124 : 10 + 6 + (i - 3) * 124,
          y: i < 3 ? 94 + 6 : 94 + 6 + 137,
          //src: apps[i][2],
          src: apps[CONF_TAP[i].id][2],
          show_level: hmUI.show_level.ONLY_NORMAL,
         });
		
        };
        
	for (let i = 0; i < 6; i++) {
        tap_IMG_tips_[i] = groupSetting.createWidget(hmUI.widget.IMG, {
         x: tap_IMG_tips_X[i],
         y: i < 3 ? 234 : 163,
         src: 'tap/tips_bg.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
		
        tap_text_tips_[i] = groupSetting.createWidget(hmUI.widget.TEXT, {
         x: tap_IMG_tips_X[i],
         y: i < 3 ? 234 : 163,
         w: 195,
         h: 56,
         text: '',
         text_size: 27,
         char_space: 0,
         line_space: 0,
         //font: 'fonts/Bebas11.ttf',
         color: 0x000000,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });			   
        };

        for (let i = 0; i < 6; i++) {
         btn_tap_[i] = groupSetting.createWidget(hmUI.widget.BUTTON, {
          x: i < 3 ? 10 + i * 124 : 10 + (i - 3) * 124,
          y: i < 3 ? 94 : 94 + 137,
          w: 125,
          h: 125,
          normal_src: '0_Empty.png',
          press_src: '0_Empty.png',
          click_func: () => {
           vibro();
           crow_tap = i
           select()
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
         }); // end button
        }; // end button


        for (let i = 0; i < app_text_arr.length; i++) {
         app_ACR_text[i] = groupSetting.createWidget(hmUI.widget.TEXT, {
          x: i < 10 ? 16 : 210,
          y: i < 10 ? 100 + i * 21 : 100 + (i - 10) * 21,
          w: 166,
          h: 30,
          text: app_text_arr[i][0],
          text_size: 21,
          char_space: 0,
          line_space: 0,
          //font: 'fonts/Bebas11.ttf',
          color: CONF_MAIN[1].id == i ? 0xff0000 : 0xffffff,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });
         app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false);
        };

        btn_str = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 290, //x кнопки
         y: 350, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
//        normal_color: 0xFFff0000,
//		press_color: 0xFFff0000,
         click_func: () => {
          vibro();
          click_Pogoda_on();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Set_on = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 290, //x кнопки
         y: 0, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
//        normal_color: 0xFF00ff00,
//		press_color: 0xFFff0000,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          groupSetting.setProperty(hmUI.prop.VISIBLE, true);
          groupVremya.setProperty(hmUI.prop.VISIBLE, false);
          select()
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Set_off = groupSetting.createWidget(hmUI.widget.BUTTON, {
         x: 155, //x кнопки
         y: 370, //y кнопки
         text: 'OK',
         color: 0xFFFFFFFF,
         text_size: 58,
         radius: 21,
         w: 80, //ширина кнопки
         h: 80, //высота кнопки
         press_color: 0xFF800040,
         normal_color: 0xFF484848,
         click_func: () => {
          vibro();
          groupSetting.setProperty(hmUI.prop.VISIBLE, false);
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_left_dw = groupSetting.createWidget(hmUI.widget.BUTTON, {
         x: 22,
         y: 370,
         w: 80,
         h: 80,
         text: '<',
         color: 0xFFFFFFFF,
         text_size: 90,
         radius: 21,
         press_color: 0xFF800040,
         normal_color: 0xFF484848,
         click_func: () => {
          vibro();
          if (crown == 0) click_color(-1);
          if (crown == 1) click_app(-1);
          if (crown == 2) click_tap(-1);
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button				


        btn_right_dw = groupSetting.createWidget(hmUI.widget.BUTTON, {
         x: 288, //x кнопки
         y: 370, //y кнопки
         text: '>',
         color: 0xFFFFFFFF,
         text_size: 90,
         radius: 21,
         w: 80, //ширина кнопки
         h: 80, //высота кнопки
         press_color: 0xFF800040,
         normal_color: 0xFF484848,
         click_func: () => {
          vibro();
          if (crown == 0) click_color(1);
          if (crown == 1) click_app(1);
          if (crown == 2) click_tap(1);
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        FILL_RECT_progress_bg = groupSetting.createWidget(hmUI.widget.FILL_RECT, {
         x: 377,
         y: 75,
         w: 13,
         h: 300,
         radius: 6,
         color: 0x525252,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        FILL_RECT_progress = groupSetting.createWidget(hmUI.widget.FILL_RECT, {
         x: 377,
         y: 75,
         w: 13,
         h: 50,
         radius: 6,
         color: 0xff0000,
         alpha: 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        text_main = groupSetting.createWidget(hmUI.widget.TEXT, {
         x: 0, //x кнопки
         y: 2, //y кнопки
         w: 390, //ширина кнопки
         h: 70, //высота кнопки
         text: CONF_MAIN[crown].name,
         color: 0xFFFFFFFF,
         text_size: 33,
         color: 0xFFFFFFFF,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         align_h: hmUI.align.CENTER_H,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
		   
        btn_left_up = groupSetting.createWidget(hmUI.widget.BUTTON, {
         x: 23,
         y: 0, //0
         w: 80,
         h: 80,
         text: '<',
         color: 0xFFFFFFFF,
         text_size: 90,
         radius: 21,
         press_color: 0xFF800040,
         normal_color: 0xFF484848,
         click_func: () => {
          vibro();
          click_crown(-1);
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button			   
		   
        btn_right_up = groupSetting.createWidget(hmUI.widget.BUTTON, {
         x: 390-80-23, //x кнопки
         y: 0, //0
         text: '>',
         color: 0xFFFFFFFF,
         text_size: 90,
         radius: 21,
         w: 80, //ширина кнопки
         h: 80, //высота кнопки
         press_color: 0xFF800040,
         normal_color: 0xFF484848,
         click_func: () => {
          vibro();
          click_crown(1);
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_background_Pogoda = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
         color: 0x000000,
         // alpha: 128,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);

        groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        }); // 

        canvas = groupPogoda.createWidget(hmUI.widget.CANVAS, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        canvas.setPaint({
         color: 0x00ff00,
         line_width: 4
        })

        normal_weather_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 47 + 5 + 6 + 2 - 29 - 9,
         w: 390,
         h: 32,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })

        normal_city_name_text_0 = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 47 + 5 + 6 + 2 - 9,
         w: 390,
         h: 32,
         text_size: 27,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: 97,
         y: 357 + 3,
         w: 150,
         h: 40,
         text_size: 35,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         font: 'fonts/Bebas11.ttf',
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.HUMIDITY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.IMG_LEVEL, {
         x: 66,
         y: 358,
         image_array: ["images/Grafik/ic_activ/vl_0.png", "images/Grafik/ic_activ/vl_1.png", "images/Grafik/ic_activ/vl_2.png", "images/Grafik/ic_activ/vl_3.png", "images/Grafik/ic_activ/vl_4.png", "images/Grafik/ic_activ/vl_5.png", "images/Grafik/ic_activ/vl_6.png", "images/Grafik/ic_activ/vl_7.png", "images/Grafik/ic_activ/vl_8.png", "images/Grafik/ic_activ/vl_9.png"],
         image_length: 10,
         type: hmUI.data_type.HUMIDITY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: 347 - 38 - 80,
         y: 357 + 3,
         w: 150,
         h: 40,
         text_size: 35,
         font: 'fonts/Bebas11.ttf',
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.UVI,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.IMG_LEVEL, {
         x: 285 - 38,
         y: 358,
         image_array: ["images/Grafik/ic_activ/uv_0.png", "images/Grafik/ic_activ/uv_1.png", "images/Grafik/ic_activ/uv_2.png", "images/Grafik/ic_activ/uv_3.png", "images/Grafik/ic_activ/uv_4.png"],
         image_length: 5,
         type: hmUI.data_type.UVI,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        for (var i = 0; i < dney; i++) {
         week_text[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
          x: x0 - 3 - 23 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
          y: 295 - 1 + 2, //- 21
          w: 50,
          h: 50,
          char_space: 0, //-1
          line_space: 0,
          color: "0xFFffffff",
          text: week_array[i],
          text_size: 22,
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });
			
         data_text[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
          x: x0 - 3 - 23 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
          y: 295 - 1 + 2 + 20, //- 21
          w: 50,
          h: 50,
          char_space: 0, //-1
          line_space: 0,
          color: "0xFFffffff",
          text: 31,
          text_size: 22,
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });

         weather_ic[i] = groupPogoda.createWidget(hmUI.widget.IMG, {
          x: x0 - 23 + i * shag,
          y: 78 + 10, //- 10
          w: 40,
          h: 40,
          shortcut: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });

         DigDay[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
         if (i < dney - 1) DigNight[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
        }

        ic_graf_img = groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 174,
         y: 379,
         src: 'images/Grafik/ic_graf_0.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_tip_grafik = groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 145, //x кнопки
         y: 350, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_tip_grafik();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_off();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        btn_Pogoda_off = groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 145, //x кнопки
         y: 175, //y кнопки
         text: '',
         w: 100, //ширина кнопки
         h: 100, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_Pogoda_off();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_off();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
        }); // 

        groupTap.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
         // radius: 9,
         color: 0x000000,
         // alpha: 128,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        for (let i = 0; i < 6; i++) {
         tap_IMG_run[i] = groupTap.createWidget(hmUI.widget.IMG, {
          x: i < 3 ? 10 + 6 + i * 124 : 10 + 6 + (i - 3) * 124,
          y: i < 3 ? 94 + 6 : 94 + 6 + 137,
          //src: apps[i][2],
          src: apps[CONF_TAP[i].id][2],
          show_level: hmUI.show_level.ONLY_NORMAL,
         });

         btn_tap_run[i] = groupTap.createWidget(hmUI.widget.BUTTON, {
          x: i < 3 ? 10 + i * 124 : 10 + (i - 3) * 124,
          y: i < 3 ? 94 : 94 + 137,
          w: 125,
          h: 125,
          normal_src: '0_Empty.png',
          press_src: '0_Empty.png',
          click_func: () => {
           vibro();
           // crow_tap = i 
           const app = apps[CONF_TAP[i].id];
           hmApp.startApp({
            appid: app[3] === 0 ? '' : app[1],
            url: app[3] === 0 ? app[1] : app[4],
            native: app[3] === 0,
            params: app[3] === 0 ? null : {
             from_wf: true
            },
           });

          },
          show_level: hmUI.show_level.ONLY_NORMAL,
         }); // end button
        }; // end button 


        Button_2 = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: 145,
         y: 380,
         w: 100,
         h: 70,
         text: 'OK',
         color: 0xFFFFFFFF,
         text_size: 40,
         radius: 12,
         press_color: 0xFF800040,
         normal_color: 0xFF464646,
         click_func: () => {
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupTap.setProperty(hmUI.prop.VISIBLE, false);
          vibro();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button 


        Button_1 = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 0,
         y: 0,
         w: 100,
         h: 100,
         // text: '',
         //color: 0xFFFF8C00,
         // text_size: 25,
         press_src: '0_Empty.png',
         normal_src: '0_Empty.png',
         click_func: () => {
          click_tap_on();
          vibro();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button				

        Button_block_on = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 0,
         y: 350,
         w: 100,
         h: 100,
         // text: '',
         // color: 0xFFFF8C00,
         // text_size: 25,
         press_src: '0_Empty.png',
         normal_src: '0_Empty.png',
         click_func: () => {
          vibro();
          click_block_on();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button	

        block = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: D_W,
         h: D_H,
         // radius: 9,
         color: 0x000000,
         alpha: 0,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        block.setProperty(hmUI.prop.VISIBLE, false);

        Button_block_off = hmUI.createWidget(hmUI.widget.BUTTON, {
         x: 0,
         y: 350,
         w: 100,
         h: 100,
         // text: '',
         // color: 0xFFFF8C00,
         // text_size: 25,
         press_src: '0_Empty.png',
         normal_src: '0_Empty.png',
         longpress_func: () => {
          vibro();
          click_block_off();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button	
        Button_block_off.setProperty(hmUI.prop.VISIBLE, false);
        
        }


        //#region time_update
        function time_update(updateHour = false, updateMinute = false) {
         console.log('time_update()');
         let hour = timeSensor.hour;
         let minute = timeSensor.minute;
         let second = timeSensor.second;
         let format_hour = timeSensor.format_hour;
         

         
         
     if (updateHour) {
         let Sensor_week = timeSensor.week;
         let Sensor_month = timeSensor.month;

         let normal_Month_Str = normal_Month_Array[Sensor_month - 1];
         normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str);
        idle_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str);

         let normal_DOW_Str = normal_DOW_Array[Sensor_week - 1];
         normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str);
        idle_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str);


         let max_x = len_week[Sensor_week - 1] - len_month[Sensor_month - 1];
         let normal_max_x = max_x < 0 ? len_month[Sensor_month - 1] : len_week[Sensor_week - 1]

         let normal_day_x = (466 - 86 - normal_max_x) / 2;

         normal_month_name_font.setProperty(hmUI.prop.X, normal_day_x + 86 - 38-5);
         normal_dow_text_font.setProperty(hmUI.prop.X, normal_day_x + 86 - 38-5);
         
         idle_month_name_font.setProperty(hmUI.prop.X, normal_day_x + 86 - 38-5);
         idle_dow_text_font.setProperty(hmUI.prop.X, normal_day_x + 86 - 38-5);
         


         select_week.setProperty(hmUI.prop.MORE, {
          center_x: 113 + (Sensor_week - 1) * 27,
          center_y: 81,
          radius: 5,
          color: 0xffffff,
          alpha: 255,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });
         
         idle_select_week.setProperty(hmUI.prop.MORE, {
          center_x: 113 + (Sensor_week - 1) * 27,
          center_y: 81,
          radius: 5,
          color: 0xffffff,
          alpha: 255,
          show_level: hmUI.show_level.ONLY_AOD,
         });
                  

    
          let normal_hourStr = format_hour.toString();
          normal_hourStr = normal_hourStr.padStart(2, '0');
          normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr);
          idle_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr);
          
         let normal_dayStr = timeSensor.day.toString();
         normal_dayStr = normal_dayStr.padStart(2, '0');

         normal_day_text_font.setProperty(hmUI.prop.MORE, {
          x: normal_day_x - 38-5,
          y: 95 - 9,
          w: 86,
          h: 100,
          text: normal_dayStr,
          text_size: 86,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Bebas11.ttf',
          color: 0xFFFFFFFF,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          // padding: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });
         
         idle_day_text_font.setProperty(hmUI.prop.MORE, {
          x: normal_day_x - 38-5,
          y: 95 - 9,
          w: 86,
          h: 100,
          text: normal_dayStr,
          text_size: 86,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Bebas11.ttf',
          color: 0xFFFFFFFF,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          // padding: true,
          show_level: hmUI.show_level.ONLY_AOD,
         });          
          
          
         };


         console.log('minute font');
         if (updateMinute) {
          let normal_minuteStr = minute.toString();
          normal_minuteStr = normal_minuteStr.padStart(2, '0');
          normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr);
          idle_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr);
         };
         
         
         // Second Circle
         let normal_secondCircleProgress = 360 * second / 60;
         if (normal_second_circle_scale)  normal_second_circle_scale.setProperty(hmUI.prop.MORE, {
           center_x: 195,
           center_y: 225,
           start_angle: 0,
           end_angle: normal_secondCircleProgress,
           radius: 199,
           line_width: 85,
           corner_flag: 3,
           color: color_bg[CONF_MAIN[0].id],
           level: 100,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });         
         

        };

        //#endregion
        function scale_call() {
         console.log('scale_call()');

         console.log('update scales STEP');

         let valueStep = step.current;
         let targetStep = step.target;
         let progressStep = valueStep / targetStep;
         if (progressStep > 1) progressStep = 1;
         let progress_ls_normal_step = progressStep;

         if (screenType != hmSetting.screen_type.AOD) {

          // normal_step_linear_scale
          // initial parameters
          let start_x_normal_step = 92;
          let start_y_normal_step = 421;
          let lenght_ls_normal_step = 206;
          let line_width_ls_normal_step = 20;
          let color_ls_normal_step = color_bg[CONF_MAIN[0].id];;

          // calculated parameters
          let start_x_normal_step_draw = start_x_normal_step;
          let start_y_normal_step_draw = start_y_normal_step;
          lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
          let lenght_ls_normal_step_draw = lenght_ls_normal_step;
          let line_width_ls_normal_step_draw = line_width_ls_normal_step;
          if (lenght_ls_normal_step < 0) {
           lenght_ls_normal_step_draw = -lenght_ls_normal_step;
           start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
          };

          normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
           x: start_x_normal_step_draw,
           y: start_y_normal_step_draw,
           w: lenght_ls_normal_step_draw,
           h: line_width_ls_normal_step_draw,
           radius: 10,
           color: color_ls_normal_step,
          });
         };

         console.log('update scales BATTERY');

         let valueBattery = battery.current;
         let targetBattery = 100;
         let progressBattery = valueBattery / targetBattery;
         if (progressBattery > 1) progressBattery = 1;
         let progress_ls_normal_battery = progressBattery;

         if (screenType != hmSetting.screen_type.AOD) {

          // normal_battery_linear_scale
          // initial parameters
          let start_x_normal_battery = 92;
          let start_y_normal_battery = 9;
          let lenght_ls_normal_battery = 206;
          let line_width_ls_normal_battery = 20;
          let color_ls_normal_battery = color_bg[CONF_MAIN[0].id];

          // calculated parameters
          let start_x_normal_battery_draw = start_x_normal_battery;
          let start_y_normal_battery_draw = start_y_normal_battery;
          lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
          let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
          let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
          if (lenght_ls_normal_battery < 0) {
           lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
           start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
          };

          normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
           x: start_x_normal_battery_draw,
           y: start_y_normal_battery_draw,
           w: lenght_ls_normal_battery_draw,
           h: line_width_ls_normal_battery_draw,
           radius: 10,
           color: color_ls_normal_battery,
          });
         };

                console.log('update scales STEP');
                let progress_ls_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_linear_scale
                  // initial parameters
                  let start_x_idle_step = 92;
                  let start_y_idle_step = 421;
                  let lenght_ls_idle_step = 206;
                  let line_width_ls_idle_step = 20;
                  let color_ls_idle_step = color_bg[CONF_MAIN[0].id];
                  
                  // calculated parameters
                  let start_x_idle_step_draw = start_x_idle_step;
                  let start_y_idle_step_draw = start_y_idle_step;
                  lenght_ls_idle_step = lenght_ls_idle_step * progress_ls_idle_step;
                  let lenght_ls_idle_step_draw = lenght_ls_idle_step;
                  let line_width_ls_idle_step_draw = line_width_ls_idle_step;
                  if (lenght_ls_idle_step < 0){
                    lenght_ls_idle_step_draw = -lenght_ls_idle_step;
                    start_x_idle_step_draw = start_x_idle_step - lenght_ls_idle_step_draw;
                  };
                  
                  idle_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step_draw,
                    y: start_y_idle_step_draw,
                    w: lenght_ls_idle_step_draw,
                    h: line_width_ls_idle_step_draw,
                    color: color_ls_idle_step,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 92;
                  let start_y_idle_battery = 9;
                  let lenght_ls_idle_battery = 206;
                  let line_width_ls_idle_battery = 20;
                  let color_ls_idle_battery = color_bg[CONF_MAIN[0].id];
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };         
         
         

        };
        
        
 if (screenType != hmSetting.screen_type.AOD)   
{      wgt_start(CONF_MAIN[0].id);
        groupVremya.setProperty(hmUI.prop.VISIBLE, true);
        groupSetting.setProperty(hmUI.prop.VISIBLE, false);
        groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
       groupTap.setProperty(hmUI.prop.VISIBLE, false);	}			  


        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
         resume_call: (function () {
          loadSettings();
            autoToggleWeatherIcons();
             updateSleep();   
         app_update();
        
          /*          setTimeout(() => {
                       updateGrafik();	
                    }, 350);*/

          console.log('resume_call()');
         scale_call();
          time_update(true, true);
          if (screenType == hmSetting.screen_type.WATCHFACE) {
           if (!normal_timerUpdateSec) {
            let animDelay = timeSensor.utc % 1000;
            let animRepeat = 1000;
            normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
             time_update(false, false);
            })); // end timer 
           }; // end timer check
          }; // end screenType

          if (screenType == hmSetting.screen_type.WATCHFACE) {
           if (!normal_timerTimeUpdate) {
            normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
             let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
             let updateMinute = timeSensor.second < 2;
             time_update(updateHour, updateMinute);
            })); // end timer 
           }; // end timer check
          }; // end screenType
          
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

         }),
         pause_call: (function () {
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupSetting.setProperty(hmUI.prop.VISIBLE, false);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
          normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);
       groupTap.setProperty(hmUI.prop.VISIBLE, false);				  

          // groupTap.setProperty(hmUI.prop.VISIBLE, false);	

          console.log('pause_call()');

          if (normal_timerUpdateSec) {
           timer.stopTimer(normal_timerUpdateSec);
           normal_timerUpdateSec = undefined;
          }
          if (normal_timerTimeUpdate) {
           timer.stopTimer(normal_timerTimeUpdate);
           normal_timerTimeUpdate = undefined;
          }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }          

         }),
        });

        //dynamic modify end
       },
       onInit() {
        logger.log('index page.js on init invoke');
       },
       build() {
        this.init_view();
        logger.log('index page.js on ready invoke');
       },
       onDestroy() {
        logger.log('index page.js on destroy invoke');
       }
      });;
     })();
    } catch (e) {
     console.log('Mini Program Error', e);
     e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));;
    }
