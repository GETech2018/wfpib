﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_digital_clock_img_time = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['000_1.png', '000_2.png', '000_3.png'];
        let backgroundToastList = ['Background %s', 'Background %s', 'Background %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: '000_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 3,
              y: 162,
              image_array: ["096.png","097.png","098.png","099.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 297,
              font_array: ["057.png","058.png","059.png","060.png","061.png","062.png","063.png","064.png","065.png","066.png"],
              padding: false,
              h_space: 3,
              unit_sc: '068.png',
              unit_tc: '068.png',
              unit_en: '068.png',
              imperial_unit_sc: '068.png',
              imperial_unit_tc: '068.png',
              imperial_unit_en: '068.png',
              negative_image: '067.png',
              invalid_image: '069.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 310,
                y: 297,
                font_array: ["057.png","058.png","059.png","060.png","061.png","062.png","063.png","064.png","065.png","066.png"],
                padding: false,
                h_space: 3,
                unit_sc: '068.png',
                unit_tc: '068.png',
                unit_en: '068.png',
                imperial_unit_sc: '068.png',
                imperial_unit_tc: '068.png',
                imperial_unit_en: '068.png',
                negative_image: '067.png',
                invalid_image: '069.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 53,
              y: 96,
              week_en: ["089.png","090.png","091.png","092.png","093.png","094.png","095.png"],
              week_tc: ["089.png","090.png","091.png","092.png","093.png","094.png","095.png"],
              week_sc: ["089.png","090.png","091.png","092.png","093.png","094.png","095.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 307,
              day_startY: 15,
              day_sc_array: ["033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png"],
              day_tc_array: ["033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png"],
              day_en_array: ["033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 218,
              month_startY: 15,
              month_sc_array: ["033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png"],
              month_tc_array: ["033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png"],
              month_en_array: ["033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png"],
              month_zero: 1,
              month_space: 3,
              month_unit_sc: '053.png',
              month_unit_tc: '053.png',
              month_unit_en: '053.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 53,
              year_startY: 15,
              year_sc_array: ["033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png"],
              year_tc_array: ["033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png"],
              year_en_array: ["033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png"],
              year_zero: 1,
              year_space: 3,
              year_unit_sc: '053.png',
              year_unit_tc: '053.png',
              year_unit_en: '053.png',
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 436,
              font_array: ["033.png","034.png","035.png","036.png","037.png","038.png","039.png","040.png","041.png","042.png"],
              padding: false,
              h_space: 3,
              unit_sc: '055.png',
              unit_tc: '055.png',
              unit_en: '055.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 78,
              y: 436,
              image_array: ["079.png","080.png","081.png","082.png","083.png","084.png","085.png","086.png","087.png","088.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 386,
              y: 111,
              src: '077.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 13,
              y: 111,
              src: '075.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 386,
              y: 54,
              src: '073.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 13,
              y: 54,
              src: '071.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 3,
              hour_startY: 314,
              hour_array: ["001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png","010.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_unit_sc: '021.png',
              hour_unit_tc: '021.png',
              hour_unit_en: '021.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 118,
              minute_startY: 314,
              minute_array: ["001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png","010.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 218,
              second_startY: 339,
              second_array: ["023.png","024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png","032.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 436,
              font_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              padding: false,
              h_space: 3,
              unit_sc: '056.png',
              unit_tc: '056.png',
              unit_en: '056.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 307,
              day_startY: 15,
              day_sc_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              day_tc_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              day_en_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              day_zero: 1,
              day_space: 3,
              day_unit_sc: '054.png',
              day_unit_tc: '054.png',
              day_unit_en: '054.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 218,
              month_startY: 15,
              month_sc_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              month_tc_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              month_en_array: ["043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png","052.png"],
              month_zero: 1,
              month_space: 3,
              month_unit_sc: '054.png',
              month_unit_tc: '054.png',
              month_unit_en: '054.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 3,
              hour_startY: 314,
              hour_array: ["011.png","012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_unit_sc: '022.png',
              hour_unit_tc: '022.png',
              hour_unit_en: '022.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 118,
              minute_startY: 314,
              minute_array: ["011.png","012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: TELEFON\r\nELVESZETT,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: TELEFON\r\nMEGVAN,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "TELEFON\r\nELVESZETT"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "TELEFON\r\nMEGVAN"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 78,
              y: 436,
              w: 277,
              h: 75,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 216,
              y: 162,
              w: 213,
              h: 129,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 3,
              y: 314,
              w: 212,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 53,
              y: 15,
              w: 327,
              h: 141,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 3,
              y: 162,
              w: 212,
              h: 129,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0000b_2.png',
              normal_src: '0000b_2.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneMusicCtrlScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 310,
              // y: 297,
              // w: 119,
              // h: 117,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '0000b_1.png',
              // normal_src: '0000b_1.png',
              // bg_list: 000_1|000_2|000_3,
              // toast_list: Background %s|Background %s|Background %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 310,
              y: 297,
              w: 119,
              h: 117,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0000b_1.png',
              normal_src: '0000b_1.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}