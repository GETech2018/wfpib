try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_db7d61d820d64838aa7044c4c37b69a8 = '';
        let stepSensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 320,
                    h: 380,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 160,
                    center_y: 160,
                    radius: 128,
                    start_angle: -149,
                    end_angle: 149,
                    color: 4294901760,
                    line_width: 7,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_db7d61d820d64838aa7044c4c37b69a8 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 115,
                    y: 328,
                    w: 120,
                    h: 50,
                    text: '[SC]',
                    color: '0xFF000000',
                    text_size: 35,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 160,
                    hour_centerY: 160,
                    hour_posX: 120,
                    hour_posY: 160,
                    hour_path: '3.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 160,
                    minute_centerY: 160,
                    minute_posX: 120,
                    minute_posY: 160,
                    minute_path: '4.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 160,
                    second_centerY: 160,
                    second_posX: 120,
                    second_posY: 160,
                    second_path: '5.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_db7d61d820d64838aa7044c4c37b69a8.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_db7d61d820d64838aa7044c4c37b69a8.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}