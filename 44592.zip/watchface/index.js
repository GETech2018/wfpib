﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_clock_img = ''
        let normal_stand_target_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_pai_day_text_img = ''
        let normal_stress_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_stand_target_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_pai_day_text_img = ''
        let idle_stress_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 41,
              y: 307,
              src: 'lock_aod.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 9,
              y: 312,
              src: 'alarm_aod.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291,
              y: 271,
              font_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 132,
              y: 273,
              week_en: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_tc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_sc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 93,
              day_startY: 270,
              day_sc_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              day_tc_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              day_en_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 297,
              y: 400,
              font_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 225,
              y: 400,
              font_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 118,
              y: 400,
              font_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 400,
              font_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'deg_theme7.png',
              unit_tc: 'deg_theme7.png',
              unit_en: 'deg_theme7.png',
              negative_image: 'dash_theme7.png',
              invalid_image: 'dash_theme7.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 17,
              y: 228,
              font_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 69,
              y: 307,
              image_array: ["progress_theme1_6.png","progress_theme1_7.png","progress_theme1_8.png","progress_theme1_9.png","progress_theme1_10.png","progress_theme1_11.png","progress_theme1_12.png","progress_theme1_13.png","progress_theme1_14.png","progress_theme1_15.png","progress_theme1_16.png","progress_theme1_17.png","progress_theme1_18.png","progress_theme1_19.png","progress_theme1_20.png"],
              image_length: 15,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 17,
              y: 153,
              font_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km_theme7.png',
              unit_tc: 'km_theme7.png',
              unit_en: 'km_theme7.png',
              dot_image: 'dotbot_theme7.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 17,
              y: 80,
              font_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 66,
              y: 39,
              image_array: ["heartrate_theme7_0.png","heartrate_theme7_1.png","heartrate_theme7_2.png","heartrate_theme7_3.png","heartrate_theme7_4.png","hours_aod_0.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 267,
              am_y: 182,
              am_sc_path: 'am_theme7.png',
              am_en_path: 'am_theme7.png',
              pm_x: 276,
              pm_y: 183,
              pm_sc_path: 'pm_theme7.png',
              pm_en_path: 'pm_theme7.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 165,
              hour_startY: 45,
              hour_array: ["hours_theme7_0.png","hours_theme7_1.png","hours_theme7_2.png","hours_theme7_3.png","hours_theme7_4.png","hours_theme7_5.png","hours_theme7_6.png","hours_theme7_7.png","hours_theme7_8.png","hours_theme7_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 271,
              minute_startY: 43,
              minute_array: ["minutes_theme7_0.png","minutes_theme7_1.png","minutes_theme7_2.png","minutes_theme7_3.png","minutes_theme7_4.png","minutes_theme7_5.png","minutes_theme7_6.png","minutes_theme7_7.png","minutes_theme7_8.png","minutes_theme7_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'background_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291,
              y: 271,
              font_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 132,
              y: 273,
              week_en: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_tc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_sc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 93,
              day_startY: 270,
              day_sc_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              day_tc_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              day_en_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 297,
              y: 400,
              font_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 225,
              y: 400,
              font_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 118,
              y: 400,
              font_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 400,
              font_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'deg_theme7.png',
              unit_tc: 'deg_theme7.png',
              unit_en: 'deg_theme7.png',
              negative_image: 'dash_theme7.png',
              invalid_image: 'dash_theme7.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 17,
              y: 228,
              font_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 69,
              y: 307,
              image_array: ["progress_aod_1.png","progress_aod_2.png","progress_aod_3.png","progress_aod_4.png","progress_aod_5.png","progress_aod_6.png","progress_aod_7.png","progress_aod_8.png","progress_aod_9.png","progress_aod_10.png","progress_aod_11.png","progress_aod_12.png","progress_aod_13.png","progress_aod_14.png","progress_aod_15.png"],
              image_length: 15,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 17,
              y: 153,
              font_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km_theme7.png',
              unit_tc: 'km_theme7.png',
              unit_en: 'km_theme7.png',
              dot_image: 'dotbot_theme7.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 17,
              y: 80,
              font_array: ["gen_theme7_0.png","gen_theme7_1.png","gen_theme7_2.png","gen_theme7_3.png","gen_theme7_4.png","gen_theme7_5.png","gen_theme7_6.png","gen_theme7_7.png","gen_theme7_8.png","gen_theme7_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 66,
              y: 39,
              image_array: ["heartrate_aod_0.png","heartrate_aod_1.png","heartrate_aod_2.png","heartrate_aod_3.png","heartrate_aod_4.png","heartrate_theme7_0.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 267,
              am_y: 182,
              am_sc_path: 'am_aod.png',
              am_en_path: 'am_aod.png',
              pm_x: 276,
              pm_y: 183,
              pm_sc_path: 'pm_aod.png',
              pm_en_path: 'pm_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 165,
              hour_startY: 45,
              hour_array: ["hours_aod_0.png","hours_aod_1.png","hours_aod_2.png","hours_aod_3.png","hours_aod_4.png","hours_aod_5.png","hours_aod_6.png","hours_aod_7.png","hours_aod_8.png","hours_aod_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 271,
              minute_startY: 43,
              minute_array: ["minutes_aod_0.png","minutes_aod_1.png","minutes_aod_2.png","minutes_aod_3.png","minutes_aod_4.png","minutes_aod_5.png","minutes_aod_6.png","minutes_aod_7.png","minutes_aod_8.png","minutes_aod_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 12,
              w: 134,
              h: 91,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 118,
              w: 148,
              h: 72,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 195,
              w: 148,
              h: 72,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 268,
              w: 199,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({ appid: 1057409, url: 'page/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 266,
              w: 199,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportStatusScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 20,
              y: 360,
              w: 87,
              h: 84,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 108,
              y: 360,
              w: 87,
              h: 84,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityWeekShowScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 197,
              y: 358,
              w: 99,
              h: 84,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StressHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 358,
              w: 99,
              h: 84,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 157,
              y: 75,
              w: 99,
              h: 84,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 261,
              y: 74,
              w: 99,
              h: 84,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}