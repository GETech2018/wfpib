﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

/// change color seconds
let secColor="sec/White/"
         let colornumber = 1
        let totalcolors = 7
        let namecolor = ''

        function colorSec() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "WHITE"
secColor="sec/White/"
}
if ( colornumber == 2) { namecolor = "GREEN"
secColor="sec/Green/"
}
if ( colornumber == 3) { namecolor = "BLUE"
secColor="sec/Blue/"
}
if ( colornumber == 4) { namecolor = "RED"
secColor="sec/Red/"
}
if ( colornumber == 5) { namecolor = "ORANGE"
secColor="sec/Orange/"
}
if ( colornumber == 6) { namecolor = "MAGENTA"
secColor="sec/Magenta/"
}
if ( colornumber == 7) { namecolor = "YELLOW"
secColor="sec/Yellow/"
}
hmUI.showToast({text: namecolor });

                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_moon_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_moon_image_progress_img_level = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let normal_cal_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['main1.png', 'main2.png', 'main3.png', 'main4.png'];
        let backgroundToastList = ['Background %s', 'Background %s', 'Background %s', 'Background %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 208,
              y: 445,
              src: 'System_BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 360,
              y: 446,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 177,
              font_array: ["Blue_Small_font_001.png","Blue_Small_font_002.png","Blue_Small_font_003.png","Blue_Small_font_004.png","Blue_Small_font_005.png","Blue_Small_font_006.png","Blue_Small_font_007.png","Blue_Small_font_008.png","Blue_Small_font_009.png","Blue_Small_font_010.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Blue_Small_font_011.png',
              dot_image: 'Blue_Small_font_011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 177,
              font_array: ["Blue_Small_font_001.png","Blue_Small_font_002.png","Blue_Small_font_003.png","Blue_Small_font_004.png","Blue_Small_font_005.png","Blue_Small_font_006.png","Blue_Small_font_007.png","Blue_Small_font_008.png","Blue_Small_font_009.png","Blue_Small_font_010.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Blue_Small_font_011.png',
              dot_image: 'Blue_Small_font_011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 85,
              month_startY: 308,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 23,
              y: 224,
              week_en: ["Weed_dat_01.png","Weed_dat_02.png","Weed_dat_03.png","Weed_dat_04.png","Weed_dat_05.png","Weed_dat_06.png","Weed_dat_07.png"],
              week_tc: ["Weed_dat_01.png","Weed_dat_02.png","Weed_dat_03.png","Weed_dat_04.png","Weed_dat_05.png","Weed_dat_06.png","Weed_dat_07.png"],
              week_sc: ["Weed_dat_01.png","Weed_dat_02.png","Weed_dat_03.png","Weed_dat_04.png","Weed_dat_05.png","Weed_dat_06.png","Weed_dat_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 53,
              day_startY: 260,
              day_sc_array: ["Time_font_S_001.png","Time_font_S_002.png","Time_font_S_003.png","Time_font_S_004.png","Time_font_S_005.png","Time_font_S_006.png","Time_font_S_007.png","Time_font_S_008.png","Time_font_S_009.png","Time_font_S_010.png"],
              day_tc_array: ["Time_font_S_001.png","Time_font_S_002.png","Time_font_S_003.png","Time_font_S_004.png","Time_font_S_005.png","Time_font_S_006.png","Time_font_S_007.png","Time_font_S_008.png","Time_font_S_009.png","Time_font_S_010.png"],
              day_en_array: ["Time_font_S_001.png","Time_font_S_002.png","Time_font_S_003.png","Time_font_S_004.png","Time_font_S_005.png","Time_font_S_006.png","Time_font_S_007.png","Time_font_S_008.png","Time_font_S_009.png","Time_font_S_010.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 19,
              y: 269,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 251,
              y: 165,
              w: 150,
              h: 34,
              text_size: 23,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 127,
              font_array: ["ACT_font_001.png","ACT_font_002.png","ACT_font_003.png","ACT_font_004.png","ACT_font_005.png","ACT_font_006.png","ACT_font_007.png","ACT_font_008.png","ACT_font_009.png","ACT_font_010.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Weather_symbo_02.png',
              unit_tc: 'Weather_symbo_02.png',
              unit_en: 'Weather_symbo_02.png',
              imperial_unit_sc: 'Weather_symbo_02.png',
              imperial_unit_tc: 'Weather_symbo_02.png',
              imperial_unit_en: 'Weather_symbo_02.png',
              negative_image: 'Weather_symbo_01.png',
              invalid_image: 'Weather_symbo_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 306,
                y: 127,
                font_array: ["ACT_font_001.png","ACT_font_002.png","ACT_font_003.png","ACT_font_004.png","ACT_font_005.png","ACT_font_006.png","ACT_font_007.png","ACT_font_008.png","ACT_font_009.png","ACT_font_010.png"],
                padding: false,
                h_space: 3,
                unit_sc: 'Weather_symbo_02.png',
                unit_tc: 'Weather_symbo_02.png',
                unit_en: 'Weather_symbo_02.png',
                imperial_unit_sc: 'Weather_symbo_02.png',
                imperial_unit_tc: 'Weather_symbo_02.png',
                imperial_unit_en: 'Weather_symbo_02.png',
                negative_image: 'Weather_symbo_01.png',
                invalid_image: 'Weather_symbo_01.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 259,
              y: 118,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_step_Batt.png',
              center_x: 217,
              center_y: 258,
              x: 9,
              y: 230,
              start_angle: 305,
              end_angle: 345,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 48,
              font_array: ["Battery_font_001.png","Battery_font_002.png","Battery_font_003.png","Battery_font_004.png","Battery_font_005.png","Battery_font_006.png","Battery_font_007.png","Battery_font_008.png","Battery_font_009.png","Battery_font_010.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Battery_font_011.png',
              unit_tc: 'Battery_font_011.png',
              unit_en: 'Battery_font_011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 82,
              font_array: ["ACT_font_001.png","ACT_font_002.png","ACT_font_003.png","ACT_font_004.png","ACT_font_005.png","ACT_font_006.png","ACT_font_007.png","ACT_font_008.png","ACT_font_009.png","ACT_font_010.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'Weather_symbo_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 309,
              y: 87,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 360,
              font_array: ["ACT_font_001.png","ACT_font_002.png","ACT_font_003.png","ACT_font_004.png","ACT_font_005.png","ACT_font_006.png","ACT_font_007.png","ACT_font_008.png","ACT_font_009.png","ACT_font_010.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Symbo_KM.png',
              unit_tc: 'Symbo_KM.png',
              unit_en: 'Symbo_KM.png',
              imperial_unit_sc: 'Symbo_Mil.png',
              imperial_unit_tc: 'Symbo_Mil.png',
              imperial_unit_en: 'Symbo_Mil.png',
              dot_image: 'ACT_font_011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_step_Batt.png',
              center_x: 217,
              center_y: 258,
              x: 9,
              y: 230,
              start_angle: 195,
              end_angle: 235,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 406,
              font_array: ["ACT_font_001.png","ACT_font_002.png","ACT_font_003.png","ACT_font_004.png","ACT_font_005.png","ACT_font_006.png","ACT_font_007.png","ACT_font_008.png","ACT_font_009.png","ACT_font_010.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 366,
              am_y: 271,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 366,
              pm_y: 271,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 365,
              second_startY: 219,
              second_array: ["Time_font_S_001.png","Time_font_S_002.png","Time_font_S_003.png","Time_font_S_004.png","Time_font_S_005.png","Time_font_S_006.png","Time_font_S_007.png","Time_font_S_008.png","Time_font_S_009.png","Time_font_S_010.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 247,
              minute_startY: 214,
              minute_array: ["Time_font_HM_001.png","Time_font_HM_002.png","Time_font_HM_003.png","Time_font_HM_004.png","Time_font_HM_005.png","Time_font_HM_006.png","Time_font_HM_007.png","Time_font_HM_008.png","Time_font_HM_009.png","Time_font_HM_010.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 117,
              hour_startY: 214,
              hour_array: ["Time_font_HM_001.png","Time_font_HM_002.png","Time_font_HM_003.png","Time_font_HM_004.png","Time_font_HM_005.png","Time_font_HM_006.png","Time_font_HM_007.png","Time_font_HM_008.png","Time_font_HM_009.png","Time_font_HM_010.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
// ===== Second runner on rounded rectangle (SMOOTH + ROTATE + LIGHT CPU) =====

let timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

// ===== Rect setting =====
const SCREEN_W = 432;
const SCREEN_H = 514;
const M = 14;
const R = 95;

const RECT_X = M;
const RECT_Y = M;
const RECT_W = SCREEN_W - M * 2;
const RECT_H = SCREEN_H - M * 2;

// ===== Perimeter =====
const straightW = RECT_W - 2 * R;
const straightH = RECT_H - 2 * R;
const arcLen = Math.PI * R / 2;
const perimeter = 2 * (straightW + straightH) + 4 * arcLen;

// ===== Image =====
const BAR_W = 125;
const BAR_H = 125;

let runner = hmUI.createWidget(hmUI.widget.IMG, {
  x: 0,
  y: 0,
  w: BAR_W,
  h: BAR_H,
  src: "sec_dot.png",
  show_level: hmUI.show_level.ONLY_NORMAL
});

// ===== Path function =====
function getPoint(dist) {

  let d = dist;

  if (d < straightW) return { x: RECT_X + R + d, y: RECT_Y };
  d -= straightW;

  if (d < arcLen) {
    let a = -Math.PI / 2 + (d / arcLen) * (Math.PI / 2);
    return {
      x: RECT_X + RECT_W - R + Math.cos(a) * R,
      y: RECT_Y + R + Math.sin(a) * R
    };
  }
  d -= arcLen;

  if (d < straightH) return { x: RECT_X + RECT_W, y: RECT_Y + R + d };
  d -= straightH;

  if (d < arcLen) {
    let a = (d / arcLen) * (Math.PI / 2);
    return {
      x: RECT_X + RECT_W - R + Math.cos(a) * R,
      y: RECT_Y + RECT_H - R + Math.sin(a) * R
    };
  }
  d -= arcLen;

  if (d < straightW)
    return { x: RECT_X + RECT_W - R - d, y: RECT_Y + RECT_H };
  d -= straightW;

  if (d < arcLen) {
    let a = Math.PI / 2 + (d / arcLen) * (Math.PI / 2);
    return {
      x: RECT_X + R + Math.cos(a) * R,
      y: RECT_Y + RECT_H - R + Math.sin(a) * R
    };
  }
  d -= arcLen;

  if (d < straightH)
    return { x: RECT_X, y: RECT_Y + RECT_H - R - d };
  d -= straightH;

  let a = Math.PI + (d / arcLen) * (Math.PI / 2);
  return {
    x: RECT_X + R + Math.cos(a) * R,
    y: RECT_Y + R + Math.sin(a) * R
  };
}

// ===== previous position (for angle) =====
let prevX = 0;
let prevY = 0;

// ===== Update =====
function updateSecond() {

  let now = Date.now();
  let date = new Date(now);

  let sec = date.getSeconds();
  let ms = date.getMilliseconds();

  let smoothSec = sec + ms / 1000;

  // start at 12 o'clock
  let startAtTop = straightW / 2;

  let dist = (smoothSec / 60) * perimeter;

let d = (startAtTop + dist) % perimeter;

  let p = getPoint(d);

  // calculate angle from movement
  let dx = p.x - prevX;
  let dy = p.y - prevY;

  let angle = Math.atan2(dy, dx) * 180 / Math.PI;

  runner.setProperty(hmUI.prop.MORE, {
    x: Math.round(p.x - BAR_W / 2),
    y: Math.round(p.y - BAR_H / 2),
    angle: angle,
  src: secColor+"sec_dot_"+sec+".png",
    center_x: BAR_W / 2,
    center_y: BAR_H / 2

  });

  prevX = p.x;
  prevY = p.y;
}

// ===== Run =====
updateSecond();
timer.createTimer(0, 99, updateSecond);
            // end user_script.js


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'main3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 208,
              y: 445,
              src: 'System_BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 360,
              y: 446,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 177,
              font_array: ["Blue_Small_font_001.png","Blue_Small_font_002.png","Blue_Small_font_003.png","Blue_Small_font_004.png","Blue_Small_font_005.png","Blue_Small_font_006.png","Blue_Small_font_007.png","Blue_Small_font_008.png","Blue_Small_font_009.png","Blue_Small_font_010.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Blue_Small_font_011.png',
              dot_image: 'Blue_Small_font_011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 177,
              font_array: ["Blue_Small_font_001.png","Blue_Small_font_002.png","Blue_Small_font_003.png","Blue_Small_font_004.png","Blue_Small_font_005.png","Blue_Small_font_006.png","Blue_Small_font_007.png","Blue_Small_font_008.png","Blue_Small_font_009.png","Blue_Small_font_010.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Blue_Small_font_011.png',
              dot_image: 'Blue_Small_font_011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 85,
              month_startY: 308,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 23,
              y: 224,
              week_en: ["Weed_dat_01.png","Weed_dat_02.png","Weed_dat_03.png","Weed_dat_04.png","Weed_dat_05.png","Weed_dat_06.png","Weed_dat_07.png"],
              week_tc: ["Weed_dat_01.png","Weed_dat_02.png","Weed_dat_03.png","Weed_dat_04.png","Weed_dat_05.png","Weed_dat_06.png","Weed_dat_07.png"],
              week_sc: ["Weed_dat_01.png","Weed_dat_02.png","Weed_dat_03.png","Weed_dat_04.png","Weed_dat_05.png","Weed_dat_06.png","Weed_dat_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 53,
              day_startY: 260,
              day_sc_array: ["Time_font_S_001.png","Time_font_S_002.png","Time_font_S_003.png","Time_font_S_004.png","Time_font_S_005.png","Time_font_S_006.png","Time_font_S_007.png","Time_font_S_008.png","Time_font_S_009.png","Time_font_S_010.png"],
              day_tc_array: ["Time_font_S_001.png","Time_font_S_002.png","Time_font_S_003.png","Time_font_S_004.png","Time_font_S_005.png","Time_font_S_006.png","Time_font_S_007.png","Time_font_S_008.png","Time_font_S_009.png","Time_font_S_010.png"],
              day_en_array: ["Time_font_S_001.png","Time_font_S_002.png","Time_font_S_003.png","Time_font_S_004.png","Time_font_S_005.png","Time_font_S_006.png","Time_font_S_007.png","Time_font_S_008.png","Time_font_S_009.png","Time_font_S_010.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 19,
              y: 269,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 251,
              y: 165,
              w: 150,
              h: 34,
              text_size: 23,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 127,
              font_array: ["ACT_font_001.png","ACT_font_002.png","ACT_font_003.png","ACT_font_004.png","ACT_font_005.png","ACT_font_006.png","ACT_font_007.png","ACT_font_008.png","ACT_font_009.png","ACT_font_010.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Weather_symbo_02.png',
              unit_tc: 'Weather_symbo_02.png',
              unit_en: 'Weather_symbo_02.png',
              imperial_unit_sc: 'Weather_symbo_02.png',
              imperial_unit_tc: 'Weather_symbo_02.png',
              imperial_unit_en: 'Weather_symbo_02.png',
              negative_image: 'Weather_symbo_01.png',
              invalid_image: 'Weather_symbo_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 306,
                y: 127,
                font_array: ["ACT_font_001.png","ACT_font_002.png","ACT_font_003.png","ACT_font_004.png","ACT_font_005.png","ACT_font_006.png","ACT_font_007.png","ACT_font_008.png","ACT_font_009.png","ACT_font_010.png"],
                padding: false,
                h_space: 3,
                unit_sc: 'Weather_symbo_02.png',
                unit_tc: 'Weather_symbo_02.png',
                unit_en: 'Weather_symbo_02.png',
                imperial_unit_sc: 'Weather_symbo_02.png',
                imperial_unit_tc: 'Weather_symbo_02.png',
                imperial_unit_en: 'Weather_symbo_02.png',
                negative_image: 'Weather_symbo_01.png',
                invalid_image: 'Weather_symbo_01.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 259,
              y: 118,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_step_Batt.png',
              center_x: 217,
              center_y: 258,
              x: 9,
              y: 230,
              start_angle: 305,
              end_angle: 345,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 48,
              font_array: ["Battery_font_001.png","Battery_font_002.png","Battery_font_003.png","Battery_font_004.png","Battery_font_005.png","Battery_font_006.png","Battery_font_007.png","Battery_font_008.png","Battery_font_009.png","Battery_font_010.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Battery_font_011.png',
              unit_tc: 'Battery_font_011.png',
              unit_en: 'Battery_font_011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 82,
              font_array: ["ACT_font_001.png","ACT_font_002.png","ACT_font_003.png","ACT_font_004.png","ACT_font_005.png","ACT_font_006.png","ACT_font_007.png","ACT_font_008.png","ACT_font_009.png","ACT_font_010.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'Weather_symbo_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 309,
              y: 87,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 360,
              font_array: ["ACT_font_001.png","ACT_font_002.png","ACT_font_003.png","ACT_font_004.png","ACT_font_005.png","ACT_font_006.png","ACT_font_007.png","ACT_font_008.png","ACT_font_009.png","ACT_font_010.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Symbo_KM.png',
              unit_tc: 'Symbo_KM.png',
              unit_en: 'Symbo_KM.png',
              imperial_unit_sc: 'Symbo_Mil.png',
              imperial_unit_tc: 'Symbo_Mil.png',
              imperial_unit_en: 'Symbo_Mil.png',
              dot_image: 'ACT_font_011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_step_Batt.png',
              center_x: 217,
              center_y: 258,
              x: 9,
              y: 230,
              start_angle: 195,
              end_angle: 235,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 406,
              font_array: ["ACT_font_001.png","ACT_font_002.png","ACT_font_003.png","ACT_font_004.png","ACT_font_005.png","ACT_font_006.png","ACT_font_007.png","ACT_font_008.png","ACT_font_009.png","ACT_font_010.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 366,
              am_y: 271,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 366,
              pm_y: 271,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 247,
              minute_startY: 214,
              minute_array: ["Time_font_HM_001.png","Time_font_HM_002.png","Time_font_HM_003.png","Time_font_HM_004.png","Time_font_HM_005.png","Time_font_HM_006.png","Time_font_HM_007.png","Time_font_HM_008.png","Time_font_HM_009.png","Time_font_HM_010.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 364,
              y: 238,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 117,
              hour_startY: 214,
              hour_array: ["Time_font_HM_001.png","Time_font_HM_002.png","Time_font_HM_003.png","Time_font_HM_004.png","Time_font_HM_005.png","Time_font_HM_006.png","Time_font_HM_007.png","Time_font_HM_008.png","Time_font_HM_009.png","Time_font_HM_010.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 194,
              y: 401,
              w: 147,
              h: 37,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 58,
              y: 55,
              w: 103,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 220,
              y: 216,
              w: 31,
              h: 82,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 361,
              y: 215,
              w: 55,
              h: 57,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 354,
              y: 443,
              w: 71,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 33,
              y: 171,
              w: 206,
              h: 29,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 311,
              y: 121,
              w: 96,
              h: 37,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 187,
              y: 352,
              w: 196,
              h: 39,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 196,
              y: 77,
              w: 55,
              h: 38,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 269,
              y: 75,
              w: 99,
              h: 39,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 14,
              y: 218,
              w: 86,
              h: 85,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 67,
              y: 354,
              w: 93,
              h: 102,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 201,
              y: 444,
              w: 117,
              h: 37,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //colorSec
colorSec()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 187,
              // y: 121,
              // w: 43,
              // h: 42,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '0_Empty.png',
              // normal_src: '0_Empty.png',
              // bg_list: main1|main2|main3|main4,
              // toast_list: Background %s|Background %s|Background %s|Background %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 187,
              y: 121,
              w: 43,
              h: 42,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

              console.log('Weather city name');
              let idle_cityNameStr = weatherData.cityName;
              idle_city_name_text.setProperty(hmUI.prop.TEXT, idle_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}