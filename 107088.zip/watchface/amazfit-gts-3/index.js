try {
    (() => {
        var e = __$$hmAppManager$$__.currentApp;
        const n = e.current,
            {
                px: g
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e, n)), e.app.__globals__),
            p = Logger.getLogger("watchface6");
        n.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: "4.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 54,
                    y: 65,
                    src: "5.png",
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 55,
                    y: 347,
                    src: "6.png",
                    type: hmUI.system_status.DISTURB,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 309,
                    y: 347,
                    src: "7.png",
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 308,
                    y: 66,
                    src: "8.png",
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 68,
                    y: 162,
                    type: hmUI.data_type.CAL,
                    font_array: ["9.png", "10.png", "11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: 2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: "19.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 45,
                    y: 160,
                    w: 90,
                    h: 25,
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 69,
                    y: 227,
                    type: hmUI.data_type.STEP,
                    font_array: ["9.png", "10.png", "11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: 2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: "20.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 45,
                    y: 226,
                    w: 100,
                    h: 25,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 69,
                    y: 197,
                    type: hmUI.data_type.DISTANCE,
                    font_array: ["9.png", "10.png", "11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: 2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: "22.png",
                    invalid_image: "21.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 45,
                    y: 195,
                    w: 100,
                    h: 25,
                    type: hmUI.data_type.DISTANCE,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 53,
                    y: 262,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: ["9.png", "10.png", "11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: 2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "25.png",
                    unit_tc: "25.png",
                    unit_en: "25.png",
                    negative_image: "24.png",
                    invalid_image: "23.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 45,
                    y: 260,
                    w: 80,
                    h: 25,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 241,
                    hour_startY: 209,
                    hour_array: ["26.png", "27.png", "28.png", "29.png", "30.png", "31.png", "32.png", "33.png", "34.png", "35.png"],
                    hour_space: 2,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 296,
                    minute_startY: 209,
                    minute_array: ["26.png", "27.png", "28.png", "29.png", "30.png", "31.png", "32.png", "33.png", "34.png", "35.png"],
                    minute_space: 4,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 129,
                    y: 266,
                    image_array: ["36.png", "37.png", "38.png", "39.png", "40.png", "41.png"],
                    image_length: 6,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 173,
                    y: 304,
                    type: hmUI.data_type.HEART,
                    font_array: ["9.png", "10.png", "11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: 2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: "42.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 129,
                    y: 276,
                    w: 130,
                    h: 55,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 308,
                    y: 66,
                    w: 28,
                    h: 28,
                    type: hmUI.data_type.ALARM_CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 129,
                    y: 334,
                    image_array: ["43.png", "44.png", "45.png", "46.png", "47.png", "48.png"],
                    image_length: 6,
                    type: hmUI.data_type.PAI_WEEKLY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 173,
                    y: 341,
                    type: hmUI.data_type.PAI_WEEKLY,
                    font_array: ["9.png", "10.png", "11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: 2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: "49.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 135,
                    y: 334,
                    w: 120,
                    h: 65,
                    type: hmUI.data_type.PAI_WEEKLY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 173,
                    y: 133,
                    type: hmUI.data_type.BATTERY,
                    font_array: ["9.png", "10.png", "11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: 2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: "50.png",
                    center_x: 195,
                    center_y: 120,
                    x: 19,
                    y: 42,
                    type: hmUI.data_type.BATTERY,
                    start_angle: -180,
                    end_angle: 120,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 267,
                    month_startY: 259,
                    month_sc_array: ["9.png", "10.png", "11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png"],
                    month_tc_array: ["9.png", "10.png", "11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png"],
                    month_en_array: ["9.png", "10.png", "11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png"],
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 2,
                    month_is_character: !1,
                    day_startX: 308,
                    day_startY: 259,
                    day_sc_array: ["9.png", "10.png", "11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png"],
                    day_tc_array: ["9.png", "10.png", "11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png"],
                    day_en_array: ["9.png", "10.png", "11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png"],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 2,
                    day_is_character: !1,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 275,
                    y: 165,
                    week_en: ["51.png", "52.png", "53.png", "54.png", "55.png", "56.png", "57.png"],
                    week_tc: ["58.png", "59.png", "60.png", "61.png", "62.png", "63.png", "64.png"],
                    week_sc: ["65.png", "66.png", "67.png", "68.png", "69.png", "70.png", "71.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 195,
                    hour_centerY: 225,
                    hour_posX: 25,
                    hour_posY: 110,
                    hour_path: "72.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 195,
                    minute_centerY: 225,
                    minute_posX: 24,
                    minute_posY: 156,
                    minute_path: "73.png",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 195,
                    second_centerY: 225,
                    second_posX: 16,
                    second_posY: 174,
                    second_path: "75.png",
                    second_cover_path: "74.png",
                    second_cover_x: 186,
                    second_cover_y: 216,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 195,
                    hour_centerY: 225,
                    hour_posX: 14,
                    hour_posY: 103,
                    hour_path: "76.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 195,
                    minute_centerY: 225,
                    minute_posX: 15,
                    minute_posY: 153,
                    minute_path: "78.png",
                    minute_cover_path: "77.png",
                    minute_cover_x: 185,
                    minute_cover_y: 215,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                })
            },
            onInit() {
                p.log("index page.js on init invoke")
            },
            build() {
                this.init_view(), p.log("index page.js on ready invoke")
            },
            onDestory() {
                p.log("index page.js on destory invoke")
            }
        })
    })()
} catch (e) {
    console.log(e)
}