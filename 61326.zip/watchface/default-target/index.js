try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_5086219a33c64eafa992237452c8b3a5 = '';
        let normal$_$text_51d8c16fd4dc4bf2928fe9b03398caa2 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_f0d284da930047d6b8afa6f073b3135c = '';
        let normal$_$text_7e80e096fcc7468ab415b48dd858004d = '';
        let batterySensor = '';
        let timeSensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 17,
                    y: 22,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 156,
                    hour_startY: 132,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 156,
                    minute_startY: 192,
                    minute_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 67,
                    am_y: 237,
                    am_en_path: '23.png',
                    pm_x: 67,
                    pm_y: 237,
                    pm_en_path: '24.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 66,
                    y: 41,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 300,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '35.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 65,
                    y: 30,
                    type: hmUI.data_type.STEP_TARGET,
                    font_array: [
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: -208,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                normal$_$text_5086219a33c64eafa992237452c8b3a5 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 35,
                    y: 32,
                    w: 17,
                    h: 17,
                    text: '[BATT_PER]',
                    color: '0xFF16b7ba',
                    text_size: 15,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_51d8c16fd4dc4bf2928fe9b03398caa2 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 186,
                    y: 287,
                    w: 96,
                    h: 17,
                    text: '[DAY_Z]         [YEAR]',
                    color: '0xFFff4c4c',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_f0d284da930047d6b8afa6f073b3135c = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 215,
                    y: 287,
                    w: 17,
                    h: 17,
                    text: '[MON_Z]',
                    color: '0xFFe1d83c',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 204,
                    y: 89,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '56.png',
                    padding: false,
                    isCharacter: false
                });
                normal$_$text_7e80e096fcc7468ab415b48dd858004d = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 258,
                    y: 96,
                    w: 28,
                    h: 16,
                    text: 'BPM',
                    color: '0xFFc92637',
                    text_size: 14,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_5086219a33c64eafa992237452c8b3a5.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }` });
                }), timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_51d8c16fd4dc4bf2928fe9b03398caa2.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }         ${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_51d8c16fd4dc4bf2928fe9b03398caa2.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }         ${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_51d8c16fd4dc4bf2928fe9b03398caa2.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }         ${ timeSensor.year }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_f0d284da930047d6b8afa6f073b3135c.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_f0d284da930047d6b8afa6f073b3135c.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_f0d284da930047d6b8afa6f073b3135c.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_5086219a33c64eafa992237452c8b3a5.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_51d8c16fd4dc4bf2928fe9b03398caa2.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }         ${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_51d8c16fd4dc4bf2928fe9b03398caa2.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }         ${ timeSensor.year }` });
                            },
                            () => {
                                normal$_$text_51d8c16fd4dc4bf2928fe9b03398caa2.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }         ${ timeSensor.year }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_f0d284da930047d6b8afa6f073b3135c.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_f0d284da930047d6b8afa6f073b3135c.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_f0d284da930047d6b8afa6f073b3135c.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_7e80e096fcc7468ab415b48dd858004d.setProperty(hmUI.prop.MORE, { text: `BPM` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}