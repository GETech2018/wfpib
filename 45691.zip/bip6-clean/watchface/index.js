import { createWidget, widget, prop, align, show_level } from '@zos/ui'
import { px } from '@zos/utils'
import { Time } from '@zos/sensor'

// Design-Raster 390 x 450, Ziffern in Originalgröße (195 x 225), Hintergrund immer schwarz.
//
// Normal-Modus:  Stunden h0-h9 (Gold, gefüllt) oben, Minuten m0-m9 (Silber, gefüllt) unten,
//                Datum: Wochentag w1-w7 (w1 = Montag) + Tag d0-d9 links unten in der Stundenreihe.
// AOD (Bildschirm aus): Stunden a0-a9 (Gold-Umriss), Minuten b0-b9 (Weiß-Umriss), kein Datum.
//
// AOD-Umrisse: Die Linien sind 3 px breit und sitzen am Bildrand. Damit zwischen benachbarten
// Ziffern keine doppelten Linien entstehen, überlappen sich die Ziffern um genau diese 3 px
// (Abstand -3 bzw. Minutenreihe bei y = 222 + Rand). Gesamtfläche: 387 x 447 px, mittig (Rand 1 px).
//
// Die Uhrzeit wird per IMG_TIME vom System gezeichnet (läuft auch im AOD ohne JavaScript).
// Nur das Datum wird per JS aktualisiert; es erscheint ausschließlich im Normal-Modus.
const BG = 0x000000
const DIGIT_W = 195
const DIGIT_H = 225

const WEEKDAY_X = 4
const DAY_X1 = 120
const DAY_X2 = 156
const DATE_Y = 180

const AOD_LINE = 3
const AOD_OFFSET = 1

// "ONAL_AOD" ist tatsächlich so geschrieben (Tippfehler in der Zepp-API)
const NORMAL = show_level.ONLY_NORMAL
const AOD = show_level.ONAL_AOD

const src = (name) => 'digits/' + name + '.png'
const digitArray = (prefix) => Array.from({ length: 10 }, (_, i) => src(prefix + i))
// JS: 0 = Sonntag ... 6 = Samstag  ->  w1 = Mo ... w7 = So
const weekdayIndex = (jsDay) => (jsDay === 0 ? 7 : jsDay)

WatchFace({
  onInit() {
    this.time = new Time()
    this.ui = {}
  },

  build() {
    // Schwarzer Hintergrund in beiden Modi
    createWidget(widget.FILL_RECT, {
      x: 0, y: 0, w: px(390), h: px(450), color: BG,
      show_level: NORMAL | AOD,
    })

    // --- Normal-Modus: gefüllte Ziffern ---
    this.timeWidget('h', 'm', NORMAL, { x: 0, y: 0, space: 0, rowH: DIGIT_H })

    // Datum liegt über den Stunden-Ziffern (wird danach erzeugt = liegt oben)
    this.ui.wd = this.img(WEEKDAY_X, DATE_Y, 'w1', NORMAL)
    this.ui.d1 = this.img(DAY_X1, DATE_Y, 'd0', NORMAL)
    this.ui.d2 = this.img(DAY_X2, DATE_Y, 'd0', NORMAL)

    // --- AOD: Umriss-Ziffern, kein Datum ---
    this.timeWidget('a', 'b', AOD, {
      x: AOD_OFFSET,
      y: AOD_OFFSET,
      space: -AOD_LINE,
      rowH: DIGIT_H - AOD_LINE,
    })

    this.onMinute = () => this.updateDate()
    this.time.onPerMinute(this.onMinute)

    createWidget(widget.WIDGET_DELEGATE, {
      resume_call: () => this.updateDate(),
      pause_call: () => {},
    })

    this.updateDate()
  },

  // Stunden oben, Minuten unten; je zwei Ziffern nebeneinander.
  // space < 0 lässt die Ziffern überlappen (von Zepp unterstützt).
  timeWidget(hourPrefix, minutePrefix, level, o) {
    createWidget(widget.IMG_TIME, {
      hour_zero: 1,
      hour_startX: px(o.x),
      hour_startY: px(o.y),
      hour_array: digitArray(hourPrefix),
      hour_space: o.space,
      hour_align: align.LEFT,
      minute_zero: 1,
      minute_startX: px(o.x),
      minute_startY: px(o.y + o.rowH),
      minute_array: digitArray(minutePrefix),
      minute_space: o.space,
      minute_align: align.LEFT,
      show_level: level,
    })
  },

  img(x, y, name, level) {
    return createWidget(widget.IMG, { x: px(x), y: px(y), src: src(name), show_level: level })
  },

  updateDate() {
    const d = new Date()
    const day = d.getDate()
    this.ui.wd.setProperty(prop.SRC, src('w' + weekdayIndex(d.getDay())))
    this.ui.d1.setProperty(prop.SRC, src('d' + Math.floor(day / 10)))
    this.ui.d2.setProperty(prop.SRC, src('d' + (day % 10)))
  },

  onDestroy() {
    this.time.offPerMinute(this.onMinute)
  },
})
