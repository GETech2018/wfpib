﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let idle_background_bg_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_end.js');
            // start user_script_end.js

// ===== Binary Dot Watch Face (HH MM SS • AUTO 12/24H) =====

const SCREEN_W = 390
const SCREEN_H = 450

const timeSensor = hmSensor.createSensor(hmSensor.id.TIME)

// ===== BIT (4 จุดต่อหลัก) =====
const BITS = [8, 4, 2, 1]

// ===== เก็บ 6 คอลัมน์ =====
const COLS = []

// ===== Layout =====
const START_X = 72
const START_Y = 120

const COL_GAP = 40
const BLOCK_GAP = 70
const ROW_GAP = 36

/*
// ===== LABEL =====
hmUI.createWidget(hmUI.widget.TEXT, {
  x: 40, y: 70, w: 80, h: 40,
  text: "H", color: 0xffffff, text_size: 28, align_h: hmUI.align.CENTER
})
hmUI.createWidget(hmUI.widget.TEXT, {
  x: 160, y: 70, w: 80, h: 40,
  text: "M", color: 0xffffff, text_size: 28, align_h: hmUI.align.CENTER
})
hmUI.createWidget(hmUI.widget.TEXT, {
  x: 280, y: 70, w: 80, h: 40,
  text: "S", color: 0xffffff, text_size: 28, align_h: hmUI.align.CENTER
})
*/

// ===== AM / PM =====
const ampmText = hmUI.createWidget(hmUI.widget.TEXT, {
  x: 21,
  y: 69,
  w: 80,
  h: 40,
  text: "",
  color: 0xff4444,
  text_size: 22,
  align_h: hmUI.align.CENTER
})

// ===== CREATE COLUMN =====
function createColumn(x) {
  let arr = []

  for (let i = 0; i < 4; i++) {
    arr.push(
      hmUI.createWidget(hmUI.widget.IMG, {
        x: x,
        y: START_Y + i * ROW_GAP,
        src: "bit_off.png"
      })
    )
  }

  return arr
}

// ===== CREATE 6 COLUMNS =====
let x = START_X

for (let i = 0; i < 6; i++) {
  COLS.push(createColumn(x))

  if (i === 1 || i === 3) {
    x += BLOCK_GAP
  } else {
    x += COL_GAP
  }
}

// ===== UPDATE COLUMN =====
function updateColumn(value, col) {
  BITS.forEach((bit, i) => {
    col[i].setProperty(
      hmUI.prop.SRC,
      (value & bit) ? "bit_on.png" : "bit_off.png"
    )
  })
}

// ===== UPDATE ALL =====
function updateAll() {
  let h = timeSensor.hour
  let m = timeSensor.minute
  let s = timeSensor.second

  // ===== AUTO DETECT 12H / 24H =====
  let is12H = false
  if (hmSetting.getTimeFormat) {
    is12H = hmSetting.getTimeFormat() === 0
  }

  // ===== แปลงถ้าเป็น 12H =====
  if (is12H) {
    let isPM = h >= 12
    h = h % 12
    if (h === 0) h = 12

    ampmText.setProperty(hmUI.prop.TEXT, isPM ? "PM" : "AM")
  } else {
    // 24H → ไม่ต้องโชว์ AM/PM
    ampmText.setProperty(hmUI.prop.TEXT, "24H")
  }

  // ===== แยกหลัก =====
  let h1 = Math.floor(h / 10)
  let h2 = h % 10

  let m1 = Math.floor(m / 10)
  let m2 = m % 10

  let s1 = Math.floor(s / 10)
  let s2 = s % 10

  updateColumn(h1, COLS[0])
  updateColumn(h2, COLS[1])

  updateColumn(m1, COLS[2])
  updateColumn(m2, COLS[3])

  updateColumn(s1, COLS[4])
  updateColumn(s2, COLS[5])
}

// ===== RUN =====
updateAll()

// ===== TIMER (เสถียรสุดสำหรับ ZeppPlayer) =====
let timerId = timer.createTimer(0, 1000, function () {
  updateAll()
})
            // end user_script_end.js


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}