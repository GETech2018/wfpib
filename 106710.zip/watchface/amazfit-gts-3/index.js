try {
    (() => {
        var n = __$$hmAppManager$$__.currentApp;
        const g = n.current,
            {
                px: e
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(n, g)), n.app.__globals__),
            p = Logger.getLogger("watchface6");
        // const img_arr = []
        let stepSensor;
        let unit;
        let num;
        // for (let i = 0; i < 165; i++) {
        //     img_arr.push('first_anim_jsmlf_' + i + '.png')
        // }
        g.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                stepSensor = hmSensor.createSensor(hmSensor.id.STEP)
                let jstime = hmSensor.createSensor(hmSensor.id.TIME);

                unit = stepSensor.target / 10
                num = Math.floor(stepSensor.current / unit)
                let size = num >= 10 ? 165 : 16 * num

                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: "4.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                let anim = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: "",
                    anim_prefix: "first_anim_jsmlf",
                    anim_ext: "png",
                    anim_fps: 30,
                    anim_size: size,
                    repeat_count: 1,
                    anim_repeat: !1,
                    // display_on_restart: !0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 61,
                    hour_startY: 176,
                    hour_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 209,
                    minute_startY: 176,
                    minute_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 131,
                    am_y: 144,
                    am_sc_path: "15.png",
                    am_en_path: "16.png",
                    pm_x: 131,
                    pm_y: 144,
                    pm_sc_path: "17.png",
                    pm_en_path: "18.png",
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 203,
                    y: 144,
                    week_en: ["19.png", "20.png", "21.png", "22.png", "23.png", "24.png", "25.png"],
                    week_tc: ["26.png", "27.png", "28.png", "29.png", "30.png", "31.png", "32.png"],
                    week_sc: ["33.png", "34.png", "35.png", "36.png", "37.png", "38.png", "39.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 179,
                    y: 282,
                    type: hmUI.data_type.BATTERY,
                    font_array: ["40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "50.png",
                    unit_tc: "50.png",
                    unit_en: "50.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 168,
                    y: 393,
                    type: hmUI.data_type.STEP,
                    font_array: ["40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: !1,
                    isCharacter: !1
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 130,
                    y: 390,
                    w: 135,
                    h: 34,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: "81.png",
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 61,
                    hour_startY: 176,
                    hour_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 207,
                    minute_startY: 176,
                    minute_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                })
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: (function () {
                        unit = stepSensor.target / 10
                        num = Math.floor(stepSensor.current / unit)
                        let size = 1
                        if (num > 0) {
                            size = num >= 10 ? 165 : 16 * num
                        }
                        // let size = num >= 10 ? 165 : 16 * num
                        anim.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP)
                        anim.setProperty(hmUI.prop.MORE, {
                            x: 0,
                            y: 0,
                            anim_path: "",
                            anim_prefix: "first_anim_jsmlf",
                            anim_ext: "png",
                            anim_fps: 30,
                            anim_size: size,
                            repeat_count: 1,
                            anim_repeat: !1,
                            // display_on_restart: !0,
                            anim_status: hmUI.anim_status.START,
                            show_level: hmUI.show_level.ONLY_NORMAL
                        })
                    }),
                    pause_call: (function () {
                        console.log('ui pause');
                    }),
                });

                stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    unit = stepSensor.target / 10
                    num = Math.floor(stepSensor.current / unit)
                });
                jstime.addEventListener(jstime.event.DAYCHANGE, function () {
                    unit = stepSensor.target / 10
                    num = Math.floor(stepSensor.current / unit)
                    let size = 1
                    if (num > 0) {
                        size = num >= 10 ? 165 : 16 * num
                    }
                    anim.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP)
                    anim.setProperty(hmUI.prop.MORE, {
                        x: 0,
                        y: 0,
                        anim_path: "",
                        anim_prefix: "first_anim_jsmlf",
                        anim_ext: "png",
                        anim_fps: 30,
                        anim_size: size,
                        repeat_count: 1,
                        anim_repeat: !1,
                        // display_on_restart: !0,
                        anim_status: hmUI.anim_status.START,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    })
                    // let size = num >= 10 ? 165 : 16 * num
                    // anim.setProperty(hmUI.prop.VISIBLE,false)
                    // anim.setProperty(hmUI.prop.VISIBLE,true)
                    // anim.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP)
                    // anim.setProperty(hmUI.prop.MORE, {
                    //     x: 0,
                    //     y: 0,
                    //     anim_path: "",
                    //     anim_prefix: "first_anim_jsmlf",
                    //     anim_ext: "png",
                    //     anim_fps: 30,
                    //     anim_size: 1,
                    //     repeat_count: 1,
                    //     anim_repeat: !1,
                    //     // display_on_restart: !0,
                    //     anim_status: hmUI.anim_status.START,
                    //     show_level: hmUI.show_level.ONLY_NORMAL
                    // })
                });
            },
            onInit() {
                p.log("index page.js on init invoke")
            },
            build() {
                this.init_view(), p.log("index page.js on ready invoke")
            },
            onDestory() {
                p.log("index page.js on destory invoke")
            }
        })
    })()
} catch (n) {
    console.log(n)
}