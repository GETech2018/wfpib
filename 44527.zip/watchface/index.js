﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_bio_charge_circle_scale = ''
        let normal_battery_circle_scale = ''
        let normal_battery_current_text_font = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_font = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_font = ''
        let normal_time_second_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_day_month_font = ''
        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_date_img_date_week_img = ''
        let idle_time_second_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SFCompactRounded-Medium-MOD.ttf; FontSize: 26
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 334,
              h: 37,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SFCompactRounded-Medium-MOD.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SFCompactRounded-Medium-MOD.ttf; FontSize: 20
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 254,
              h: 28,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SFCompactRounded-Medium-MOD.ttf',
              color: 0xFFFF0000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 76,
              center_y: 81,
              start_angle: -98,
              end_angle: 98,
              radius: 20,
              line_width: 10,
              corner_flag: 3,
              type: hmUI.data_type.BIO_CHARGE,
              color: 0xFF0080FF,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 315,
              // center_y: 362,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 35,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 315,
              center_y: 362,
              start_angle: 0,
              end_angle: 360,
              radius: 30,
              line_width: 10,
              corner_flag: 3,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 292,
              y: 345,
              w: 47,
              h: 30,
              text_size: 18,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 76,
              // center_y: 79,
              // start_angle: -98,
              // end_angle: 98,
              // radius: 45,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 76,
              center_y: 79,
              start_angle: -98,
              end_angle: 98,
              radius: 40,
              line_width: 10,
              corner_flag: 3,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 40,
              y: 373,
              w: 150,
              h: 30,
              text_size: 26,
              char_space: 0,
              font: 'fonts/SFCompactRounded-Medium-MOD.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 76,
              // center_y: 80,
              // start_angle: -98,
              // end_angle: 98,
              // radius: 35,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFFFF8000,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 76,
              center_y: 80,
              start_angle: -98,
              end_angle: 98,
              radius: 30,
              line_width: 10,
              corner_flag: 3,
              color: 0xFFFF8000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 40,
              y: 313,
              w: 150,
              h: 30,
              text_size: 26,
              char_space: 0,
              font: 'fonts/SFCompactRounded-Medium-MOD.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 0,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 295,
              y: 59,
              w: 64,
              h: 39,
              text_size: 26,
              char_space: 0,
              font: 'fonts/SFCompactRounded-Medium-MOD.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 40,
              y: 353,
              w: 88,
              h: 26,
              text_size: 20,
              char_space: 0,
              font: 'fonts/SFCompactRounded-Medium-MOD.ttf',
              color: 0xFFFF0000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: 'Steps',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 40,
              y: 293,
              w: 88,
              h: 26,
              text_size: 20,
              char_space: 0,
              font: 'fonts/SFCompactRounded-Medium-MOD.ttf',
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: 'Calories',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
let clockDigitHrHigh = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'pth_0.png',
    x: 32,
    y: 133,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockDigitHrLow = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'pth_0.png',
    x: 126,
    y: 68,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockDigitMinHigh = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'ijo_0.png',
    x: 120,
    y: 223,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockDigitMinLow = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'ijo_0.png',
    x: 220,
    y: 154,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockDigitHrHighAOD_S1 = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'AOD_0.png',
    x: 32,
    y: 133,
    show_level: hmUI.show_level.ONLY_AOD,
});

let clockDigitHrLowAOD_S1 = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'AOD_0.png',
    x: 126,
    y: 68,
    show_level: hmUI.show_level.ONLY_AOD,
});

let clockDigitMinHighAOD_S1 = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'AOD_0.png',
    x: 120,
    y: 223,
    show_level: hmUI.show_level.ONLY_AOD,
});

let clockDigitMinLowAOD_S1 = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'AOD_0.png',
    x: 220,
    y: 154,
    show_level: hmUI.show_level.ONLY_AOD,
});


//set visibility for digits
clockDigitHrHighAOD_S1.setProperty(hmUI.prop.VISIBLE, hmFS.SysProGetBool('styleOneVisible') ?? true);
clockDigitHrLowAOD_S1.setProperty(hmUI.prop.VISIBLE, hmFS.SysProGetBool('styleOneVisible') ?? true);
clockDigitMinHighAOD_S1.setProperty(hmUI.prop.VISIBLE, hmFS.SysProGetBool('styleOneVisible') ?? true);
clockDigitMinLowAOD_S1.setProperty(hmUI.prop.VISIBLE, hmFS.SysProGetBool('styleOneVisible') ?? true);

function updateMins(){
    let currHourFormat = hmSetting.getTimeFormat(); // 0 = 12h, 1 = 24h
    let clockHr = timeSensor.hour;
    let clockMin = timeSensor.minute;

    //convert clock depending on format
    if (currHourFormat == 0){
        if (clockHr == 0){
            clockHr = 12;
        }else if (clockHr > 12){
            clockHr -= 12;
        }
    }

    //add zeros if its less than 10
    let clockHrTXT = clockHr.toString().padStart(2, "0");
    let clockMinsTXT = clockMin.toString().padStart(2, "0");

    //set digits (normal and aod)
    //normal
    let clockHrHigh_SRC = "pth_" + clockHrTXT[0] + ".png";
    let clockHrLow_SRC = "pth_" + clockHrTXT[1] + ".png";
    let clockMinsHigh_SRC = "ijo_" + clockMinsTXT[0] + ".png";
    let clockMinsLow_SRC = "ijo_" + clockMinsTXT[1] + ".png";
    //aod
    //style1
    let clockAODHrHigh_S1_SRC = "AOD_" + clockHrTXT[0] + ".png";
    let clockAODHrLow_S1_SRC = "AOD_" + clockHrTXT[1] + ".png";
    let clockAODMinsHigh_S1_SRC = "AOD_" + clockMinsTXT[0] + ".png";
    let clockAODMinsLow_S1_SRC = "AOD_" + clockMinsTXT[1] + ".png";

    //update digits (normal and aod)
    //normal
    clockDigitHrHigh.setProperty(hmUI.prop.MORE, {
        src: clockHrHigh_SRC
    });
    clockDigitHrLow.setProperty(hmUI.prop.MORE, {
        src: clockHrLow_SRC
    });
    clockDigitMinHigh.setProperty(hmUI.prop.MORE, {
        src: clockMinsHigh_SRC
    });
    clockDigitMinLow.setProperty(hmUI.prop.MORE, {
       src: clockMinsLow_SRC
    });
    //aod
    //style1
    clockDigitHrHighAOD_S1.setProperty(hmUI.prop.SRC, clockAODHrHigh_S1_SRC);
    clockDigitHrLowAOD_S1.setProperty(hmUI.prop.SRC, clockAODHrLow_S1_SRC);
    clockDigitMinHighAOD_S1.setProperty(hmUI.prop.SRC, clockAODMinsHigh_S1_SRC);
    clockDigitMinLowAOD_S1.setProperty(hmUI.prop.SRC, clockAODMinsLow_S1_SRC);
}
updateMins();
            // end user_script.js

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 170,
              y: 133,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 0,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              updateMins();
			  console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '/' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '/' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

              console.log('second font');
                let idle_secondStr = second.toString();
                idle_time_second_text_font.setProperty(hmUI.prop.TEXT, idle_secondStr );
            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 315,
                      center_y: 362,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 30,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 76,
                      center_y: 79,
                      start_angle: -98,
                      end_angle: 98,
                      radius: 40,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 76,
                      center_y: 80,
                      start_angle: -98,
                      end_angle: 98,
                      radius: 30,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFFFF8000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}