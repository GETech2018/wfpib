﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_year = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_second_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 320,
              h: 380,
              src: 'watch_dial.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 60,
              font_array: ["TEMP_num_0.png","TEMP_num_1.png","TEMP_num_2.png","TEMP_num_3.png","TEMP_num_4.png","TEMP_num_5.png","TEMP_num_6.png","TEMP_num_7.png","TEMP_num_8.png","TEMP_num_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'TEMP_num_colon.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 49,
              font_array: ["BATT_num_0.png","BATT_num_1.png","BATT_num_2.png","BATT_num_3.png","BATT_num_4.png","BATT_num_5.png","BATT_num_6.png","BATT_num_7.png","BATT_num_8.png","BATT_num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 169,
              y: 41,
              src: 'BATT_percent.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 58,
              month_startY: 169,
              month_sc_array: ["MESE_01.png","MESE_02.png","MESE_03.png","MESE_04.png","MESE_05.png","MESE_06.png","MESE_07.png","MESE_08.png","MESE_09.png","MESE_10.png","MESE_11.png","MESE_12.png"],
              month_tc_array: ["MESE_01.png","MESE_02.png","MESE_03.png","MESE_04.png","MESE_05.png","MESE_06.png","MESE_07.png","MESE_08.png","MESE_09.png","MESE_10.png","MESE_11.png","MESE_12.png"],
              month_en_array: ["MESE_01.png","MESE_02.png","MESE_03.png","MESE_04.png","MESE_05.png","MESE_06.png","MESE_07.png","MESE_08.png","MESE_09.png","MESE_10.png","MESE_11.png","MESE_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 130,
              day_startY: 166,
              day_sc_array: ["DAY_num_0.png","DAY_num_1.png","DAY_num_2.png","DAY_num_3.png","DAY_num_4.png","DAY_num_5.png","DAY_num_6.png","DAY_num_7.png","DAY_num_8.png","DAY_num_9.png"],
              day_tc_array: ["DAY_num_0.png","DAY_num_1.png","DAY_num_2.png","DAY_num_3.png","DAY_num_4.png","DAY_num_5.png","DAY_num_6.png","DAY_num_7.png","DAY_num_8.png","DAY_num_9.png"],
              day_en_array: ["DAY_num_0.png","DAY_num_1.png","DAY_num_2.png","DAY_num_3.png","DAY_num_4.png","DAY_num_5.png","DAY_num_6.png","DAY_num_7.png","DAY_num_8.png","DAY_num_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 189,
              year_startY: 169,
              year_sc_array: ["ANNO_num_0.png","ANNO_num_1.png","ANNO_num_2.png","ANNO_num_3.png","ANNO_num_4.png","ANNO_num_5.png","ANNO_num_6.png","ANNO_num_7.png","ANNO_num_8.png","ANNO_num_9.png"],
              year_tc_array: ["ANNO_num_0.png","ANNO_num_1.png","ANNO_num_2.png","ANNO_num_3.png","ANNO_num_4.png","ANNO_num_5.png","ANNO_num_6.png","ANNO_num_7.png","ANNO_num_8.png","ANNO_num_9.png"],
              year_en_array: ["ANNO_num_0.png","ANNO_num_1.png","ANNO_num_2.png","ANNO_num_3.png","ANNO_num_4.png","ANNO_num_5.png","ANNO_num_6.png","ANNO_num_7.png","ANNO_num_8.png","ANNO_num_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 70,
              hour_startY: 263,
              hour_array: ["HOUR_num_0.png","HOUR_num_1.png","HOUR_num_2.png","HOUR_num_3.png","HOUR_num_4.png","HOUR_num_5.png","HOUR_num_6.png","HOUR_num_7.png","HOUR_num_8.png","HOUR_num_9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 151,
              minute_startY: 262,
              minute_array: ["MIN_num_0.png","MIN_num_1.png","MIN_num_2.png","MIN_num_3.png","MIN_num_4.png","MIN_num_5.png","MIN_num_6.png","MIN_num_7.png","MIN_num_8.png","MIN_num_9.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 228,
              second_startY: 264,
              second_array: ["SEC_num_0.png","SEC_num_1.png","SEC_num_2.png","SEC_num_3.png","SEC_num_4.png","SEC_num_5.png","SEC_num_6.png","SEC_num_7.png","SEC_num_8.png","SEC_num_9.png"],
              second_zero: 1,
              second_space: -4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 132,
              y: 260,
              src: 'HOUR_num_colon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 211,
              y: 260,
              src: 'SEC_num_colon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}