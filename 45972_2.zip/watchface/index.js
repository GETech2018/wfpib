try{(()=>{var __$$app$$__=__$$hmAppManager$$__.currentApp;var __$$module$$__=__$$app$$__.current;var e=new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__,__$$module$$__),"clasico");"use strict";
__$$module$$__.module=DeviceRuntimeCore.WatchFace({
init_view(){
const N=hmUI.show_level.ONLY_NORMAL, AOD=hmUI.show_level.ONLY_AOD, DT=hmUI.data_type, L=hmUI.align.LEFT, CH=hmUI.align.CENTER_H;
const safe=(f)=>{try{f()}catch(err){console.log(err)}};
const img=(x,y,w,h,src,lv)=>safe(()=>hmUI.createWidget(hmUI.widget.IMG,{x:x,y:y,w:w,h:h,src:src,show_level:lv||N}));
img(0,0,390,450,"0001.png");
safe(()=>hmUI.createWidget(hmUI.widget.IMG_LEVEL,{x:153,y:280,image_array:["0037.png", "0038.png", "0039.png", "0040.png", "0041.png", "0042.png", "0043.png", "0044.png", "0045.png", "0046.png", "0047.png", "0048.png", "0049.png", "0050.png", "0051.png", "0052.png", "0053.png", "0054.png", "0055.png", "0056.png", "0057.png"],image_length:21,type:DT.BATTERY,show_level:N}));
safe(()=>hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:167,y:311,w:56,h:22,font_array:["0026.png", "0027.png", "0028.png", "0029.png", "0030.png", "0031.png", "0032.png", "0033.png", "0034.png", "0035.png"],h_space:0,align_h:CH,type:DT.BATTERY,unit_sc:"0036.png",unit_tc:"0036.png",unit_en:"0036.png",show_level:N}));
safe(()=>hmUI.createWidget(hmUI.widget.IMG_WEEK,{x:266,y:212,week_en:["0009.png", "0010.png", "0011.png", "0012.png", "0013.png", "0014.png", "0015.png"],week_tc:["0009.png", "0010.png", "0011.png", "0012.png", "0013.png", "0014.png", "0015.png"],week_sc:["0009.png", "0010.png", "0011.png", "0012.png", "0013.png", "0014.png", "0015.png"],show_level:N}));
safe(()=>hmUI.createWidget(hmUI.widget.IMG_DATE,{day_startX:306,day_startY:212,day_sc_array:["0016.png", "0017.png", "0018.png", "0019.png", "0020.png", "0021.png", "0022.png", "0023.png", "0024.png", "0025.png"],day_tc_array:["0016.png", "0017.png", "0018.png", "0019.png", "0020.png", "0021.png", "0022.png", "0023.png", "0024.png", "0025.png"],day_en_array:["0016.png", "0017.png", "0018.png", "0019.png", "0020.png", "0021.png", "0022.png", "0023.png", "0024.png", "0025.png"],day_zero:0,day_space:0,day_align:L,show_level:N}));
safe(()=>hmUI.createWidget(hmUI.widget.TIME_POINTER,{
 hour_centerX:195,hour_centerY:225,hour_posX:14,hour_posY:112,hour_path:"0004.png",
 minute_centerX:195,minute_centerY:225,minute_posX:14,minute_posY:164,minute_path:"0003.png",
 second_centerX:195,second_centerY:225,second_posX:8,second_posY:179,second_path:"0005.png",show_level:N}));
img(184,214,22,22,"0008.png");
img(0,0,390,450,"0002.png",AOD);
safe(()=>hmUI.createWidget(hmUI.widget.TIME_POINTER,{
 hour_centerX:195,hour_centerY:225,hour_posX:14,hour_posY:112,hour_path:"0007.png",
 minute_centerX:195,minute_centerY:225,minute_posX:14,minute_posY:164,minute_path:"0006.png",show_level:AOD}));
},
onInit(){this.init_view()},onReady(){},onShow(){},onHide(){},onDestroy(){}
})})()}catch(e){console.log(e)}
