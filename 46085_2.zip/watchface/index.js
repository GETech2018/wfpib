// Aroelzm-WF01 — Amazfit Bip Max (432 x 514)
// Ditulis untuk API Zepp OS 1.0 (hmUI, hmSensor, hmSetting, hmFS)
try {
  ;(() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp
    const __$$module$$__ = __$$app$$__.current

    const NORMAL = hmUI.show_level.ONLY_NORMAL
    const AOD = hmUI.show_level.ONAL_AOD

    // urutan harus sama dengan THEMES di tools/gen.py
    const THEMES = [
      'lime', 'green', 'mint', 'sky', 'blue', 'violet',
      'magenta', 'pink', 'red', 'orange', 'yellow', 'white'
    ]
    const THEME_KEY = 'digital_card_theme'
    // warna untuk FILL_RECT; urutan sama dengan THEMES
    const THEME_COLORS = [
      0xc6f24e, 0x4be36b, 0x3fe8c0, 0x63c7ff, 0x6c8cff, 0xb49cff,
      0xe56bf5, 0xff72b6, 0xff5560, 0xff8a3d, 0xffd43b, 0xf4f5f0
    ]
    // AOD: warna tema diredupkan 85%
    const THEME_AOD_COLORS = [
      0xa8cd42, 0x3fc05a, 0x35c5a3, 0x54a9d8, 0x5b77d8, 0x9984d8,
      0xc25ad0, 0xd8609a, 0xd84851, 0xd87533, 0xd8b432, 0xcfd0cc
    ]
    // tata letak: dicerminkan pada garis tengah x = 216
    const CARD_MID = 314
    const BAR_X = 238
    const BAR_W = 152
    const STEP_FULL = 10000
    // kartu data: nama garis tepi dan posisinya
    const FRAMES = [
      ['card', 220, 70], ['card', 220, 182], ['card', 220, 294],
      ['stat', 24, 404], ['stat', 155, 404], ['stat', 286, 404]
    ]
    const SPO2_COLOR = 0x63c7ff
    // baterai layar aktif: r = merah (0-25), y = kuning (26-50), g = hijau (51-100); AOD: warna tema
    const BATTERY_COLORS = { r: 0xff4358, y: 0xffc700, g: 0x3ddc84 }

    // kode dari getLanguage(); bahasa lain memakai Inggris
    const LANGUAGES = {
      0: 'zh-cn', 1: 'zh-tw', 2: 'en', 3: 'es', 4: 'ru', 5: 'ko', 6: 'fr', 7: 'de',
      8: 'id', 9: 'pl', 10: 'it', 11: 'ja', 14: 'vi', 15: 'pt', 16: 'nl', 17: 'tr',
      18: 'uk', 20: 'pt', 31: 'ms'
    }
    // bahasa dengan urutan bulan lalu tanggal
    const MONTH_FIRST = ['zh-cn', 'zh-tw', 'ja', 'ko']

    function safe(read, fallback) {
      try {
        const value = read()
        return value === undefined || value === null ? fallback : value
      } catch (e) {
        return fallback
      }
    }

    // gambar yang isinya sama hanya disimpan sekali; tabel ini diisi oleh tools/pack.py
    const ALIAS = {"lang_en_aod_month_0.png":"lang_de_aod_month_0.png","lang_en_aod_month_1.png":"lang_de_aod_month_1.png","lang_en_aod_month_10.png":"lang_de_aod_month_10.png","lang_en_aod_month_3.png":"lang_de_aod_month_3.png","lang_en_aod_month_5.png":"lang_de_aod_month_5.png","lang_en_aod_month_6.png":"lang_de_aod_month_6.png","lang_en_aod_month_7.png":"lang_de_aod_month_7.png","lang_en_aod_month_8.png":"lang_de_aod_month_8.png","lang_en_aod_stress.png":"lang_de_aod_stress.png","lang_en_month_0.png":"lang_de_month_0.png","lang_en_month_1.png":"lang_de_month_1.png","lang_en_month_10.png":"lang_de_month_10.png","lang_en_month_3.png":"lang_de_month_3.png","lang_en_month_5.png":"lang_de_month_5.png","lang_en_month_6.png":"lang_de_month_6.png","lang_en_month_7.png":"lang_de_month_7.png","lang_en_month_8.png":"lang_de_month_8.png","lang_en_stress.png":"lang_de_stress.png","lang_es_aod_month_1.png":"lang_de_aod_month_1.png","lang_es_aod_month_10.png":"lang_de_aod_month_10.png","lang_es_aod_month_2.png":"lang_en_aod_month_2.png","lang_es_aod_month_4.png":"lang_en_aod_month_4.png","lang_es_aod_month_5.png":"lang_de_aod_month_5.png","lang_es_aod_month_6.png":"lang_de_aod_month_6.png","lang_es_aod_month_8.png":"lang_de_aod_month_8.png","lang_es_aod_month_9.png":"lang_en_aod_month_9.png","lang_es_aod_week_1.png":"lang_en_aod_month_2.png","lang_es_month_1.png":"lang_de_month_1.png","lang_es_month_10.png":"lang_de_month_10.png","lang_es_month_2.png":"lang_en_month_2.png","lang_es_month_4.png":"lang_en_month_4.png","lang_es_month_5.png":"lang_de_month_5.png","lang_es_month_6.png":"lang_de_month_6.png","lang_es_month_8.png":"lang_de_month_8.png","lang_es_month_9.png":"lang_en_month_9.png","lang_es_week_1.png":"lang_en_month_2.png","lang_fr_aod_cal.png":"lang_en_aod_cal.png","lang_fr_aod_dist.png":"lang_en_aod_dist.png","lang_fr_aod_month_10.png":"lang_de_aod_month_10.png","lang_fr_aod_month_4.png":"lang_de_aod_month_4.png","lang_fr_aod_month_9.png":"lang_en_aod_month_9.png","lang_fr_aod_stress.png":"lang_de_aod_stress.png","lang_fr_aod_week_0.png":"lang_es_aod_week_0.png","lang_fr_aod_week_1.png":"lang_en_aod_month_2.png","lang_fr_cal.png":"lang_en_cal.png","lang_fr_dist.png":"lang_en_dist.png","lang_fr_month_10.png":"lang_de_month_10.png","lang_fr_month_4.png":"lang_de_month_4.png","lang_fr_month_9.png":"lang_en_month_9.png","lang_fr_stress.png":"lang_de_stress.png","lang_fr_week_0.png":"lang_es_week_0.png","lang_fr_week_1.png":"lang_en_month_2.png","lang_id_aod_month_0.png":"lang_de_aod_month_0.png","lang_id_aod_month_1.png":"lang_de_aod_month_1.png","lang_id_aod_month_10.png":"lang_de_aod_month_10.png","lang_id_aod_month_2.png":"lang_en_aod_month_2.png","lang_id_aod_month_3.png":"lang_de_aod_month_3.png","lang_id_aod_month_5.png":"lang_de_aod_month_5.png","lang_id_aod_month_6.png":"lang_de_aod_month_6.png","lang_id_aod_month_8.png":"lang_de_aod_month_8.png","lang_id_aod_month_9.png":"lang_de_aod_month_9.png","lang_id_month_0.png":"lang_de_month_0.png","lang_id_month_1.png":"lang_de_month_1.png","lang_id_month_10.png":"lang_de_month_10.png","lang_id_month_2.png":"lang_en_month_2.png","lang_id_month_3.png":"lang_de_month_3.png","lang_id_month_5.png":"lang_de_month_5.png","lang_id_month_6.png":"lang_de_month_6.png","lang_id_month_8.png":"lang_de_month_8.png","lang_id_month_9.png":"lang_de_month_9.png","lang_it_aod_month_1.png":"lang_de_aod_month_1.png","lang_it_aod_month_10.png":"lang_de_aod_month_10.png","lang_it_aod_month_11.png":"lang_es_aod_month_11.png","lang_it_aod_month_2.png":"lang_en_aod_month_2.png","lang_it_aod_month_3.png":"lang_de_aod_month_3.png","lang_it_aod_month_7.png":"lang_es_aod_month_7.png","lang_it_aod_stress.png":"lang_de_aod_stress.png","lang_it_aod_week_0.png":"lang_es_aod_week_0.png","lang_it_aod_week_1.png":"lang_en_aod_month_2.png","lang_it_aod_week_2.png":"lang_fr_aod_week_2.png","lang_it_aod_week_4.png":"lang_fr_aod_week_4.png","lang_it_aod_week_5.png":"lang_id_aod_week_5.png","lang_it_aod_week_6.png":"lang_es_aod_week_6.png","lang_it_month_1.png":"lang_de_month_1.png","lang_it_month_10.png":"lang_de_month_10.png","lang_it_month_11.png":"lang_es_month_11.png","lang_it_month_2.png":"lang_en_month_2.png","lang_it_month_3.png":"lang_de_month_3.png","lang_it_month_7.png":"lang_es_month_7.png","lang_it_stress.png":"lang_de_stress.png","lang_it_week_0.png":"lang_es_week_0.png","lang_it_week_1.png":"lang_en_month_2.png","lang_it_week_2.png":"lang_fr_week_2.png","lang_it_week_4.png":"lang_fr_week_4.png","lang_it_week_5.png":"lang_id_week_5.png","lang_it_week_6.png":"lang_es_week_6.png","lang_ms_aod_cal.png":"lang_id_aod_cal.png","lang_ms_aod_dist.png":"lang_id_aod_dist.png","lang_ms_aod_month_0.png":"lang_de_aod_month_0.png","lang_ms_aod_month_1.png":"lang_de_aod_month_1.png","lang_ms_aod_month_10.png":"lang_de_aod_month_10.png","lang_ms_aod_month_3.png":"lang_de_aod_month_3.png","lang_ms_aod_month_4.png":"lang_id_aod_month_4.png","lang_ms_aod_month_5.png":"lang_de_aod_month_5.png","lang_ms_aod_month_6.png":"lang_de_aod_month_6.png","lang_ms_aod_month_8.png":"lang_de_aod_month_8.png","lang_ms_aod_month_9.png":"lang_de_aod_month_9.png","lang_ms_aod_steps.png":"lang_id_aod_steps.png","lang_ms_aod_stress.png":"lang_id_aod_stress.png","lang_ms_aod_week_1.png":"lang_id_aod_week_1.png","lang_ms_aod_week_2.png":"lang_id_aod_week_2.png","lang_ms_aod_week_4.png":"lang_id_aod_week_4.png","lang_ms_aod_week_5.png":"lang_id_aod_week_5.png","lang_ms_cal.png":"lang_id_cal.png","lang_ms_dist.png":"lang_id_dist.png","lang_ms_month_0.png":"lang_de_month_0.png","lang_ms_month_1.png":"lang_de_month_1.png","lang_ms_month_10.png":"lang_de_month_10.png","lang_ms_month_3.png":"lang_de_month_3.png","lang_ms_month_4.png":"lang_id_month_4.png","lang_ms_month_5.png":"lang_de_month_5.png","lang_ms_month_6.png":"lang_de_month_6.png","lang_ms_month_8.png":"lang_de_month_8.png","lang_ms_month_9.png":"lang_de_month_9.png","lang_ms_steps.png":"lang_id_steps.png","lang_ms_stress.png":"lang_id_stress.png","lang_ms_week_1.png":"lang_id_week_1.png","lang_ms_week_2.png":"lang_id_week_2.png","lang_ms_week_4.png":"lang_id_week_4.png","lang_ms_week_5.png":"lang_id_week_5.png","lang_nl_aod_month_0.png":"lang_de_aod_month_0.png","lang_nl_aod_month_1.png":"lang_de_aod_month_1.png","lang_nl_aod_month_10.png":"lang_de_aod_month_10.png","lang_nl_aod_month_11.png":"lang_en_aod_month_11.png","lang_nl_aod_month_3.png":"lang_de_aod_month_3.png","lang_nl_aod_month_4.png":"lang_id_aod_month_4.png","lang_nl_aod_month_5.png":"lang_de_aod_month_5.png","lang_nl_aod_month_6.png":"lang_de_aod_month_6.png","lang_nl_aod_month_7.png":"lang_de_aod_month_7.png","lang_nl_aod_month_8.png":"lang_de_aod_month_8.png","lang_nl_aod_month_9.png":"lang_de_aod_month_9.png","lang_nl_aod_stress.png":"lang_de_aod_stress.png","lang_nl_aod_week_1.png":"lang_de_aod_week_1.png","lang_nl_aod_week_3.png":"lang_de_aod_week_3.png","lang_nl_month_0.png":"lang_de_month_0.png","lang_nl_month_1.png":"lang_de_month_1.png","lang_nl_month_10.png":"lang_de_month_10.png","lang_nl_month_11.png":"lang_en_month_11.png","lang_nl_month_3.png":"lang_de_month_3.png","lang_nl_month_4.png":"lang_id_month_4.png","lang_nl_month_5.png":"lang_de_month_5.png","lang_nl_month_6.png":"lang_de_month_6.png","lang_nl_month_7.png":"lang_de_month_7.png","lang_nl_month_8.png":"lang_de_month_8.png","lang_nl_month_9.png":"lang_de_month_9.png","lang_nl_stress.png":"lang_de_stress.png","lang_nl_week_1.png":"lang_de_week_1.png","lang_nl_week_3.png":"lang_de_week_3.png","lang_pl_aod_heart.png":"lang_de_aod_heart.png","lang_pl_aod_month_2.png":"lang_en_aod_month_2.png","lang_pl_aod_stress.png":"lang_id_aod_stress.png","lang_pl_heart.png":"lang_de_heart.png","lang_pl_month_2.png":"lang_en_month_2.png","lang_pl_stress.png":"lang_id_stress.png","lang_pt_aod_heart.png":"lang_es_aod_heart.png","lang_pt_aod_month_0.png":"lang_de_aod_month_0.png","lang_pt_aod_month_10.png":"lang_de_aod_month_10.png","lang_pt_aod_month_11.png":"lang_de_aod_month_11.png","lang_pt_aod_month_2.png":"lang_en_aod_month_2.png","lang_pt_aod_month_3.png":"lang_es_aod_month_3.png","lang_pt_aod_month_4.png":"lang_de_aod_month_4.png","lang_pt_aod_month_5.png":"lang_de_aod_month_5.png","lang_pt_aod_month_6.png":"lang_de_aod_month_6.png","lang_pt_aod_month_7.png":"lang_es_aod_month_7.png","lang_pt_aod_month_8.png":"lang_it_aod_month_8.png","lang_pt_aod_stress.png":"lang_de_aod_stress.png","lang_pt_aod_week_5.png":"lang_es_aod_week_5.png","lang_pt_aod_week_6.png":"lang_es_aod_week_6.png","lang_pt_heart.png":"lang_es_heart.png","lang_pt_month_0.png":"lang_de_month_0.png","lang_pt_month_10.png":"lang_de_month_10.png","lang_pt_month_11.png":"lang_de_month_11.png","lang_pt_month_2.png":"lang_en_month_2.png","lang_pt_month_3.png":"lang_es_month_3.png","lang_pt_month_4.png":"lang_de_month_4.png","lang_pt_month_5.png":"lang_de_month_5.png","lang_pt_month_6.png":"lang_de_month_6.png","lang_pt_month_7.png":"lang_es_month_7.png","lang_pt_month_8.png":"lang_it_month_8.png","lang_pt_stress.png":"lang_de_stress.png","lang_pt_week_5.png":"lang_es_week_5.png","lang_pt_week_6.png":"lang_es_week_6.png","lang_tr_aod_month_2.png":"lang_en_aod_month_2.png","lang_tr_aod_month_4.png":"lang_en_aod_month_4.png","lang_tr_aod_stress.png":"lang_id_aod_stress.png","lang_tr_month_2.png":"lang_en_month_2.png","lang_tr_month_4.png":"lang_en_month_4.png","lang_tr_stress.png":"lang_id_stress.png","lang_uk_aod_heart.png":"lang_ru_aod_heart.png","lang_uk_aod_week_0.png":"lang_ru_aod_week_0.png","lang_uk_aod_week_1.png":"lang_ru_aod_week_1.png","lang_uk_aod_week_2.png":"lang_ru_aod_week_2.png","lang_uk_aod_week_3.png":"lang_ru_aod_week_3.png","lang_uk_aod_week_4.png":"lang_ru_aod_week_4.png","lang_uk_aod_week_5.png":"lang_ru_aod_week_5.png","lang_uk_heart.png":"lang_ru_heart.png","lang_uk_week_0.png":"lang_ru_week_0.png","lang_uk_week_1.png":"lang_ru_week_1.png","lang_uk_week_2.png":"lang_ru_week_2.png","lang_uk_week_3.png":"lang_ru_week_3.png","lang_uk_week_4.png":"lang_ru_week_4.png","lang_uk_week_5.png":"lang_ru_week_5.png","lang_zh-cn_aod_day_unit.png":"lang_ja_aod_day_unit.png","lang_zh-cn_aod_month_0.png":"lang_ja_aod_month_0.png","lang_zh-cn_aod_month_1.png":"lang_ja_aod_month_1.png","lang_zh-cn_aod_month_10.png":"lang_ja_aod_month_10.png","lang_zh-cn_aod_month_11.png":"lang_ja_aod_month_11.png","lang_zh-cn_aod_month_2.png":"lang_ja_aod_month_2.png","lang_zh-cn_aod_month_3.png":"lang_ja_aod_month_3.png","lang_zh-cn_aod_month_4.png":"lang_ja_aod_month_4.png","lang_zh-cn_aod_month_5.png":"lang_ja_aod_month_5.png","lang_zh-cn_aod_month_6.png":"lang_ja_aod_month_6.png","lang_zh-cn_aod_month_7.png":"lang_ja_aod_month_7.png","lang_zh-cn_aod_month_8.png":"lang_ja_aod_month_8.png","lang_zh-cn_aod_month_9.png":"lang_ja_aod_month_9.png","lang_zh-cn_day_unit.png":"lang_ja_day_unit.png","lang_zh-cn_month_0.png":"lang_ja_month_0.png","lang_zh-cn_month_1.png":"lang_ja_month_1.png","lang_zh-cn_month_10.png":"lang_ja_month_10.png","lang_zh-cn_month_11.png":"lang_ja_month_11.png","lang_zh-cn_month_2.png":"lang_ja_month_2.png","lang_zh-cn_month_3.png":"lang_ja_month_3.png","lang_zh-cn_month_4.png":"lang_ja_month_4.png","lang_zh-cn_month_5.png":"lang_ja_month_5.png","lang_zh-cn_month_6.png":"lang_ja_month_6.png","lang_zh-cn_month_7.png":"lang_ja_month_7.png","lang_zh-cn_month_8.png":"lang_ja_month_8.png","lang_zh-cn_month_9.png":"lang_ja_month_9.png","lang_zh-tw_aod_cal.png":"lang_zh-cn_aod_cal.png","lang_zh-tw_aod_day_unit.png":"lang_ja_aod_day_unit.png","lang_zh-tw_aod_heart.png":"lang_zh-cn_aod_heart.png","lang_zh-tw_aod_month_0.png":"lang_ja_aod_month_0.png","lang_zh-tw_aod_month_1.png":"lang_ja_aod_month_1.png","lang_zh-tw_aod_month_10.png":"lang_ja_aod_month_10.png","lang_zh-tw_aod_month_11.png":"lang_ja_aod_month_11.png","lang_zh-tw_aod_month_2.png":"lang_ja_aod_month_2.png","lang_zh-tw_aod_month_3.png":"lang_ja_aod_month_3.png","lang_zh-tw_aod_month_4.png":"lang_ja_aod_month_4.png","lang_zh-tw_aod_month_5.png":"lang_ja_aod_month_5.png","lang_zh-tw_aod_month_6.png":"lang_ja_aod_month_6.png","lang_zh-tw_aod_month_7.png":"lang_ja_aod_month_7.png","lang_zh-tw_aod_month_8.png":"lang_ja_aod_month_8.png","lang_zh-tw_aod_month_9.png":"lang_ja_aod_month_9.png","lang_zh-tw_cal.png":"lang_zh-cn_cal.png","lang_zh-tw_day_unit.png":"lang_ja_day_unit.png","lang_zh-tw_heart.png":"lang_zh-cn_heart.png","lang_zh-tw_month_0.png":"lang_ja_month_0.png","lang_zh-tw_month_1.png":"lang_ja_month_1.png","lang_zh-tw_month_10.png":"lang_ja_month_10.png","lang_zh-tw_month_11.png":"lang_ja_month_11.png","lang_zh-tw_month_2.png":"lang_ja_month_2.png","lang_zh-tw_month_3.png":"lang_ja_month_3.png","lang_zh-tw_month_4.png":"lang_ja_month_4.png","lang_zh-tw_month_5.png":"lang_ja_month_5.png","lang_zh-tw_month_6.png":"lang_ja_month_6.png","lang_zh-tw_month_7.png":"lang_ja_month_7.png","lang_zh-tw_month_8.png":"lang_ja_month_8.png","lang_zh-tw_month_9.png":"lang_ja_month_9.png","theme_green_aod_zone_label_0.png":"theme_blue_aod_zone_label_0.png","theme_lime_aod_zone_label_0.png":"theme_blue_aod_zone_label_0.png","theme_magenta_aod_zone_label_0.png":"theme_blue_aod_zone_label_0.png","theme_mint_aod_zone_label_0.png":"theme_blue_aod_zone_label_0.png","theme_orange_aod_zone_label_0.png":"theme_blue_aod_zone_label_0.png","theme_pink_aod_zone_label_0.png":"theme_blue_aod_zone_label_0.png","theme_red_aod_zone_label_0.png":"theme_blue_aod_zone_label_0.png","theme_sky_aod_zone_label_0.png":"theme_blue_aod_zone_label_0.png","theme_violet_aod_zone_label_0.png":"theme_blue_aod_zone_label_0.png","theme_white_aod_zone_label_0.png":"theme_blue_aod_zone_label_0.png","theme_yellow_aod_zone_label_0.png":"theme_blue_aod_zone_label_0.png","zone_label_0.png":"theme_blue_aod_zone_label_0.png"}
    // semua gambar berada langsung di folder assets: 'theme/lime/pill.png' -> 'theme_lime_pill.png'
    const res = (path) => {
      const name = path.split('/').join('_')
      return ALIAS[name] || name
    }
    const range = (n) => Array.from({ length: n }, (_, i) => i)
    const digits = (dir) => range(10).map((i) => res(`${dir}/${i}.png`))
    const series = (dir, n) => range(n).map((i) => res(`${dir}/${i}.png`))

    // widget bisa kosong bila show_level tidak cocok dengan layar yang aktif
    function set(widget, property, value) {
      if (widget) widget.setProperty(hmUI.prop[property], value)
    }

    // gambar yang bisa diganti: widget disimpan bersama posisinya
    function image(x, y, src, show_level = NORMAL) {
      const widget = hmUI.createWidget(hmUI.widget.IMG, { x, y, src: res(src), show_level })
      return widget ? { widget, x, y } : null
    }

    // hmUI.prop.MORE adalah cara terdokumentasi untuk mengganti properti widget
    function setSrc(item, path) {
      if (item) item.widget.setProperty(hmUI.prop.MORE, { x: item.x, y: item.y, src: res(path) })
    }

    function show(item, visible) {
      if (item) set(item.widget, 'VISIBLE', visible)
    }

    // bar progres: lebar mengikuti nilai 0-100
    function bar(box, level) {
      return hmUI.createWidget(hmUI.widget.FILL_RECT, { ...box, color: 0x000000, show_level: level })
    }

    function setBar(widget, box, value, color) {
      set(widget, 'VISIBLE', value > 0)
      if (widget && value > 0) {
        const w = Math.max(box.h, Math.round((box.w * value) / 100))
        widget.setProperty(hmUI.prop.MORE, { ...box, w, color })
      }
    }

    // angka yang selalu di tengah: satu kelompok widget untuk tiap panjang teks
    function centered(lengths, middle, y, step, dir, show_level = NORMAL) {
      return lengths.map((n) =>
        range(n).map((i) =>
          image(middle - Math.round((n * step) / 2) + i * step, y, `${dir}/dash.png`, show_level)
        )
      )
    }

    function fill(groups, dir, chars) {
      groups.forEach((group) => {
        const used = group.length === chars.length
        group.forEach((item, i) => {
          if (used) setSrc(item, `${dir}/${chars[i]}.png`)
          show(item, used)
        })
      })
    }

    // Angka yang diperbarui otomatis oleh sistem jam
    function number(type, dir, x, y, w, level, extra = {}) {
      hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x,
        y,
        w,
        type: hmUI.data_type[type],
        font_array: digits(dir),
        h_space: 0,
        align_h: hmUI.align.LEFT,
        invalid_image: res(`${dir}/invalid.png`),
        show_level: level,
        ...extra
      })
    }

    const units = (key, path) => ({
      [`${key}_sc`]: res(path),
      [`${key}_tc`]: res(path),
      [`${key}_en`]: res(path)
    })

    function createFace() {
      const lang = LANGUAGES[safe(() => hmSetting.getLanguage(), 2)] || 'en'
      const monthFirst = MONTH_FIRST.includes(lang)

      const age = safe(() => hmSetting.getUserData().age, 30)
      const maxHeartRate = 220 - (age >= 5 && age <= 110 ? age : 30)

      const sensor = (id) => safe(() => hmSensor.createSensor(hmSensor.id[id]), null)
      const time = sensor('TIME')
      const heartSensor = sensor('HEART')
      const spo2Sensor = sensor('SPO2')
      const stressSensor = sensor('STRESS')
      const batterySensor = sensor('BATTERY')
      const stepSensor = sensor('STEP')

      // pilihan warna disimpan sampai jam dimulai ulang
      let theme = 0
      function loadTheme() {
        const saved = Number(safe(() => hmFS.SysProGetInt(THEME_KEY), theme))
        if (saved >= 0 && saved < THEMES.length && Math.floor(saved) === saved) theme = saved
      }
      loadTheme()
      const themed = (name) => `theme/${THEMES[theme]}/${name}`

      // Satu fungsi untuk layar aktif dan AOD, sehingga tata letaknya selalu sama
      function createDashboard(aod) {
        const level = aod ? AOD : NORMAL
        const p = aod ? 'aod_' : '' // awalan gambar bahasa dan tema
        const dir = (name) => (aod ? `aod/${name}` : name)
        const text = (name) => `lang/${lang}/${p}${name}`
        const view = { aod }

        // latar, ikon AOD, dan baris tanggal (hari - tanggal - bulan, simetris)
        image(0, 0, aod ? 'aod_bg.png' : 'bg.png', level)
        if (aod) view.icons = image(228, 76, themed('aod_icons.png'), level)
        view.frames = FRAMES.map(([kind, x, y]) =>
          image(x, y, themed(`${p}${kind}_frame.png`), level)
        )
        const weekX = monthFirst ? 252 : 116
        const monthX = monthFirst ? 106 : 242
        view.pill = image(weekX, 28, themed(`${p}pill.png`), level)
        view.monthPill = image(monthX, 28, themed(`${p}pill.png`), level)

        // tanggal
        const week = series(text('week'), 7)
        const month = series(text('month'), 12)
        const dayDigits = digits(dir('d_date'))
        hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: weekX,
          y: 28,
          week_en: week,
          week_sc: week,
          week_tc: week,
          show_level: level
        })
        hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: monthFirst ? 186 : 198,
          day_startY: 31,
          day_en_array: dayDigits,
          day_sc_array: dayDigits,
          day_tc_array: dayDigits,
          day_zero: 1,
          day_space: 0,
          day_align: hmUI.align.LEFT,
          day_is_character: false,
          ...(monthFirst ? units('day_unit', text('day_unit.png')) : {}),
          month_startX: monthX,
          month_startY: 28,
          month_en_array: month,
          month_sc_array: month,
          month_tc_array: month,
          month_is_character: true,
          show_level: level
        })

        // jam 24 jam
        const pair = (y, folder) => [0, 1].map((i) => image(22 + i * 96, y, `${folder}/0.png`, level))
        view.hour = pair(70, `${p}hour`)
        // angka menit: kotak warna tema di belakang gambar hitam berlubang
        view.minuteBox = { x: 22, y: 242, w: 192, h: 156 }
        view.minuteFill = bar(view.minuteBox, level)
        view.minute = pair(242, `${p}min`)

        // bar di kartu kanan dan baterai: AOD lebih tipis
        const box = (x, y, w) => (aod ? { x, y: y + 3, w, h: 4 } : { x, y, w, h: 10, radius: 5 })

        // kartu detak jantung
        image(260, 78, text('heart.png'), level)
        view.zoneLabel = image(368, 78, aod ? themed('aod_zone_label/0.png') : 'zone/label_0.png', level)
        view.heart = centered([1, 2, 3], CARD_MID, 103, 28, dir('d_hr'), level)
        view.zoneBar = image(BAR_X, 149, aod ? themed('aod_zone/0.png') : 'zone/0.png', level)

        // kartu langkah: bar 0 - 10K
        image(260, 190, text('steps.png'), level)
        number('STEP', dir('d_step'), 220, 212, 188, level, { align_h: hmUI.align.CENTER_H })
        view.stepBox = box(BAR_X, 254, BAR_W)
        view.stepBar = bar(view.stepBox, level)
        image(BAR_X, 254, `${p}card_ticks.png`, level)

        // kartu SpO2: bar 0 - 100
        view.spo2 = centered([2, 3, 4], CARD_MID, 326, 24, dir('d_spo2'), level)
        view.spo2Box = box(BAR_X, 366, BAR_W)
        view.spo2Bar = bar(view.spo2Box, level)
        image(BAR_X, 366, `${p}card_ticks.png`, level)

        // baris statistik: kalori, jarak, stres
        const center = { align_h: hmUI.align.CENTER_H }
        image(28, 409, text('cal.png'), level)
        image(159, 409, text('dist.png'), level)
        image(290, 409, text('stress.png'), level)
        number('CAL', dir('d_stat'), 24, 427, 122, level, center)
        number('DISTANCE', dir('d_stat'), 155, 427, 122, level, {
          ...center,
          dot_image: res(`${dir('d_stat')}/dot.png`)
        })
        view.stress = centered([1, 2, 3], 347, 427, 17, dir('d_stat'), level)
        view.stressBar = image(307, 456, aod ? themed('aod_stress/0.png') : 'stress/0.png', level)

        // baterai: ikon (di latar) di kiri, bar 3 warna berskala 0-100, persentase di kanan
        view.batteryBox = box(106, 474, 220)
        view.batteryBar = bar(view.batteryBox, level)
        image(106, 474, 'batt_ticks.png', level)
        // AOD: persentase berupa lubang pada gambar, warnanya dari kotak di belakangnya
        view.batteryFill = aod ? bar({ x: 349, y: 471, w: 22, h: 17 }, level) : null
        view.battery = centered([2, 3, 4], 360, 471, 11, aod ? 'aod_batt' : 'd_batt_g', level)

        // status di kiri dan kanan tanggal
        ;[
          ['DISCONNECT', 71, 'st_bt.png'],
          ['CLOCK', 338, 'st_alarm.png']
        ].forEach(([type, x, src]) => {
          hmUI.createWidget(hmUI.widget.IMG_STATUS, {
            x,
            y: 32,
            type: hmUI.system_status[type],
            src: `${p}${src}`,
            show_level: level
          })
        })

        return view
      }

      let views = []
      const two = (n) => (n < 10 ? `0${n}` : `${n}`)
      const barSrc = (view, name, value) =>
        view.aod ? themed(`aod_${name}/${value}.png`) : `${name}/${value}.png`
      const reading = (sensor, read, min, max) => {
        const raw = sensor ? safe(read, 0) : 0
        return raw >= min && raw <= max ? Math.round(raw) : 0
      }

      // Zona dari persentase detak maksimum: Z1 50%, Z2 60%, Z3 70%, Z4 80%, Z5 90%
      function zoneOf(bpm) {
        return Math.max(0, Math.min(5, Math.floor((bpm * 10) / maxHeartRate) - 4))
      }

      // Tingkat stres: 1-39, 40-59, 60-79, 80-100
      function stressLevel(value) {
        if (!value) return 0
        return value < 40 ? 1 : value < 60 ? 2 : value < 80 ? 3 : 4
      }

      function updateClock() {
        if (!time) return
        // time.hour selalu 0-23, tidak mengikuti pengaturan 12/24 jam
        const hour = two(time.hour)
        const minute = two(time.minute)
        views.forEach((view) => {
          const p = view.aod ? 'aod_' : ''
          view.hour.forEach((w, i) => setSrc(w, `${p}hour/${hour[i]}.png`))
          view.minute.forEach((w, i) => setSrc(w, `${p}min/${minute[i]}.png`))
        })
      }

      function updateHeart() {
        const bpm = reading(heartSensor, () => heartSensor.last, 1, 255)
        const zone = zoneOf(bpm)
        views.forEach((view) => {
          fill(view.heart, view.aod ? 'aod/d_hr' : 'd_hr', bpm ? String(bpm).split('') : ['dash', 'dash'])
          setSrc(view.zoneBar, barSrc(view, 'zone', zone))
          setSrc(view.zoneLabel, view.aod ? themed(`aod_zone_label/${zone}.png`) : `zone/label_${zone}.png`)
        })
      }

      function updateSpo2() {
        const value = reading(spo2Sensor, () => spo2Sensor.current, 1, 100)
        views.forEach((view) => {
          const chars = value ? [...String(value).split(''), 'pct'] : ['dash', 'dash']
          fill(view.spo2, view.aod ? 'aod/d_spo2' : 'd_spo2', chars)
          setBar(view.spo2Bar, view.spo2Box, value, view.aod ? THEME_AOD_COLORS[theme] : SPO2_COLOR)
        })
      }

      function updateStress() {
        const value = reading(stressSensor, () => stressSensor.current, 1, 100)
        views.forEach((view) => {
          const chars = value ? String(value).split('') : ['dash', 'dash']
          fill(view.stress, view.aod ? 'aod/d_stat' : 'd_stat', chars)
          setSrc(view.stressBar, barSrc(view, 'stress', stressLevel(value)))
        })
      }

      // Bar langkah: penuh pada 10.000 langkah
      function updateSteps() {
        const raw = stepSensor ? safe(() => stepSensor.current, 0) : 0
        const value = raw > 0 ? Math.min(100, (raw * 100) / STEP_FULL) : 0
        views.forEach((view) => {
          const colors = view.aod ? THEME_AOD_COLORS : THEME_COLORS
          setBar(view.stepBar, view.stepBox, value, colors[theme])
        })
      }

      // Baterai (angka dan bar): layar aktif merah/kuning/hijau, AOD warna tema
      function updateBattery() {
        const value = reading(batterySensor, () => batterySensor.current, 1, 100)
        const key = value && value <= 25 ? 'r' : value && value <= 50 ? 'y' : 'g'
        views.forEach((view) => {
          const chars = value ? [...String(value).split(''), 'pct'] : ['dash', 'dash']
          fill(view.battery, view.aod ? 'aod_batt' : `d_batt_${key}`, chars)
          const color = view.aod ? THEME_AOD_COLORS[theme] : BATTERY_COLORS[key]
          if (view.batteryFill) {
            const w = chars.length * 11
            const box = { x: 360 - Math.round(w / 2), y: 471, w, h: 17, color }
            view.batteryFill.setProperty(hmUI.prop.MORE, box)
          }
          setBar(view.batteryBar, view.batteryBox, value, color)
        })
      }

      function updateTheme() {
        views.forEach((view) => {
          if (view.aod) setSrc(view.icons, themed('aod_icons.png'))
          const pill = themed(`${view.aod ? 'aod_' : ''}pill.png`)
          setSrc(view.pill, pill)
          setSrc(view.monthPill, pill)
          const colors = view.aod ? THEME_AOD_COLORS : THEME_COLORS
          view.minuteFill &&
            view.minuteFill.setProperty(hmUI.prop.MORE, { ...view.minuteBox, color: colors[theme] })
          const p = view.aod ? 'aod_' : ''
          view.frames.forEach((frame, i) => setSrc(frame, themed(`${p}${FRAMES[i][0]}_frame.png`)))
        })
      }

      function updateAll() {
        loadTheme()
        updateTheme()
        updateClock()
        updateHeart()
        updateSteps()
        updateSpo2()
        updateStress()
        updateBattery()
      }

      function nextTheme() {
        theme = (theme + 1) % THEMES.length
        safe(() => hmFS.SysProSetInt(THEME_KEY, theme), null)
        updateAll()
      }

      views = [createDashboard(false), createDashboard(true)]

      // Ketuk angka jam untuk ganti warna (tidak ada aksi tahan lama)
      hmUI.createWidget(hmUI.widget.BUTTON, {
        x: 24,
        y: 70,
        w: 188,
        h: 328,
        text: '',
        normal_src: 'time_tap.png',
        press_src: 'time_tap.png',
        click_func: nextTheme,
        show_level: NORMAL
      })

      // Pintasan: ketuk kartu untuk membuka aplikasinya
      const shortcuts = [
        ['HEART', 220, 70, 188, 104],
        ['STEP', 220, 182, 188, 104],
        ['SPO2', 220, 294, 188, 104],
        ['STRESS', 286, 404, 122, 62]
      ]
      shortcuts.forEach(([type, x, y, w, h]) => {
        hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x,
          y,
          w,
          h,
          type: hmUI.data_type[type],
          src: 'blank.png',
          show_level: NORMAL
        })
      })

      // ---------- pembaruan ----------
      const listeners = [
        [time, () => time.event.MINUTEEND, updateAll],
        [heartSensor, () => heartSensor.event.LAST, updateHeart],
        [spo2Sensor, () => hmSensor.event.CHANGE, updateSpo2],
        [stressSensor, () => hmSensor.event.CHANGE, updateStress],
        [batterySensor, () => hmSensor.event.CHANGE, updateBattery],
        [stepSensor, () => hmSensor.event.CHANGE, updateSteps]
      ]
      listeners.forEach(([source, event, handler]) => {
        safe(() => source.addEventListener(event(), handler), null)
      })

      // cadangan di layar aktif: periksa pergantian menit setiap detik
      let ticker = null
      let shownMinute = -1
      function stopTicker() {
        if (ticker) safe(() => timer.stopTimer(ticker), null)
        ticker = null
      }
      function resume() {
        updateAll()
        const active = safe(() => hmSetting.getScreenType() === hmSetting.screen_type.WATCHFACE, false)
        if (active && !ticker) {
          ticker = safe(
            () =>
              timer.createTimer(1000, 1000, () => {
                if (time && time.minute !== shownMinute) {
                  shownMinute = time.minute
                  updateClock()
                }
              }),
            null
          )
        }
      }

      hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: resume,
        pause_call: stopTicker
      })
      updateAll()

      return () => {
        stopTicker()
        listeners.forEach(([source, event, handler]) => {
          safe(() => source.removeEventListener && source.removeEventListener(event(), handler), null)
        })
      }
    }

    let dispose = null

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      onInit() {},
      build() {
        dispose = createFace()
      },
      onDestroy() {
        if (dispose) dispose()
      }
    })
  })()
} catch (e) {
  console.log('Watchface Error', e)
  e && e.stack && e.stack.split(/\n/).forEach((i) => console.log('error stack', i))
}
