﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 465,
              font_array: ["kroki_00.png","kroki_01.png","kroki_02.png","kroki_03.png","kroki_04.png","kroki_05.png","kroki_06.png","kroki_07.png","kroki_08.png","kroki_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 14,
              y: 463,
              src: 'kroki.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 406,
              font_array: ["kroki_00.png","kroki_01.png","kroki_02.png","kroki_03.png","kroki_04.png","kroki_05.png","kroki_06.png","kroki_07.png","kroki_08.png","kroki_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'kropka.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 14,
              y: 402,
              src: 'dystans.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 345,
              font_array: ["kroki_00.png","kroki_01.png","kroki_02.png","kroki_03.png","kroki_04.png","kroki_05.png","kroki_06.png","kroki_07.png","kroki_08.png","kroki_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 14,
              y: 345,
              src: 'puls.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 312,
              year_startY: 121,
              year_sc_array: ["sekunda_00.png","sekunda_01.png","sekunda_02.png","sekunda_03.png","sekunda_04.png","sekunda_05.png","sekunda_06.png","sekunda_07.png","sekunda_08.png","sekunda_09.png"],
              year_tc_array: ["sekunda_00.png","sekunda_01.png","sekunda_02.png","sekunda_03.png","sekunda_04.png","sekunda_05.png","sekunda_06.png","sekunda_07.png","sekunda_08.png","sekunda_09.png"],
              year_en_array: ["sekunda_00.png","sekunda_01.png","sekunda_02.png","sekunda_03.png","sekunda_04.png","sekunda_05.png","sekunda_06.png","sekunda_07.png","sekunda_08.png","sekunda_09.png"],
              year_zero: 0,
              year_space: 0,
              year_unit_sc: 'rok.png',
              year_unit_tc: 'rok.png',
              year_unit_en: 'rok.png',
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 209,
              month_startY: 122,
              month_sc_array: ["miesiac_001.png","miesiac_002.png","miesiac_003.png","miesiac_004.png","miesiac_005.png","miesiac_006.png","miesiac_007.png","miesiac_008.png","miesiac_009.png","miesiac_010.png","miesiac_011.png","miesiac_012.png"],
              month_tc_array: ["miesiac_001.png","miesiac_002.png","miesiac_003.png","miesiac_004.png","miesiac_005.png","miesiac_006.png","miesiac_007.png","miesiac_008.png","miesiac_009.png","miesiac_010.png","miesiac_011.png","miesiac_012.png"],
              month_en_array: ["miesiac_001.png","miesiac_002.png","miesiac_003.png","miesiac_004.png","miesiac_005.png","miesiac_006.png","miesiac_007.png","miesiac_008.png","miesiac_009.png","miesiac_010.png","miesiac_011.png","miesiac_012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 116,
              day_startY: 121,
              day_sc_array: ["sekunda_00.png","sekunda_01.png","sekunda_02.png","sekunda_03.png","sekunda_04.png","sekunda_05.png","sekunda_06.png","sekunda_07.png","sekunda_08.png","sekunda_09.png"],
              day_tc_array: ["sekunda_00.png","sekunda_01.png","sekunda_02.png","sekunda_03.png","sekunda_04.png","sekunda_05.png","sekunda_06.png","sekunda_07.png","sekunda_08.png","sekunda_09.png"],
              day_en_array: ["sekunda_00.png","sekunda_01.png","sekunda_02.png","sekunda_03.png","sekunda_04.png","sekunda_05.png","sekunda_06.png","sekunda_07.png","sekunda_08.png","sekunda_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 13,
              y: 122,
              week_en: ["dzien_01.png","dzien_02.png","dzien_03.png","dzien_04.png","dzien_05.png","dzien_06.png","dzien_07.png"],
              week_tc: ["dzien_01.png","dzien_02.png","dzien_03.png","dzien_04.png","dzien_05.png","dzien_06.png","dzien_07.png"],
              week_sc: ["dzien_01.png","dzien_02.png","dzien_03.png","dzien_04.png","dzien_05.png","dzien_06.png","dzien_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 11,
              hour_startY: 214,
              hour_array: ["godzina_00.png","godzina_01.png","godzina_02.png","godzina_03.png","godzina_04.png","godzina_05.png","godzina_06.png","godzina_07.png","godzina_08.png","godzina_09.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'dwukropek.png',
              hour_unit_tc: 'dwukropek.png',
              hour_unit_en: 'dwukropek.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 195,
              minute_startY: 214,
              minute_array: ["minuta_00.png","minuta_01.png","minuta_02.png","minuta_03.png","minuta_04.png","minuta_05.png","minuta_06.png","minuta_07.png","minuta_08.png","minuta_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 347,
              second_startY: 253,
              second_array: ["sekunda_00.png","sekunda_01.png","sekunda_02.png","sekunda_03.png","sekunda_04.png","sekunda_05.png","sekunda_06.png","sekunda_07.png","sekunda_08.png","sekunda_09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 286,
              y: 44,
              font_array: ["kroki_00.png","kroki_01.png","kroki_02.png","kroki_03.png","kroki_04.png","kroki_05.png","kroki_06.png","kroki_07.png","kroki_08.png","kroki_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'procent.png',
              unit_tc: 'procent.png',
              unit_en: 'procent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 282,
              y: 44,
              src: 'bateria_ikona.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 28,
              y: 16,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 44,
              font_array: ["kroki_00.png","kroki_01.png","kroki_02.png","kroki_03.png","kroki_04.png","kroki_05.png","kroki_06.png","kroki_07.png","kroki_08.png","kroki_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'stopnie.png',
              unit_tc: 'stopnie.png',
              unit_en: 'stopnie.png',
              negative_image: 'minus.png',
              invalid_image: 'error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'bg_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 214,
              hour_array: ["godzina_00.png","godzina_01.png","godzina_02.png","godzina_03.png","godzina_04.png","godzina_05.png","godzina_06.png","godzina_07.png","godzina_08.png","godzina_09.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'dwukropek.png',
              hour_unit_tc: 'dwukropek.png',
              hour_unit_en: 'dwukropek.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 233,
              minute_startY: 214,
              minute_array: ["minuta_00.png","minuta_01.png","minuta_02.png","minuta_03.png","minuta_04.png","minuta_05.png","minuta_06.png","minuta_07.png","minuta_08.png","minuta_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 148,
              y: 44,
              font_array: ["kroki_00.png","kroki_01.png","kroki_02.png","kroki_03.png","kroki_04.png","kroki_05.png","kroki_06.png","kroki_07.png","kroki_08.png","kroki_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'procent.png',
              unit_tc: 'procent.png',
              unit_en: 'procent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 282,
              y: 44,
              src: 'bateria_ikona.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}