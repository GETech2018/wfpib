﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let colornumber_main = 1
        let totalcolors_main = 6
        let namecolor_main = ''
		let pointerstring = 'Batt_1.png'
		
        function click_Color() {
            if(colornumber_main >= totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main = colornumber_main+1;
            }

			if ( colornumber_main == 1) { namecolor_main = "Orange"
				pointerstring = "Batt_" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 2) { namecolor_main = "Blue"
				pointerstring = "Batt_" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 3) { namecolor_main = "Green"
				pointerstring = "Batt_" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 4) { namecolor_main = "Red"
				pointerstring = "Batt_" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 5) { namecolor_main = "Turquoise"
				pointerstring = "Batt_" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 6) { namecolor_main = "Yellow"
				pointerstring = "Batt_" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main <= 6) {

			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: pointerstring,
              center_x: 180,
              center_y: 180,
              x: 166,
              y: -49,
              start_angle: 118,
              end_angle: 183,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
             });                          
			}
		
			hmUI.showToast({text: namecolor_main });                          
			normal_battery_icon_img.setProperty(hmUI.prop.SRC, "Main_" + parseInt(colornumber_main) + ".png");
			
		}

				/////////////////////////////////////////////////////////////////////////////////////////////////



       // Start Hour color change
	   let colornumberH = 1
	   let totalcolorsH = 6
	   let namecolorH = ''
	   let Rootpath = ''
	   function click_ColorH() {
		   if(colornumberH >= totalcolorsH) {
		   colornumberH=1;
			   }
		   else {
			   colornumberH = colornumberH+1;
		   }
if ( colornumberH == 1) { namecolorH = "Orange"
Rootpath = ''
}
if ( colornumberH == 2) { namecolorH = "Blue"
Rootpath = "Bleu/"
}
if ( colornumberH == 3) { namecolorH = "Green"
Rootpath = "Vert/"
}
if ( colornumberH == 4) { namecolorH = "Red"
Rootpath = "Rouge/"
}
if ( colornumberH == 5) { namecolorH = "Lime"
Rootpath = "Jaune/"
}
if ( colornumberH == 6) { namecolorH = "Cyan"
Rootpath = "Turquoise/"
}
            normal_hour_TextRotate_ASCIIARRAY[0] = Rootpath+'110.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = Rootpath+'111.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = Rootpath+'112.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = Rootpath+'113.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = Rootpath+'114.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = Rootpath+'115.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = Rootpath+'116.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = Rootpath+'117.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = Rootpath+'118.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = Rootpath+'119.png';  // set of images with numbers

hmUI.showToast({text: namecolorH });    
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i].setProperty(hmUI.prop.MORE, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 255,
                center_y: -21,
                pos_x: 255,
                pos_y: -21,
                angle: 0,
                src: 'dot.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
          normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                  
            };


		}
        // end user_functions.js

        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 173;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 110;
        let normal_battery_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_linear_scale = ''
        let normal_battery_linear_scale_mirror = ''
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС'];
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 35;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 110;
        let idle_timerTextUpdate = undefined;
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 173;
        let idle_image_img = ''
        let image_top_img = ''
        let Button_1 = ''
        let Button_3 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: RussoOne-Regular.ttf; FontSize: 90
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 1215,
              h: 129,
              text_size: 90,
              char_space: -2,
              line_space: 0,
              font: 'fonts/RussoOne-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: RussoOne-Regular.ttf; FontSize: 90; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 108,
              h: 108,
              text_size: 90,
              char_space: -3,
              line_space: 0,
              font: 'fonts/RussoOne-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 255,
              // y: -21,
              // font_array: ["110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -48,
              // angle: 0,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = '110.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = '111.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = '112.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = '113.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = '114.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = '115.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = '116.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = '117.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = '118.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = '119.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 255,
                center_y: -21,
                pos_x: 255,
                pos_y: -21,
                angle: 0,
                src: '110.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 258,
              // y: 223,
              // font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = '0.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = '1.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = '2.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = '3.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = '4.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = '5.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = '6.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = '7.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = '8.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = '9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 258,
                center_y: 223,
                pos_x: 258,
                pos_y: 223,
                angle: 0,
                src: '0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Main_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Batt_1.png',
              center_x: 233,
              center_y: 233,
              x: 215,
              y: -63,
              start_angle: 118,
              end_angle: 183,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
              normal_battery_linear_scale_mirror = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 382,
              // start_y: 390,
              // color: 0xFF6B6B6B,
              // lenght: 327,
              // line_width: 8,
              // line_cap: Flat,
              // vertical: True,
              // mirror: True,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -9,
              y: 310,
              w: 146,
              h: 100,
              text_size: 90,
              char_space: -2,
              line_space: 0,
              font: 'fonts/RussoOne-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -11,
              y: 211,
              w: 150,
              h: 130,
              text_size: 90,
              char_space: -3,
              line_space: 0,
              font: 'fonts/RussoOne-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 26,
              // y: 12,
              // font_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -90,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = '20.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = '21.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = '22.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = '23.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = '24.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = '25.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = '26.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = '27.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = '28.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = '29.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 26,
                center_y: 12,
                pos_x: 26,
                pos_y: 12,
                angle: -90,
                src: '20.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });


            console.log('Watch_Face.ScreenAOD');

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 239,
              // y: 30,
              // font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 13,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = '0.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = '1.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = '2.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = '3.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = '4.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = '5.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = '6.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = '7.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = '8.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = '9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 239,
                center_y: 30,
                pos_x: 239,
                pos_y: 30,
                angle: 13,
                src: '0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -18,
              // y: 208,
              // font_array: ["110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -48,
              // angle: -16,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = '110.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = '111.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = '112.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = '113.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = '114.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = '115.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = '116.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = '117.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = '118.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = '119.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: -18,
                center_y: 208,
                pos_x: -18,
                pos_y: 208,
                angle: -16,
                src: '110.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'CONTOUR.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 195,
              y: 59,
              w: 103,
              h: 95,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                click_ColorH();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 26,
              y: 321,
              w: 62,
              h: 86,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                click_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_hour_TextRotate_posOffset = normal_hour_TextRotate_img_width * normal_hour_rotate_string.length;
                  normal_hour_TextRotate_posOffset = normal_hour_TextRotate_posOffset + -48 * (normal_hour_rotate_string.length - 1);
                  img_offset -= normal_hour_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 255 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + -48;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_minute_TextRotate_posOffset = normal_minute_TextRotate_img_width * normal_minute_rotate_string.length;
                  img_offset -= normal_minute_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 258 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  img_offset -= normal_step_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 26 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 239 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, -18 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width + -48;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 382;
                  let start_y_normal_battery = 717;
                  let lenght_ls_normal_battery = -327;
                  let line_width_ls_normal_battery = 8;
                  let color_ls_normal_battery = 0xFF6B6B6B;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = line_width_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = lenght_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    line_width_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_y_normal_battery_draw = start_y_normal_battery_draw - line_width_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                  
                  // normal_battery_linear_scale_mirror
                  // initial parameters
                  let start_x_normal_battery_mirror = 382;
                  let start_y_normal_battery_mirror = 63;
                  let lenght_ls_normal_battery_mirror = 327;
                  let line_width_ls_normal_battery_mirror =8;
                  let color_ls_normal_battery_mirror = 0xFF6B6B6B;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw_mirror = start_x_normal_battery_mirror;
                  let start_y_normal_battery_draw_mirror = start_y_normal_battery_mirror;
                  lenght_ls_normal_battery_mirror = lenght_ls_normal_battery_mirror * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw_mirror = line_width_ls_normal_battery_mirror;
                  let line_width_ls_normal_battery_draw_mirror = lenght_ls_normal_battery_mirror;
                  if (lenght_ls_normal_battery_mirror < 0){
                    line_width_ls_normal_battery_draw_mirror = -lenght_ls_normal_battery_mirror;
                    start_y_normal_battery_draw_mirror = start_y_normal_battery_draw - line_width_ls_normal_battery_draw_mirror;
                  };
                  
                  normal_battery_linear_scale_mirror.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw_mirror,
                    y: start_y_normal_battery_draw_mirror,
                    w: lenght_ls_normal_battery_draw_mirror,
                    h: line_width_ls_normal_battery_draw_mirror,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}