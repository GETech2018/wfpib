﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 320,
              h: 380,
              src: 'bg_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 134,
              y: 288,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 111,
              y: 34,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 176,
              y: 260,
              image_array: ["Weather_image_01.png","Weather_image_02.png","Weather_image_03.png","Weather_image_04.png","Weather_image_05.png","Weather_image_06.png","Weather_image_07.png","Weather_image_08.png","Weather_image_09.png","Weather_image_10.png","Weather_image_11.png","Weather_image_12.png","Weather_image_13.png","Weather_image_14.png","Weather_image_15.png","Weather_image_16.png","Weather_image_17.png","Weather_image_18.png","Weather_image_19.png","Weather_image_20.png","Weather_image_21.png","Weather_image_22.png","Weather_image_23.png","Weather_image_24.png","Weather_image_25.png","Weather_image_26.png","Weather_image_27.png","Weather_image_28.png","Weather_image_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 219,
              y: 262,
              font_array: ["piccolo_n-00.png","piccolo_n-01.png","piccolo_n-02.png","piccolo_n-03.png","piccolo_n-04.png","piccolo_n-05.png","piccolo_n-06.png","piccolo_n-07.png","piccolo_n-08.png","piccolo_n-09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'weather_symbo1.png',
              unit_tc: 'weather_symbo1.png',
              unit_en: 'weather_symbo1.png',
              negative_image: 'weather_symbo2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 65,
              y: 257,
              src: 'ste1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 265,
              font_array: ["piccolo_n-00.png","piccolo_n-01.png","piccolo_n-02.png","piccolo_n-03.png","piccolo_n-04.png","piccolo_n-05.png","piccolo_n-06.png","piccolo_n-07.png","piccolo_n-08.png","piccolo_n-09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 128,
              font_array: ["piccolo_n-00.png","piccolo_n-01.png","piccolo_n-02.png","piccolo_n-03.png","piccolo_n-04.png","piccolo_n-05.png","piccolo_n-06.png","piccolo_n-07.png","piccolo_n-08.png","piccolo_n-09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 88,
              font_array: ["piccolo_n-00.png","piccolo_n-01.png","piccolo_n-02.png","piccolo_n-03.png","piccolo_n-04.png","piccolo_n-05.png","piccolo_n-06.png","piccolo_n-07.png","piccolo_n-08.png","piccolo_n-09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'proc2.png',
              unit_tc: 'proc2.png',
              unit_en: 'proc2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 196,
              y: 92,
              week_en: ["day-1.png","day-2.png","day-3.png","day-4.png","day-5.png","day-6.png","day-7.png"],
              week_tc: ["day-1.png","day-2.png","day-3.png","day-4.png","day-5.png","day-6.png","day-7.png"],
              week_sc: ["day-1.png","day-2.png","day-3.png","day-4.png","day-5.png","day-6.png","day-7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 210,
              day_startY: 119,
              day_sc_array: ["piccolo_n-10.png","piccolo_n-11.png","piccolo_n-12.png","piccolo_n-13.png","piccolo_n-14.png","piccolo_n-15.png","piccolo_n-16.png","piccolo_n-17.png","piccolo_n-18.png","piccolo_n-19.png"],
              day_tc_array: ["piccolo_n-10.png","piccolo_n-11.png","piccolo_n-12.png","piccolo_n-13.png","piccolo_n-14.png","piccolo_n-15.png","piccolo_n-16.png","piccolo_n-17.png","piccolo_n-18.png","piccolo_n-19.png"],
              day_en_array: ["piccolo_n-10.png","piccolo_n-11.png","piccolo_n-12.png","piccolo_n-13.png","piccolo_n-14.png","piccolo_n-15.png","piccolo_n-16.png","piccolo_n-17.png","piccolo_n-18.png","piccolo_n-19.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 58,
              hour_startY: 185,
              hour_array: ["ore_01.png","ore_02.png","ore_03.png","ore_04.png","ore_05.png","ore_06.png","ore_07.png","ore_08.png","ore_09.png","ore_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 166,
              minute_startY: 185,
              minute_array: ["ore_01.png","ore_02.png","ore_03.png","ore_04.png","ore_05.png","ore_06.png","ore_07.png","ore_08.png","ore_09.png","ore_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 254,
              second_startY: 190,
              second_array: ["piccolo_n-00.png","piccolo_n-01.png","piccolo_n-02.png","piccolo_n-03.png","piccolo_n-04.png","piccolo_n-05.png","piccolo_n-06.png","piccolo_n-07.png","piccolo_n-08.png","piccolo_n-09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 139,
              y: 182,
              src: 'z_042.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 51,
              y: 254,
              w: 100,
              h: 33,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 58,
              y: 121,
              w: 100,
              h: 39,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 128,
              y: 287,
              w: 63,
              h: 58,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 172,
              y: 253,
              w: 100,
              h: 34,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 52,
              y: 178,
              w: 88,
              h: 66,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}