# BipMax Apollo

Zeus CLI watchface project exported by **Dialcraft**.

- Target: Amazfit Bip Max (`bip-max`, 432×514)
- designWidth: 432
- Assets: `assets/bip-max/images/`
- Code: `watchface/bip-max/index.js`
- Fonts: `assets/bip-max/fonts/SairaCondensed-SemiBold.ttf`, `SF-Pro-Rounded-Medium.ttf` — referenced by Text widgets as `font: 'fonts/<file>'`

## Build / preview

```bash
npm i @zeppos/zeus-cli -g
zeus dev        # live preview in the Zepp OS simulator
zeus preview    # QR code for the Zepp app (developer mode)
zeus build      # installable package in dist/
```

Add more devices by copying the `targets` block in `app.json` (the key must
match the `assets/<key>.<st>` folder) — see the device list in the docs:
https://docs.zepp.com/docs/reference/related-resources/device-list/
