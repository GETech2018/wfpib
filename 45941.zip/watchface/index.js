﻿    /*
    ** Watch_Face_Editor tool v 18.2
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_frame_animation_3 = ''
        let normal_frame_animation_4 = ''
        let normal_frame_animation_5 = ''
        let normal_frame_animation_6 = ''
        let normal_frame_animation_7 = ''
        let normal_frame_animation_8 = ''
        let normal_frame_animation_9 = ''
        let normal_frame_animation_10 = ''
        let normal_frame_animation_11 = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'seal_mission_bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 139,
              y: 151,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "seal_fire",
              anim_fps: 12,
              anim_size: 24,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 389,
              y: 449,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "seal_flicker0",
              anim_fps: 12,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_3 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 389,
              y: 449,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "seal_flicker1",
              anim_fps: 12,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_4 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 389,
              y: 449,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "seal_flicker2",
              anim_fps: 12,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_5 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 389,
              y: 449,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "seal_flicker3",
              anim_fps: 12,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_6 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 389,
              y: 449,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "seal_flicker4",
              anim_fps: 12,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_7 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 389,
              y: 449,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "seal_flicker5",
              anim_fps: 12,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_8 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 389,
              y: 449,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "seal_flicker6",
              anim_fps: 12,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_9 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 389,
              y: 449,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "seal_flicker7",
              anim_fps: 12,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_10 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 389,
              y: 449,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "seal_flicker8",
              anim_fps: 12,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_11 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 389,
              y: 449,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "seal_flicker9",
              anim_fps: 12,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 84,
              hour_array: ["seal_digit_0.png","seal_digit_1.png","seal_digit_2.png","seal_digit_3.png","seal_digit_4.png","seal_digit_5.png","seal_digit_6.png","seal_digit_7.png","seal_digit_8.png","seal_digit_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 205,
              minute_startY: 84,
              minute_array: ["seal_digit_0.png","seal_digit_1.png","seal_digit_2.png","seal_digit_3.png","seal_digit_4.png","seal_digit_5.png","seal_digit_6.png","seal_digit_7.png","seal_digit_8.png","seal_digit_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 105,
              src: 'seal_colon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 249,
              font_array: ["seal_charge_0.png","seal_charge_1.png","seal_charge_2.png","seal_charge_3.png","seal_charge_4.png","seal_charge_5.png","seal_charge_6.png","seal_charge_7.png","seal_charge_8.png","seal_charge_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'seal_percent.png',
              unit_tc: 'seal_percent.png',
              unit_en: 'seal_percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 64,
              y: 274,
              image_array: ["seal_ward_0.png","seal_ward_1.png","seal_ward_2.png","seal_ward_3.png","seal_ward_4.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 239,
              font_array: ["seal_ink_0.png","seal_ink_1.png","seal_ink_2.png","seal_ink_3.png","seal_ink_4.png","seal_ink_5.png","seal_ink_6.png","seal_ink_7.png","seal_ink_8.png","seal_ink_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 258,
              y: 237,
              image_array: ["seal_stamp_0.png","seal_stamp_1.png","seal_stamp_2.png","seal_stamp_3.png"],
              image_length: 4,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 143,
              y: 56,
              week_en: ["seal_week_01.png","seal_week_02.png","seal_week_03.png","seal_week_04.png","seal_week_05.png","seal_week_06.png","seal_week_07.png"],
              week_tc: ["seal_week_01.png","seal_week_02.png","seal_week_03.png","seal_week_04.png","seal_week_05.png","seal_week_06.png","seal_week_07.png"],
              week_sc: ["seal_week_01.png","seal_week_02.png","seal_week_03.png","seal_week_04.png","seal_week_05.png","seal_week_06.png","seal_week_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 183,
              month_startY: 56,
              month_sc_array: ["seal_month_01.png","seal_month_02.png","seal_month_03.png","seal_month_04.png","seal_month_05.png","seal_month_06.png","seal_month_07.png","seal_month_08.png","seal_month_09.png","seal_month_10.png","seal_month_11.png","seal_month_12.png"],
              month_tc_array: ["seal_month_01.png","seal_month_02.png","seal_month_03.png","seal_month_04.png","seal_month_05.png","seal_month_06.png","seal_month_07.png","seal_month_08.png","seal_month_09.png","seal_month_10.png","seal_month_11.png","seal_month_12.png"],
              month_en_array: ["seal_month_01.png","seal_month_02.png","seal_month_03.png","seal_month_04.png","seal_month_05.png","seal_month_06.png","seal_month_07.png","seal_month_08.png","seal_month_09.png","seal_month_10.png","seal_month_11.png","seal_month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 218,
              day_startY: 56,
              day_sc_array: ["seal_date_0.png","seal_date_1.png","seal_date_2.png","seal_date_3.png","seal_date_4.png","seal_date_5.png","seal_date_6.png","seal_date_7.png","seal_date_8.png","seal_date_9.png"],
              day_tc_array: ["seal_date_0.png","seal_date_1.png","seal_date_2.png","seal_date_3.png","seal_date_4.png","seal_date_5.png","seal_date_6.png","seal_date_7.png","seal_date_8.png","seal_date_9.png"],
              day_en_array: ["seal_date_0.png","seal_date_1.png","seal_date_2.png","seal_date_3.png","seal_date_4.png","seal_date_5.png","seal_date_6.png","seal_date_7.png","seal_date_8.png","seal_date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 56,
              src: 'seal_separator.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 47,
              font_array: ["seal_header_0.png","seal_header_1.png","seal_header_2.png","seal_header_3.png","seal_header_4.png","seal_header_5.png","seal_header_6.png","seal_header_7.png","seal_header_8.png","seal_header_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'seal_degree.png',
              unit_tc: 'seal_degree.png',
              unit_en: 'seal_degree.png',
              negative_image: 'seal_minus.png',
              invalid_image: 'seal_missing.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 51,
              y: 47,
              image_array: ["seal_weather_00.png","seal_weather_01.png","seal_weather_02.png","seal_weather_03.png","seal_weather_04.png","seal_weather_05.png","seal_weather_06.png","seal_weather_07.png","seal_weather_08.png","seal_weather_09.png","seal_weather_10.png","seal_weather_11.png","seal_weather_12.png","seal_weather_13.png","seal_weather_14.png","seal_weather_15.png","seal_weather_16.png","seal_weather_17.png","seal_weather_18.png","seal_weather_19.png","seal_weather_20.png","seal_weather_21.png","seal_weather_22.png","seal_weather_23.png","seal_weather_24.png","seal_weather_25.png","seal_weather_26.png","seal_weather_27.png","seal_weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 307,
              y: 47,
              font_array: ["seal_header_0.png","seal_header_1.png","seal_header_2.png","seal_header_3.png","seal_header_4.png","seal_header_5.png","seal_header_6.png","seal_header_7.png","seal_header_8.png","seal_header_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'seal_missing.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'seal_aod_background.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 37,
              hour_startY: 154,
              hour_array: ["seal_aod_digit_0.png","seal_aod_digit_1.png","seal_aod_digit_2.png","seal_aod_digit_3.png","seal_aod_digit_4.png","seal_aod_digit_5.png","seal_aod_digit_6.png","seal_aod_digit_7.png","seal_aod_digit_8.png","seal_aod_digit_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 208,
              minute_startY: 154,
              minute_array: ["seal_aod_digit_0.png","seal_aod_digit_1.png","seal_aod_digit_2.png","seal_aod_digit_3.png","seal_aod_digit_4.png","seal_aod_digit_5.png","seal_aod_digit_6.png","seal_aod_digit_7.png","seal_aod_digit_8.png","seal_aod_digit_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 187,
              y: 176,
              src: 'seal_aod_colon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_3.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_4.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_5.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_6.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_7.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_8.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_9.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_10.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_11.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_3.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_4.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_5.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_6.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_7.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_8.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_9.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_10.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_11.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}