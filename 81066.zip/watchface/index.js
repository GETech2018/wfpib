﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_spo2_text_text_img = ''
        let idle_spo2_text_separator_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_second_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 320,
              h: 380,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 134,
              y: 65,
              image_array: ["Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png","Batt_06.png","Batt_07.png","Batt_08.png","Batt_09.png","Batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 177,
              font_array: ["Date0.png","Date1.png","Date2.png","Date3.png","Date4.png","Date5.png","Date6.png","Date7.png","Date8.png","Date9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 197,
              y: 177,
              week_en: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_tc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_sc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 231,
              day_startY: 179,
              day_sc_array: ["Date0.png","Date1.png","Date2.png","Date3.png","Date4.png","Date5.png","Date6.png","Date7.png","Date8.png","Date9.png"],
              day_tc_array: ["Date0.png","Date1.png","Date2.png","Date3.png","Date4.png","Date5.png","Date6.png","Date7.png","Date8.png","Date9.png"],
              day_en_array: ["Date0.png","Date1.png","Date2.png","Date3.png","Date4.png","Date5.png","Date6.png","Date7.png","Date8.png","Date9.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 310,
              font_array: ["Date0.png","Date1.png","Date2.png","Date3.png","Date4.png","Date5.png","Date6.png","Date7.png","Date8.png","Date9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icon_Steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_Hour.png',
              hour_centerX: 160,
              hour_centerY: 195,
              hour_posX: 14,
              hour_posY: 204,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_Min.png',
              minute_centerX: 160,
              minute_centerY: 195,
              minute_posX: 14,
              minute_posY: 204,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 144,
              y: 181,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 320,
              h: 380,
              src: 'main9.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 203,
              y: 222,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 102,
              y: 223,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 331,
              font_array: ["Act_Small_0.png","Act_Small_1.png","Act_Small_2.png","Act_Small_3.png","Act_Small_4.png","Act_Small_5.png","Act_Small_6.png","Act_Small_7.png","Act_Small_8.png","Act_Small_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_Symbo.png',
              unit_tc: 'Batt_Symbo.png',
              unit_en: 'Batt_Symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 330,
              src: 'icon_O2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 333,
              font_array: ["Act_Small_0.png","Act_Small_1.png","Act_Small_2.png","Act_Small_3.png","Act_Small_4.png","Act_Small_5.png","Act_Small_6.png","Act_Small_7.png","Act_Small_8.png","Act_Small_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Batt_Symbo.png',
              unit_tc: 'Batt_Symbo.png',
              unit_en: 'Batt_Symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 134,
              y: 367,
              image_array: ["Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png","Batt_06.png","Batt_07.png","Batt_08.png","Batt_09.png","Batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 165,
              font_array: ["Date0.png","Date1.png","Date2.png","Date3.png","Date4.png","Date5.png","Date6.png","Date7.png","Date8.png","Date9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 232,
              y: 164,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 131,
              font_array: ["Act_Small_0.png","Act_Small_1.png","Act_Small_2.png","Act_Small_3.png","Act_Small_4.png","Act_Small_5.png","Act_Small_6.png","Act_Small_7.png","Act_Small_8.png","Act_Small_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 208,
              y: 129,
              src: 'icon_dis.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 97,
              font_array: ["Act_Small_0.png","Act_Small_1.png","Act_Small_2.png","Act_Small_3.png","Act_Small_4.png","Act_Small_5.png","Act_Small_6.png","Act_Small_7.png","Act_Small_8.png","Act_Small_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 285,
              y: 78,
              src: 'icon_cal.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 14,
              y: 323,
              w: 99,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 0,
              y: 125,
              font_array: ["Time_Sec_0.png","Time_Sec_1.png","Time_Sec_2.png","Time_Sec_3.png","Time_Sec_4.png","Time_Sec_5.png","Time_Sec_6.png","Time_Sec_7.png","Time_Sec_8.png","Time_Sec_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 8,
              y: 81,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 72,
              y: 123,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 128,
              month_startY: 83,
              month_sc_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_tc_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_en_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 31,
              y: 39,
              week_en: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_tc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_sc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 139,
              day_startY: 5,
              day_sc_array: ["Date0.png","Date1.png","Date2.png","Date3.png","Date4.png","Date5.png","Date6.png","Date7.png","Date8.png","Date9.png"],
              day_tc_array: ["Date0.png","Date1.png","Date2.png","Date3.png","Date4.png","Date5.png","Date6.png","Date7.png","Date8.png","Date9.png"],
              day_en_array: ["Date0.png","Date1.png","Date2.png","Date3.png","Date4.png","Date5.png","Date6.png","Date7.png","Date8.png","Date9.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 7,
              y: 166,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 4,
              y: 190,
              src: 'icon_Steps.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 13,
              am_y: 275,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 13,
              pm_y: 275,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 173,
              minute_startY: 247,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 51,
              hour_startY: 247,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 248,
              src: 'Time_Dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 277,
              second_startY: 284,
              second_array: ["Time_Sec_0.png","Time_Sec_1.png","Time_Sec_2.png","Time_Sec_3.png","Time_Sec_4.png","Time_Sec_5.png","Time_Sec_6.png","Time_Sec_7.png","Time_Sec_8.png","Time_Sec_9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -1,
              y: 208,
              src: 'Top_Sec.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_Hour.png',
              hour_centerX: 160,
              hour_centerY: 195,
              hour_posX: 14,
              hour_posY: 204,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_Min.png',
              minute_centerX: 160,
              minute_centerY: 195,
              minute_posX: 14,
              minute_posY: 204,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_Sec.png',
              second_centerX: 160,
              second_centerY: 195,
              second_posX: 14,
              second_posY: 198,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}