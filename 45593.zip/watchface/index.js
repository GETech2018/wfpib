﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//////Vibration feedback for buttons
const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
let timer_StopVibrate = null;

function makeVibrate(level = 1) {
  stopVibrate();

  //The values are used as follows: 1 for buttons, 2 for open settings menu, 3 for close settings menu
  const levelToScene = {
    1: 26,
    2: 27,
    3: 29
  };

  let scene = levelToScene[level] || 25;
  let stopDelay = scene > 25 ? 1300 : 50;

  vibrate.scene = scene;
  vibrate.start();

  timer_StopVibrate = timer.createTimer(stopDelay, 0, stopVibrate, {});
}

function stopVibrate() {
  vibrate.stop();
  if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
  timer_StopVibrate = null;
}

//////Watchface Language Sets (Uppercase)
const watchfaceLangs = {
  EN:{
    WEEKDAYS_SHORT: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
    WEEKDAYS_FULL:  ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"],
    MONTHS_SHORT:   ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"],
    MONTHS_FULL:    ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"],

    STEPSLABEL: "STEPS",
    BATTERYLABEL: "BATTERY",
    HEARTRATELABEL: "BPM",
    CALORIESLABEL: "CALORIES",
  },

  ES:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MIÉ", "JUE", "VIE", "SÁB", "DOM"],
    WEEKDAYS_FULL:  ["LUNES", "MARTES", "MIÉRCOLES", "JUEVES", "VIERNES", "SÁBADO", "DOMINGO"],
    MONTHS_SHORT:   ["ENE", "FEB", "MAR", "ABR", "MAY", "JUN", "JUL", "AGO", "SEP", "OCT", "NOV", "DIC"],
    MONTHS_FULL:    ["ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"],

    STEPSLABEL: "PASOS",
    BATTERYLABEL: "BATERÍA",
    HEARTRATELABEL: "BPM",
    CALORIESLABEL: "CALORÍAS",
  },

  IT:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MER", "GIO", "VEN", "SAB", "DOM"],
    WEEKDAYS_FULL:  ["LUNEDÌ", "MARTEDÌ", "MERCOLEDÌ", "GIOVEDÌ", "VENERDÌ", "SABATO", "DOMENICA"],
    MONTHS_SHORT:   ["GEN", "FEB", "MAR", "APR", "MAG", "GIU", "LUG", "AGO", "SET", "OTT", "NOV", "DIC"],
    MONTHS_FULL:    ["GENNAIO", "FEBBRAIO", "MARZO", "APRILE", "MAGGIO", "GIUGNO", "LUGLIO", "AGOSTO", "SETTEMBRE", "OTTOBRE", "NOVEMBRE", "DICEMBRE"],

    STEPSLABEL: "PASSI",
    BATTERYLABEL: "BATTERIA",
    HEARTRATELABEL: "BPM",
    CALORIESLABEL: "CALORIE",
  },

  PT:{
    WEEKDAYS_SHORT: ["SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM"],
    WEEKDAYS_FULL:  ["SEGUNDA-FEIRA", "TERÇA-FEIRA", "QUARTA-FEIRA", "QUINTA-FEIRA", "SEXTA-FEIRA", "SÁBADO", "DOMINGO"],
    MONTHS_SHORT:   ["JAN", "FEV", "MAR", "ABR", "MAI", "JUN", "JUL", "AGO", "SET", "OUT", "NOV", "DEZ"],
    MONTHS_FULL:    ["JANEIRO", "FEVEREIRO", "MARÇO", "ABRIL", "MAIO", "JUNHO", "JULHO", "AGOSTO", "SETEMBRO", "OUTUBRO", "NOVEMBRO", "DEZEMBRO"],

    STEPSLABEL: "PASSOS",
    BATTERYLABEL: "BATERIA",
    HEARTRATELABEL: "BPM",
    CALORIESLABEL: "CALORIAS",
  },

  FR:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MER", "JEU", "VEN", "SAM", "DIM"],
    WEEKDAYS_FULL:  ["LUNDI", "MARDI", "MERCREDI", "JEUDI", "VENDREDI", "SAMEDI", "DIMANCHE"],
    MONTHS_SHORT:   ["JAN", "FÉV", "MAR", "AVR", "MAI", "JUN", "JUI", "AOÛ", "SEP", "OCT", "NOV", "DÉC"],
    MONTHS_FULL:    ["JANVIER", "FÉVRIER", "MARS", "AVRIL", "MAI", "JUIN", "JUILLET", "AOÛT", "SEPTEMBRE", "OCTOBRE", "NOVEMBRE", "DÉCEMBRE"],

    STEPSLABEL: "PAS",
    BATTERYLABEL: "BATTERIE",
    HEARTRATELABEL: "BPM",
    CALORIESLABEL: "CALORIES",
  },

  DE:{
    WEEKDAYS_SHORT: ["MON", "DIE", "MIT", "DON", "FRE", "SAM", "SON"],
    WEEKDAYS_FULL:  ["MONTAG", "DIENSTAG", "MITTWOCH", "DONNERSTAG", "FREITAG", "SAMSTAG", "SONNTAG"],
    MONTHS_SHORT:   ["JAN", "FEB", "MÄR", "APR", "MAI", "JUN", "JUL", "AUG", "SEP", "OKT", "NOV", "DEZ"],
    MONTHS_FULL:    ["JANUAR", "FEBRUAR", "MÄRZ", "APRIL", "MAI", "JUNI", "JULI", "AUGUST", "SEPTEMBER", "OKTOBER", "NOVEMBER", "DEZEMBER"],

    STEPSLABEL: "SCHRITTE",
    BATTERYLABEL: "BATTERIE",
    HEARTRATELABEL: "BPM",
    CALORIESLABEL: "KALORIEN",
  },
};
let currWatchfaceLang;
let currLangCode;

const colorHEXset = [
    0xFF74C0FC, // Blue
    0xFF66E6FF, // Cyan
    0xFF63E6BE, // Turquoise
    0xFFAEE66D, // Lime
    0xFF8BE78B, // Green
    0xFFFFEB66, // Yellow
    0xFFFFA94D, // Orange
    0xFFFF6B6B, // Red
    0xFFF58AB5, // Pink
    0xFFA68AD9, // Violet
    0xFFC1C9E5, // Gray
    0xFFFFFFFF, // White
];

let colorsIndex = 0;
let currHEXColor = colorHEXset[colorsIndex];

let isEditModMenuVisible = false;

let weatherModColorStateSet = [ "ONLY_ICON", "ONLY_TEMP", "BOTH", "NONE" ];
let weatherModColorStateIndex = 0;
let currWeatherModColorState = weatherModColorStateSet[weatherModColorStateIndex];

let minutesColorStateSet = [ "NONE", "ALL", "ONLY_CURR", "ONLY_PREVNEXT" ];
let minutesColorStateIndex = 1;
let currMinutesColorState = minutesColorStateSet[minutesColorStateIndex];

let isHourClockColored = false;

let dateColorStateSet = [ "NONE", "ONLY_DOW", "ONLY_DATENUMBER", "ALL" ];
let dateColorStateIndex = 0;
let currDateColorState = dateColorStateSet[dateColorStateIndex];
        // end user_functions.js

        let normal_background_bg = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_time_second_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_day_month_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time_hour = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SF-Compact-Rounded-Semibold.ttf; FontSize: 33; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 430,
              y: 512,
              w: 39,
              h: 39,
              text_size: 33,
              char_space: 4,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Semibold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

//////Function to detect current language from system
function detectLanguage() {
    const zeppAvailableLangs = [
        "ZH", // 0  Chinese (Simplified)
        "ZH", // 1  Chinese (Traditional)
        "EN", // 2  English
        "ES", // 3  Spanish
        "RU", // 4  Russian
        "KO", // 5  Korean
        "FR", // 6  French
        "DE", // 7  German
        "ID", // 8  Indonesian
        "PL", // 9  Polish
        "IT", // 10 Italian
        "JA", // 11 Japanese
        "TH", // 12 Thai
        "AR", // 13 Arabic
        "VI", // 14 Vietnamese
        "PT", // 15 Portuguese (Portugal)
        "NL", // 16 Dutch
        "TR", // 17 Turkish
        "UK", // 18 Ukrainian
        "HE", // 19 Hebrew
        "PT", // 20 Portuguese (Brazil)
        "RO", // 21 Romanian
        "CS", // 22 Czech
        "EL", // 23 Greek
        "SR", // 24 Serbian
        "CA", // 25 Catalan
        "FI", // 26 Finnish
        "NO", // 27 Norwegian
        "DA", // 28 Danish
        "SV", // 29 Swedish
        "HU", // 30 Hungarian
        "MS", // 31 Malay
        "SK", // 32 Slovak
        "HI"  // 33 Hindi
    ];
    let langCode = zeppAvailableLangs[hmSetting.getLanguage()]; //Get current language on watch

    currLangCode = watchfaceLangs[langCode] ? langCode : "EN";
    currWatchfaceLang = watchfaceLangs[currLangCode];
}
detectLanguage();

const bgColor = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 0,
    y: 0,
    w: 432,
    h: 514,
    color: 0xFF74C0FC,
    show_level: hmUI.show_level.ONLY_NORMAL,
})

let hourNoColorOverlay = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'OVERLAY_HR.png',
    x: 0,
    y: 0,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let minutesNoColorOverlay = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'OVERLAY_MINS_NONE.png',
    x: 0,
    y: 0,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
minutesNoColorOverlay.setProperty(hmUI.prop.VISIBLE, false);

let weatherNoColorOverlay = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'OVERLAY_WEATHER.png',
    x: 0,
    y: 0,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
weatherNoColorOverlay.setProperty(hmUI.prop.VISIBLE, false);

let bgCounting = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'BG.png',
    x: 0,
    y: 0,
    w: 432,
    h: 514,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 184,
              hour_array: ["HOUR_0.png","HOUR_1.png","HOUR_2.png","HOUR_3.png","HOUR_4.png","HOUR_5.png","HOUR_6.png","HOUR_7.png","HOUR_8.png","HOUR_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 133,
              y: 0,
              w: 166,
              h: 33,
              text_size: 22,
              char_space: 0,
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 55,
              y: 373,
              w: 166,
              h: 55,
              text_size: 33,
              char_space: 4,
              font: 'fonts/SF-Compact-Rounded-Semibold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 55,
              y: 409,
              w: 166,
              h: 55,
              text_size: 33,
              char_space: 4,
              font: 'fonts/SF-Compact-Rounded-Semibold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 56,
              y: 58,
              image_array: ["WEATHERICON_1.png","WEATHERICON_2.png","WEATHERICON_3.png","WEATHERICON_4.png","WEATHERICON_5.png","WEATHERICON_6.png","WEATHERICON_7.png","WEATHERICON_8.png","WEATHERICON_9.png","WEATHERICON_10.png","WEATHERICON_11.png","WEATHERICON_12.png","WEATHERICON_13.png","WEATHERICON_14.png","WEATHERICON_15.png","WEATHERICON_16.png","WEATHERICON_17.png","WEATHERICON_18.png","WEATHERICON_19.png","WEATHERICON_20.png","WEATHERICON_21.png","WEATHERICON_22.png","WEATHERICON_23.png","WEATHERICON_24.png","WEATHERICON_25.png","WEATHERICON_26.png","WEATHERICON_27.png","WEATHERICON_28.png","WEATHERICON_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 55,
              y: 99,
              w: 166,
              h: 55,
              text_size: 33,
              char_space: 4,
              font: 'fonts/SF-Compact-Rounded-Semibold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
normal_background_bg.setAlpha(0);

let firstDigit_xpos = 262;
let secondDigit_xpos = 304;
let prevMin_ypos = 51;
let currMin_ypos = 206;
let nextMin_ypos = 361;

let prevMinDigits = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
    x: firstDigit_xpos,
    y: prevMin_ypos,
    font_array: ["MINS_0.png", "MINS_1.png", "MINS_2.png", "MINS_3.png", "MINS_4.png", "MINS_5.png", "MINS_6.png", "MINS_7.png", "MINS_8.png", "MINS_9.png"],
    padding: false,
    h_space: 0,
    text: "00",
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let currMinDigits = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
    x: firstDigit_xpos,
    y: currMin_ypos,
    font_array: ["MINS_0.png", "MINS_1.png", "MINS_2.png", "MINS_3.png", "MINS_4.png", "MINS_5.png", "MINS_6.png", "MINS_7.png", "MINS_8.png", "MINS_9.png"],
    padding: false,
    h_space: 0,
    text: "01",
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let nextMinDigits = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
    x: firstDigit_xpos,
    y: nextMin_ypos,
    font_array: ["MINS_0.png", "MINS_1.png", "MINS_2.png", "MINS_3.png", "MINS_4.png", "MINS_5.png", "MINS_6.png", "MINS_7.png", "MINS_8.png", "MINS_9.png"],
    padding: false,
    h_space: 0,
    text: "02",
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let minsOverlay = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'MINS_OVERLAY.png',
    x: 0,
    y: 0,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

//AOD Screen
let bgColorAOD = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 0,
    y: 0,
    w: 432,
    h: 514,
    color: '0xFF74C0FC',
    show_level: hmUI.show_level.ONLY_AOD,
});

let prevMinDigitsAOD = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
    x: firstDigit_xpos,
    y: prevMin_ypos,
    font_array: ["MINS_0.png", "MINS_1.png", "MINS_2.png", "MINS_3.png", "MINS_4.png", "MINS_5.png", "MINS_6.png", "MINS_7.png", "MINS_8.png", "MINS_9.png"],
    padding: false,
    h_space: 0,
    text: "00",
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_AOD,
});

let currMinDigitsAOD = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
    x: firstDigit_xpos,
    y: currMin_ypos,
    font_array: ["MINS_0.png", "MINS_1.png", "MINS_2.png", "MINS_3.png", "MINS_4.png", "MINS_5.png", "MINS_6.png", "MINS_7.png", "MINS_8.png", "MINS_9.png"],
    padding: false,
    h_space: 0,
    text: "01",
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_AOD,
});

let nextMinDigitsAOD = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
    x: firstDigit_xpos,
    y: nextMin_ypos,
    font_array: ["MINS_0.png", "MINS_1.png", "MINS_2.png", "MINS_3.png", "MINS_4.png", "MINS_5.png", "MINS_6.png", "MINS_7.png", "MINS_8.png", "MINS_9.png"],
    padding: false,
    h_space: 0,
    text: "02",
    align_h: hmUI.align.LEFT,
    show_level: hmUI.show_level.ONLY_AOD,
});

let bgCountingAOD = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    w: 432,
    h: 514,
    src: 'BG_AOD.png',
    show_level: hmUI.show_level.ONLY_AOD,
});

function updateMins(){
    let currMins = timeSensor.minute;
    let prevMins = (currMins - 1 + 60) % 60;
    let nextMins = (currMins + 1) % 60;

    //////Format digits
    let prevMinstxt = prevMins.toString().padStart(2, "0");
    let currMinstxt = currMins.toString().padStart(2, "0");
    let nextMinstxt = nextMins.toString().padStart(2, "0");

    //////Update digits
    //Normal
    prevMinDigits.setProperty(hmUI.prop.TEXT, prevMinstxt);
    currMinDigits.setProperty(hmUI.prop.TEXT, currMinstxt);
    nextMinDigits.setProperty(hmUI.prop.TEXT, nextMinstxt);
    //AOD
    prevMinDigitsAOD.setProperty(hmUI.prop.TEXT, prevMinstxt);
    currMinDigitsAOD.setProperty(hmUI.prop.TEXT, currMinstxt);
    nextMinDigitsAOD.setProperty(hmUI.prop.TEXT, nextMinstxt);
}
updateMins();
            // end user_script.js


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 184,
              hour_array: ["HOUR_0.png","HOUR_1.png","HOUR_2.png","HOUR_3.png","HOUR_4.png","HOUR_5.png","HOUR_6.png","HOUR_7.png","HOUR_8.png","HOUR_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

idle_background_bg.setAlpha(0);
            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 33,
              y: 39,
              w: 166,
              h: 111,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                settingsMenu(true)
makeVibrate(2)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 33,
              y: 194,
              w: 166,
              h: 111,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 33,
              y: 354,
              w: 166,
              h: 111,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 255,
              y: 39,
              w: 166,
              h: 111,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 255,
              y: 194,
              w: 166,
              h: 111,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 255,
              y: 354,
              w: 166,
              h: 111,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'MusicCommonScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

//////Watchface Menu
//Main menu
let prevColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 0,
    y: 66,
    w: 134,
    h: 382,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/EDGEBTN_PREV_PRESSED.png',
    normal_src: 'settings/EDGEBTN_PREV_NORMAL.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    click_func: (button_widget) => {
    prevColor()
    makeVibrate(1)
    }, // end func
}); // end button

let nextColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 298,
    y: 66,
    w: 134,
    h: 382,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/EDGEBTN_NEXT_PRESSED.png',
    normal_src: 'settings/EDGEBTN_NEXT_NORMAL.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    click_func: (button_widget) => {
    nextColor()
    makeVibrate(1)
    }, // end func
}); // end button

let editStylebtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 171,
    y: 282,
    w: 90,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/EDIT_BUTTON_PRESSED.png',
    normal_src: 'settings/EDIT_BUTTON_NORMAL.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    click_func: (button_widget) => {
    editModMenu(true)
    makeVibrate(2)
    }, // end func
}); // end button

let Confirmbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 156,
    y: 385,
    w: 120,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_CONFIRM_PRESSED.png',
    normal_src: 'settings/BTN_CONFIRM_NORMAL.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    click_func: (button_widget) => {
    settingsMenu(false)
    makeVibrate(3)
    }, // end func
}); // end button

//Edit menu
let styleClockHourbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 30,
    y: 197,
    w: 200,
    h: 120,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'BUTTON.png',
    normal_src: 'BUTTON.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    click_func: (button_widget) => {
    styleClockHour()
    makeVibrate(1)
    }, // end func
}); // end button

let styleClockMinsbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 250,
    y: 197,
    w: 170,
    h: 120,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'BUTTON.png',
    normal_src: 'BUTTON.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    click_func: (button_widget) => {
    styleClockMins()
    makeVibrate(1)
    }, // end func
}); // end button

let styleWeatherModbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 30,
    y: 35,
    w: 200,
    h: 120,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'BUTTON.png',
    normal_src: 'BUTTON.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    click_func: (button_widget) => {
    styleWeatherModule()
    makeVibrate(1)
    }, // end func
}); // end button

let styleCalendarModbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 30,
    y: 359,
    w: 200,
    h: 120,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'BUTTON.png',
    normal_src: 'BUTTON.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    click_func: (button_widget) => {
    styleCalendarModule()
    makeVibrate(1)
    }, // end func
}); // end button

let closeEditbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 171,
    y: 385,
    w: 90,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/CLOSE_BUTTON_PRESSED.png',
    normal_src: 'settings/CLOSE_BUTTON_NORMAL.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    click_func: (button_widget) => {
    editModMenu(false)
    makeVibrate(2)
    }, // end func
}); // end button

function prevColor(){
    colorsIndex = (colorsIndex - 1 + colorHEXset.length) % colorHEXset.length;
    currHEXColor = colorHEXset[colorsIndex];
    updateWatchface();
}

function nextColor(){
    colorsIndex = (colorsIndex + 1) % colorHEXset.length;
    currHEXColor = colorHEXset[colorsIndex];
    updateWatchface();
}

function styleClockHour(){
    isHourClockColored = !isHourClockColored;

    editStyleToast = isHourClockColored ? "Hour Digits Style: Colored" : "Hour Digits Style: No Colored";
    hmUI.showToast({text: editStyleToast});

    updateWatchface();
}

function styleClockMins(){
    minutesColorStateIndex = (minutesColorStateIndex + 1) % minutesColorStateSet.length;
    currMinutesColorState = minutesColorStateSet[minutesColorStateIndex];

    switch (currMinutesColorState){
        case "ONLY_CURR":
            editStyleToast = "Mins Digits Style: Current Min";
            break;
        case "ONLY_PREVNEXT":
            editStyleToast = "Mins Digits Style: Prev and Next";
            break;
        case "ALL":
            editStyleToast = "Mins Digits Style: All";
            break;
        case "NONE":
            editStyleToast = "Mins Digits Style: None";
            break;
    }
    hmUI.showToast({text: editStyleToast});

    updateWatchface();
}

function styleWeatherModule(){
    weatherModColorStateIndex = (weatherModColorStateIndex + 1) % weatherModColorStateSet.length;
    currWeatherModColorState = weatherModColorStateSet[weatherModColorStateIndex];

    switch (currWeatherModColorState){
        case "ONLY_ICON":
            editStyleToast = "Weather Style: Only Icon";
            break;
        case "ONLY_TEMP":
            editStyleToast = "Weather Style: Only Temp";
            break;
        case "BOTH":
            editStyleToast = "Weather Style: All";
            break;
        case "NONE":
            editStyleToast = "Weather Style: None";
            break;
    }
    hmUI.showToast({text: editStyleToast});

    updateWatchface();
}

function styleCalendarModule(){
    dateColorStateIndex = (dateColorStateIndex + 1) % dateColorStateSet.length;
    currDateColorState = dateColorStateSet[dateColorStateIndex];

    switch (currDateColorState){
        case "NONE":
            editStyleToast = "Date Style: None";
            break;
        case "ONLY_DOW":
            editStyleToast = "Date Style: Only Weekday";
            break;
        case "ONLY_DATENUMBER":
            editStyleToast = "Date Style: Only Day";
            break;
        case "ALL":
            editStyleToast = "Date Style: All";
            break;
    }
    hmUI.showToast({text: editStyleToast});

    updateWatchface();
}

function updateWatchface(){
    //Set edit button visible based on current chosen color
    if (!isEditModMenuVisible){
        editStylebtn.setProperty(hmUI.prop.VISIBLE, colorsIndex !== 11 ? true : false);
    }

    //General watchface color
    bgColor.setProperty(hmUI.prop.COLOR, currHEXColor);

    //Save color for AOD
    hmFS.SysProSetInt('countingColorAOD', currHEXColor);

    //Clock hour style
    hourNoColorOverlay.setProperty(hmUI.prop.VISIBLE, !isHourClockColored);

    //Clock mins style
    let currMinutesOverlayIMG;
    let isMinutesOverlayVisible;
    switch (currMinutesColorState){
        case "ONLY_CURR":
            currMinutesOverlayIMG = "OVERLAY_MINS_ONLYCURR.png";
            isMinutesOverlayVisible = true;
            break;
        case "ONLY_PREVNEXT":
            currMinutesOverlayIMG = "OVERLAY_MINS_ONLYPREVNEXT.png";
            isMinutesOverlayVisible = true;
            break;
        case "ALL":
            currMinutesOverlayIMG = "OVERLAY_MINS_NONE.png";
            isMinutesOverlayVisible = false;
            break;
        case "NONE":
            currMinutesOverlayIMG = "OVERLAY_MINS_NONE.png";
            isMinutesOverlayVisible = true;
            break;
    }
    minutesNoColorOverlay.setProperty(hmUI.prop.SRC, currMinutesOverlayIMG);
    minutesNoColorOverlay.setProperty(hmUI.prop.VISIBLE, isMinutesOverlayVisible);

    //Weather module style
    let weatherModuleColor;
    let isColoredWeatherIcon;
    switch (currWeatherModColorState){
        case "ONLY_ICON":
            isColoredWeatherIcon = true;
            weatherModuleColor = 0xFFFFFFFF;
            break;
        case "ONLY_TEMP":
            isColoredWeatherIcon = false;
            weatherModuleColor = currHEXColor;
            break;
        case "BOTH":
            isColoredWeatherIcon = true;
            weatherModuleColor = currHEXColor;
            break;
        case "NONE":
            isColoredWeatherIcon = false;
            weatherModuleColor = 0xFFFFFFFF;
            break;
    }
    weatherNoColorOverlay.setProperty(hmUI.prop.VISIBLE, !isColoredWeatherIcon);
    normal_temperature_current_text_font.setProperty(hmUI.prop.MORE, {
        x: 55,
        y: 99,
        w: 166,
        h: 55,
        text_size: 33,
        char_space: 4,
        font: 'fonts/SF-Compact-Rounded-Semibold.ttf',
        color: weatherModuleColor,
        line_space: 0,
        align_v: hmUI.align.TOP,
        text_style: hmUI.text_style.ELLIPSIS,
        align_h: hmUI.align.LEFT,
        unit_type: 1,
        type: hmUI.data_type.WEATHER_CURRENT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    //Calendar module style
    let currDOWcolor;
    let currDateNumberColor;
    switch (currDateColorState){
        case "NONE":
            currDOWcolor = 0XFFFFFFFF;
            currDateNumberColor = 0XFFFFFFFF;
            break;
        case "ONLY_DOW":
            currDOWcolor = currHEXColor;
            currDateNumberColor = 0XFFFFFFFF;
            break;
        case "ONLY_DATENUMBER":
            currDOWcolor = 0XFFFFFFFF;
            currDateNumberColor = currHEXColor;
            break;
        case "ALL":
            currDOWcolor = currHEXColor;
            currDateNumberColor = currHEXColor;
            break;
    }
    normal_dow_text_font.setProperty(hmUI.prop.MORE, {
        x: 55,
        y: 373,
        w: 166,
        h: 55,
        text_size: 33,
        char_space: 4,
        font: 'fonts/SF-Compact-Rounded-Semibold.ttf',
        color: currDOWcolor,
        line_space: 0,
        align_v: hmUI.align.TOP,
        text_style: hmUI.text_style.ELLIPSIS,
        align_h: hmUI.align.LEFT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
    normal_day_month_font.setProperty(hmUI.prop.MORE, {
        x: 55,
        y: 409,
        w: 166,
        h: 55,
        text_size: 33,
        char_space: 4,
        font: 'fonts/SF-Compact-Rounded-Semibold.ttf',
        color: currDateNumberColor,
        line_space: 0,
        align_v: hmUI.align.TOP,
        text_style: hmUI.text_style.ELLIPSIS,
        align_h: hmUI.align.LEFT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
}

let watchfaceButtons = [ Button_1, Button_2, Button_3, Button_4, Button_5, Button_6 ];
let settingMenuLayout = [ prevColorbtn, nextColorbtn, editStylebtn, Confirmbtn ];
let editModulesMenuLayout = [ styleWeatherModbtn, styleClockHourbtn, styleClockMinsbtn, styleCalendarModbtn, closeEditbtn ];

function editModMenu(isVisible){
    settingMenuLayout.forEach(element => element.setProperty(hmUI.prop.VISIBLE, !isVisible));
    editModulesMenuLayout.forEach(element => element.setProperty(hmUI.prop.VISIBLE, isVisible));
    isEditModMenuVisible = isVisible;
}

function settingsMenu(isVisible){
    watchfaceButtons.forEach(element => element.setProperty(hmUI.prop.VISIBLE, !isVisible));
    settingMenuLayout.forEach(element => element.setProperty(hmUI.prop.VISIBLE, isVisible));
}

editModMenu(false);
settingsMenu(false);

bgColorAOD.setProperty(hmUI.prop.COLOR, hmFS.SysProGetInt('countingColorAOD') ?? 0xFF74C0FC);
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute){
                updateMins();
              }

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = currWatchfaceLang.WEEKDAYS_SHORT[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();

                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');

                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '/' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '/' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };
            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

                console.log('pause_call.js');
                // start pause_call.js

editModMenu(false);
settingsMenu(false);
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}