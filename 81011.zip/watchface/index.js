﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_month = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        // Activity select change theme color
        let btnbackground = ''
        let backgroundnumber = 1
        let totalpictures = 8
        let cc = 0

        function click_Background() {
            if(backgroundnumber>=totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }
                if(backgroundnumber==3) {
                  UpdateBackgroundThree();
                }
                if(backgroundnumber==4) {
                  UpdateBackgroundFour();
                }
                if(backgroundnumber==5) {
                  UpdateBackgroundFive();
                }
                if(backgroundnumber==6) {
                  UpdateBackgroundSix();
                }
                if(backgroundnumber==7) {
                  UpdateBackgroundSeven();
                }
                if(backgroundnumber==8) {
                  UpdateBackgroundEight();
                }

    

            }
          if(backgroundnumber==1) hmUI.showToast({text: 'Theme color Gold'});
          if(backgroundnumber==2) hmUI.showToast({text: 'Theme color Pink'});
          if(backgroundnumber==3) hmUI.showToast({text: 'Theme color Green'});
          if(backgroundnumber==4) hmUI.showToast({text: 'Theme color Blue'});
          if(backgroundnumber==5) hmUI.showToast({text: 'Theme color Yellow'});
          if(backgroundnumber==6) hmUI.showToast({text: 'Theme color Orange'});
          if(backgroundnumber==7) hmUI.showToast({text: 'Theme color Red'});
          if(backgroundnumber==8) hmUI.showToast({text: 'Theme color White'});

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //color1
        function UpdateBackgroundOne(){
            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 130,
              minute_startY: 134,
              minute_array: ["Time_C1_01.png","Time_C1_02.png","Time_C1_03.png","Time_C1_04.png","Time_C1_05.png","Time_C1_06.png","Time_C1_07.png","Time_C1_08.png","Time_C1_09.png","Time_C1_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 37,
              hour_startY: 136,
              hour_array: ["Time_C1_01.png","Time_C1_02.png","Time_C1_03.png","Time_C1_04.png","Time_C1_05.png","Time_C1_06.png","Time_C1_07.png","Time_C1_08.png","Time_C1_09.png","Time_C1_10.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(backgroundnumber) + ".png");
                           

       }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Color2
        function UpdateBackgroundTwo(){
            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 130,
              minute_startY: 134,
              minute_array: ["Time_C2_01.png","Time_C2_02.png","Time_C2_03.png","Time_C2_04.png","Time_C2_05.png","Time_C2_06.png","Time_C2_07.png","Time_C2_08.png","Time_C2_09.png","Time_C2_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 37,
              hour_startY: 136,
              hour_array: ["Time_C2_01.png","Time_C2_02.png","Time_C2_03.png","Time_C2_04.png","Time_C2_05.png","Time_C2_06.png","Time_C2_07.png","Time_C2_08.png","Time_C2_09.png","Time_C2_10.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(backgroundnumber) + ".png");


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Color3
        function UpdateBackgroundThree(){
            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 130,
              minute_startY: 134,
              minute_array: ["Time_C3_01.png","Time_C3_02.png","Time_C3_03.png","Time_C3_04.png","Time_C3_05.png","Time_C3_06.png","Time_C3_07.png","Time_C3_08.png","Time_C3_09.png","Time_C3_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 37,
              hour_startY: 136,
              hour_array: ["Time_C3_01.png","Time_C3_02.png","Time_C3_03.png","Time_C3_04.png","Time_C3_05.png","Time_C3_06.png","Time_C3_07.png","Time_C3_08.png","Time_C3_09.png","Time_C3_10.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(backgroundnumber) + ".png");


        }

//////////////////////////////////////////////////////////////////////////////////////////////////
        //Color4
        function UpdateBackgroundFour(){
            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 130,
              minute_startY: 134,
              minute_array: ["Time_C4_01.png","Time_C4_02.png","Time_C4_03.png","Time_C4_04.png","Time_C4_05.png","Time_C4_06.png","Time_C4_07.png","Time_C4_08.png","Time_C4_09.png","Time_C4_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 37,
              hour_startY: 136,
              hour_array: ["Time_C4_01.png","Time_C4_02.png","Time_C4_03.png","Time_C4_04.png","Time_C4_05.png","Time_C4_06.png","Time_C4_07.png","Time_C4_08.png","Time_C4_09.png","Time_C4_10.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(backgroundnumber) + ".png");


        }

//////////////////////////////////////////////////////////////////////////////////////////////////
        //Color5
        function UpdateBackgroundFive(){
            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 130,
              minute_startY: 134,
              minute_array: ["Time_C5_01.png","Time_C5_02.png","Time_C5_03.png","Time_C5_04.png","Time_C5_05.png","Time_C5_06.png","Time_C5_07.png","Time_C5_08.png","Time_C5_09.png","Time_C5_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 37,
              hour_startY: 136,
              hour_array: ["Time_C5_01.png","Time_C5_02.png","Time_C5_03.png","Time_C5_04.png","Time_C5_05.png","Time_C5_06.png","Time_C5_07.png","Time_C5_08.png","Time_C5_09.png","Time_C5_10.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(backgroundnumber) + ".png");

        }

//////////////////////////////////////////////////////////////////////////////////////////////////
        //Color6
        function UpdateBackgroundSix(){
            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 130,
              minute_startY: 134,
              minute_array: ["Time_C6_01.png","Time_C6_02.png","Time_C6_03.png","Time_C6_04.png","Time_C6_05.png","Time_C6_06.png","Time_C6_07.png","Time_C6_08.png","Time_C6_09.png","Time_C6_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 37,
              hour_startY: 136,
              hour_array: ["Time_C6_01.png","Time_C6_02.png","Time_C6_03.png","Time_C6_04.png","Time_C6_05.png","Time_C6_06.png","Time_C6_07.png","Time_C6_08.png","Time_C6_09.png","Time_C6_10.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(backgroundnumber) + ".png");

        }

//////////////////////////////////////////////////////////////////////////////////////////////////
        //Color7
        function UpdateBackgroundSeven(){
            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 130,
              minute_startY: 134,
              minute_array: ["Time_C7_01.png","Time_C7_02.png","Time_C7_03.png","Time_C7_04.png","Time_C7_05.png","Time_C7_06.png","Time_C7_07.png","Time_C7_08.png","Time_C7_09.png","Time_C7_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 37,
              hour_startY: 136,
              hour_array: ["Time_C7_01.png","Time_C7_02.png","Time_C7_03.png","Time_C7_04.png","Time_C7_05.png","Time_C7_06.png","Time_C7_07.png","Time_C7_08.png","Time_C7_09.png","Time_C7_10.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(backgroundnumber) + ".png");

        }

//////////////////////////////////////////////////////////////////////////////////////////////////
        //Color8
        function UpdateBackgroundEight(){
            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 130,
              minute_startY: 134,
              minute_array: ["Time_C8_01.png","Time_C8_02.png","Time_C8_03.png","Time_C8_04.png","Time_C8_05.png","Time_C8_06.png","Time_C8_07.png","Time_C8_08.png","Time_C8_09.png","Time_C8_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 37,
              hour_startY: 136,
              hour_array: ["Time_C8_01.png","Time_C8_02.png","Time_C8_03.png","Time_C8_04.png","Time_C8_05.png","Time_C8_06.png","Time_C8_07.png","Time_C8_08.png","Time_C8_09.png","Time_C8_10.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(backgroundnumber) + ".png");

       }

//////////////////////////////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color change ( change hour , minute color )
        let btncolor = ''
        let colornumber = 1
        let totalcolors = 8
        let namecolor = ''

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "Time color Gold"
            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 130,
              minute_startY: 134,
              minute_array: ["Time_C1_01.png","Time_C1_02.png","Time_C1_03.png","Time_C1_04.png","Time_C1_05.png","Time_C1_06.png","Time_C1_07.png","Time_C1_08.png","Time_C1_09.png","Time_C1_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 37,
              hour_startY: 136,
              hour_array: ["Time_C1_01.png","Time_C1_02.png","Time_C1_03.png","Time_C1_04.png","Time_C1_05.png","Time_C1_06.png","Time_C1_07.png","Time_C1_08.png","Time_C1_09.png","Time_C1_10.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
}
if ( colornumber == 2) { namecolor = "Time color Pink"
            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 130,
              minute_startY: 134,
              minute_array: ["Time_C2_01.png","Time_C2_02.png","Time_C2_03.png","Time_C2_04.png","Time_C2_05.png","Time_C2_06.png","Time_C2_07.png","Time_C2_08.png","Time_C2_09.png","Time_C2_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 37,
              hour_startY: 136,
              hour_array: ["Time_C2_01.png","Time_C2_02.png","Time_C2_03.png","Time_C2_04.png","Time_C2_05.png","Time_C2_06.png","Time_C2_07.png","Time_C2_08.png","Time_C2_09.png","Time_C2_10.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
}
if ( colornumber == 3) { namecolor = "Time color Green"
            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 130,
              minute_startY: 134,
              minute_array: ["Time_C3_01.png","Time_C3_02.png","Time_C3_03.png","Time_C3_04.png","Time_C3_05.png","Time_C3_06.png","Time_C3_07.png","Time_C3_08.png","Time_C3_09.png","Time_C3_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 37,
              hour_startY: 136,
              hour_array: ["Time_C3_01.png","Time_C3_02.png","Time_C3_03.png","Time_C3_04.png","Time_C3_05.png","Time_C3_06.png","Time_C3_07.png","Time_C3_08.png","Time_C3_09.png","Time_C3_10.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
}
if ( colornumber == 4) { namecolor = "Time color Blue"
            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 130,
              minute_startY: 134,
              minute_array: ["Time_C4_01.png","Time_C4_02.png","Time_C4_03.png","Time_C4_04.png","Time_C4_05.png","Time_C4_06.png","Time_C4_07.png","Time_C4_08.png","Time_C4_09.png","Time_C4_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 37,
              hour_startY: 136,
              hour_array: ["Time_C4_01.png","Time_C4_02.png","Time_C4_03.png","Time_C4_04.png","Time_C4_05.png","Time_C4_06.png","Time_C4_07.png","Time_C4_08.png","Time_C4_09.png","Time_C4_10.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
}
if ( colornumber == 5) { namecolor = "Time color Yellow"
            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 130,
              minute_startY: 134,
              minute_array: ["Time_C5_01.png","Time_C5_02.png","Time_C5_03.png","Time_C5_04.png","Time_C5_05.png","Time_C5_06.png","Time_C5_07.png","Time_C5_08.png","Time_C5_09.png","Time_C5_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 37,
              hour_startY: 136,
              hour_array: ["Time_C5_01.png","Time_C5_02.png","Time_C5_03.png","Time_C5_04.png","Time_C5_05.png","Time_C5_06.png","Time_C5_07.png","Time_C5_08.png","Time_C5_09.png","Time_C5_10.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
}
if ( colornumber == 6) { namecolor = "Time color Orange"
            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 130,
              minute_startY: 134,
              minute_array: ["Time_C6_01.png","Time_C6_02.png","Time_C6_03.png","Time_C6_04.png","Time_C6_05.png","Time_C6_06.png","Time_C6_07.png","Time_C6_08.png","Time_C6_09.png","Time_C6_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 37,
              hour_startY: 136,
              hour_array: ["Time_C6_01.png","Time_C6_02.png","Time_C6_03.png","Time_C6_04.png","Time_C6_05.png","Time_C6_06.png","Time_C6_07.png","Time_C6_08.png","Time_C6_09.png","Time_C6_10.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
}
if ( colornumber == 7) { namecolor = "Time color Red"
            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 130,
              minute_startY: 134,
              minute_array: ["Time_C7_01.png","Time_C7_02.png","Time_C7_03.png","Time_C7_04.png","Time_C7_05.png","Time_C7_06.png","Time_C7_07.png","Time_C7_08.png","Time_C7_09.png","Time_C7_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 37,
              hour_startY: 136,
              hour_array: ["Time_C7_01.png","Time_C7_02.png","Time_C7_03.png","Time_C7_04.png","Time_C7_05.png","Time_C7_06.png","Time_C7_07.png","Time_C7_08.png","Time_C7_09.png","Time_C7_10.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
}
if ( colornumber == 8) { namecolor = "Time color White"
            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 130,
              minute_startY: 134,
              minute_array: ["Time_C8_01.png","Time_C8_02.png","Time_C8_03.png","Time_C8_04.png","Time_C8_05.png","Time_C8_06.png","Time_C8_07.png","Time_C8_08.png","Time_C8_09.png","Time_C8_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 37,
              hour_startY: 136,
              hour_array: ["Time_C8_01.png","Time_C8_02.png","Time_C8_03.png","Time_C8_04.png","Time_C8_05.png","Time_C8_06.png","Time_C8_07.png","Time_C8_08.png","Time_C8_09.png","Time_C8_10.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
}
hmUI.showToast({text: namecolor });

             //hmUI.showToast({text: "color " + parseInt(colornumber) });
             //normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");
                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 320,
              h: 380,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 332,
              font_array: ["YEAR_01.png","YEAR_02.png","YEAR_03.png","YEAR_04.png","YEAR_05.png","YEAR_06.png","YEAR_07.png","YEAR_08.png","YEAR_09.png","YEAR_10.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 344,
              font_array: ["YEAR_01.png","YEAR_02.png","YEAR_03.png","YEAR_04.png","YEAR_05.png","YEAR_06.png","YEAR_07.png","YEAR_08.png","YEAR_09.png","YEAR_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 310,
              font_array: ["YEAR_01.png","YEAR_02.png","YEAR_03.png","YEAR_04.png","YEAR_05.png","YEAR_06.png","YEAR_07.png","YEAR_08.png","YEAR_09.png","YEAR_10.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 310,
              font_array: ["YEAR_01.png","YEAR_02.png","YEAR_03.png","YEAR_04.png","YEAR_05.png","YEAR_06.png","YEAR_07.png","YEAR_08.png","YEAR_09.png","YEAR_10.png"],
              padding: true,
              h_space: 1,
              unit_sc: 'Batt_Symbo.png',
              unit_tc: 'Batt_Symbo.png',
              unit_en: 'Batt_Symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 174,
              y: 252,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 159,
              y: 251,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 199,
              y: 248,
              w: 67,
              h: 20,
              text_size: 14,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 149,
              y: 229,
              font_array: ["YEAR_01.png","YEAR_02.png","YEAR_03.png","YEAR_04.png","YEAR_05.png","YEAR_06.png","YEAR_07.png","YEAR_08.png","YEAR_09.png","YEAR_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'weather_symbo1.png',
              unit_tc: 'weather_symbo1.png',
              unit_en: 'weather_symbo1.png',
              negative_image: 'weather_symbo2.png',
              invalid_image: 'weather_symbo2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 229,
              font_array: ["YEAR_01.png","YEAR_02.png","YEAR_03.png","YEAR_04.png","YEAR_05.png","YEAR_06.png","YEAR_07.png","YEAR_08.png","YEAR_09.png","YEAR_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'weather_symbo1.png',
              unit_tc: 'weather_symbo1.png',
              unit_en: 'weather_symbo1.png',
              negative_image: 'weather_symbo2.png',
              invalid_image: 'weather_symbo2.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 226,
              font_array: ["YEAR_01.png","YEAR_02.png","YEAR_03.png","YEAR_04.png","YEAR_05.png","YEAR_06.png","YEAR_07.png","YEAR_08.png","YEAR_09.png","YEAR_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'weather_symbo1.png',
              unit_tc: 'weather_symbo1.png',
              unit_en: 'weather_symbo1.png',
              negative_image: 'weather_symbo2.png',
              invalid_image: 'weather_symbo2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 192,
              y: 221,
              image_array: ["weather_icons_01.png","weather_icons_02.png","weather_icons_03.png","weather_icons_04.png","weather_icons_05.png","weather_icons_06.png","weather_icons_07.png","weather_icons_08.png","weather_icons_09.png","weather_icons_10.png","weather_icons_11.png","weather_icons_12.png","weather_icons_13.png","weather_icons_14.png","weather_icons_15.png","weather_icons_16.png","weather_icons_17.png","weather_icons_18.png","weather_icons_19.png","weather_icons_20.png","weather_icons_21.png","weather_icons_22.png","weather_icons_23.png","weather_icons_24.png","weather_icons_25.png","weather_icons_26.png","weather_icons_27.png","weather_icons_28.png","weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 192,
              font_array: ["YEAR_01.png","YEAR_02.png","YEAR_03.png","YEAR_04.png","YEAR_05.png","YEAR_06.png","YEAR_07.png","YEAR_08.png","YEAR_09.png","YEAR_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Act_KM.png',
              unit_tc: 'Act_KM.png',
              unit_en: 'Act_KM.png',
              imperial_unit_sc: 'Act_Mi.png',
              imperial_unit_tc: 'Act_Mi.png',
              imperial_unit_en: 'Act_Mi.png',
              dot_image: 'Act_Dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 134,
              y: 191,
              font_array: ["YEAR_01.png","YEAR_02.png","YEAR_03.png","YEAR_04.png","YEAR_05.png","YEAR_06.png","YEAR_07.png","YEAR_08.png","YEAR_09.png","YEAR_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Batt_pointer.png',
              center_x: 104,
              center_y: 251,
              x: 8,
              y: 32,
              start_angle: 179,
              end_angle: 451,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 20,
              y: 266,
              font_array: ["YEAR_01.png","YEAR_02.png","YEAR_03.png","YEAR_04.png","YEAR_05.png","YEAR_06.png","YEAR_07.png","YEAR_08.png","YEAR_09.png","YEAR_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_Symbo.png',
              unit_tc: 'Batt_Symbo.png',
              unit_en: 'Batt_Symbo.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 76,
              font_array: ["YEAR_01.png","YEAR_02.png","YEAR_03.png","YEAR_04.png","YEAR_05.png","YEAR_06.png","YEAR_07.png","YEAR_08.png","YEAR_09.png","YEAR_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 118,
              y: 65,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 14,
              y: 35,
              src: 'icon_Go.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 32,
              y: 77,
              font_array: ["YEAR_01.png","YEAR_02.png","YEAR_03.png","YEAR_04.png","YEAR_05.png","YEAR_06.png","YEAR_07.png","YEAR_08.png","YEAR_09.png","YEAR_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 211,
              year_startY: 90,
              year_sc_array: ["YEAR_01.png","YEAR_02.png","YEAR_03.png","YEAR_04.png","YEAR_05.png","YEAR_06.png","YEAR_07.png","YEAR_08.png","YEAR_09.png","YEAR_10.png"],
              year_tc_array: ["YEAR_01.png","YEAR_02.png","YEAR_03.png","YEAR_04.png","YEAR_05.png","YEAR_06.png","YEAR_07.png","YEAR_08.png","YEAR_09.png","YEAR_10.png"],
              year_en_array: ["YEAR_01.png","YEAR_02.png","YEAR_03.png","YEAR_04.png","YEAR_05.png","YEAR_06.png","YEAR_07.png","YEAR_08.png","YEAR_09.png","YEAR_10.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 183,
              day_startY: 33,
              day_sc_array: ["DAY_01.png","DAY_02.png","DAY_03.png","DAY_04.png","DAY_05.png","DAY_06.png","DAY_07.png","DAY_08.png","DAY_09.png","DAY_10.png"],
              day_tc_array: ["DAY_01.png","DAY_02.png","DAY_03.png","DAY_04.png","DAY_05.png","DAY_06.png","DAY_07.png","DAY_08.png","DAY_09.png","DAY_10.png"],
              day_en_array: ["DAY_01.png","DAY_02.png","DAY_03.png","DAY_04.png","DAY_05.png","DAY_06.png","DAY_07.png","DAY_08.png","DAY_09.png","DAY_10.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 267,
              y: 148,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 169,
              y: 116,
              week_en: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_tc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_sc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 96,
              month_startY: 25,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 251,
              month_startY: 55,
              month_sc_array: ["YEAR_01.png","YEAR_02.png","YEAR_03.png","YEAR_04.png","YEAR_05.png","YEAR_06.png","YEAR_07.png","YEAR_08.png","YEAR_09.png","YEAR_10.png"],
              month_tc_array: ["YEAR_01.png","YEAR_02.png","YEAR_03.png","YEAR_04.png","YEAR_05.png","YEAR_06.png","YEAR_07.png","YEAR_08.png","YEAR_09.png","YEAR_10.png"],
              month_en_array: ["YEAR_01.png","YEAR_02.png","YEAR_03.png","YEAR_04.png","YEAR_05.png","YEAR_06.png","YEAR_07.png","YEAR_08.png","YEAR_09.png","YEAR_10.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 107,
              am_y: 108,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 107,
              pm_y: 108,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 209,
              second_startY: 140,
              second_array: ["Time_Seconds_01.png","Time_Seconds_02.png","Time_Seconds_03.png","Time_Seconds_04.png","Time_Seconds_05.png","Time_Seconds_06.png","Time_Seconds_07.png","Time_Seconds_08.png","Time_Seconds_09.png","Time_Seconds_10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 130,
              minute_startY: 134,
              minute_array: ["Time_C1_01.png","Time_C1_02.png","Time_C1_03.png","Time_C1_04.png","Time_C1_05.png","Time_C1_06.png","Time_C1_07.png","Time_C1_08.png","Time_C1_09.png","Time_C1_10.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 37,
              hour_startY: 136,
              hour_array: ["Time_C1_01.png","Time_C1_02.png","Time_C1_03.png","Time_C1_04.png","Time_C1_05.png","Time_C1_06.png","Time_C1_07.png","Time_C1_08.png","Time_C1_09.png","Time_C1_10.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 209,
              y: 140,
              w: 40,
              h: 33,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 139,
              y: 143,
              w: 41,
              h: 28,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 249,
              w: 42,
              h: 30,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 262,
              y: 141,
              w: 27,
              h: 34,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 151,
              y: 215,
              w: 128,
              h: 30,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 88,
              y: 338,
              w: 71,
              h: 28,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		// calendar
	hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 176,
              y: 21,
              w: 81,
              h: 100,
	 text: '',
	  normal_src: '0_Empty.png',
	  press_src: '0_Empty.png',
	  click_func: () => {
	hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
	  },
	  show_level: hmUI.show_level.ONLY_NORMAL,
	});
/////////////////////////////////////////////////////////////////////////////////

		// GO ACTIVITY
	hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 15,
              y: 15,
              w: 72,
              h: 45,
	 text: '',
	  normal_src: '0_Empty.png',
	  press_src: '0_Empty.png',
	  click_func: () => {
	hmApp.startApp({ url: 'SportListScreen', native: true });
	  },
	  show_level: hmUI.show_level.ONLY_NORMAL,
	});


            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 8,
              y: 296,
              w: 85,
              h: 34,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 95,
              y: 61,
              w: 56,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 20,
              y: 69,
              w: 62,
              h: 28,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });



/////////////////Show element at the first time //////////

if (cc==0) {
  cc = 1

 
}
//////////////////////////////////////////////////////////////////////////////////////////////////
 
           // Element on/off
            btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 263,
              y: 315,
              text: '',
              w: 53,
              h: 53,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Background();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

//////////////////////////////////////////////////////////////////////////////////////////////////  
          // Change color background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x:268,
              y: 9,
              text: '',
              w: 39,
              h: 39,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            //Change color background shortcut end

    
//////////////////////////////////////////////////////////////////////////////////////////////////



                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}