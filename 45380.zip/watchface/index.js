﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_humidity_text_text_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 243,
              y: 319,
              font_array: ["chars_9720B5DD_000.png","chars_9720B5DD_001.png","chars_9720B5DD_002.png","chars_9720B5DD_003.png","chars_9720B5DD_004.png","chars_9720B5DD_005.png","chars_9720B5DD_006.png","chars_9720B5DD_007.png","chars_9720B5DD_008.png","chars_9720B5DD_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 247,
              y: 286,
              image_array: ["set_33_90x21_h69s200b200_img_level_1.png","set_33_90x21_h69s200b200_img_level_2.png","set_33_90x21_h69s200b200_img_level_3.png","set_33_90x21_h69s200b200_img_level_4.png","set_33_90x21_h69s200b200_img_level_5.png","set_33_90x21_h69s200b200_img_level_6.png","set_33_90x21_h69s200b200_img_level_7.png","set_33_90x21_h69s200b200_img_level_8.png","set_33_90x21_h69s200b200_img_level_9.png","set_33_90x21_h69s200b200_img_level_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 178,
              hour_array: ["chars_FC966DE3_000.png","chars_FC966DE3_001.png","chars_FC966DE3_002.png","chars_FC966DE3_003.png","chars_FC966DE3_004.png","chars_FC966DE3_005.png","chars_FC966DE3_006.png","chars_FC966DE3_007.png","chars_FC966DE3_008.png","chars_FC966DE3_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 211,
              minute_startY: 178,
              minute_array: ["chars_A986780E_000.png","chars_A986780E_001.png","chars_A986780E_002.png","chars_A986780E_003.png","chars_A986780E_004.png","chars_A986780E_005.png","chars_A986780E_006.png","chars_A986780E_007.png","chars_A986780E_008.png","chars_A986780E_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 324,
              second_startY: 211,
              second_array: ["chars_5C52213_000.png","chars_5C52213_001.png","chars_5C52213_002.png","chars_5C52213_003.png","chars_5C52213_004.png","chars_5C52213_005.png","chars_5C52213_006.png","chars_5C52213_007.png","chars_5C52213_008.png","chars_5C52213_009.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 95,
              font_array: ["chars_21FE9587_000.png","chars_21FE9587_001.png","chars_21FE9587_002.png","chars_21FE9587_003.png","chars_21FE9587_004.png","chars_21FE9587_005.png","chars_21FE9587_006.png","chars_21FE9587_007.png","chars_21FE9587_008.png","chars_21FE9587_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_21FE9587_011.png',
              unit_tc: 'chars_21FE9587_011.png',
              unit_en: 'chars_21FE9587_011.png',
              negative_image: 'chars_21FE9587_010.png',
              invalid_image: 'chars_21FE9587_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 285,
              y: 30,
              image_array: ["set_7_55x55_meteo_1.png","set_7_55x55_meteo_2.png","set_7_55x55_meteo_3.png","set_7_55x55_meteo_4.png","set_7_55x55_meteo_5.png","set_7_55x55_meteo_6.png","set_7_55x55_meteo_7.png","set_7_55x55_meteo_8.png","set_7_55x55_meteo_9.png","set_7_55x55_meteo_10.png","set_7_55x55_meteo_11.png","set_7_55x55_meteo_12.png","set_7_55x55_meteo_13.png","set_7_55x55_meteo_14.png","set_7_55x55_meteo_15.png","set_7_55x55_meteo_16.png","set_7_55x55_meteo_17.png","set_7_55x55_meteo_18.png","set_7_55x55_meteo_19.png","set_7_55x55_meteo_20.png","set_7_55x55_meteo_21.png","set_7_55x55_meteo_22.png","set_7_55x55_meteo_23.png","set_7_55x55_meteo_24.png","set_7_55x55_meteo_25.png","set_7_55x55_meteo_26.png","set_7_55x55_meteo_27.png","set_7_55x55_meteo_28.png","set_7_55x55_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 59,
              y: 318,
              font_array: ["chars_B1C8A26E_000.png","chars_B1C8A26E_001.png","chars_B1C8A26E_002.png","chars_B1C8A26E_003.png","chars_B1C8A26E_004.png","chars_B1C8A26E_005.png","chars_B1C8A26E_006.png","chars_B1C8A26E_007.png","chars_B1C8A26E_008.png","chars_B1C8A26E_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 45,
              y: 286,
              image_array: ["set_33_90x21_h62s200b200_img_level_1.png","set_33_90x21_h62s200b200_img_level_2.png","set_33_90x21_h62s200b200_img_level_3.png","set_33_90x21_h62s200b200_img_level_4.png","set_33_90x21_h62s200b200_img_level_5.png","set_33_90x21_h62s200b200_img_level_6.png","set_33_90x21_h62s200b200_img_level_7.png","set_33_90x21_h62s200b200_img_level_8.png","set_33_90x21_h62s200b200_img_level_9.png","set_33_90x21_h62s200b200_img_level_10.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 153,
              y: 410,
              font_array: ["chars_F0352FFF_000.png","chars_F0352FFF_001.png","chars_F0352FFF_002.png","chars_F0352FFF_003.png","chars_F0352FFF_004.png","chars_F0352FFF_005.png","chars_F0352FFF_006.png","chars_F0352FFF_007.png","chars_F0352FFF_008.png","chars_F0352FFF_009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'chars_F0352FFF_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 7,
              y: 193,
              font_array: ["chars_EB1C7061_000.png","chars_EB1C7061_001.png","chars_EB1C7061_002.png","chars_EB1C7061_003.png","chars_EB1C7061_004.png","chars_EB1C7061_005.png","chars_EB1C7061_006.png","chars_EB1C7061_007.png","chars_EB1C7061_008.png","chars_EB1C7061_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 319,
              font_array: ["chars_A565FA78_000.png","chars_A565FA78_001.png","chars_A565FA78_002.png","chars_A565FA78_003.png","chars_A565FA78_004.png","chars_A565FA78_005.png","chars_A565FA78_006.png","chars_A565FA78_007.png","chars_A565FA78_008.png","chars_A565FA78_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 146,
              y: 286,
              image_array: ["set_33_90x21_h82s200b200_img_level_1.png","set_33_90x21_h82s200b200_img_level_2.png","set_33_90x21_h82s200b200_img_level_3.png","set_33_90x21_h82s200b200_img_level_4.png","set_33_90x21_h82s200b200_img_level_5.png","set_33_90x21_h82s200b200_img_level_6.png","set_33_90x21_h82s200b200_img_level_7.png","set_33_90x21_h82s200b200_img_level_8.png","set_33_90x21_h82s200b200_img_level_9.png","set_33_90x21_h82s200b200_img_level_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 170,
              day_startY: 54,
              day_sc_array: ["chars_758C1870_000.png","chars_758C1870_001.png","chars_758C1870_002.png","chars_758C1870_003.png","chars_758C1870_004.png","chars_758C1870_005.png","chars_758C1870_006.png","chars_758C1870_007.png","chars_758C1870_008.png","chars_758C1870_009.png"],
              day_tc_array: ["chars_758C1870_000.png","chars_758C1870_001.png","chars_758C1870_002.png","chars_758C1870_003.png","chars_758C1870_004.png","chars_758C1870_005.png","chars_758C1870_006.png","chars_758C1870_007.png","chars_758C1870_008.png","chars_758C1870_009.png"],
              day_en_array: ["chars_758C1870_000.png","chars_758C1870_001.png","chars_758C1870_002.png","chars_758C1870_003.png","chars_758C1870_004.png","chars_758C1870_005.png","chars_758C1870_006.png","chars_758C1870_007.png","chars_758C1870_008.png","chars_758C1870_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 132,
              y: 103,
              week_en: ["chars_2143CB97_000.png","chars_2143CB97_001.png","chars_2143CB97_002.png","chars_2143CB97_003.png","chars_2143CB97_004.png","chars_2143CB97_005.png","chars_2143CB97_006.png"],
              week_tc: ["chars_2143CB97_000.png","chars_2143CB97_001.png","chars_2143CB97_002.png","chars_2143CB97_003.png","chars_2143CB97_004.png","chars_2143CB97_005.png","chars_2143CB97_006.png"],
              week_sc: ["chars_2143CB97_000.png","chars_2143CB97_001.png","chars_2143CB97_002.png","chars_2143CB97_003.png","chars_2143CB97_004.png","chars_2143CB97_005.png","chars_2143CB97_006.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 176,
              y: 135,
              image_array: ["moon_5_45x45_moon_1.png","moon_5_45x45_moon_2.png","moon_5_45x45_moon_3.png","moon_5_45x45_moon_4.png","moon_5_45x45_moon_5.png","moon_5_45x45_moon_6.png","moon_5_45x45_moon_7.png","moon_5_45x45_moon_8.png","moon_5_45x45_moon_9.png","moon_5_45x45_moon_10.png","moon_5_45x45_moon_11.png","moon_5_45x45_moon_12.png","moon_5_45x45_moon_13.png","moon_5_45x45_moon_14.png","moon_5_45x45_moon_15.png","moon_5_45x45_moon_16.png","moon_5_45x45_moon_17.png","moon_5_45x45_moon_18.png","moon_5_45x45_moon_19.png","moon_5_45x45_moon_20.png","moon_5_45x45_moon_21.png","moon_5_45x45_moon_22.png","moon_5_45x45_moon_23.png","moon_5_45x45_moon_24.png","moon_5_45x45_moon_25.png","moon_5_45x45_moon_26.png","moon_5_45x45_moon_27.png","moon_5_45x45_moon_28.png","moon_5_45x45_moon_29.png","moon_5_45x45_moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 43,
              y: 95,
              font_array: ["chars_E4CAF12_000.png","chars_E4CAF12_001.png","chars_E4CAF12_002.png","chars_E4CAF12_003.png","chars_E4CAF12_004.png","chars_E4CAF12_005.png","chars_E4CAF12_006.png","chars_E4CAF12_007.png","chars_E4CAF12_008.png","chars_E4CAF12_009.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'chars_E4CAF12_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 178,
              hour_array: ["chars_EA4B7A31_000.png","chars_EA4B7A31_001.png","chars_EA4B7A31_002.png","chars_EA4B7A31_003.png","chars_EA4B7A31_004.png","chars_EA4B7A31_005.png","chars_EA4B7A31_006.png","chars_EA4B7A31_007.png","chars_EA4B7A31_008.png","chars_EA4B7A31_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 211,
              minute_startY: 178,
              minute_array: ["chars_EA4B7A31_000.png","chars_EA4B7A31_001.png","chars_EA4B7A31_002.png","chars_EA4B7A31_003.png","chars_EA4B7A31_004.png","chars_EA4B7A31_005.png","chars_EA4B7A31_006.png","chars_EA4B7A31_007.png","chars_EA4B7A31_008.png","chars_EA4B7A31_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}