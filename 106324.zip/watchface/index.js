try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    'use strict';

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let rootPath = null
    let animatePath = null
    let anim_aPath = null
    let anim_bPath = null
    let anim_cPath = null
    let green_numberPath = null
    let monthPath = null
    let red_numberPath = null
    let timePath = null
    let weekPath = null

    let green_number_array = null
    let red_number_array = null
    let month_array = null
    let time_array = null
    let week_array = null

    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({


      init_view() {
        rootPath = "images/";
        animatePath = rootPath + "animate/"
        anim_aPath = animatePath + "A"
        anim_bPath = animatePath + "B"
        anim_cPath = animatePath + "C"
        green_numberPath = rootPath + "green_number/"
        monthPath = rootPath + "month/"
        red_numberPath = rootPath + "red_number/"
        timePath = rootPath + "time/"
        weekPath = rootPath + "week/"

        green_number_array = [
          green_numberPath + "0.png",
          green_numberPath + "1.png",
          green_numberPath + "2.png",
          green_numberPath + "3.png",
          green_numberPath + "4.png",
          green_numberPath + "5.png",
          green_numberPath + "6.png",
          green_numberPath + "7.png",
          green_numberPath + "8.png",
          green_numberPath + "9.png",
        ]

        red_number_array = [
          red_numberPath + "0.png",
          red_numberPath + "1.png",
          red_numberPath + "2.png",
          red_numberPath + "3.png",
          red_numberPath + "4.png",
          red_numberPath + "5.png",
          red_numberPath + "6.png",
          red_numberPath + "7.png",
          red_numberPath + "8.png",
          red_numberPath + "9.png",
        ]

        month_array = [
          monthPath + "1.png",
          monthPath + "2.png",
          monthPath + "3.png",
          monthPath + "4.png",
          monthPath + "5.png",
          monthPath + "6.png",
          monthPath + "7.png",
          monthPath + "8.png",
          monthPath + "9.png",
          monthPath + "10.png",
          monthPath + "11.png",
          monthPath + "12.png",
        ]

        time_array = [
          timePath + "0.png",
          timePath + "1.png",
          timePath + "2.png",
          timePath + "3.png",
          timePath + "4.png",
          timePath + "5.png",
          timePath + "6.png",
          timePath + "7.png",
          timePath + "8.png",
          timePath + "9.png",
        ]

        week_array = [
          weekPath + "1.png",
          weekPath + "2.png",
          weekPath + "3.png",
          weekPath + "4.png",
          weekPath + "5.png",
          weekPath + "6.png",
          weekPath + "7.png",
        ]

        let bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: rootPath + "bg.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        })


        let animA = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
          x: 239,
          y: 36,

          anim_path: anim_aPath,

          anim_prefix: "A",

          anim_ext: "png",
          // anim_0 
          anim_fps: 15,

          anim_size: 15,

          repeat_count: 1, //0位无限重复
          anim_repeat: true, //是否重复
          anim_status: hmUI.anim_status.START,
          display_on_restart: false, //从息屏到亮屏是否自动重复播放
          // anim_complete_call:animCall,//动画结束回调 无限重复永远不会调用到

        });
        //设置动画状态
        animA.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.PAUSE)

        let animB = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
          x: 6,
          y: 194,

          anim_path: anim_bPath,

          anim_prefix: "B",

          anim_ext: "png",
          // anim_0 
          anim_fps: 15,

          anim_size: 15,

          repeat_count: 1, //0位无限重复
          anim_repeat: true, //是否重复
          anim_status: hmUI.anim_status.START,
          display_on_restart: false, //从息屏到亮屏是否自动重复播放
          // anim_complete_call:animCall,//动画结束回调 无限重复永远不会调用到

        });
        //设置动画状态
        animB.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.PAUSE)

        let animC = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
          x: 99,
          y: 390,

          anim_path: anim_cPath,

          anim_prefix: "C",

          anim_ext: "png",
          // anim_0 
          anim_fps: 15,

          anim_size: 15,

          repeat_count: 1, //0位无限重复
          anim_repeat: true, //是否重复
          anim_status: hmUI.anim_status.START,
          display_on_restart: false, //从息屏到亮屏是否自动重复播放
          // anim_complete_call:animCall,//动画结束回调 无限重复永远不会调用到

        });
        //设置动画状态
        animC.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.PAUSE)

        let heartText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 164,
          y: 34,
          type: hmUI.data_type.HEART,
          font_array: red_number_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          invalid_image: red_numberPath + "null.png",
          padding: true
        });

        let calText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 190,
          y: 339,
          type: hmUI.data_type.CAL,
          font_array: red_number_array,
          h_space: 0,
          align_h: hmUI.align.LEFT,
          show_level: hmUI.show_level.ONLY_NORMAL,
          // invalid_image: number_sPath + "null.png",
          // padding:true
        });

        let bg_img1 = hmUI.createWidget(hmUI.widget.IMG, {
          x: 180,
          y: 168,
          src: timePath + "maohao.png",
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
        })

        let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_zero: 1, //是否补零
          hour_startX: 116,
          hour_startY: 168,
          hour_array: time_array,
          hour_space: 0, //每个数组间的间隔
          minute_zero: 1, //是否补零
          minute_startX: 210,
          minute_startY: 168,
          minute_array: time_array,

          hour_align: hmUI.align.LEFT,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
        });

        let weekText = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 165,
          y: 266,
          week_en: week_array,
          week_tc: week_array,
          week_sc: week_array,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let dataText = hmUI.createWidget(hmUI.widget.IMG_DATE, {

          month_startX: 84,
          month_startY: 266,
          month_en_array: month_array,
          month_sc_array: month_array,
          month_tc_array: month_array,
          month_is_character: true,
          day_startX: 264,
          day_startY: 273,
          day_en_array: green_number_array,
          day_sc_array: green_number_array,
          day_tc_array: green_number_array,

          // day_follow:1,//是否跟随
          show_level: hmUI.show_level.ONLY_NORMAL,
          //月日同上 需要替换前缀为month/day
        });

        let stepText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 151,
          y: 98,
          type: hmUI.data_type.STEP,
          font_array: green_number_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          // invalid_image: number_sPath + "null.png",
          padding: true
        });
        let heartClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, { //使用IMGCLICK控件传入组件对应类型
          x: 124,
          y: 23,
          w: 131,
          h: 66,
          type: hmUI.data_type.HEART,
        })
        let stepClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, { //使用IMGCLICK控件传入组件对应类型
          x: 124,
          y: 98,
          w: 131,
          h: 66,
          type: hmUI.data_type.STEP,
        })
        let calClick = hmUI.createWidget(hmUI.widget.IMG_CLICK, { //使用IMGCLICK控件传入组件对应类型
          x: 124,
          y: 334,
          w: 131,
          h: 66,
          type: hmUI.data_type.CAL,
        })
      },

      onInit() {
        console.log('index page.js on init invoke');

        this.init_view();


      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
     * end js
     */
  })()
} catch (e) {
  console.log(e)
}