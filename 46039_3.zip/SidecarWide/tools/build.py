"""Single source of truth for the Sidecar layout.

Generates watchface/index.js + app.json from the widget list below, and renders preview
PNGs (sample / worst-case / zero) by simulating the same widgets with the same assets.
Also runs fit checks: safe area, corner clearance, notification-badge zone, overlaps.

usage: python3 tools/build.py <project_root> [version_code]
"""
import json, math, os, sys
from PIL import Image, ImageDraw, ImageFont

ROOT = sys.argv[1]
VERSION_CODE = int(sys.argv[2]) if len(sys.argv) > 2 else 1
A = os.path.join(ROOT, 'assets', 'bip6')
META = json.load(open(os.path.join(ROOT, 'tools', 'assets.json')))
PAD, SIZES, SETS = META['pad'], META['sizes'], META['sets']
SW, SH, RADIUS = 390, 450, 86
SAFE = (14, 28, 376, 436)            # x0, y0, x1, y1
CORNER_CLEAR = 8
BADGE = (165, 0, 225, 46)            # top-centre notification bubble: keep empty

ZONES = ['relaxed', 'light', 'intensive', 'aerobic', 'anaerobic', 'vo2']
ZONE_EDGES = [95, 114, 133, 152, 171]
# crop ends for the lit zone ladder: end of segment z + 1px into the gap (never into the next segment)
_ZS = (100 - 2 * 5) / 6
ZONE_ENDS = [int(i * (_ZS + 2) + _ZS) + 1 for i in range(6)]          # HR < 95 relaxed ... >= 171 VO2 max (max 190)

def gw(setname, ch):
    """glyph width for a font set character"""
    if ch.isdigit():
        return SETS[setname]
    key = {'-': 'minus', '.': 'dot', ':': 'colon', '%': 'pct', '°': 'deg'}.get(ch, ch)
    return SIZES[f'font/{setname}/{key}.png'][0]

def fa(setname):
    return [f'font/{setname}/{d}.png' for d in range(10)]

# --------------------------------------------------------------------- widgets
W = []  # dicts: id, type, p (params), aod(bool), dyn(bool), box (visible x,y,w,h for checks), group

def add(id, type, p, box=None, aod=False, group=None, check=True):
    W.append(dict(id=id, type=type, p=p, aod=aod, box=box, group=group, check=check))

def img(id, src, x, y, padded=True, **kw):
    w, h = SIZES[src]
    if padded:
        add(id, 'IMG', dict(x=x - PAD, y=y - PAD, w=w, h=h, src=src), box=(x, y, w - 2 * PAD, h - 2 * PAD), **kw)
    else:
        add(id, 'IMG', dict(x=x, y=y, w=w, h=h, src=src), box=(x, y, w, h), **kw)

def text_img(id, setname, x, y, w, h, align='left', **extra):
    p = dict(x=x, y=y, w=w, h=h, font_array=fa(setname), h_space=0, align_h=align, _set=setname)
    for k in ('unit', 'iunit', 'negative', 'invalid', 'dot'):
        if k in extra:
            p[k] = extra.pop(k)
    p.update({k: v for k, v in extra.items() if k not in ('group',)})
    add(id, 'TEXT_IMG', p, box=(x, y, w, h), group=extra.get('group'))

def fill(id, x, y, w, h, color, radius=0, **kw):
    add(id, 'FILL_RECT', dict(x=x, y=y, w=w, h=h, color=color, radius=radius), box=(x, y, w, h), **kw)

# backgrounds
img('lcd', 'panel/lcd.png', 14, 52, check=False)
for i, x in enumerate((14, 137, 260)):
    img(f'tile{i}', 'panel/tile.png', x, 226, check=False)
img('sky', 'panel/sky.png', 14, 292, check=False)
img('act', 'panel/act.png', 199, 292, check=False)

# top: date (left) + city (right, above nothing in the badge zone)
add('week', 'IMG_WEEK', dict(x=44, y=28, week_en=[f'week/{i}.png' for i in range(7)]), box=(44, 28, 42, 16))
add('date', 'IMG_DATE', dict(day_startX=91, day_startY=28, day_en_array=fa('date'), day_zero=1, day_space=0,
                             month_startX=121, month_startY=28, month_en_array=[f'month/{i}.png' for i in range(12)],
                             month_is_character=True), box=(91, 28, 70, 16))
add('city', 'TEXT', dict(x=230, y=28, w=126, h=16, text='', text_size=13, color='0xF08A5D', align_h='right'), box=(230, 28, 126, 16))

# full-width LCD: time + week strip
TX, TY = 48, 62
CW, COLW, SECW = SETS['time'], SIZES['font/time/colon.png'][0], SETS['sec']
MX = TX + 2 * CW + COLW
SX = MX + 2 * CW + 3
add('time', 'IMG_TIME', dict(hour_zero=1, hour_startX=TX, hour_startY=TY, hour_array=fa('time'), hour_space=0,
                             minute_zero=1, minute_startX=MX, minute_startY=TY, minute_array=fa('time'), minute_space=0,
                             second_zero=1, second_startX=SX, second_startY=TY + 40, second_array=fa('sec'), second_space=0,
                             am_x=SX, am_y=TY + 14, am_en_path='label/am.png', am_sc_path='label/am.png',
                             pm_x=SX, pm_y=TY + 14, pm_en_path='label/pm.png', pm_sc_path='label/pm.png'),
    box=(TX, TY, SX + 2 * SECW - TX, 76))
img('colon', 'font/time/colon.png', TX + 2 * CW, TY, padded=False, check=False)
AX = (SW - (4 * SETS['aod'] + SIZES['font/aod/colon.png'][0])) // 2
add('aod_time', 'IMG_TIME', dict(hour_zero=1, hour_startX=AX, hour_startY=180, hour_array=fa('aod'), hour_space=0,
                                 minute_zero=1, minute_startX=AX + 2 * SETS['aod'] + SIZES['font/aod/colon.png'][0],
                                 minute_startY=180, minute_array=fa('aod'), minute_space=0), aod=True, check=False)
add('aod_colon', 'IMG', dict(x=AX + 2 * SETS['aod'], y=180, w=SIZES['font/aod/colon.png'][0], h=SIZES['font/aod/colon.png'][1], src='font/aod/colon.png'), aod=True, check=False)

WK = dict(x0=79, gap=4, small=(28, 20), big=(40, 30), base=176)
for i in range(7):
    add(f'wk{i}', 'IMG', dict(x=0, y=0, w=SIZES[f'week/past_{i}.png'][0], h=SIZES[f'week/past_{i}.png'][1], src=f'week/past_{i}.png'), check=False)
fill('wkfill', 0, 0, 10, 10, '0xD9572B', check=False)
add('wkframe', 'IMG', dict(x=0, y=0, w=SIZES['week/today_0.png'][0], h=SIZES['week/today_0.png'][1], src='week/today_0.png'), check=False)

# calendar progress under the LCD
BARW = 172
img('mo_lbl', 'label/mo.png', 14, 194, padded=False)
text_img('mo_days', 'small', 43, 194, 34, 14, unit='font/small/D.png')
text_img('mo_pct', 'small', 140, 194, 46, 14, align='right', unit='font/small/pct.png')
fill('mo_track', 14, 212, BARW, 6, '0x30353D', 3)
fill('mo_fill', 14, 212, 80, 6, '0xF08A5D', 3, check=False)
img('yr_lbl', 'label/yr.png', 204, 194, padded=False)
text_img('yr_days', 'small', 229, 194, 45, 14, unit='font/small/D.png')
text_img('yr_pct', 'small', 330, 194, 46, 14, align='right', unit='font/small/pct.png')
fill('yr_track', 204, 212, BARW, 6, '0x30353D', 3)
fill('yr_fill', 204, 212, 100, 6, '0xF08A5D', 3, check=False)

# body tiles: charge | heart rate | sleep
img('chg_icon', 'icon/charge.png', 22, 234)
text_img('chg_val', 'charge', 46, 232, 51, 24, align='left', type='BIO_CHARGE', invalid='font/charge/dash.png')
img('chg_track', 'meter/track.png', 22, 266)
fill('chg_fill', 22, 266, 60, 6, '0x22D3EE', 0, check=False)
img('chg_mask', 'meter/mask.png', 22, 266, check=False)
add('chg_lvl', 'IMG_LEVEL', dict(x=22 - PAD, y=266 - PAD, w=SIZES['meter/lv_0.png'][0], h=SIZES['meter/lv_0.png'][1],
                                 image_array=[f'meter/lv_{k}.png' for k in range(11)], image_length=11, type='BIO_CHARGE'), check=False)
for z in ZONES:
    img(f'hr_icon_{z}', f'icon/heart_{z}.png', 145, 234, check=(z == 'relaxed'))
    text_img(f'hr_val_{z}', f'hr_{z}', 169, 232, 51, 24)
    if z != 'relaxed':
        W[-1]['check'] = False
img('zone_track', 'zone/track.png', 145, 266)
img('zone_lit', 'zone/lit.png', 145, 266, check=False)
img('bed', 'icon/bed.png', 268, 235)
text_img('sleep_val', 'sleep', 292, 233, 74, 22, dot='font/sleep/colon.png')
fill('sleep_track', 268, 266, 100, 6, '0x30353D', 3)
fill('sleep_fill', 268, 266, 60, 6, '0xB49CFF', 3, check=False)

# SKY card (bottom-left): weather + range, next sun event + moon
add('wicon', 'IMG_LEVEL', dict(x=24 - PAD, y=300 - PAD, w=SIZES['weather/0.png'][0], h=SIZES['weather/0.png'][1],
                               image_array=[f'weather/{i}.png' for i in range(29)], image_length=29, type='WEATHER_CURRENT'),
    box=(24, 300, 30, 30))
text_img('wtemp', 'temp', 58, 304, 57, 22, align='left', type='WEATHER_CURRENT', negative='font/temp/minus.png',
         unit='font/temp/deg.png', invalid='font/temp/dash.png')
img('hi_tri', 'tri/up.png', 128, 304)
text_img('hi_val', 'hi', 138, 301, 32, 12, type='WEATHER_HIGH', negative='font/hi/minus.png', unit='font/hi/deg.png', invalid='font/hi/dash.png')
img('lo_tri', 'tri/dn.png', 128, 320)
text_img('lo_val', 'lo', 138, 317, 32, 12, type='WEATHER_LOW', negative='font/lo/minus.png', unit='font/lo/deg.png', invalid='font/lo/dash.png')
img('sun_up', 'icon/sunup.png', 24, 358)
img('sun_dn', 'icon/sundn.png', 24, 358, check=False)
text_img('sun_time', 'ssmall', 44, 359, 51, 14, dot='font/ssmall/colon.png')
add('moon', 'IMG_LEVEL', dict(x=112 - PAD, y=354 - PAD, w=SIZES['moon/0.png'][0], h=SIZES['moon/0.png'][1],
                              image_array=[f'moon/{k}.png' for k in range(30)], image_length=30), box=(112, 354, 22, 22))
text_img('moon_pct', 'ssmall', 138, 358, 46, 14, unit='font/ssmall/pct.png')

# ACTIVITY card (bottom-right): steps ring + steps/km, PAI, VO2
add('ring', 'IMG_LEVEL', dict(x=207 - PAD, y=311 - PAD, w=SIZES['ring/0.png'][0], h=SIZES['ring/0.png'][1],
                              image_array=[f'ring/{k}.png' for k in range(41)], image_length=41), box=(207, 311, 70, 70))
img('feet', 'icon/feet.png', 235, 339, check=False)
text_img('steps', 'pdark', 287, 302, 81, 18, align='left')
text_img('dist', 'psmall', 287, 324, 81, 14, align='left', type='DISTANCE', dot='font/psmall/dot.png', unit='font/psmall/km.png', iunit='font/psmall/mi.png')
img('pai_badge', 'badge/pai.png', 287, 346)
text_img('pai_val', 'pdark', 326, 345, 42, 18, align='right')
img('vo2_badge', 'badge/vo2.png', 287, 372)
text_img('vo2_val', 'pdark', 326, 371, 42, 18, align='right', type='VO2MAX', invalid='font/pdark/dash.png')

# bottom: alarm + battery
img('bell', 'icon/bell.png', 120, 408)
text_img('alarm', 'small', 139, 408, 51, 14, type='ALARM_CLOCK', dot='font/small/colon.png', invalid='font/small/dash.png')
img('batt', 'icon/batt.png', 212, 408)
fill('batt_fill', 215, 411, 17, 8, '0x2FD67B', 2, check=False)
text_img('batt_pct', 'small', 244, 408, 46, 14, unit='font/small/pct.png')

TAPS = [('tap_chg', 14, 226, 116, 56, 'BIO_CHARGE'), ('tap_hr', 137, 226, 116, 56, 'HEART'), ('tap_sleep', 260, 226, 116, 56, 'SLEEP'),
        ('tap_wx', 14, 292, 177, 50, 'WEATHER_CURRENT'), ('tap_moon', 102, 346, 89, 54, 'MOON'),
        ('tap_steps', 199, 292, 177, 52, 'STEP'), ('tap_pai', 280, 344, 96, 26, 'PAI_WEEKLY'),
        ('tap_vo2', 280, 370, 96, 28, 'VO2MAX'), ('tap_alarm', 114, 403, 80, 24, 'ALARM_CLOCK')]
for id, x, y, w, h, t in TAPS:
    add(id, 'IMG_CLICK', dict(x=x, y=y, w=w, h=h, src='misc/clear.png', type=t), check=False)

# --------------------------------------------------------------------- dynamic logic (python mirror of the JS)
DIM = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

def weekday_mon0(y, m, d):
    t = [0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4]
    yy = y - 1 if m < 3 else y
    dow = (yy + yy // 4 - yy // 100 + yy // 400 + t[m - 1] + d) % 7  # 0 = Sunday
    return (dow + 6) % 7

def leap(y): return (y % 4 == 0 and y % 100 != 0) or y % 400 == 0

def moon_phase(y, m, d, h, mi):
    # days since 2000-01-06 18:14 UTC (reference new moon); local time is close enough for a face
    a = (14 - m) // 12; yy = y + 4800 - a; mm = m + 12 * a - 3
    jdn = d + (153 * mm + 2) // 5 + 365 * yy + yy // 4 - yy // 100 + yy // 400 - 32045
    jd = jdn - 0.5 + (h + mi / 60) / 24
    age = ((jd - 2451550.26) % 29.530588853 + 29.530588853) % 29.530588853
    f = age / 29.530588853
    lit = round((1 - math.cos(2 * math.pi * f)) / 2 * 100)
    return int(round(f * 30)) % 30 + 1, lit   # IMG_LEVEL is 1-based

def zone_of(hr):
    z = 0
    for e in ZONE_EDGES:
        if hr >= e: z += 1
    return z

def dynamic(v):
    """v: dict of live values -> {widget_id: overrides} (same math as the JS)."""
    o = {}
    y, m, d, h, mi = v['Y'], v['M'], v['D'], v['h'], v['m']
    t = weekday_mon0(y, m, d)
    x = WK['x0']
    frac = (h * 60 + mi) / 1440
    for i in range(7):
        if i == t:
            bw, bh = WK['big']; by = WK['base'] - bh
            o['wkframe'] = dict(x=x - PAD, y=by - PAD, src=f'week/today_{i}.png')
            o[f'wk{i}'] = dict(visible=False)
            inner = bw - 4
            fw = max(1, round(inner * frac))
            o['wkfill'] = dict(x=x + 2, y=by + 2, w=fw, h=bh - 4)
        else:
            bw, bh = WK['small']; by = WK['base'] - bh
            o[f'wk{i}'] = dict(x=x - PAD, y=by - PAD, src=f'week/{"past" if i < t else "next"}_{i}.png', visible=True)
        x += bw + WK['gap']
    dim = DIM[m - 1] + (1 if m == 2 and leap(y) else 0)
    mo_p = ((d - 1) + frac) / dim
    o['mo_days'] = dict(text=str(dim - d)); o['mo_pct'] = dict(text=str(int(mo_p * 100)))
    o['mo_fill'] = dict(w=max(6, round(BARW * mo_p)))
    diy = 366 if leap(y) else 365
    doy = sum(DIM[:m - 1]) + (1 if m > 2 and leap(y) else 0) + d
    yr_p = ((doy - 1) + frac) / diy
    o['yr_days'] = dict(text=str(diy - doy)); o['yr_pct'] = dict(text=str(int(yr_p * 100)))
    o['yr_fill'] = dict(w=max(6, round(BARW * yr_p)))
    lvl, lit = moon_phase(y, m, d, h, mi)
    o['moon'] = dict(level=lvl); o['moon_pct'] = dict(text=str(lit))
    # next sun event
    sr, ss = v.get('sunrise'), v.get('sunset')
    now = h * 60 + mi
    if sr and ss:
        up_next = now < sr[0] * 60 + sr[1] or now >= ss[0] * 60 + ss[1]
        ev = sr if up_next else ss
        o['sun_up'] = dict(visible=up_next); o['sun_dn'] = dict(visible=not up_next)
        o['sun_time'] = dict(text=f'{ev[0]:02d}.{ev[1]:02d}')
    else:
        o['sun_time'] = dict(text='', visible=False); o['sun_dn'] = dict(visible=False)
    # heart rate: one font/icon per zone; hide the others
    hr = v.get('hr', 0)
    z = zone_of(hr) if hr > 0 else 0
    for k, zn in enumerate(ZONES):
        o[f'hr_val_{zn}'] = dict(visible=(k == z), text=str(hr) if hr > 0 else '--')
        o[f'hr_icon_{zn}'] = dict(visible=(k == z))
    o['zone_lit'] = dict(w=PAD + ZONE_ENDS[z], visible=hr > 0)
    # hybrid charge (BioCharge source): JS value -> width bar; 0 / missing -> '--'
    c = v.get('charge')
    if c is None:
        o['chg_fill'] = dict(visible=False); o['chg_mask'] = dict(visible=False)
        o['chg_lvl'] = dict(visible=True, level=1)
    else:
        o['chg_lvl'] = dict(visible=False)
        o['chg_fill'] = dict(w=max(1, round(100 * c / 100)), visible=c > 0)
        o['chg_val'] = dict(text=str(c) if c > 0 else '--')
    # sleep h:mm  ('.' is drawn with the colon image)
    s = v.get('sleep', 0)
    o['sleep_val'] = dict(text=f'{s // 60}.{s % 60:02d}' if s > 0 else '--')
    o['sleep_fill'] = dict(w=max(6, round(100 * min(1, s / 480))), visible=s > 0)
    st, tg = v.get('steps', 0), v.get('target', 8000) or 8000
    o['ring'] = dict(level=(min(40, max(1, math.ceil(st / tg * 40))) + 1) if st > 0 else 1)
    o['steps'] = dict(text=str(min(st, 99999)))
    o['pai_val'] = dict(text=str(min(v.get('pai', 0), 999)))
    vo = v.get('vo2', 0)
    o['vo2_val'] = dict(text=str(vo) if vo > 0 else '--')
    b = v.get('batt', 0)
    o['batt_pct'] = dict(text=str(b))
    o['batt_fill'] = dict(w=max(1, round(17 * b / 100)), color='0xFF3B4E' if b <= 15 else '0xFFC53D' if b <= 30 else '0x2FD67B')
    o['city'] = dict(text=(v.get('city') or '').upper())
    return o

# --------------------------------------------------------------------- simulator / preview
_cache = {}
def load(name):
    if name not in _cache:
        _cache[name] = Image.open(os.path.join(A, name)).convert('RGBA')
    return _cache[name]

def hexcol(c): return '#' + c[2:]

def draw_text_img(canvas, p, text, setname):
    if text is None: return
    glyphs = []
    if text in ('--', '') and p.get('invalid') and text == '--':
        glyphs = [p['invalid']]
    else:
        for ch in text:
            if ch == '-': glyphs.append(p.get('negative', f'font/{setname}/minus.png'))
            elif ch == '.': glyphs.append(p.get('dot'))
            elif ch.isdigit(): glyphs.append(f'font/{setname}/{ch}.png')
            elif ch == '-' * 2: pass
        if text == '--' and not p.get('invalid'):
            glyphs = [f'font/{setname}/dash.png']
        if text not in ('', '--') and p.get('unit'): glyphs.append(p['unit'])
    glyphs = [g for g in glyphs if g]
    total = sum(load(g).width for g in glyphs)
    if total > p['w']:
        raise SystemExit(f'TEXT_IMG overflow: {p} text={text!r} needs {total}px > w={p["w"]}')
    x = p['x'] + {'left': 0, 'center': (p['w'] - total) // 2, 'right': p['w'] - total}[p['align_h']]
    for g in glyphs:
        im = load(g)
        canvas.alpha_composite(im, (x, p['y'] + (p['h'] - im.height) // 2)); x += im.width

def render(values, path, aod=False, worst_text=None):
    canvas = Image.new('RGBA', (SW, SH), (0, 0, 0, 255))
    o = dynamic(values)
    T = values
    for wdg in W:
        if wdg['aod'] != aod: continue
        p = dict(wdg['p']); p.update({k: v for k, v in o.get(wdg['id'], {}).items() if k not in ('text', 'visible', 'level')})
        ov = o.get(wdg['id'], {})
        if ov.get('visible') is False: continue
        t = wdg['type']
        if t == 'IMG':
            im = load(p['src']).crop((0, 0, p['w'], p['h']))
            canvas.alpha_composite(im, (p['x'], p['y']))
        elif t == 'FILL_RECT':
            d = ImageDraw.Draw(canvas)
            d.rounded_rectangle((p['x'], p['y'], p['x'] + p['w'] - 1, p['y'] + p['h'] - 1), radius=min(p['radius'], p['h'] // 2), fill=hexcol(p['color']))
        elif t == 'IMG_LEVEL':
            if wdg['id'] == 'wicon': lvl = values.get('wcode', 0) + 1
            elif wdg['id'] == 'chg_lvl': lvl = ov.get('level', 1)
            else: lvl = ov.get('level', 1)
            canvas.alpha_composite(load(p['image_array'][lvl - 1]), (p['x'], p['y']))
        elif t == 'TEXT_IMG':
            typ = p.get('type')
            txt = ov.get('text')
            if typ == 'WEATHER_CURRENT': txt = str(values['temp'])
            elif typ == 'WEATHER_HIGH': txt = str(values['hi'])
            elif typ == 'WEATHER_LOW': txt = str(values['lo'])
            elif typ == 'VO2MAX' and txt is None: txt = str(values['vo2'])
            elif typ == 'ALARM_CLOCK': txt = values['alarm']
            elif typ == 'DISTANCE':
                d = values.get('dist', 0) / 1000 * (0.621371 if values.get('imperial') else 1)
                txt = f'{min(d, 99.99):.2f}'
                if values.get('imperial'): p = dict(p, unit=p['iunit'])
            elif typ == 'BIO_CHARGE' and txt is None: txt = str(values.get('charge_sys', '--'))
            draw_text_img(canvas, p, txt, p['_set'])
        elif t == 'IMG_TIME':
            hh = T['h'] if values.get('h24', True) else (T['h'] % 12 or 12)
            for key, val in (('hour', hh), ('minute', T['m']), ('second', T.get('s'))):
                if val is None or f'{key}_array' not in p: continue
                x = p[f'{key}_startX']
                for ch in f'{val:02d}':
                    im = load(p[f'{key}_array'][int(ch)]); canvas.alpha_composite(im, (x, p[f'{key}_startY'])); x += im.width
            if not values.get('h24', True) and 'am_x' in p:
                src = p['am_en_path'] if T['h'] < 12 else p['pm_en_path']
                canvas.alpha_composite(load(src), (p['am_x'], p['am_y']))
        elif t == 'IMG_WEEK':
            canvas.alpha_composite(load(p['week_en'][weekday_mon0(T['Y'], T['M'], T['D'])]), (p['x'], p['y']))
        elif t == 'IMG_DATE':
            x = p['day_startX']
            for ch in f"{T['D']:02d}":
                im = load(p['day_en_array'][int(ch)]); canvas.alpha_composite(im, (x, p['day_startY'])); x += im.width
            canvas.alpha_composite(load(p['month_en_array'][T['M'] - 1]), (p['month_startX'], p['month_startY']))
        elif t == 'TEXT':
            f = ImageFont.truetype('/usr/share/fonts/truetype/google-fonts/ofl/roboto/Roboto[wdth,wght].ttf', p['text_size'] + 2)
            f.set_variation_by_axes([600, 100])
            txt = ov.get('text', '')
            d = ImageDraw.Draw(canvas)
            while txt and d.textlength(txt, font=f) > p['w']: txt = txt[:-2] + '…'
            d.text((p['x'], p['y'] + p['h'] // 2), txt, font=f, fill=hexcol(p['color']), anchor='lm')
    # device mask (rounded corners) for realism
    mask = Image.new('L', (SW, SH), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, SW - 1, SH - 1), radius=RADIUS, fill=255)
    out = Image.new('RGBA', (SW, SH), (0, 0, 0, 0)); out.paste(canvas, (0, 0), mask)
    out.save(path)
    return out

# --------------------------------------------------------------------- checks
def corner_ok(px, py):
    r = RADIUS - CORNER_CLEAR
    for cx, cy in ((RADIUS, RADIUS), (SW - RADIUS, RADIUS), (RADIUS, SH - RADIUS), (SW - RADIUS, SH - RADIUS)):
        inx = px < cx if cx == RADIUS else px > cx
        iny = py < cy if cy == RADIUS else py > cy
        if inx and iny and math.hypot(px - cx, py - cy) > r: return False
    return True

def checks():
    problems = []
    boxes = []
    for wdg in W:
        if not wdg['box'] or not wdg['check'] or wdg['aod']: continue
        x, y, w, h = wdg['box']
        if x < SAFE[0] or y < SAFE[1] or x + w > SAFE[2] or y + h > SAFE[3]:
            problems.append(f'{wdg["id"]} outside safe area {wdg["box"]}')
        for px, py in ((x, y), (x + w, y), (x, y + h), (x + w, y + h)):
            if not corner_ok(px, py): problems.append(f'{wdg["id"]} too close to corner curve at {(px, py)}')
        if x < BADGE[2] and x + w > BADGE[0] and y < BADGE[3] and y + h > BADGE[1]:
            problems.append(f'{wdg["id"]} intrudes on notification badge zone')
        p = wdg['p']
        if wdg['type'] == 'IMG':
            iw, ih = SIZES[p['src']]
            if p['w'] < iw or p['h'] < ih: problems.append(f'{wdg["id"]} w/h smaller than image')
        boxes.append((wdg['id'], x, y, w, h))
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            a, b = boxes[i], boxes[j]
            if a[1] < b[1] + b[3] and b[1] < a[1] + a[3] and a[2] < b[2] + b[4] and b[2] < a[2] + a[4]:
                pair = {a[0], b[0]}
                allowed = [{'zone_track', 'zone_lit'}, {'sun_up', 'sun_dn'}]
                if not any(pair <= s for s in allowed):
                    problems.append(f'overlap: {a[0]} x {b[0]}')
    return problems

# --------------------------------------------------------------------- JS generation
JS_CONST_TYPES = {'WEATHER_CURRENT', 'WEATHER_HIGH', 'WEATHER_LOW', 'BIO_CHARGE', 'VO2MAX', 'ALARM_CLOCK', 'HEART', 'SLEEP',
                  'MOON', 'STEP', 'PAI_WEEKLY'}

def js_params(wdg):
    p = {k: v for k, v in wdg['p'].items() if not k.startswith('_')}
    out = []
    for k, v in p.items():
        if k == 'type': out.append(f'type: data_type.{v}'); continue
        if k == 'align_h': out.append(f'align_h: align.{ {"left": "LEFT", "center": "CENTER_H", "right": "RIGHT"}[v] }'); continue
        if k == 'color': out.append(f'color: {v}'); continue
        if k == 'unit': out.extend([f'unit_en: {json.dumps(v)}', f'unit_sc: {json.dumps(v)}', f'unit_tc: {json.dumps(v)}']); continue
        if k == 'iunit': out.extend([f'imperial_unit_en: {json.dumps(v)}', f'imperial_unit_sc: {json.dumps(v)}', f'imperial_unit_tc: {json.dumps(v)}']); continue
        if k == 'negative': out.append(f'negative_image: {json.dumps(v)}'); continue
        if k == 'invalid': out.append(f'invalid_image: {json.dumps(v)}'); continue
        if k == 'dot': out.append(f'dot_image: {json.dumps(v)}'); continue
        if k == 'week_en': out.extend([f'week_en: {json.dumps(v)}', f'week_sc: {json.dumps(v)}', f'week_tc: {json.dumps(v)}']); continue
        if k == 'day_en_array': out.extend([f'day_en_array: {json.dumps(v)}', f'day_sc_array: {json.dumps(v)}', f'day_tc_array: {json.dumps(v)}']); continue
        if k == 'month_en_array': out.extend([f'month_en_array: {json.dumps(v)}', f'month_sc_array: {json.dumps(v)}', f'month_tc_array: {json.dumps(v)}']); continue
        if k in ('am_en_path', 'pm_en_path'):
            out.append(f'{k}: {json.dumps(v)}'); continue
        out.append(f'{k}: {json.dumps(v)}')
    out.append('show_level: show_level.ONLY_AOD' if wdg['aod'] else 'show_level: show_level.ONLY_NORMAL')
    return '{ ' + ', '.join(out) + ' }'

def gen_js():
    lines = []
    for wdg in W:
        lines.append(f"    W[{json.dumps(wdg['id'])}] = mk(widget.{wdg['type']}, P[{json.dumps(wdg['id'])}] = {js_params(wdg)})")
    tpl = open(os.path.join(ROOT, 'tools', 'index.template.js')).read()
    cfg = dict(WK=WK, PAD=PAD, BARW=BARW, ZONES=ZONES, ZONE_EDGES=ZONE_EDGES, ZONE_ENDS=ZONE_ENDS, ZONE_SEG=SIZES['zone/lit.png'][0] - 2 * PAD,
               ZONE_H=SIZES['zone/lit.png'][1])
    js = tpl.replace('/*WIDGETS*/', '\n'.join(lines)).replace('/*CFG*/', json.dumps(cfg))
    os.makedirs(os.path.join(ROOT, 'watchface'), exist_ok=True)
    open(os.path.join(ROOT, 'watchface', 'index.js'), 'w').write(js)

def gen_app_json():
    perms = ['data:user.hd.heart_rate', 'data:user.hd.step', 'data:user.hd.distance', 'data:user.hd.sleep', 'data:user.hd.pai']
    aj = {
        'configVersion': 'v3',
        'app': {'appId': 1093518, 'appName': 'Sidecar Wide', 'appType': 'watchface',
                'version': {'code': VERSION_CODE, 'name': f'1.0.{VERSION_CODE}'},
                'icon': 'icon.png', 'vender': 'sidecar', 'description': 'Sidecar Wide watch face for Amazfit Bip 6'},
        'permissions': perms,
        'runtime': {'apiVersion': {'compatible': '4.2.0', 'target': '4.2.0', 'minVersion': '4.2.0'}},
        'targets': {'bip6': {
            'module': {'watchface': {'path': 'watchface/index', 'main': 1, 'editable': 0, 'lockscreen': 0, 'hightCost': 0}},
            'platforms': [{'name': 'bip6', 'deviceSource': 9765120}, {'name': 'bip6-w', 'deviceSource': 9765121},
                          {'name': 'bip6-x', 'deviceSource': 10158337}],
            'designWidth': 390}},
        'i18n': {'en-US': {'appName': 'Sidecar Wide'}},
        'defaultLanguage': 'en-US', 'debug': False,
    }
    json.dump(aj, open(os.path.join(ROOT, 'app.json'), 'w'), indent=2)
    open(os.path.join(ROOT, 'app.js'), 'w').write("App({\n  globalData: {},\n  onCreate() {},\n  onDestroy() {}\n})\n")

# --------------------------------------------------------------------- main
if __name__ == '__main__':
    probs = checks()
    SAMPLE = dict(Y=2026, M=11, D=21, h=10, m=42, s=37, hr=158, charge=76, sleep=444, steps=8412, target=10000, dist=6120, imperial=True,
                  pai=86, vo2=48, batt=64, temp=14, hi=16, lo=6, wcode=0, alarm='06.30', sunrise=(6, 52), sunset=(17, 22),
                  city='Springfield', h24=False)
    WORST = dict(Y=2026, M=12, D=1, h=23, m=58, s=59, hr=190, charge=100, sleep=779, steps=99999, target=8000, dist=99990,
                 pai=999, vo2=65, batt=100, temp=-15, hi=-15, lo=-25, wcode=18, alarm='23.59', sunrise=(7, 5), sunset=(16, 20),
                 city='Rancho Santa Margarita', h24=True)
    ZERO = dict(Y=2027, M=1, D=4, h=0, m=1, s=0, hr=0, charge=0, sleep=0, steps=0, target=8000, dist=0,
                pai=0, vo2=0, batt=5, temp=0, hi=0, lo=0, wcode=28, alarm='--', sunrise=(7, 30), sunset=(16, 40),
                city='', h24=False)
    out = os.path.join(ROOT, 'preview'); os.makedirs(out, exist_ok=True)
    render(SAMPLE, os.path.join(out, 'sample.png'))
    render(WORST, os.path.join(out, 'worst_case.png'))
    render(ZERO, os.path.join(out, 'zeros.png'))
    render(dict(SAMPLE, steps=150, target=8000), os.path.join(out, 'low_steps.png'))
    render(SAMPLE, os.path.join(out, 'aod.png'), aod=True)
    # app icon + store preview from the sample render
    s = Image.open(os.path.join(out, 'sample.png'))
    s.resize((266, 307), Image.LANCZOS).save(os.path.join(A, 'preview.png'))
    s.resize((124, 143), Image.LANCZOS).save(os.path.join(ROOT, 'assets', 'bip6', 'icon.png'))
    gen_js(); gen_app_json()
    print('\n'.join(probs) if probs else 'checks: OK')
