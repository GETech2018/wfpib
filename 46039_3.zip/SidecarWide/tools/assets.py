"""Render every static PNG for the Sidecar watch face.

Glyph fonts are drawn with Pillow from the local Roboto variable font (condensed width).
Icons, panels and multi-frame art are drawn as SVG and rasterised by headless Chrome.
Every non-font image gets PAD px of transparent padding on all sides; the layout places
such images PAD px up/left so the visible art lands on the intended pixel.
"""
import json, math, os, sys
from PIL import Image, ImageDraw, ImageFont

ROOT = sys.argv[1]
OUT = os.path.join(ROOT, 'assets', 'bip6')
PAD = 2
ROBOTO = '/usr/share/fonts/truetype/google-fonts/ofl/roboto/Roboto[wdth,wght].ttf'
os.makedirs(OUT, exist_ok=True)
META = {}  # name -> (w, h) of the PNG as written (padding included for art)

# ---------------------------------------------------------------- colours
C = dict(
    ink='#F4F1EC', dim='#A9ADB4', lcd='#17140F', lcd_dot='#221D16', lcd_ink='#F3E9D2', red='#FF7A45',
    cyan='#22D3EE', cyan_dim='#123E47', track='#30353D', border='#3E444E', orange='#F08A5D',
    coral='#F0566A', panel_ink='#04211E', violet='#B49CFF', blue='#8FB8FF', sun='#FFC53D',
    aod='#9AA0A6',
)
ZONES = [('relaxed', '#7C9FBB'), ('light', '#4DA3FF'), ('intensive', '#2FD67B'),
         ('aerobic', '#FFD23F'), ('anaerobic', '#FF8A2A'), ('vo2', '#FF3B4E')]


def font(size, wght=700, wdth=75):
    f = ImageFont.truetype(ROBOTO, size)
    try:
        f.set_variation_by_axes([wght, wdth])
    except Exception:
        pass
    return f


def save(img, name):
    path = os.path.join(OUT, name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path)
    META[name] = img.size


# ---------------------------------------------------------------- glyph sets
def glyph_set(prefix, size, color, cell_h, wght=700, extra=None, cell_w=None):
    """Digits 0-9 in fixed-width cells (so text boxes can be sized for the widest value)
    plus optional extra glyphs: dict name -> text. Returns cell width."""
    f = font(size, wght)
    widths = [f.getbbox(str(d))[2] - f.getbbox(str(d))[0] for d in range(10)]
    cw = cell_w or (max(widths) + 2)
    asc = max(-f.getbbox(str(d), anchor='ls')[1] for d in range(10))
    base = (cell_h + asc) // 2  # vertically centre the digit's cap height
    def draw(text, w):
        im = Image.new('RGBA', (w, cell_h), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((w / 2, base), text, font=f, fill=color, anchor='ms')
        return im
    for d in range(10):
        save(draw(str(d), cw), f'{prefix}/{d}.png')
    for name, text in (extra or {}).items():
        bb = f.getbbox(text)
        w = max(4, bb[2] - bb[0] + 2)
        save(draw(text, w), f'{prefix}/{name}.png')
    return cw


SETS = {}
SETS['time'] = glyph_set('font/time', 104, C['lcd_ink'], 76, 800, {'colon': ':'})
SETS['aod'] = glyph_set('font/aod', 104, C['aod'], 76, 600, {'colon': ':'})
SETS['sec'] = glyph_set('font/sec', 36, C['red'], 28, 800)
SETS['charge'] = glyph_set('font/charge', 30, C['cyan'], 24, 700, {'dash': '--'})
for z, col in ZONES:
    SETS['hr_' + z] = glyph_set('font/hr_' + z, 30, col, 24, 700, {'dash': '--'})
SETS['sleep'] = glyph_set('font/sleep', 28, C['ink'], 22, 700, {'colon': ':', 'dash': '--'})
SETS['small'] = glyph_set('font/small', 17, C['ink'], 14, 700,
                          {'pct': '%', 'D': 'D', 'colon': ':', 'dash': '--', 'minus': '-', 'deg': '°'})
SETS['date'] = glyph_set('font/date', 20, C['ink'], 16, 700)
SETS['temp'] = glyph_set('font/temp', 28, C['ink'], 22, 700, {'minus': '-', 'deg': '°', 'dash': '--'})
SETS['hi'] = glyph_set('font/hi', 13, C['orange'], 12, 800, {'minus': '-', 'deg': '°', 'dash': '--'})
SETS['lo'] = glyph_set('font/lo', 13, C['blue'], 12, 800, {'minus': '-', 'deg': '°', 'dash': '--'})
SETS['ssmall'] = glyph_set('font/ssmall', 17, C['ink'], 14, 700, {'pct': '%', 'colon': ':', 'dash': '--'})
SETS['pdark'] = glyph_set('font/pdark', 23, C['panel_ink'], 18, 800, {'dash': '--'})
SETS['psmall'] = glyph_set('font/psmall', 17, C['panel_ink'], 14, 700,
                           {'pct': '%', 'colon': ':', 'dot': '.', 'km': 'km', 'mi': 'mi', 'dash': '--'})

# word images (week, month, labels)
def word(name, text, size, color, wght=700, h=None):
    f = font(size, wght)
    bb = f.getbbox(text)
    w = bb[2] - bb[0] + 2
    hh = h or (bb[3] - bb[1] + 2)
    asc = -f.getbbox('A', anchor='ls')[1]
    im = Image.new('RGBA', (w, hh), (0, 0, 0, 0))
    ImageDraw.Draw(im).text((1 - bb[0], (hh + asc) // 2), text, font=f, fill=color, anchor='ls')
    save(im, name)

for i, d in enumerate(['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN']):
    word(f'week/{i}.png', d, 20, C['ink'], h=16)
for i, m in enumerate(['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']):
    word(f'month/{i}.png', m, 20, C['ink'], h=16)
word('label/am.png', 'AM', 15, C['red'], h=12)
word('label/pm.png', 'PM', 15, C['red'], h=12)
word('label/mo.png', 'MO', 17, C['orange'], h=14)
word('label/yr.png', 'YR', 17, C['orange'], h=14)
word('label/h.png', 'H', 17, C['panel_ink'], h=14)
word('label/l.png', 'L', 17, C['panel_ink'], h=14)

json.dump({'sets': SETS}, open(os.path.join(ROOT, 'tools', 'glyphs.json'), 'w'))

# ---------------------------------------------------------------- SVG art via Chrome
ART = {}  # name -> (w, h, svg_inner, viewBox or None)

def art(name, w, h, inner, vb=None):
    ART[name] = (w, h, inner, vb or f'0 0 {w} {h}')

HEART = 'M12 20.5C12 20.5 3 15 2.2 9.5 1.6 5.8 4 3.5 7 3.5 9.2 3.5 10.9 4.8 12 6.6 13.1 4.8 14.8 3.5 17 3.5 20 3.5 22.4 5.8 21.8 9.5 21 15 12 20.5 12 20.5Z'
CHARGE = ('<g fill="{c}"><circle cx="12" cy="6.6" r="3.7"/><rect x="10.6" y="9.5" width="2.8" height="3.4" rx=".6"/>'
          '<path fill-rule="evenodd" d="M4.2 20C4.2 15.2 7.5 12.3 12 12.3S19.8 15.2 19.8 20Z M12.9 13.7 10.3 17.1H12l-.7 2.2 2.6-3.4h-1.6Z"/></g>')
FEET = 'M8.5 3c2 0 3 2.3 3 4.8S10.4 12 8.5 12 5.5 10.3 5.5 7.8 6.5 3 8.5 3zM7 13.5h3.2l-.3 2.3a1.5 1.5 0 0 1-3 0zM15.5 7c2 0 3 2.3 3 4.8s-1.1 4.2-3 4.2-3-1.7-3-4.2S13.5 7 15.5 7zM14 17.5h3.2l-.3 2.3a1.5 1.5 0 0 1-3 0z'
BED = '<path d="M3 19V6M3 14h18v5M21 14v-1a3 3 0 0 0-3-3h-7v4" fill="none" stroke="{c}" stroke-width="2.4" stroke-linecap="round"/><circle cx="7" cy="10.5" r="1.8" fill="{c}"/>'
BELL = '<path d="M6 16.5V11a6 6 0 0 1 12 0v5.5l1.5 1.5h-15zM10 20.5a2 2 0 0 0 4 0" fill="none" stroke="{c}" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>'
SUNUP = '<path d="M3 19h18M7 19a5 5 0 0 1 10 0M12 3v6M9 6l3-3 3 3" fill="none" stroke="{c}" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>'
SUNDN = '<path d="M3 19h18M7 19a5 5 0 0 1 10 0M12 3v6M9 6l3 3 3-3" fill="none" stroke="{c}" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>'

for z, col in ZONES:
    art(f'icon/heart_{z}.png', 20, 20, f'<path d="{HEART}" fill="{col}"/>', '0 0 24 24')
art('icon/charge.png', 20, 20, CHARGE.format(c=C['cyan']), '0 0 24 24')
art('icon/bed.png', 18, 18, BED.format(c=C['violet']), '0 0 24 24')
art('icon/feet.png', 14, 14, f'<path d="{FEET}" fill="{C["panel_ink"]}"/>', '0 0 24 24')
art('icon/bell.png', 15, 15, BELL.format(c=C['ink']), '0 0 24 24')
art('icon/sunup.png', 16, 16, SUNUP.format(c=C['sun']), '0 0 24 24')
art('icon/sundn.png', 16, 16, SUNDN.format(c='#FF8A4C'), '0 0 24 24')
art('icon/batt.png', 26, 14, f'<rect x="1" y="1" width="21" height="12" rx="3" fill="none" stroke="{C["ink"]}" stroke-width="2"/>'
    f'<rect x="23" y="4.5" width="2.5" height="5" rx="1" fill="{C["ink"]}"/>')
art('badge/pai.png', 30, 16, f'<rect width="30" height="16" rx="4" fill="{C["panel_ink"]}"/>'
    f'<text x="15" y="12.2" text-anchor="middle" font-family="Roboto" font-stretch="75%" font-weight="800" font-size="12" fill="#2EC4B6">PAI</text>')
art('badge/vo2.png', 30, 16, f'<rect x="1" y="1" width="28" height="14" rx="3.5" fill="none" stroke="{C["panel_ink"]}" stroke-width="1.6"/>'
    f'<text x="15" y="12.2" text-anchor="middle" font-family="Roboto" font-stretch="75%" font-weight="800" font-size="12" fill="{C["panel_ink"]}">VO₂</text>')

# panels
art('panel/lcd.png', 362, 132, f'<defs><pattern id="d" width="4" height="4" patternUnits="userSpaceOnUse"><rect width="4" height="4" fill="{C["lcd"]}"/>'
    f'<circle cx="2" cy="2" r="0.9" fill="{C["lcd_dot"]}"/></pattern></defs><rect width="362" height="132" rx="18" fill="url(#d)"/>')
art('panel/tile.png', 116, 56, '<rect x=".5" y=".5" width="115" height="55" rx="14" fill="#111317" stroke="#3E444E" stroke-width="1"/>')
art('panel/sky.png', 177, 108, '<rect x=".75" y=".75" width="175.5" height="106.5" rx="18" fill="#13202A" stroke="#3E5670" stroke-width="1.5"/>')
art('panel/act.png', 177, 108, '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2EC4B6"/>'
    '<stop offset="1" stop-color="#1B998B"/></linearGradient></defs><rect width="177" height="108" rx="18" fill="url(#g)"/>')
# segmented charge meter: lit strip is a FILL_RECT under this mask; mask paints the gaps black
SEG_W, SEG_N, SEG_GAP = 100, 10, 2
seg = (SEG_W - SEG_GAP * (SEG_N - 1)) / SEG_N
holes = ''.join(f'<rect x="{i * (seg + SEG_GAP):.2f}" y="0" width="{seg:.2f}" height="6" rx="2" fill="black"/>' for i in range(SEG_N))
art('meter/mask.png', SEG_W, 6, f'<defs><mask id="m"><rect width="{SEG_W}" height="6" fill="white"/>{holes}</mask></defs>'
    f'<rect width="{SEG_W}" height="6" fill="#000000" mask="url(#m)"/>')
art('meter/track.png', SEG_W, 6, ''.join(f'<rect x="{i * (seg + SEG_GAP):.2f}" y="0" width="{seg:.2f}" height="6" rx="2" fill="{C["cyan_dim"]}"/>' for i in range(SEG_N)))
# fallback stepped meter frames (used only if a JS BioCharge reading is unavailable)
for k in range(11):
    art(f'meter/lv_{k}.png', SEG_W, 6, ''.join(f'<rect x="{i * (seg + SEG_GAP):.2f}" y="0" width="{seg:.2f}" height="6" rx="2" fill="{C["cyan"] if i < k else C["cyan_dim"]}"/>' for i in range(SEG_N)))
# heart-rate zone ladder: dim track; lit overlay is a cropped IMG (same method as bars)
ZW, ZG = 100, 2
zs = (ZW - ZG * 5) / 6
art('zone/track.png', ZW, 6, ''.join(f'<rect x="{i * (zs + ZG):.2f}" y="0" width="{zs:.2f}" height="6" rx="3" fill="{C["track"]}"/>' for i in range(6)))
art('zone/lit.png', ZW, 6, ''.join(f'<rect x="{i * (zs + ZG):.2f}" y="0" width="{zs:.2f}" height="6" rx="3" fill="{col}"/>' for i, (_, col) in enumerate(ZONES)))

# week strip boxes (Monday first)
LET = ['MO', 'TU', 'WE', 'TH', 'FR', 'SA', 'SU']
for i, l in enumerate(LET):
    t = f'<text x="14" y="14.6" text-anchor="middle" font-family="Roboto" font-stretch="75%" font-weight="800" font-size="12.5"'
    art(f'week/past_{i}.png', 28, 20, f'<rect width="28" height="20" rx="3" fill="{C["lcd_ink"]}"/>{t} fill="{C["lcd"]}">{l}</text>')
    art(f'week/next_{i}.png', 28, 20, f'<rect x=".75" y=".75" width="26.5" height="18.5" rx="2.5" fill="none" stroke="#5A6070" stroke-width="1.5"/>{t} fill="{C["lcd_ink"]}">{l}</text>')
    art(f'week/today_{i}.png', 40, 30, f'<rect x="1" y="1" width="38" height="28" rx="4" fill="none" stroke="{C["red"]}" stroke-width="2"/>'
        f'<text x="20" y="19.5" text-anchor="middle" font-family="Roboto" font-stretch="75%" font-weight="800" font-size="12.5" fill="{C["lcd_ink"]}">{l}</text>')

# steps ring: 21 frames (0%..100%)
R, SW = 30, 6
circ = 2 * math.pi * R
for k in range(41):
    p = k / 40
    arc = f'<circle cx="35" cy="35" r="{R}" fill="none" stroke="{C["panel_ink"]}" stroke-width="{SW}" stroke-linecap="round" stroke-dasharray="{circ * p:.2f} {circ:.2f}" transform="rotate(-90 35 35)"/>' if k else ''
    art(f'ring/{k}.png', 70, 70, f'<circle cx="35" cy="35" r="{R}" fill="#1A0E0A" fill-opacity=".12" stroke="#1A0E0A" stroke-opacity=".25" stroke-width="{SW}"/>{arc}')

# moon: 30 frames, frame k = phase k/30 (0 new, 15 full), waxing lit on the right (northern hemisphere)
for k in range(30):
    f = k / 30
    lit = '#F1EBD8'; dark = '#24384E'
    if f <= 0.5:   # waxing: right side lit
        rx = abs(math.cos(2 * math.pi * f)) * 11
        sweep2 = 0 if f < 0.25 else 1
        d = f'M15 4A11 11 0 0 1 15 26A{rx:.2f} 11 0 0 {sweep2} 15 4Z'
    else:          # waning: left side lit
        rx = abs(math.cos(2 * math.pi * f)) * 11
        sweep2 = 1 if f < 0.75 else 0
        d = f'M15 4A11 11 0 0 0 15 26A{rx:.2f} 11 0 0 {1 - sweep2} 15 4Z'
    shape = '' if k == 0 else f'<path d="{d}" fill="{lit}"/>'
    art(f'moon/{k}.png', 22, 22, f'<circle cx="15" cy="15" r="11" fill="{dark}"/>{shape}', '4 4 22 22')

# weather: 29 icons in Zepp code order (0-based)
def cloud(c='#E6E8EC', dx=0, dy=0, s=1):
    return f'<path transform="translate({dx} {dy}) scale({s})" d="M8 20h9.5a3.8 3.8 0 0 0 .4-7.6A5.2 5.2 0 0 0 8 13.2 3.4 3.4 0 0 0 8 20z" fill="{c}"/>'
SUN = f'<circle cx="9" cy="9" r="4.5" fill="{C["sun"]}"/>'
SUNBIG = f'<circle cx="12" cy="12" r="5" fill="{C["sun"]}"/>' + ''.join(
    f'<line x1="{12 + 7.5 * math.cos(a):.1f}" y1="{12 + 7.5 * math.sin(a):.1f}" x2="{12 + 10 * math.cos(a):.1f}" y2="{12 + 10 * math.sin(a):.1f}" stroke="{C["sun"]}" stroke-width="2" stroke-linecap="round"/>'
    for a in [i * math.pi / 4 for i in range(8)])
MOONI = '<path d="M16 4.5a7.5 7.5 0 1 0 5 12.2A6 6 0 0 1 16 4.5z" fill="#E8DFC8"/>'
def drops(n, c='#5AB0FF', y=21):
    xs = [8, 12, 16, 10, 14][:n]
    return ''.join(f'<line x1="{x}" y1="{y}" x2="{x - 1.2}" y2="{y + 2.6}" stroke="{c}" stroke-width="1.8" stroke-linecap="round"/>' for x in xs)
def flakes(n, y=22):
    xs = [8, 12, 16][:n]
    return ''.join(f'<circle cx="{x}" cy="{y}" r="1.3" fill="#FFFFFF"/>' for x in xs)
BOLT = '<path d="M12.5 17 10 21h2.5l-1 3 3.5-4.5h-2.5l1-2.5z" fill="#FFD23F"/>'
HAIL = '<circle cx="9" cy="23" r="1.4" fill="#BFE3FF"/><circle cx="15" cy="23" r="1.4" fill="#BFE3FF"/>'
FOG = ''.join(f'<line x1="5" y1="{y}" x2="19" y2="{y}" stroke="#C9CDD3" stroke-width="2" stroke-linecap="round"/>' for y in (9, 13, 17))
DUST = ''.join(f'<path d="M4 {y}h12a2 2 0 1 0-2-2" fill="none" stroke="#D9B26A" stroke-width="1.8" stroke-linecap="round"/>' for y in (10, 15))
def up(c): return cloud(c, 0, -3)
W = {
    0: SUN + cloud(), 1: up('#C9CDD3') + drops(2), 2: up('#C9CDD3') + flakes(2), 3: SUNBIG,
    4: cloud('#AEB3BB', 0, -1), 5: up('#C9CDD3') + drops(2), 6: up('#C9CDD3') + flakes(2),
    7: up('#C9CDD3') + drops(3), 8: up('#C9CDD3') + flakes(3), 9: up('#AEB3BB') + flakes(3, 21) + flakes(2, 24),
    10: up('#AEB3BB') + drops(3) + drops(2, y=24), 11: DUST + '<circle cx="18" cy="19" r="1.5" fill="#D9B26A"/>',
    12: up('#C9CDD3') + drops(1) + '<circle cx="15" cy="22" r="1.3" fill="#FFFFFF"/>', 13: FOG,
    14: FOG.replace('#C9CDD3', '#B8A98F'), 15: up('#AEB3BB') + BOLT + drops(1, y=20),
    16: up('#8E949D') + flakes(3, 20) + flakes(3, 24), 17: DUST, 18: up('#8E949D') + drops(3) + drops(3, '#2F8CFF', 24),
    19: up('#AEB3BB') + drops(1) + HAIL, 20: up('#8E949D') + BOLT + HAIL, 21: up('#8E949D') + drops(3, '#2F8CFF') + drops(2, '#2F8CFF', 24),
    22: DUST.replace('#D9B26A', '#C99A4A'), 23: DUST.replace('1.8', '2.6') + '<circle cx="19" cy="20" r="2" fill="#C99A4A"/>',
    24: up('#AEB3BB') + drops(3, '#2F8CFF'), 25: '<text x="12" y="18" text-anchor="middle" font-family="Roboto" font-weight="800" font-size="15" fill="#C9CDD3">?</text>',
    26: MOONI + cloud('#C9CDD3', 0, 1), 27: MOONI + up('#C9CDD3') + drops(2), 28: MOONI,
}
for code in range(29):
    art(f'weather/{code}.png', 30, 30, W[code], '0 0 24 26')

art('misc/clear.png', 4, 4, '')
art('tri/up.png', 8, 7, f'<path d="M4 0 8 7H0z" fill="{C["orange"]}"/>')
art('tri/dn.png', 8, 7, f'<path d="M0 0h8L4 7z" fill="{C["blue"]}"/>')
html = ['<html><head><style>@font-face{font-family:Roboto;src:url("file://' + ROBOTO + '")}'
        'body{margin:0;background:transparent}div{display:inline-block;line-height:0}</style></head><body>']
for i, (name, (w, h, inner, vb)) in enumerate(ART.items()):
    html.append(f'<div id="a{i}" style="padding:{PAD}px"><svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="{vb}">{inner}</svg></div>')
html.append('</body></html>')
hp = os.path.join(ROOT, 'tools', '_art.html')
open(hp, 'w').write(''.join(html))

from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--allow-file-access-from-files'])
    pg = b.new_page(device_scale_factor=1)
    pg.goto('file://' + hp)
    pg.wait_for_timeout(300)
    for i, name in enumerate(ART):
        path = os.path.join(OUT, name)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        pg.locator(f'#a{i}').screenshot(path=path, omit_background=True)
        META[name] = Image.open(path).size
    b.close()

json.dump({'pad': PAD, 'sizes': META, 'sets': SETS}, open(os.path.join(ROOT, 'tools', 'assets.json'), 'w'), indent=0)
print('assets:', len(META))
