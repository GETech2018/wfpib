﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'background_a96b7f62.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 310,
              y: 382,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 70,
              y: 356,
              src: 'bd_1.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 5,
              font_array: ["chars_A1AAAE7_000.png","chars_A1AAAE7_001.png","chars_A1AAAE7_002.png","chars_A1AAAE7_003.png","chars_A1AAAE7_004.png","chars_A1AAAE7_005.png","chars_A1AAAE7_006.png","chars_A1AAAE7_007.png","chars_A1AAAE7_008.png","chars_A1AAAE7_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 121,
              month_startY: 40,
              month_sc_array: ["chars_F21DD619_000.png","chars_F21DD619_001.png","chars_F21DD619_002.png","chars_F21DD619_003.png","chars_F21DD619_004.png","chars_F21DD619_005.png","chars_F21DD619_006.png","chars_F21DD619_007.png","chars_F21DD619_008.png","chars_F21DD619_009.png"],
              month_tc_array: ["chars_F21DD619_000.png","chars_F21DD619_001.png","chars_F21DD619_002.png","chars_F21DD619_003.png","chars_F21DD619_004.png","chars_F21DD619_005.png","chars_F21DD619_006.png","chars_F21DD619_007.png","chars_F21DD619_008.png","chars_F21DD619_009.png"],
              month_en_array: ["chars_F21DD619_000.png","chars_F21DD619_001.png","chars_F21DD619_002.png","chars_F21DD619_003.png","chars_F21DD619_004.png","chars_F21DD619_005.png","chars_F21DD619_006.png","chars_F21DD619_007.png","chars_F21DD619_008.png","chars_F21DD619_009.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 67,
              day_startY: 40,
              day_sc_array: ["chars_D4C700F1_000.png","chars_D4C700F1_001.png","chars_D4C700F1_002.png","chars_D4C700F1_003.png","chars_D4C700F1_004.png","chars_D4C700F1_005.png","chars_D4C700F1_006.png","chars_D4C700F1_007.png","chars_D4C700F1_008.png","chars_D4C700F1_009.png"],
              day_tc_array: ["chars_D4C700F1_000.png","chars_D4C700F1_001.png","chars_D4C700F1_002.png","chars_D4C700F1_003.png","chars_D4C700F1_004.png","chars_D4C700F1_005.png","chars_D4C700F1_006.png","chars_D4C700F1_007.png","chars_D4C700F1_008.png","chars_D4C700F1_009.png"],
              day_en_array: ["chars_D4C700F1_000.png","chars_D4C700F1_001.png","chars_D4C700F1_002.png","chars_D4C700F1_003.png","chars_D4C700F1_004.png","chars_D4C700F1_005.png","chars_D4C700F1_006.png","chars_D4C700F1_007.png","chars_D4C700F1_008.png","chars_D4C700F1_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 158,
              y: 39,
              week_en: ["chars_DFDB1338_000.png","chars_DFDB1338_001.png","chars_DFDB1338_002.png","chars_DFDB1338_003.png","chars_DFDB1338_004.png","chars_DFDB1338_005.png","chars_DFDB1338_006.png"],
              week_tc: ["chars_DFDB1338_000.png","chars_DFDB1338_001.png","chars_DFDB1338_002.png","chars_DFDB1338_003.png","chars_DFDB1338_004.png","chars_DFDB1338_005.png","chars_DFDB1338_006.png"],
              week_sc: ["chars_DFDB1338_000.png","chars_DFDB1338_001.png","chars_DFDB1338_002.png","chars_DFDB1338_003.png","chars_DFDB1338_004.png","chars_DFDB1338_005.png","chars_DFDB1338_006.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 34,
              hour_startY: 75,
              hour_array: ["chars_A7858887_000.png","chars_A7858887_001.png","chars_A7858887_002.png","chars_A7858887_003.png","chars_A7858887_004.png","chars_A7858887_005.png","chars_A7858887_006.png","chars_A7858887_007.png","chars_A7858887_008.png","chars_A7858887_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 210,
              minute_startY: 75,
              minute_array: ["chars_A7858887_000.png","chars_A7858887_001.png","chars_A7858887_002.png","chars_A7858887_003.png","chars_A7858887_004.png","chars_A7858887_005.png","chars_A7858887_006.png","chars_A7858887_007.png","chars_A7858887_008.png","chars_A7858887_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 343,
              second_startY: 140,
              second_array: ["chars_81976841_000.png","chars_81976841_001.png","chars_81976841_002.png","chars_81976841_003.png","chars_81976841_004.png","chars_81976841_005.png","chars_81976841_006.png","chars_81976841_007.png","chars_81976841_008.png","chars_81976841_009.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 132,
              y: 120,
              image_array: ["set_3_140x140_meteo_1.png","set_3_140x140_meteo_2.png","set_3_140x140_meteo_3.png","set_3_140x140_meteo_4.png","set_3_140x140_meteo_5.png","set_3_140x140_meteo_6.png","set_3_140x140_meteo_7.png","set_3_140x140_meteo_8.png","set_3_140x140_meteo_9.png","set_3_140x140_meteo_10.png","set_3_140x140_meteo_11.png","set_3_140x140_meteo_12.png","set_3_140x140_meteo_13.png","set_3_140x140_meteo_14.png","set_3_140x140_meteo_15.png","set_3_140x140_meteo_16.png","set_3_140x140_meteo_17.png","set_3_140x140_meteo_18.png","set_3_140x140_meteo_19.png","set_3_140x140_meteo_20.png","set_3_140x140_meteo_21.png","set_3_140x140_meteo_22.png","set_3_140x140_meteo_23.png","set_3_140x140_meteo_24.png","set_3_140x140_meteo_25.png","set_3_140x140_meteo_26.png","set_3_140x140_meteo_27.png","set_3_140x140_meteo_28.png","set_3_140x140_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 24,
              y: 177,
              font_array: ["chars_75D7A3E7_000.png","chars_75D7A3E7_001.png","chars_75D7A3E7_002.png","chars_75D7A3E7_003.png","chars_75D7A3E7_004.png","chars_75D7A3E7_005.png","chars_75D7A3E7_006.png","chars_75D7A3E7_007.png","chars_75D7A3E7_008.png","chars_75D7A3E7_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_75D7A3E7_011.png',
              unit_tc: 'chars_75D7A3E7_011.png',
              unit_en: 'chars_75D7A3E7_011.png',
              negative_image: 'chars_75D7A3E7_010.png',
              invalid_image: 'chars_75D7A3E7_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 12,
              y: 243,
              font_array: ["chars_FB28CCCE_000.png","chars_FB28CCCE_001.png","chars_FB28CCCE_002.png","chars_FB28CCCE_003.png","chars_FB28CCCE_004.png","chars_FB28CCCE_005.png","chars_FB28CCCE_006.png","chars_FB28CCCE_007.png","chars_FB28CCCE_008.png","chars_FB28CCCE_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_FB28CCCE_011.png',
              unit_tc: 'chars_FB28CCCE_011.png',
              unit_en: 'chars_FB28CCCE_011.png',
              negative_image: 'chars_FB28CCCE_010.png',
              invalid_image: 'chars_FB28CCCE_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 67,
              y: 243,
              font_array: ["chars_FB28CCCE_000.png","chars_FB28CCCE_001.png","chars_FB28CCCE_002.png","chars_FB28CCCE_003.png","chars_FB28CCCE_004.png","chars_FB28CCCE_005.png","chars_FB28CCCE_006.png","chars_FB28CCCE_007.png","chars_FB28CCCE_008.png","chars_FB28CCCE_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_FB28CCCE_011.png',
              unit_tc: 'chars_FB28CCCE_011.png',
              unit_en: 'chars_FB28CCCE_011.png',
              negative_image: 'chars_FB28CCCE_010.png',
              invalid_image: 'chars_FB28CCCE_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 189,
              font_array: ["chars_CC7AB14_000.png","chars_CC7AB14_001.png","chars_CC7AB14_002.png","chars_CC7AB14_003.png","chars_CC7AB14_004.png","chars_CC7AB14_005.png","chars_CC7AB14_006.png","chars_CC7AB14_007.png","chars_CC7AB14_008.png","chars_CC7AB14_009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'chars_CC7AB14_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 239,
              font_array: ["chars_CC7AB14_000.png","chars_CC7AB14_001.png","chars_CC7AB14_002.png","chars_CC7AB14_003.png","chars_CC7AB14_004.png","chars_CC7AB14_005.png","chars_CC7AB14_006.png","chars_CC7AB14_007.png","chars_CC7AB14_008.png","chars_CC7AB14_009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'chars_CC7AB14_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 306,
              font_array: ["chars_9CF025FC_000.png","chars_9CF025FC_001.png","chars_9CF025FC_002.png","chars_9CF025FC_003.png","chars_9CF025FC_004.png","chars_9CF025FC_005.png","chars_9CF025FC_006.png","chars_9CF025FC_007.png","chars_9CF025FC_008.png","chars_9CF025FC_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 306,
              font_array: ["chars_C047B770_000.png","chars_C047B770_001.png","chars_C047B770_002.png","chars_C047B770_003.png","chars_C047B770_004.png","chars_C047B770_005.png","chars_C047B770_006.png","chars_C047B770_007.png","chars_C047B770_008.png","chars_C047B770_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 305,
              font_array: ["chars_C047B770_000.png","chars_C047B770_001.png","chars_C047B770_002.png","chars_C047B770_003.png","chars_C047B770_004.png","chars_C047B770_005.png","chars_C047B770_006.png","chars_C047B770_007.png","chars_C047B770_008.png","chars_C047B770_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 386,
              font_array: ["chars_C047B770_000.png","chars_C047B770_001.png","chars_C047B770_002.png","chars_C047B770_003.png","chars_C047B770_004.png","chars_C047B770_005.png","chars_C047B770_006.png","chars_C047B770_007.png","chars_C047B770_008.png","chars_C047B770_009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'chars_C047B770_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 310,
              y: 382,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 70,
              y: 356,
              src: 'bd_1.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 89,
              y: 39,
              week_en: ["chars_DFDB1338_000.png","chars_DFDB1338_001.png","chars_DFDB1338_002.png","chars_DFDB1338_003.png","chars_DFDB1338_004.png","chars_DFDB1338_005.png","chars_DFDB1338_006.png"],
              week_tc: ["chars_DFDB1338_000.png","chars_DFDB1338_001.png","chars_DFDB1338_002.png","chars_DFDB1338_003.png","chars_DFDB1338_004.png","chars_DFDB1338_005.png","chars_DFDB1338_006.png"],
              week_sc: ["chars_DFDB1338_000.png","chars_DFDB1338_001.png","chars_DFDB1338_002.png","chars_DFDB1338_003.png","chars_DFDB1338_004.png","chars_DFDB1338_005.png","chars_DFDB1338_006.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 34,
              hour_startY: 75,
              hour_array: ["chars_A7858887_000.png","chars_A7858887_001.png","chars_A7858887_002.png","chars_A7858887_003.png","chars_A7858887_004.png","chars_A7858887_005.png","chars_A7858887_006.png","chars_A7858887_007.png","chars_A7858887_008.png","chars_A7858887_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 210,
              minute_startY: 75,
              minute_array: ["chars_A7858887_000.png","chars_A7858887_001.png","chars_A7858887_002.png","chars_A7858887_003.png","chars_A7858887_004.png","chars_A7858887_005.png","chars_A7858887_006.png","chars_A7858887_007.png","chars_A7858887_008.png","chars_A7858887_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 126,
              y: 0,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'anteprima.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 11,
              y: 175,
              w: 100,
              h: 107,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'anteprima.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 277,
              y: 178,
              w: 100,
              h: 107,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'anteprima.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 9,
              y: 290,
              w: 113,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'anteprima.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 130,
              y: 290,
              w: 135,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'anteprima.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 267,
              y: 290,
              w: 135,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'anteprima.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportStatusScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 130,
              y: 368,
              w: 135,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'anteprima.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1047865, url: 'page/square_pamir/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}