﻿    /*
    ** Watch_Face_Editor tool v 17.2
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js


///////////////////  weathe animation /////////////////////////////
let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
let checkWIcon = null 

function switchWeatherIconsAnimation() {


let curAirIconIndex = weather.curAirIconIndex;
let Folder = "/W"+parseInt(curAirIconIndex)


if (weather.curAirIconIndex == undefined) { Folder = "/W25"} // ถ้ารับค่าไม่ได้ ให้ Folder เท่ากับ "/W25"

if (checkWIcon != curAirIconIndex) {
 hmUI.deleteWidget(normal_frame_animation_1);

            normal_frame_animation_1= hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 253,
              y: 378,
              anim_path: "animation"+Folder,
              anim_ext: "png",
              anim_prefix: "F",
              anim_fps: 3,
              anim_size: 4,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

checkWIcon = curAirIconIndex
}

 //hmUI.showToast({text: "index " + parseInt(curAirIconIndex)+":"+parseInt(checkWIcon) });
}

/////////////////// end  Weather animation /////////////////////////////////////



// Start color change
        let colornumber = 1
        let totalcolors = 6
        let namecolor = ''
        let array_min = ''
        let array_hour = ''
        let timedot = ''

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "WHITE"
array_min = ["Time1_0.png","Time1_1.png","Time1_2.png","Time1_3.png","Time1_4.png","Time1_5.png","Time1_6.png","Time1_7.png","Time1_8.png","Time1_9.png"];
array_hour = ["Time1_0.png","Time1_1.png","Time1_2.png","Time1_3.png","Time1_4.png","Time1_5.png","Time1_6.png","Time1_7.png","Time1_8.png","Time1_9.png"];
timedot = 'TIME_DOT_1.png'
}
if ( colornumber == 2) { namecolor = "BLUE"
array_min = ["Time2_0.png","Time2_1.png","Time2_2.png","Time2_3.png","Time2_4.png","Time2_5.png","Time2_6.png","Time2_7.png","Time2_8.png","Time2_9.png"];
array_hour =["Time2_0.png","Time2_1.png","Time2_2.png","Time2_3.png","Time2_4.png","Time2_5.png","Time2_6.png","Time2_7.png","Time2_8.png","Time2_9.png"];
timedot = 'TIME_DOT_2.png'
}
if ( colornumber == 3) { namecolor = "GREEN"
array_min = ["Time3_0.png","Time3_1.png","Time3_2.png","Time3_3.png","Time3_4.png","Time3_5.png","Time3_6.png","Time3_7.png","Time3_8.png","Time3_9.png"];
array_hour = ["Time3_0.png","Time3_1.png","Time3_2.png","Time3_3.png","Time3_4.png","Time3_5.png","Time3_6.png","Time3_7.png","Time3_8.png","Time3_9.png"];
timedot = 'TIME_DOT_3.png'
}
if ( colornumber == 4) { namecolor = "ORANGE"
array_min = ["Time4_0.png","Time4_1.png","Time4_2.png","Time4_3.png","Time4_4.png","Time4_5.png","Time4_6.png","Time4_7.png","Time4_8.png","Time4_9.png"];
array_hour = ["Time4_0.png","Time4_1.png","Time4_2.png","Time4_3.png","Time4_4.png","Time4_5.png","Time4_6.png","Time4_7.png","Time4_8.png","Time4_9.png"];
timedot = 'TIME_DOT_4.png'
}
if ( colornumber == 5) { namecolor = "YELLOW"
array_min = ["Time5_0.png","Time5_1.png","Time5_2.png","Time5_3.png","Time5_4.png","Time5_5.png","Time5_6.png","Time5_7.png","Time5_8.png","Time5_9.png"];
array_hour = ["Time5_0.png","Time5_1.png","Time5_2.png","Time5_3.png","Time5_4.png","Time5_5.png","Time5_6.png","Time5_7.png","Time5_8.png","Time5_9.png"];
timedot = 'TIME_DOT_5.png'
}
if ( colornumber == 6) { namecolor = "RED"
array_min = ["Time6_0.png","Time6_1.png","Time6_2.png","Time6_3.png","Time6_4.png","Time6_5.png","Time6_6.png","Time6_7.png","Time6_8.png","Time6_9.png"];
array_hour = ["Time6_0.png","Time6_1.png","Time6_2.png","Time6_3.png","Time6_4.png","Time6_5.png","Time6_6.png","Time6_7.png","Time6_8.png","Time6_9.png"];
timedot = 'TIME_DOT_6.png'
}


if (colornumber <= totalcolors){
//const deviceInfo = hmSetting.getDeviceInfo();

hmUI.showToast({text: namecolor});

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 318,
              minute_startY: 202,
              minute_array: array_min,
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.MORE, {
              x: 306,
              y: 212,
              src: timedot,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 193,
              hour_startY: 202,
              hour_array: array_hour,
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

}

                         
        }


        function click_Color2() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "WHITE"
array_min = ["Time1_0.png","Time1_1.png","Time1_2.png","Time1_3.png","Time1_4.png","Time1_5.png","Time1_6.png","Time1_7.png","Time1_8.png","Time1_9.png"];
array_hour = ["Time1_0.png","Time1_1.png","Time1_2.png","Time1_3.png","Time1_4.png","Time1_5.png","Time1_6.png","Time1_7.png","Time1_8.png","Time1_9.png"];
timedot = 'TIME_DOT_1.png'
}
if ( colornumber == 2) { namecolor = "BLUE"
array_min = ["Time2_0.png","Time2_1.png","Time2_2.png","Time2_3.png","Time2_4.png","Time2_5.png","Time2_6.png","Time2_7.png","Time2_8.png","Time2_9.png"];
array_hour =["Time2_0.png","Time2_1.png","Time2_2.png","Time2_3.png","Time2_4.png","Time2_5.png","Time2_6.png","Time2_7.png","Time2_8.png","Time2_9.png"];
timedot = 'TIME_DOT_2.png'
}
if ( colornumber == 3) { namecolor = "GREEN"
array_min = ["Time3_0.png","Time3_1.png","Time3_2.png","Time3_3.png","Time3_4.png","Time3_5.png","Time3_6.png","Time3_7.png","Time3_8.png","Time3_9.png"];
array_hour = ["Time3_0.png","Time3_1.png","Time3_2.png","Time3_3.png","Time3_4.png","Time3_5.png","Time3_6.png","Time3_7.png","Time3_8.png","Time3_9.png"];
timedot = 'TIME_DOT_3.png'
}
if ( colornumber == 4) { namecolor = "ORANGE"
array_min = ["Time4_0.png","Time4_1.png","Time4_2.png","Time4_3.png","Time4_4.png","Time4_5.png","Time4_6.png","Time4_7.png","Time4_8.png","Time4_9.png"];
array_hour = ["Time4_0.png","Time4_1.png","Time4_2.png","Time4_3.png","Time4_4.png","Time4_5.png","Time4_6.png","Time4_7.png","Time4_8.png","Time4_9.png"];
timedot = 'TIME_DOT_4.png'
}
if ( colornumber == 5) { namecolor = "YELLOW"
array_min = ["Time5_0.png","Time5_1.png","Time5_2.png","Time5_3.png","Time5_4.png","Time5_5.png","Time5_6.png","Time5_7.png","Time5_8.png","Time5_9.png"];
array_hour = ["Time5_0.png","Time5_1.png","Time5_2.png","Time5_3.png","Time5_4.png","Time5_5.png","Time5_6.png","Time5_7.png","Time5_8.png","Time5_9.png"];
timedot = 'TIME_DOT_5.png'
}
if ( colornumber == 6) { namecolor = "RED"
array_min = ["Time6_0.png","Time6_1.png","Time6_2.png","Time6_3.png","Time6_4.png","Time6_5.png","Time6_6.png","Time6_7.png","Time6_8.png","Time6_9.png"];
array_hour = ["Time6_0.png","Time6_1.png","Time6_2.png","Time6_3.png","Time6_4.png","Time6_5.png","Time6_6.png","Time6_7.png","Time6_8.png","Time6_9.png"];
timedot = 'TIME_DOT_6.png'
}


if (colornumber <= totalcolors){
//const deviceInfo = hmSetting.getDeviceInfo();

hmUI.showToast({text: namecolor});


            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 193,
              hour_startY: 202,
              hour_array: array_hour,
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

}                     
        }


        function click_Color3() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "WHITE"
array_min = ["Time1_0.png","Time1_1.png","Time1_2.png","Time1_3.png","Time1_4.png","Time1_5.png","Time1_6.png","Time1_7.png","Time1_8.png","Time1_9.png"];
array_hour = ["Time1_0.png","Time1_1.png","Time1_2.png","Time1_3.png","Time1_4.png","Time1_5.png","Time1_6.png","Time1_7.png","Time1_8.png","Time1_9.png"];
timedot = 'TIME_DOT_1.png'
}
if ( colornumber == 2) { namecolor = "BLUE"
array_min = ["Time2_0.png","Time2_1.png","Time2_2.png","Time2_3.png","Time2_4.png","Time2_5.png","Time2_6.png","Time2_7.png","Time2_8.png","Time2_9.png"];
array_hour =["Time2_0.png","Time2_1.png","Time2_2.png","Time2_3.png","Time2_4.png","Time2_5.png","Time2_6.png","Time2_7.png","Time2_8.png","Time2_9.png"];
timedot = 'TIME_DOT_2.png'
}
if ( colornumber == 3) { namecolor = "GREEN"
array_min = ["Time3_0.png","Time3_1.png","Time3_2.png","Time3_3.png","Time3_4.png","Time3_5.png","Time3_6.png","Time3_7.png","Time3_8.png","Time3_9.png"];
array_hour = ["Time3_0.png","Time3_1.png","Time3_2.png","Time3_3.png","Time3_4.png","Time3_5.png","Time3_6.png","Time3_7.png","Time3_8.png","Time3_9.png"];
timedot = 'TIME_DOT_3.png'
}
if ( colornumber == 4) { namecolor = "ORANGE"
array_min = ["Time4_0.png","Time4_1.png","Time4_2.png","Time4_3.png","Time4_4.png","Time4_5.png","Time4_6.png","Time4_7.png","Time4_8.png","Time4_9.png"];
array_hour = ["Time4_0.png","Time4_1.png","Time4_2.png","Time4_3.png","Time4_4.png","Time4_5.png","Time4_6.png","Time4_7.png","Time4_8.png","Time4_9.png"];
timedot = 'TIME_DOT_4.png'
}
if ( colornumber == 5) { namecolor = "YELLOW"
array_min = ["Time5_0.png","Time5_1.png","Time5_2.png","Time5_3.png","Time5_4.png","Time5_5.png","Time5_6.png","Time5_7.png","Time5_8.png","Time5_9.png"];
array_hour = ["Time5_0.png","Time5_1.png","Time5_2.png","Time5_3.png","Time5_4.png","Time5_5.png","Time5_6.png","Time5_7.png","Time5_8.png","Time5_9.png"];
timedot = 'TIME_DOT_5.png'
}
if ( colornumber == 6) { namecolor = "RED"
array_min = ["Time6_0.png","Time6_1.png","Time6_2.png","Time6_3.png","Time6_4.png","Time6_5.png","Time6_6.png","Time6_7.png","Time6_8.png","Time6_9.png"];
array_hour = ["Time6_0.png","Time6_1.png","Time6_2.png","Time6_3.png","Time6_4.png","Time6_5.png","Time6_6.png","Time6_7.png","Time6_8.png","Time6_9.png"];
timedot = 'TIME_DOT_6.png'
}


if (colornumber <= totalcolors){
//const deviceInfo = hmSetting.getDeviceInfo();

hmUI.showToast({text: namecolor});


            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 318,
              minute_startY: 202,
              minute_array: array_min,
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


}
                        
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_icon_img = ''
        let normal_spo2_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_step_current_text_img = ''
        let normal_step_linear_scale = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_distance_icon_img = ''
        let idle_spo2_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_step_current_text_img = ''
        let idle_step_linear_scale = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_icon_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 253,
              y: 378,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "F",
              anim_fps: 4,
              anim_size: 4,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 235,
              y: 286,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 177,
              y: 286,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 341,
              y: 401,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 257,
              y: 463,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              imperial_unit_sc: 'Weather_Symbo1.png',
              imperial_unit_tc: 'Weather_Symbo1.png',
              imperial_unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 257,
                y: 463,
                font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
                padding: false,
                h_space: 3,
                unit_sc: 'Weather_Symbo1.png',
                unit_tc: 'Weather_Symbo1.png',
                unit_en: 'Weather_Symbo1.png',
                imperial_unit_sc: 'Weather_Symbo1.png',
                imperial_unit_tc: 'Weather_Symbo1.png',
                imperial_unit_en: 'Weather_Symbo1.png',
                negative_image: 'Weather_Symbo2.png',
                invalid_image: 'Weather_Symbo2.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 341,
              y: 141,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 142,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 135,
              y: 136,
              src: 'Top_Dis.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 138,
              y: 465,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'O2_unit.png',
              unit_tc: 'O2_unit.png',
              unit_en: 'O2_unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 152,
              y: 390,
              font_array: ["ACT1_0.png","ACT1_1.png","ACT1_2.png","ACT1_3.png","ACT1_4.png","ACT1_5.png","ACT1_6.png","ACT1_7.png","ACT1_8.png","ACT1_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 125,
              y: 400,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 18,
              month_startY: 418,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 43,
              day_startY: 371,
              day_sc_array: ["ACT1_0.png","ACT1_1.png","ACT1_2.png","ACT1_3.png","ACT1_4.png","ACT1_5.png","ACT1_6.png","ACT1_7.png","ACT1_8.png","ACT1_9.png"],
              day_tc_array: ["ACT1_0.png","ACT1_1.png","ACT1_2.png","ACT1_3.png","ACT1_4.png","ACT1_5.png","ACT1_6.png","ACT1_7.png","ACT1_8.png","ACT1_9.png"],
              day_en_array: ["ACT1_0.png","ACT1_1.png","ACT1_2.png","ACT1_3.png","ACT1_4.png","ACT1_5.png","ACT1_6.png","ACT1_7.png","ACT1_8.png","ACT1_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 69,
              font_array: ["ACT1_0.png","ACT1_1.png","ACT1_2.png","ACT1_3.png","ACT1_4.png","ACT1_5.png","ACT1_6.png","ACT1_7.png","ACT1_8.png","ACT1_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 19,
              // start_y: 94,
              // color: 0xFF00FF00,
              // lenght: 61,
              // line_width: 6,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 127,
              y: 325,
              week_en: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_tc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_sc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 43,
              y: 199,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png","Batt_icon_07.png","Batt_icon_08.png","Batt_icon_09.png","Batt_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 235,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 318,
              am_y: 277,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 318,
              pm_y: 277,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 350,
              second_startY: 71,
              second_array: ["ACT1_0.png","ACT1_1.png","ACT1_2.png","ACT1_3.png","ACT1_4.png","ACT1_5.png","ACT1_6.png","ACT1_7.png","ACT1_8.png","ACT1_9.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 318,
              minute_startY: 202,
              minute_array: ["Time1_0.png","Time1_1.png","Time1_2.png","Time1_3.png","Time1_4.png","Time1_5.png","Time1_6.png","Time1_7.png","Time1_8.png","Time1_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 306,
              y: 212,
              src: 'TIME_DOT_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 193,
              hour_startY: 202,
              hour_array: ["Time1_0.png","Time1_1.png","Time1_2.png","Time1_3.png","Time1_4.png","Time1_5.png","Time1_6.png","Time1_7.png","Time1_8.png","Time1_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 169,
              y: 169,
              src: 'Top_Digital.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 235,
              y: 286,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 177,
              y: 286,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 342,
              y: 402,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 257,
              y: 463,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              imperial_unit_sc: 'Weather_Symbo1.png',
              imperial_unit_tc: 'Weather_Symbo1.png',
              imperial_unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 257,
                y: 463,
                font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
                padding: false,
                h_space: 3,
                unit_sc: 'Weather_Symbo1.png',
                unit_tc: 'Weather_Symbo1.png',
                unit_en: 'Weather_Symbo1.png',
                imperial_unit_sc: 'Weather_Symbo1.png',
                imperial_unit_tc: 'Weather_Symbo1.png',
                imperial_unit_en: 'Weather_Symbo1.png',
                negative_image: 'Weather_Symbo2.png',
                invalid_image: 'Weather_Symbo2.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 253,
              y: 378,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 341,
              y: 141,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 142,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 135,
              y: 136,
              src: 'Top_Dis.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 138,
              y: 465,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'O2_unit.png',
              unit_tc: 'O2_unit.png',
              unit_en: 'O2_unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 152,
              y: 390,
              font_array: ["ACT1_0.png","ACT1_1.png","ACT1_2.png","ACT1_3.png","ACT1_4.png","ACT1_5.png","ACT1_6.png","ACT1_7.png","ACT1_8.png","ACT1_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 125,
              y: 400,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 18,
              month_startY: 418,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 43,
              day_startY: 371,
              day_sc_array: ["ACT1_0.png","ACT1_1.png","ACT1_2.png","ACT1_3.png","ACT1_4.png","ACT1_5.png","ACT1_6.png","ACT1_7.png","ACT1_8.png","ACT1_9.png"],
              day_tc_array: ["ACT1_0.png","ACT1_1.png","ACT1_2.png","ACT1_3.png","ACT1_4.png","ACT1_5.png","ACT1_6.png","ACT1_7.png","ACT1_8.png","ACT1_9.png"],
              day_en_array: ["ACT1_0.png","ACT1_1.png","ACT1_2.png","ACT1_3.png","ACT1_4.png","ACT1_5.png","ACT1_6.png","ACT1_7.png","ACT1_8.png","ACT1_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 69,
              font_array: ["ACT1_0.png","ACT1_1.png","ACT1_2.png","ACT1_3.png","ACT1_4.png","ACT1_5.png","ACT1_6.png","ACT1_7.png","ACT1_8.png","ACT1_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 19,
              // start_y: 94,
              // color: 0xFF00FF00,
              // lenght: 61,
              // line_width: 6,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 127,
              y: 325,
              week_en: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_tc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_sc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 43,
              y: 199,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png","Batt_icon_07.png","Batt_icon_08.png","Batt_icon_09.png","Batt_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 235,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 341,
              y: 74,
              src: 'AOD_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 318,
              am_y: 277,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 318,
              pm_y: 277,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 318,
              minute_startY: 202,
              minute_array: ["Time1_0.png","Time1_1.png","Time1_2.png","Time1_3.png","Time1_4.png","Time1_5.png","Time1_6.png","Time1_7.png","Time1_8.png","Time1_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 306,
              y: 212,
              src: 'TIME_DOT_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 193,
              hour_startY: 202,
              hour_array: ["Time1_0.png","Time1_1.png","Time1_2.png","Time1_3.png","Time1_4.png","Time1_5.png","Time1_6.png","Time1_7.png","Time1_8.png","Time1_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 169,
              y: 169,
              src: 'Top_Digital.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 245,
              y: 65,
              w: 68,
              h: 59,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 339,
              y: 64,
              w: 73,
              h: 61,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 178,
              y: 280,
              w: 133,
              h: 28,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 335,
              y: 393,
              w: 64,
              h: 66,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 255,
              y: 440,
              w: 66,
              h: 55,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 299,
              y: 135,
              w: 111,
              h: 41,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 71,
              y: 455,
              w: 153,
              h: 40,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 119,
              y: 381,
              w: 102,
              h: 45,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 24,
              y: 28,
              w: 64,
              h: 71,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 145,
              y: 135,
              w: 131,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 29,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 11,
              y: 342,
              w: 89,
              h: 95,
              text: '',
              color: 0xFFFF8C00,
              text_size: 29,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 45,
              y: 204,
              w: 97,
              h: 94,
              text: '',
              color: 0xFFFF8C00,
              text_size: 29,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 257,
              y: 16,
              w: 136,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 29,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 295,
              y: 203,
              w: 32,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 29,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 217,
              y: 205,
              w: 61,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 29,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Color2()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 347,
              y: 205,
              w: 53,
              h: 61,
              text: '',
              color: 0xFFFF8C00,
              text_size: 29,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Color3()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

switchWeatherIconsAnimation()
            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 19;
                  let start_y_normal_step = 94;
                  let lenght_ls_normal_step = 61;
                  let line_width_ls_normal_step = 6;
                  let color_ls_normal_step = 0xFF00FF00;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

                console.log('update scales STEP');
                let progress_ls_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_linear_scale
                  // initial parameters
                  let start_x_idle_step = 19;
                  let start_y_idle_step = 94;
                  let lenght_ls_idle_step = 61;
                  let line_width_ls_idle_step = 6;
                  let color_ls_idle_step = 0xFF00FF00;
                  
                  // calculated parameters
                  let start_x_idle_step_draw = start_x_idle_step;
                  let start_y_idle_step_draw = start_y_idle_step;
                  lenght_ls_idle_step = lenght_ls_idle_step * progress_ls_idle_step;
                  let lenght_ls_idle_step_draw = lenght_ls_idle_step;
                  let line_width_ls_idle_step_draw = line_width_ls_idle_step;
                  if (lenght_ls_idle_step < 0){
                    lenght_ls_idle_step_draw = -lenght_ls_idle_step;
                    start_x_idle_step_draw = start_x_idle_step - lenght_ls_idle_step_draw;
                  };
                  
                  idle_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step_draw,
                    y: start_y_idle_step_draw,
                    w: lenght_ls_idle_step_draw,
                    h: line_width_ls_idle_step_draw,
                    color: color_ls_idle_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

                console.log('resume_call.js');
                // start resume_call.js

switchWeatherIconsAnimation()
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}