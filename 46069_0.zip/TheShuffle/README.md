# The Shuffle (v1.0.15)

**Amazfit Bip Max edition** (432 × 514, device ID 11206915). Same paper as the Bip 6 version, redrawn for the bigger screen: every word, number, line and picture is drawn fresh at the larger size (not stretched), and the extra height is shared out between the sections so the page fills the screen.

v1.0.6: bell, battery and the always-on charge icon centred on their numbers.

v1.0.15: battery cells go down within a cell too (5 % steps), not only a whole cell at a time.

v1.0.14: always-on stats row now shows Hybrid Charge, heart rate and steps.

v1.0.13: battery colours now work on the watch (yellow <= 40 %, red <= 20 %).

v1.0.12: temperature headlines ("Scorcher", "Freezing") removed. Rain and snow headlines stay.

v1.0.10: the Hybrid Charge bar now fills (it is filled by the watch, like the number). The moon is bigger (15 px) and opens Sun & Moon when tapped; the sunset/sunrise part of the weather box also opens Sun & Moon, the rest still opens Weather.

v1.0.9: every Sport row now reads label first, like the Health rows: "Steps 8412 … 6.12 km", "PAI 86 12 … VO₂ 48", "Cal 1840 … fat burn 24 min". Distance, VO₂ and fat burn now stay in fixed places on the right, which fixes fat burn (and distance) not showing on the watch.

v1.0.8: fat burn is shown in minutes and labelled "fat burn".

v1.0.7: full-screen layout on the main and always-on screens; calendar taps removed (the Bip Max has no calendar a face can open).

v1.0.5: fat burn was shown in kcal, matching what the Bip Max shows ("1840 kcal · fat 24 kcal").

v1.0.4: always-on display now actually turns on (the face was not marked as supporting it).

v1.0.3: the stress word (normal / medium) is no longer cut off; today's box in the week line is no longer clipped at the top; fat burn now comes straight from the watch and reads "24 min" (was "24m"); a little more room above the masthead.

v1.0.2: the house in night scenes is moonlit blue-grey with an outline, so it no longer disappears into the dark.: watch face for Amazfit Bip Max

A newspaper for your wrist, printed on darker paper. Zepp OS API 4.2, 432×514.

## What's on the page
- **Masthead** changes with the weekday: Monday Mumble, Tuesday Tattler, Wednesday Whisper, Thursday Thunder, Friday Flyer, Saturday Shuffle, Sunday Snooze.
- **Strap line**: your city (from the weather app), weekday + date, and a joke price that changes daily.
- **Weather photo** that changes with the weather (sun, clouds, rain, storm, snow, fog, dust, clear or cloudy night), temperature, today's high/low; the condition in words underneath, plus the moon phase.
- **Time** with seconds; AM/PM shows only in 12-hour mode.
- **Headline** written from your own data (heart rate, steps, sleep, Hybrid Charge, PAI, weather, the day). Battery ≤ 20 % always takes the headline; otherwise every matching headline takes a turn, changing each hour.
- **Week line**: past days struck through, today boxed and filling left → right through the day.
- **Health**: Hybrid Charge + bar, heart rate in its zone colour + zone ladder, sleep (night without awake time, plus naps) + bar, stress with a word (calm / normal / medium / high) + bar.
- **Sport**: steps + distance (km or mi from your settings) + bar, PAI with today's gain, VO₂ max, calories + fat-burn minutes (e.g. "Cal 1840 … fat burn 24 min"), days left in the month and year with bars.
- **Weather box**: humidity, UV index, air quality, next sunrise or sunset.
- **Quote of the day**: 30 hopeful lines from many traditions, a new one each day.
- **Footer**: alarm and a 5-segment battery (yellow ≤ 40 %, red ≤ 20 %).
- **Always-on**: the same page in dim ink on black (title, date, weather, time, charge, heart rate, alarm, battery).

## Taps
Weather photo / weather box → Weather · Charge → Hybrid Charge · Heart → Heart rate · Slept → Sleep · Stress → Stress · Steps → Steps · PAI → PAI · VO₂ → VO₂ max · Calories → Calories · Alarm → Alarms · Battery → Battery.

## Notes
- The masthead uses Gelasio (a newspaper serif); the blackletter in the canvas mockup isn't available offline.
- UV and air quality show the number only (no "moderate"/"good" word): the watch gives the numbers to the face but not the level names.
- Fonts bundled for the live text: Crimson Text (SIL Open Font License).

## Build
```
python3 tools/assets.py .
python3 tools/build.py . 1
```


## Bip Max build
```
TARGET=bipmax python3 tools/assets.py <root>
TARGET=bipmax python3 tools/build.py <root> <version>
```
(Without TARGET the same tools build the Bip 6 face.) Screen corner radius is assumed to be 95 px (86 px scaled); everything stays clear of it.
