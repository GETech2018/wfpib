﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// for vibration feedback
const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
let timer_StopVibrate = null;

function makeVibrate(level = 2) {
  let stopDelay = 50;
  stopVibrate();
  vibrate.stop();

  const levelToScene = {
    1: 25,
    2: 23,
    3: 28
  };

  let scene = levelToScene[level] || 25;
  vibrate.scene = scene;
  if (scene > 25) stopDelay = 1300;
  vibrate.start();
  timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibrate, {});
}

function stopVibrate() {
  vibrate.stop();
  if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
}

const colorsSet = [
    "WHITE",
    "BLUE",
    "TURQUOISE",
    "GREEN",
    "ORANGE",
    "RED",
    "VIOLET"
];

const colorHEXset = [
    0xFFE0E0E0, //White
    0xFF74C0FC, //Blue
    0xFF63E6BE, //Turquoise
    0xFF8BE78B, //Green
    0xFFFFA94D, //Orange
    0xFFFF6B6B, //Red
    0xFFA68AD9  //Violet
];

let colorsIndex = 0;
let currColor = colorsSet[colorsIndex];
let currHEXColor = colorHEXset[colorsIndex];
let isActive_tempColor = false;
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_day_month_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_weather_image_progress_img_level = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SFUIDisplay-Regular.ttf; FontSize: 24; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 28,
              h: 28,
              text_size: 24,
              char_space: 2,
              line_space: 0,
              font: 'fonts/SFUIDisplay-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

let firstDigit_xpos = 236;
let secondDigit_xpos = 304;
let prevMin_ypos = 39;
let currMin_ypos = 179;
let nextMin_ypos = 319;
let normal_temperature_widgets = [];

// bg color and no color temp
let bgColor = hmUI.createWidget(hmUI.widget.IMG, {
  src: 'colors/WHITE.png',
  x: 0,
  y: 0,
});

let tempNoColor_overlay = hmUI.createWidget(hmUI.widget.IMG, {
  src: 'WEATHER_NOCOLOR_OVERLAY.png',
  x: 0,
  y: 0,
});

let bgCounting = hmUI.createWidget(hmUI.widget.IMG, {
  src: 'BACKGROUND.png',
  x: 0,
  y: 0,
});

for (let i = 0; i < colorHEXset.length; i++) {
  let tempWidget = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
    x: 50,
    y: 86,
    w: 150,
    h: 30,
    text_size: 24,
    char_space: 2,
    line_space: 0,
    font: 'fonts/SFUIDisplay-Regular.ttf',
    color: colorHEXset[i],
    align_h: hmUI.align.LEFT,
    align_v: hmUI.align.TOP,
    unit_type: 1,
    text_style: hmUI.text_style.ELLIPSIS,
    type: hmUI.data_type.WEATHER_CURRENT,
    show_level: hmUI.show_level.ONLY_NORMAL,
  });
  
  normal_temperature_widgets.push(tempWidget);
}

for (let i = 1; i < normal_temperature_widgets.length; i++) {
  normal_temperature_widgets[i].setProperty(hmUI.prop.VISIBLE, false);
}

let prevMinsHigh = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'clock/MINS_0.png',
    x: firstDigit_xpos,
    y: prevMin_ypos,
});

let prevMinsLow = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'clock/MINS_0.png',
    x: secondDigit_xpos,
    y: prevMin_ypos,
});

let currMinsHigh = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'clock/MINS_0.png',
    x: firstDigit_xpos,
    y: currMin_ypos,
});

let currMinsLow = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'clock/MINS_0.png',
    x: secondDigit_xpos,
    y: currMin_ypos,
});

let nextMinsHigh = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'clock/MINS_0.png',
    x: firstDigit_xpos,
    y: nextMin_ypos,
});

let nextMinsLow = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'clock/MINS_0.png',
    x: secondDigit_xpos,
    y: nextMin_ypos,
});

const minsOverlay = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'MINS_OVERLAY.png',
    x: 0,
    y: 0,
});
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'TRANSPARENT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 18,
              hour_startY: 159,
              hour_array: ["HOUR_0.png","HOUR_1.png","HOUR_2.png","HOUR_3.png","HOUR_4.png","HOUR_5.png","HOUR_6.png","HOUR_7.png","HOUR_8.png","HOUR_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 50,
              y: 328,
              w: 150,
              h: 50,
              text_size: 24,
              char_space: 2,
              line_space: 0,
              font: 'fonts/SFUIDisplay-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 50,
              y: 360,
              w: 150,
              h: 50,
              text_size: 24,
              char_space: 2,
              line_space: 0,
              font: 'fonts/SFUIDisplay-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 50,
              y: 45,
              image_array: ["WEATHERICON_1.png","WEATHERICON_2.png","WEATHERICON_3.png","WEATHERICON_4.png","WEATHERICON_5.png","WEATHERICON_6.png","WEATHERICON_7.png","WEATHERICON_8.png","WEATHERICON_9.png","WEATHERICON_10.png","WEATHERICON_11.png","WEATHERICON_12.png","WEATHERICON_13.png","WEATHERICON_14.png","WEATHERICON_15.png","WEATHERICON_16.png","WEATHERICON_17.png","WEATHERICON_18.png","WEATHERICON_19.png","WEATHERICON_20.png","WEATHERICON_21.png","WEATHERICON_22.png","WEATHERICON_23.png","WEATHERICON_24.png","WEATHERICON_25.png","WEATHERICON_26.png","WEATHERICON_27.png","WEATHERICON_28.png","WEATHERICON_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 18,
              hour_startY: 159,
              hour_array: ["HOUR_0.png","HOUR_1.png","HOUR_2.png","HOUR_3.png","HOUR_4.png","HOUR_5.png","HOUR_6.png","HOUR_7.png","HOUR_8.png","HOUR_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 236,
              minute_startY: 179,
              minute_array: ["MINS_0.png","MINS_1.png","MINS_2.png","MINS_3.png","MINS_4.png","MINS_5.png","MINS_6.png","MINS_7.png","MINS_8.png","MINS_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

//settings layout
let settingsBG = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: "settings/SETTINGS_BG.png",
});

let noColorTempbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 174,
    y: 40,
    w: 195,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/TEMPERATURE_COLOR_PRESSED.png',
    normal_src: 'settings/TEMPERATURE_COLOR_NORMAL.png',
    click_func: (button_widget) => {
    tempWeatherColor()
    makeVibrate(1)
    },
});

let prevColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 125,
    y: 320,
    w: 90,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_SELECTOR_PREV_PRESSED.png',
    normal_src: 'settings/BTN_SELECTOR_PREV_NORMAL.png',
    click_func: (button_widget) => {
    prevColor()
    makeVibrate(1)
    }, // end func
}); // end button

let nextColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 314,
    y: 320,
    w: 90,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_SELECTOR_NEXT_PRESSED.png',
    normal_src: 'settings/BTN_SELECTOR_NEXT_NORMAL.png',
    click_func: (button_widget) => {
    nextColor()
    makeVibrate(1)
    }, // end func
}); // end button

let Confirmbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 254,
    y: 180,
    w: 120,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_CONFIRM_PRESSED.png',
    normal_src: 'settings/BTN_CONFIRM_NORMAL.png',
    click_func: (button_widget) => {
    hideSettings()
    makeVibrate(3)
    }, // end func
}); // end button

function updateMins(){
    let currMins = timeSensor.minute;
    let prevMins = (currMins - 1 + 60) % 60;
    let nextMins = (currMins + 1) % 60;

    //add zeros if its less than 10
    let prevMinstxt = prevMins.toString().padStart(2, "0");
    let currMinstxt = currMins.toString().padStart(2, "0");
    let nextMinstxt = nextMins.toString().padStart(2, "0");

    //extract digits
    let prevMinsHightxt = "clock/MINS_" + prevMinstxt[0] + ".png";
    let prevMinsLowtxt = "clock/MINS_" + prevMinstxt[1] + ".png";

    let currMinsHightxt = "clock/MINS_" + currMinstxt[0] + ".png";
    let currMinsLowtxt = "clock/MINS_" + currMinstxt[1] + ".png";

    let nextMinsHightxt = "clock/MINS_" + nextMinstxt[0] + ".png";
    let nextMinsLowtxt = "clock/MINS_" + nextMinstxt[1] + ".png";

    //update digits
    prevMinsHigh.setProperty(hmUI.prop.SRC, prevMinsHightxt);
    prevMinsLow.setProperty(hmUI.prop.SRC, prevMinsLowtxt);

    currMinsHigh.setProperty(hmUI.prop.SRC, currMinsHightxt);
    currMinsLow.setProperty(hmUI.prop.SRC, currMinsLowtxt);

    nextMinsHigh.setProperty(hmUI.prop.SRC, nextMinsHightxt);
    nextMinsLow.setProperty(hmUI.prop.SRC, nextMinsLowtxt);
}
updateMins();

function updateWatchface(){
    let currColorSRC = "colors/" + currColor + ".png";
    bgColor.setProperty(hmUI.prop.SRC, currColorSRC);

    for (let i = 0; i < normal_temperature_widgets.length; i++) {
        normal_temperature_widgets[i].setProperty(hmUI.prop.VISIBLE, false);
    }

    if (isActive_tempColor){
        normal_temperature_widgets[colorsIndex].setProperty(hmUI.prop.VISIBLE, true);
        tempNoColor_overlay.setProperty(hmUI.prop.VISIBLE, false);
    }else{
        normal_temperature_widgets[0].setProperty(hmUI.prop.VISIBLE, true);
        tempNoColor_overlay.setProperty(hmUI.prop.VISIBLE, true);
    };
}
updateWatchface();

function prevColor(){
    colorsIndex = (colorsIndex - 1 + colorsSet.length) % colorsSet.length;
    currColor = colorsSet[colorsIndex];
    currHEXColor = colorHEXset[colorsIndex];
    updateWatchface();
}

function nextColor(){
    colorsIndex = (colorsIndex + 1) % colorsSet.length;
    currColor = colorsSet[colorsIndex];
    currHEXColor = colorHEXset[colorsIndex];
    updateWatchface();
}

function tempWeatherColor(){
    isActive_tempColor = !isActive_tempColor;
    updateWatchface();
}
            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 30,
              y: 35,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 30,
              y: 175,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 255,
              y: 175,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 30,
              y: 320,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 290,
              y: 0,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                showSettings()
makeVibrate(2)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

function hideSettings(){
    Button_1.setProperty(hmUI.prop.VISIBLE, true);
    Button_2.setProperty(hmUI.prop.VISIBLE, true);
    Button_3.setProperty(hmUI.prop.VISIBLE, true);
    Button_4.setProperty(hmUI.prop.VISIBLE, true);
    Button_5.setProperty(hmUI.prop.VISIBLE, true); //this one open settings

    nextMinsHigh.setProperty(hmUI.prop.VISIBLE, true); //this digit to let see through the color
    minsOverlay.setProperty(hmUI.prop.VISIBLE, true); //overlay on the digits

    // settings layout
    settingsBG.setProperty(hmUI.prop.VISIBLE, false);
    noColorTempbtn.setProperty(hmUI.prop.VISIBLE, false);
    prevColorbtn.setProperty(hmUI.prop.VISIBLE, false);
    nextColorbtn.setProperty(hmUI.prop.VISIBLE, false);
    Confirmbtn.setProperty(hmUI.prop.VISIBLE, false);
}
hideSettings();

function showSettings(){
    Button_1.setProperty(hmUI.prop.VISIBLE, false);
    Button_2.setProperty(hmUI.prop.VISIBLE, false);
    Button_3.setProperty(hmUI.prop.VISIBLE, false);
    Button_4.setProperty(hmUI.prop.VISIBLE, false);
    Button_5.setProperty(hmUI.prop.VISIBLE, false); //this one open settings

    nextMinsHigh.setProperty(hmUI.prop.VISIBLE, false); //this digit to let see through the color
    minsOverlay.setProperty(hmUI.prop.VISIBLE, false); //overlay on the digits

    // settings layout
    settingsBG.setProperty(hmUI.prop.VISIBLE, true);
    noColorTempbtn.setProperty(hmUI.prop.VISIBLE, true);
    prevColorbtn.setProperty(hmUI.prop.VISIBLE, true);
    nextColorbtn.setProperty(hmUI.prop.VISIBLE, true);
    Confirmbtn.setProperty(hmUI.prop.VISIBLE, true);
}
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '/' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '/' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

const original_time_update = time_update;

time_update = function(updateHour = false, updateMinute = false) {
  original_time_update(updateHour, updateMinute);

if (updateMinute) {
    updateMins();
  }
};

                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}