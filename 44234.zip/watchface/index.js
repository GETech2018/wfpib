﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start change color digital minute
        let colornumber = 1
        let totalcolors = 7
        let namecolor = ''

        function click_ColorMinute() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }


if ( colornumber == 1) { namecolor = "RED"}
if ( colornumber == 2) { namecolor = "ORANGE"}
if ( colornumber == 3) { namecolor = "YELLOW"}
if ( colornumber == 4) { namecolor = "GREEN"}
if ( colornumber == 5) { namecolor = "BLUE"}
if ( colornumber == 6) { namecolor = "MAGENTA"}
if ( colornumber == 7) { namecolor = "WHITE"}
hmUI.showToast({text: namecolor });

             normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.SRC, "BG_minute" + parseInt(colornumber) + ".png");
             normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.SRC, "Digital_dot" + parseInt(colornumber) + ".png");
                          
        }

/////////////////////////////////////////////////////////////////////////////////////////////////

        // Heart change color
      
        let colornumber_2 = 1
        let totalcolors_2 = 7
        let namecolor_2 = ''

        function click_ColorHeart() {
            if(colornumber_2>=totalcolors_2) {
            colornumber_2=1;
                }
            else {
                colornumber_2=colornumber_2+1;
            }

if ( colornumber_2 == 1) { namecolor_2  = "RED"}
if ( colornumber_2 == 2) { namecolor_2  = "ORANGE"}
if ( colornumber_2 == 3) { namecolor_2  = "YELLOW"}
if ( colornumber_2 == 4) { namecolor_2  = "GREEN"}
if ( colornumber_2  == 5) { namecolor_2  = "BLUE"}
if ( colornumber_2  == 6) { namecolor_2  = "MAGENTA"}
if ( colornumber_2  == 7) { namecolor_2  = "WHITE"}
hmUI.showToast({text: namecolor_2 });

             normal_heart_rate_icon_img.setProperty(hmUI.prop.SRC, "Bcolor" + parseInt(colornumber_2) + ".png");
                             
        }

/////////////////////////////////////////////////////////////////////////////////////////////////

        // calories change color
      
        let colornumber_3 = 1
        let totalcolors_3 = 7
        let namecolor_3 = ''

        function click_ColorCalories() {
            if(colornumber_3>=totalcolors_3) {
            colornumber_3=1;
                }
            else {
                colornumber_3=colornumber_3+1;
            }

if ( colornumber_3 == 1) { namecolor_3  = "RED"}
if ( colornumber_3 == 2) { namecolor_3  = "ORANGE"}
if ( colornumber_3 == 3) { namecolor_3  = "YELLOW"}
if ( colornumber_3 == 4) { namecolor_3  = "GREEN"}
if ( colornumber_3  == 5) { namecolor_3  = "BLUE"}
if ( colornumber_3  == 6) { namecolor_3  = "MAGENTA"}
if ( colornumber_3  == 7) { namecolor_3  = "WHITE"}
hmUI.showToast({text: namecolor_3 });

             normal_calorie_icon_img.setProperty(hmUI.prop.SRC, "Bcolor" + parseInt(colornumber_3) + ".png");
                
        }

/////////////////////////////////////////////////////////////////////////////////////////////////
        // step change color
      
        let colornumber_4 = 1
        let totalcolors_4 = 7
        let namecolor_4 = ''

        function click_Colorstep() {
            if(colornumber_4>=totalcolors_4) {
            colornumber_4=1;
                }
            else {
                colornumber_4=colornumber_4+1;
            }

if ( colornumber_4 == 1) { namecolor_4  = "RED"}
if ( colornumber_4 == 2) { namecolor_4  = "ORANGE"}
if ( colornumber_4 == 3) { namecolor_4  = "YELLOW"}
if ( colornumber_4 == 4) { namecolor_4  = "GREEN"}
if ( colornumber_4  == 5) { namecolor_4  = "BLUE"}
if ( colornumber_4  == 6) { namecolor_4  = "MAGENTA"}
if ( colornumber_4  == 7) { namecolor_4  = "WHITE"}
hmUI.showToast({text: namecolor_4 });

             normal_step_icon_img.setProperty(hmUI.prop.SRC, "Bcolor" + parseInt(colornumber_4) + ".png");
                    
        }

/////////////////////////////////////////////////////////////////////////////////////////////////

        // battery change color
      
        let colornumber_5 = 1
        let totalcolors_5 = 7
        let namecolor_5 = ''

        function click_Colorbatt() {
            if(colornumber_5>=totalcolors_5) {
            colornumber_5=1;
                }
            else {
                colornumber_5=colornumber_5+1;
            }

if ( colornumber_5 == 1) { namecolor_5  = "RED"}
if ( colornumber_5 == 2) { namecolor_5  = "ORANGE"}
if ( colornumber_5 == 3) { namecolor_5  = "YELLOW"}
if ( colornumber_5 == 4) { namecolor_5  = "GREEN"}
if ( colornumber_5  == 5) { namecolor_5  = "BLUE"}
if ( colornumber_5  == 6) { namecolor_5  = "MAGENTA"}
if ( colornumber_5  == 7) { namecolor_5  = "WHITE"}
hmUI.showToast({text: namecolor_5 });

           normal_battery_icon_img.setProperty(hmUI.prop.SRC, "Bcolor" + parseInt(colornumber_5) + ".png");
      
         
        }

/////////////////////////////////////////////////////////////////////////////////////////////////
        // end user_functions.js

        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_calorie_icon_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF808080',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'TopBG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 115,
              y: 393,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 37,
              y: 43,
              image_array: ["Weather_icon01.png","Weather_icon02.png","Weather_icon03.png","Weather_icon04.png","Weather_icon05.png","Weather_icon06.png","Weather_icon07.png","Weather_icon08.png","Weather_icon09.png","Weather_icon10.png","Weather_icon11.png","Weather_icon12.png","Weather_icon13.png","Weather_icon14.png","Weather_icon15.png","Weather_icon16.png","Weather_icon17.png","Weather_icon18.png","Weather_icon19.png","Weather_icon20.png","Weather_icon21.png","Weather_icon22.png","Weather_icon23.png","Weather_icon24.png","Weather_icon25.png","Weather_icon26.png","Weather_icon27.png","Weather_icon28.png","Weather_icon29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 38,
              y: 96,
              font_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'TempC.png',
              unit_tc: 'TempC.png',
              unit_en: 'TempC.png',
              imperial_unit_sc: 'TempF.png',
              imperial_unit_tc: 'TempF.png',
              imperial_unit_en: 'TempF.png',
              negative_image: 'TempError.png',
              invalid_image: 'TempError.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 38,
                y: 96,
                font_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'TempF.png',
                unit_tc: 'TempF.png',
                unit_en: 'TempF.png',
                imperial_unit_sc: 'TempC.png',
                imperial_unit_tc: 'TempC.png',
                imperial_unit_en: 'TempC.png',
                negative_image: 'TempError.png',
                invalid_image: 'TempError.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 264,
              // start_y: 347,
              // color: 0xFF00F500,
              // lenght: 91,
              // line_width: 6,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 322,
              src: 'Bcolor4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 368,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 226,
              src: 'Bcolor3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 239,
              y: 277,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 247,
              font_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 36,
              src: 'Bcolor1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 320,
              y: 76,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 78,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 132,
              src: 'Bcolor2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 239,
              y: 178,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 179,
              y: 49,
              src: 'TopBcolor.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 80,
              y: 422,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 109,
              y: 22,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 119,
              am_y: 110,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 119,
              pm_y: 110,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 143,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 27,
              y: 234,
              src: 'BG_minute1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 113,
              second_startY: 326,
              second_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 26,
              y: 139,
              src: 'Top_Digital.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 26,
              minute_startY: 234,
              minute_array: ["Time_T_0.png","Time_T_1.png","Time_T_2.png","Time_T_3.png","Time_T_4.png","Time_T_5.png","Time_T_6.png","Time_T_7.png","Time_T_8.png","Time_T_9.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 177,
              y: 432,
              src: 'Digital_dot1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 36,
              y: 378,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 42,
              day_startY: 340,
              day_sc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_tc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_en_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF808080',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'TopBG.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 115,
              y: 393,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 37,
              y: 43,
              image_array: ["Weather_icon01.png","Weather_icon02.png","Weather_icon03.png","Weather_icon04.png","Weather_icon05.png","Weather_icon06.png","Weather_icon07.png","Weather_icon08.png","Weather_icon09.png","Weather_icon10.png","Weather_icon11.png","Weather_icon12.png","Weather_icon13.png","Weather_icon14.png","Weather_icon15.png","Weather_icon16.png","Weather_icon17.png","Weather_icon18.png","Weather_icon19.png","Weather_icon20.png","Weather_icon21.png","Weather_icon22.png","Weather_icon23.png","Weather_icon24.png","Weather_icon25.png","Weather_icon26.png","Weather_icon27.png","Weather_icon28.png","Weather_icon29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 38,
              y: 96,
              font_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'TempC.png',
              unit_tc: 'TempC.png',
              unit_en: 'TempC.png',
              imperial_unit_sc: 'TempF.png',
              imperial_unit_tc: 'TempF.png',
              imperial_unit_en: 'TempF.png',
              negative_image: 'TempError.png',
              invalid_image: 'TempError.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 38,
                y: 96,
                font_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'TempF.png',
                unit_tc: 'TempF.png',
                unit_en: 'TempF.png',
                imperial_unit_sc: 'TempC.png',
                imperial_unit_tc: 'TempC.png',
                imperial_unit_en: 'TempC.png',
                negative_image: 'TempError.png',
                invalid_image: 'TempError.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 264,
              // start_y: 347,
              // color: 0xFF00F500,
              // lenght: 91,
              // line_width: 6,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 322,
              src: 'Bcolor4.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 368,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 226,
              src: 'Bcolor3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 239,
              y: 277,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 247,
              font_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 36,
              src: 'Bcolor1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 320,
              y: 76,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 78,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 132,
              src: 'Bcolor2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 239,
              y: 178,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 179,
              y: 49,
              src: 'TopBcolor.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 80,
              y: 422,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 109,
              y: 22,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 119,
              am_y: 110,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 119,
              pm_y: 110,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 143,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 27,
              y: 234,
              src: 'BG_minute7.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 26,
              minute_startY: 234,
              minute_array: ["Time_T_0.png","Time_T_1.png","Time_T_2.png","Time_T_3.png","Time_T_4.png","Time_T_5.png","Time_T_6.png","Time_T_7.png","Time_T_8.png","Time_T_9.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 177,
              y: 432,
              src: 'Digital_dot7.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 36,
              y: 378,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 42,
              day_startY: 340,
              day_sc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_tc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_en_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 233,
              w: 57,
              h: 70,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 176,
              y: 44,
              w: 69,
              h: 69,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 177,
              y: 140,
              w: 57,
              h: 61,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 113,
              y: 388,
              w: 39,
              h: 39,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 33,
              y: 46,
              w: 64,
              h: 62,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 268,
              y: 73,
              w: 96,
              h: 38,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 108,
              y: 320,
              w: 55,
              h: 47,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 57,
              y: 153,
              w: 68,
              h: 64,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 106,
              y: 21,
              w: 53,
              h: 44,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 181,
              y: 329,
              w: 59,
              h: 71,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 32,
              y: 337,
              w: 63,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 268,
              y: 417,
              w: 103,
              h: 33,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 329,
              y: 31,
              w: 31,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_click.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // Change color Pulse
click_ColorHeart()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 329,
              y: 129,
              w: 31,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_click.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // Change color Calories
click_ColorCalories()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 329,
              y: 224,
              w: 31,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_click.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // Change color Steps
click_Colorstep()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 329,
              y: 319,
              w: 31,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_click.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // Change color Battery
click_Colorbatt()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 165,
              y: 416,
              w: 71,
              h: 34,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_click.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //Change color Digital minute
click_ColorMinute()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 264;
                  let start_y_normal_battery = 347;
                  let lenght_ls_normal_battery = 91;
                  let line_width_ls_normal_battery = 6;
                  let color_ls_normal_battery = 0xFF00F500;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 264;
                  let start_y_idle_battery = 347;
                  let lenght_ls_idle_battery = 91;
                  let line_width_ls_idle_battery = 6;
                  let color_ls_idle_battery = 0xFF00F500;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}