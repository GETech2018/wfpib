AROELZM — Amazfit Bip Max
Zepp OS target: API_LEVEL 4.4
Device source: 11206915 (PikeW)
Display: 432 x 514, square
Project config: app.json v3
Project version: 1.2.0 (version code 3)

IMPORTANT: This is a Zeus source project ZIP, not a compiled .zab installer.
Zepp's official build process is required to create the installable package.

Build:
  1. Install Node.js (>=14) and Zeus CLI:
       npm i -g @zeppos/zeus-cli
  2. Open this folder in terminal.
  3. Run:
       zeus build
  4. The compiled .zab installer is generated in dist/.
  5. For device preview/install QR:
       zeus login
       zeus preview

Install via Zepp App Developer Mode > Scan.

Project layout follows Zepp OS v3 requirements:
  assets/432x514-amazfit-bip-max/  (all target assets)
  watchface/index.js
  app.json

The runtime apiVersion values in app.json are JS-SDK compatibility versions.
They are not the device API_LEVEL number. Bip Max API_LEVEL 4.4 is declared by
Zepp's official device list; it should not be written as minVersion 4.4.0.
