/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
** Copyright © SashaCX75. All Rights Reserved
*/

try {
(() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
        return __$$app$$__.app;
    }
    function getCurrentPage() {
        return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const {px} = __$$app$$__.__globals__;
    const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
    //end of ignored block

    //dynamic modify start

    // Bip Max 屏幕参数 (432x514)
    // Bip 6 原屏幕 (390x450)
    // 缩放比例 111% (1.11)
    const SCALE = 1.11;
    const BIPMAX_W = 432;
    const BIPMAX_H = 514;
    const CENTER_X = 216;   // Bip Max 中心 X: 432/2
    const CENTER_Y = 257;   // Bip Max 中心 Y: 514/2
    const ORIGIN_CENTER_X = 195;
    const ORIGIN_CENTER_Y = 225;
    const OFFSET_X = CENTER_X - ORIGIN_CENTER_X;  // 21
    const OFFSET_Y = CENTER_Y - ORIGIN_CENTER_Y;  // 32

    function scaleX(x) { return Math.round(x * SCALE); }
    function scaleY(y) { return Math.round(y * SCALE); }
    function scaleW(w) { return Math.round(w * SCALE); }
    function scaleH(h) { return Math.round(h * SCALE); }

    let normal_background_bg_img = ''
    let normal_battery_current_text_font = ''
    let normal_temperature_current_text_font = ''
    let normal_day_month_font = ''
    let normal_timerTimeUpdate = undefined;
    let normal_dow_text_font = ''
    let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
    let normal_analog_clock_pro_hour_pointer_img = ''
    let normal_analog_clock_pro_minute_pointer_img = ''
    let normal_timerUpdateSec = undefined;
    let normal_analog_clock_time_pointer_smooth_second = ''
    let idle_background_bg_img = ''
    let idle_battery_current_text_font = ''
    let idle_temperature_current_text_font = ''
    let idle_day_month_font = ''
    let idle_timerTimeUpdate = undefined;
    let idle_dow_text_font = ''
    let idle_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
    let idle_analog_clock_pro_hour_pointer_img = ''
    let idle_analog_clock_pro_minute_pointer_img = ''
    let idle_analog_clock_pro_second_pointer_img = ''
    let idle_timerUpdateSec = undefined;
    let Button_1 = ''
    let Button_2 = ''
    let Button_3 = ''
    let Button_4 = ''
    let timeSensor = '';


    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        init_view() {
            //dynamic modify start
                
            
        // FontName: SFRounded-Semibold.ttf; FontSize: 29
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: scaleX(388),
          y: scaleY(448),
          w: scaleW(435),
          h: scaleH(42),
          text_size: Math.round(29 * SCALE),
          char_space: 1,
          line_space: 0,
          font: 'fonts/SFRounded-Semibold.ttf',
          color: 0xFFF4F4F4,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "0123456789 _-.,:;`'%°\\/",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: SFRounded-Semibold.ttf; FontSize: 29; Cache: full
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: scaleX(388),
          y: scaleY(448),
          w: scaleW(34),
          h: scaleH(34),
          text_size: Math.round(29 * SCALE),
          char_space: 0,
          line_space: 0,
          font: 'fonts/SFRounded-Semibold.ttf',
          color: 0xFFF4F4F4,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.NONE,
          text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        console.log('Watch_Face.ScreenNormal');
        normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: BIPMAX_W,
          h: BIPMAX_H,
          src: 'bg.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {   //电池
          x: scaleX(-48) + OFFSET_X - 21,
          y: scaleY(-18) + OFFSET_Y - 18,
          w: scaleW(486),
          h: scaleH(486),
          text_size: Math.round(29 * SCALE),
          char_space: 1,
          font: 'fonts/SFRounded-Semibold.ttf',
          color: 0xFFF4F4F4,
          start_angle: 99,
          end_angle: 185,
          mode: 1,
          align_h: hmUI.align.CENTER_H,
          unit_type: 1,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {    //步數
          x: scaleX(-55) + OFFSET_X - 21,
          y: scaleY(-25) + OFFSET_Y - 24,
          w: scaleW(500),
          h: scaleH(500),
          text_size: Math.round(29 * SCALE),
          char_space: 1,
          font: 'fonts/SFRounded-Semibold.ttf',
          color: 0xFFF4F4F4,
          start_angle: 163,
          end_angle: 273,
          mode: 1,
          align_h: hmUI.align.CENTER_H,
          unit_type: 0,   //沒單位，1＝完整，2＝簡寫
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        let screenType = hmSetting.getScreenType();
        normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: scaleX(-55) + OFFSET_X - 21,
          y: scaleY(-25) + OFFSET_Y - 32,
          w: scaleW(500),
          h: scaleH(500),
          text_size: Math.round(29 * SCALE),
          char_space: 0,
          font: 'fonts/SFRounded-Semibold.ttf',
          color: 0xFFF4F4F4,
          start_angle: -73,
          end_angle: -4,
          mode: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
          time_update(true);
        });

        normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: scaleX(-55) + OFFSET_X - 21,
          y: scaleY(-25) + OFFSET_Y - 32,
          w: scaleW(500),
          h: scaleH(500),
          text_size: Math.round(29 * SCALE),
          char_space: 0,
          font: 'fonts/SFRounded-Semibold.ttf',
          color: 0xFFF4F4F4,
          start_angle: -54,
          end_angle: 134,
          mode: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        const deviceInfo = hmSetting.getDeviceInfo();
        timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
          let updateHour = timeSensor.minute == 0;

          time_update(updateHour, true);
        });

        normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: CENTER_X - 26,
          pos_y: CENTER_Y - 155,  // 圓心在圖片頂端往下 143px
          center_x: CENTER_X,
          center_y: CENTER_Y,
          src: 'hour.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: CENTER_X - 26,
          pos_y: CENTER_Y - 228,  // 圓心在圖片頂端往下 218px
          center_x: CENTER_X,
          center_y: CENTER_Y,
          src: 'min.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          second_path: 'seconds.png',
          second_centerX: CENTER_X,
          second_centerY: CENTER_Y,
          second_posX: Math.round(23 * SCALE),
          second_posY: Math.round(157 * SCALE),
          fresh_frequency: 15,
          fresh_freqency: 15,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        console.log('Watch_Face.ScreenAOD');
        idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: BIPMAX_W,
          h: BIPMAX_H,
          src: 'aodbg.png',
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: scaleX(-48) + OFFSET_X - 21,
          y: scaleY(-18) + OFFSET_Y - 32,
          w: scaleW(486),
          h: scaleH(486),
          text_size: Math.round(29 * SCALE),
          char_space: 1,
          font: 'fonts/SFRounded-Semibold.ttf',
          color: 0xFFF4F4F4,
          start_angle: 99,
          end_angle: 185,
          mode: 1,
          align_h: hmUI.align.CENTER_H,
          unit_type: 1,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: scaleX(-55) + OFFSET_X - 21,
          y: scaleY(-25) + OFFSET_Y - 32,
          w: scaleW(500),
          h: scaleH(500),
          text_size: Math.round(29 * SCALE),
          char_space: 1,
          font: 'fonts/SFRounded-Semibold.ttf',
          color: 0xFFF4F4F4,
          start_angle: 163,
          end_angle: 273,
          mode: 1,
          align_h: hmUI.align.CENTER_H,
          unit_type: 1,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: scaleX(-55) + OFFSET_X - 21,
          y: scaleY(-25) + OFFSET_Y - 32,
          w: scaleW(500),
          h: scaleH(500),
          text_size: Math.round(29 * SCALE),
          char_space: 0,
          font: 'fonts/SFRounded-Semibold.ttf',
          color: 0xFFF4F4F4,
          start_angle: -73,
          end_angle: -4,
          mode: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: scaleX(-55) + OFFSET_X - 21,
          y: scaleY(-25) + OFFSET_Y - 32,
          w: scaleW(500),
          h: scaleH(500),
          text_size: Math.round(29 * SCALE),
          char_space: 0,
          font: 'fonts/SFRounded-Semibold.ttf',
          color: 0xFFF4F4F4,
          start_angle: -54,
          end_angle: 134,
          mode: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_AOD,
        });


        idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: CENTER_X - 26,   // 53/2 = 26.5
          pos_y: CENTER_Y - 155,  // 圓心在圖片頂端往下 143px
          center_x: CENTER_X,
          center_y: CENTER_Y,
          src: 'aodhour.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_AOD,
        });


        idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: CENTER_X - 26,
          pos_y: CENTER_Y - 228,  // 圓心在圖片頂端往下 218px
          center_x: CENTER_X,
          center_y: CENTER_Y,
          src: 'aodmin.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: CENTER_X - Math.round(23 * SCALE),
          pos_y: CENTER_Y - Math.round(157 * SCALE),
          center_x: CENTER_X,
          center_y: CENTER_Y,
          src: 'seconds.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        console.log('Watch_Face.Buttons');
        Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: Math.round(8 * SCALE),
          y: Math.round(18 * SCALE),
          w: Math.round(94 * SCALE),
          h: Math.round(67 * SCALE),
          text: '',
          color: 0xFFFF8C00,
          text_size: Math.round(25 * SCALE),
          press_src: 'Button_texture.png',
          normal_src: 'Button_texture.png',
          click_func: (button_widget) => {
            hmApp.startApp({url: 'ScheduleCalScreen', native: true });
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: Math.round(314 * SCALE),
          y: Math.round(18 * SCALE),
          w: Math.round(94 * SCALE),
          h: Math.round(67 * SCALE),
          text: '',
          color: 0xFFFF8C00,
          text_size: Math.round(25 * SCALE),
          press_src: 'Button_texture.png',
          normal_src: 'Button_texture.png',
          click_func: (button_widget) => {
            hmApp.startApp({url: 'CountdownAppScreen', native: true });
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: Math.round(294 * SCALE),
          y: Math.round(371 * SCALE),
          w: Math.round(94 * SCALE),
          h: Math.round(67 * SCALE),
          text: '',
          color: 0xFFFF8C00,
          text_size: Math.round(25 * SCALE),
          press_src: 'Button_texture.png',
          normal_src: 'Button_texture.png',
          click_func: (button_widget) => {
            hmApp.startApp({url: 'LowBatteryScreen', native: true });
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: Math.round(3 * SCALE),
          y: Math.round(371 * SCALE),
          w: Math.round(94 * SCALE),
          h: Math.round(67 * SCALE),
          text: '',
          color: 0xFFFF8C00,
          text_size: Math.round(25 * SCALE),
          press_src: 'Button_texture.png',
          normal_src: 'Button_texture.png',
          click_func: (button_widget) => {
            hmApp.startApp({url: 'WeatherScreen', native: true });
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        //#region time_update
        function time_update(updateHour = false, updateMinute = false) {
          console.log('time_update()');
          let hour = timeSensor.hour;
          let minute = timeSensor.minute;
          let second = timeSensor.second;
          let format_hour = timeSensor.format_hour;

          console.log('day/month font');
          if (updateHour) {
            let normal_DayStr = timeSensor.day.toString();
            let normal_MonthStr = timeSensor.month.toString();
            normal_DayStr = normal_DayStr.padStart(2, '0');
            normal_MonthStr = normal_MonthStr.padStart(2, '0');
            let normal_DayMonthStr = '--';
            const dateFormat = hmSetting.getDateFormat();
            if (dateFormat == 0 || dateFormat == 2) {
              normal_DayMonthStr = normal_MonthStr + '/' + normal_DayStr;
            }
            if (dateFormat == 1) {
              normal_DayMonthStr = normal_DayStr + '/' + normal_MonthStr;
            }
            normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
          };

          console.log('day of week font');
          if (updateHour) {
            let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
            normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
          };

          if (updateMinute) { // Hour Pointer
            let normal_hour = hour;
            let normal_fullAngle_hour = 360;
            if (normal_hour > 11) normal_hour -= 12;
            let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
            if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
          };

            let normal_fullAngle_minute = 360;
            let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
            if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
          console.log('day/month font');
          if (updateHour) {
            let idle_DayStr = timeSensor.day.toString();
            let idle_MonthStr = timeSensor.month.toString();
            idle_DayStr = idle_DayStr.padStart(2, '0');
            idle_MonthStr = idle_MonthStr.padStart(2, '0');
            let idle_DayMonthStr = '--';
            const dateFormat = hmSetting.getDateFormat();
            if (dateFormat == 0 || dateFormat == 2) {
              idle_DayMonthStr = idle_MonthStr + '/' + idle_DayStr;
            }
            if (dateFormat == 1) {
              idle_DayMonthStr = idle_DayStr + '/' + idle_MonthStr;
            }
            idle_day_month_font.setProperty(hmUI.prop.TEXT, idle_DayMonthStr );
          };

          console.log('day of week font');
          if (updateHour) {
            let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
            idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
          };

          if (updateMinute) { // Hour Pointer
            let idle_hour = hour;
            let idle_fullAngle_hour = 360;
            if (idle_hour > 11) idle_hour -= 12;
            let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
            if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
          };

          if (updateMinute) { // Minute Pointer
            let idle_fullAngle_minute = 360;
            let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
            if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
          };

          // Second Pointer
          let idle_fullAngle_second = 360;
          let idle_angle_second = 0 + idle_fullAngle_second*second/60;
          if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

        };

        //#endregion
        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            console.log('resume_call()');
            time_update(true, true);
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerTimeUpdate) {
                normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                  let updateHour = timeSensor.minute == 0;
                  let updateMinute = timeSensor.second < 2;
                  time_update(updateHour, updateMinute);
                }));  // end timer 
              };  // end timer check
            };  // end screenType

            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerUpdateSec) {
                let animDelay = timeSensor.utc % 1000;
                let animRepeat = 1000;
                normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                  time_update(false, true);
                }));  // end timer 
              };  // end timer check
            };  // end screenType

            if (screenType == hmSetting.screen_type.AOD) {
              if (!idle_timerTimeUpdate) {
                idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                  let updateHour = timeSensor.minute == 0;
                  let updateMinute = timeSensor.second < 2;
                  time_update(updateHour, updateMinute);
                }));  // end timer 
              };  // end timer check
            };  // end screenType

            if (screenType == hmSetting.screen_type.AOD) {
              if (!idle_timerUpdateSec) {
                let animDelay = timeSensor.utc % 1000;
                let animRepeat = 1000;
                idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                  time_update(false, false);
                }));  // end timer 
              };  // end timer check
            };  // end screenType


          }),
          pause_call: (function () {
            console.log('pause_call()');
            if (normal_timerTimeUpdate) {
              timer.stopTimer(normal_timerTimeUpdate);
              normal_timerTimeUpdate = undefined;
            }
            if (normal_timerUpdateSec) {
              timer.stopTimer(normal_timerUpdateSec);
              normal_timerUpdateSec = undefined;
            }
            if (idle_timerTimeUpdate) {
              timer.stopTimer(idle_timerTimeUpdate);
              idle_timerTimeUpdate = undefined;
            }
            if (idle_timerUpdateSec) {
              timer.stopTimer(idle_timerUpdateSec);
              idle_timerUpdateSec = undefined;
            }

          }),
        });

            //dynamic modify end
        },
        onInit() {
            logger.log('index page.js on init invoke');
        },
        build() {
            this.init_view();
            logger.log('index page.js on ready invoke');
        },
        onDestroy() {
            logger.log('index page.js on destroy invoke');
        }
    });
    ;
})();
} catch (e) {
console.log('Mini Program Error', e);
e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
;
}