try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ('use strict');

    console.log('----->>>current');
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    const ROOTPATH = 'images/';
    const numberPath = ROOTPATH + 'number/';
    const timePath = ROOTPATH + 'time/';
    const weekPath = ROOTPATH + 'week/';
    const weekSCPath = ROOTPATH + 'weeksc/';
    const weekTCPath = ROOTPATH + 'weektc/';

    let animResident = null;
    let animCreate = null;

    let number_array = [];
    let time_array = [];
    let week_array = [];
    let weekSC_array = [];
    let weekTC_array = [];

    for (let i = 0; i < 10; i++) {
      number_array.push(numberPath + i + '.png');
      time_array.push(timePath + i + '.png');
      if (i >= 1 && i <= 7) {
        week_array.push(weekPath + i + '.png');
        weekSC_array.push(weekSCPath + i + '.png');
        weekTC_array.push(weekTCPath + i + '.png');
      }
    }

    let objNorBg = {
      x: 0,
      y: 0,
      w: 390,
      h: 450,
      color: 0x000000,
    };

    let objWeek = {
      //zhoushu
      x: 26,
      y: 25,
      week_en: week_array,
      week_tc: weekTC_array,
      week_sc: weekSC_array,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
    };

    let objDate = {
      day_startX: 33,
      day_startY: 60,
      day_align: hmUI.align.CENTER_H,
      day_space: -1, //文字间隔
      day_zero: 1, //是否补零
      day_follow: 0, //是否跟随
      day_en_array: time_array,
      day_sc_array: time_array,
      day_tc_array: time_array,
      // day_is_character: true,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
    };

    let objTimePointer = {
      hour_centerX: 195, //指针旋转中心 对应centerX
      hour_centerY: 225, //指针旋转中心 对应centerY
      hour_posX: 32, //指针自身旋转中心 对应positioin中的x
      hour_posY: 194, //指针自身旋转中心 对应positioin中的y
      hour_path: 'images/Pointer/hour.png',
      minute_centerX: 195, //指针旋转中心 对应centerX
      minute_centerY: 225, //指针旋转中心 对应centerY
      minute_posX: 25, //指针自身旋转中心 对应positioin中的x
      minute_posY: 188, //指针自身旋转中心 对应positioin中的y
      minute_path: 'images/Pointer/min.png',
      //指针圆心图片
      minute_cover_y: 195,
      minute_cover_x: 164,
      minute_cover_path: 'images/Pointer/center.png',

      second_centerX: 195, //指针旋转中心 对应centerX
      second_centerY: 225, //指针旋转中心 对应centerY
      second_posX: 20, //指针自身旋转中心 对应positioin中的x
      second_posY: 173, //指针自身旋转中心 对应positioin中的y
      second_path: 'images/Pointer/sec.png',
      second_cover_y: 195,
      second_cover_x: 164,
      second_cover_path: 'images/Pointer/center.png',
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    let objHeartIcon = {
      //心的图片
      x: 276,
      y: 388,
      alpha: 255, //透明度 0 - 255
      src: numberPath + 'xin.png',
      // angle：0//旋转角度
      show_level: hmUI.show_level.ONLY_NORMAL,
    };

    let objHeartText = {
      x: 310,
      y: 393,
      type: hmUI.data_type.HEART,
      font_array: number_array,
      h_space: -1,
      //图片间隔
      align_h: hmUI.align.LEFT,
      padding: false,
      //是否补零 true为补零
      invalid_image: numberPath + 'none.png',
      // 无数据时显示的图片
      show_level: hmUI.show_level.ONLY_NORMAL,
    };
    let objAodTimePointer = {
      hour_centerX: 195, //指针旋转中心 对应centerX
      hour_centerY: 225, //指针旋转中心 对应centerY
      hour_posX: 32, //指针自身旋转中心 对应positioin中的x
      hour_posY: 194, //指针自身旋转中心 对应positioin中的y
      hour_path: 'images/AODPointer/hour.png',
      //指针路径
      hour_cover_path: 'images/AODPointer/center.png',
      //指针圆心图片
      hour_cover_y: 195,
      hour_cover_x: 164,
      //分针 秒针同上 只需要把hour替换成minute/second 即可
      minute_centerX: 195, //指针旋转中心 对应centerX
      minute_centerY: 225, //指针旋转中心 对应centerY
      minute_posX: 25, //指针自身旋转中心 对应positioin中的x
      minute_posY: 188, //指针自身旋转中心 对应positioin中的y
      minute_path: 'images/AODPointer/min.png',
      //指针圆心图片
      minute_cover_y: 195,
      minute_cover_x: 164,
      minute_cover_path: 'images/AODPointer/center.png',

      show_level: hmUI.show_level.ONAL_AOD,
    };
    // 热区跳转
    let objClickHeart = {
      x: 266,
      y: 378,
      w: 100,
      h: 44,
      type: hmUI.data_type.HEART,
    };
    const logger = DeviceRuntimeCore.HmLogger.getLogger('sanjiao');
    __$$module$$__.module = DeviceRuntimeCore.Page({
      _animNext() {
        animResident.setProperty(hmUI.prop.ANIM_STATUS, 1);
        animCreate.setProperty(hmUI.prop.VISIBLE, false);
      },

      init_view() {
        //===================================动画========================================
        var screenType = hmSetting.getScreenType();
        var nomalModel =
          screenType == hmSetting.screen_type.APP ||
          screenType == hmSetting.screen_type.WATCHFACE;
        var aodModel = screenType == hmSetting.screen_type.AOD;
        if (nomalModel) {
          bg = hmUI.createWidget(hmUI.widget.FILL_RECT, objNorBg);

          animResident = hmUI.createWidget(hmUI.widget.IMG_ANIM);
          //   图片前缀不是 anim_  上移配置对象会出问题
          animResident.setProperty(hmUI.prop.MORE, {
            x: 0,
            y: 30,
            w: 390,
            h: 390,
            align_h: hmUI.align.CENTER_H, // 横轴
            align_v: hmUI.align.CENTER_V, // 竖轴
            anim_path: ROOTPATH + 'anims', //文件路径   文件夹的名称
            anim_prefix: 'Madrid', //相当于图片的前缀
            anim_ext: 'png', //图片的后缀以或者图片的格式
            // anim_fps: 10, //图片的播放速度
            anim_fps: 15, //图片的播放速度
            anim_size: 45, //图片的数量
            anim_repeat: true, //开启循环播放

            // repeat_count: 210,
            repeat_count: 1, //0位无限重复
            anim_status: 1, //  1  开启动画   0  //  关闭动画
          });
        }

        //===========================================================================

        hmUI.createWidget(hmUI.widget.IMG_DATE, objDate);
        hmUI.createWidget(hmUI.widget.TIME_POINTER, objTimePointer);
        hmUI.createWidget(hmUI.widget.IMG, objHeartIcon);
        hmUI.createWidget(hmUI.widget.TEXT_IMG, objHeartText);
        hmUI.createWidget(hmUI.widget.IMG_CLICK, objClickHeart);
        hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek);
        hmUI.createWidget(hmUI.widget.TIME_POINTER, objAodTimePointer);
      },

      onInit() {
        console.log('index page.js on init invoke');
        this.init_view();
      },

      onReady() {
        console.log('index page.js on ready invoke');
      },

      onShow() {
        console.log('index page.js on show invoke');
      },

      onHide() {
        console.log('index page.js on hide invoke');
      },

      onDestory() {
        console.log('index page.js on destory invoke');
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}
