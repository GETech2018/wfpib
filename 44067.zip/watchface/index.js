﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_date_img_date_day = ''
        let normal_step_current_text_img = ''
        let normal_battery_current_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_frame_animation_1 = ''
        let normal_moon_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_alarm_clock_text_text_img = ''
        let normal_heart_rate_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_distance_current_text_font = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_time_hour_min_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_date_img_date_day = ''
        let idle_step_current_text_img = ''
        let idle_battery_current_text_font = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_moon_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_alarm_clock_text_text_img = ''
        let idle_heart_rate_text_font = ''
        let idle_calorie_current_text_font = ''
        let idle_distance_current_text_font = ''
        let Button_Switch_BG_Color = ''

        let bgColorIndex = 0;
        let bgColorList = [0xFFFA9B9B, 0xFFFAD19B, 0xFFFAF99B, 0xFFA6FA9B, 0xFF9BFAF9, 0xFF9BACFA];
        let bgColorToastList = ['Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';
		
        let normal_month_name_font = ''
        let idle_month_name_font = ''
		
		
      const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
let isDayIcons = false
		
 function autoToggleWeatherIcons() {

  let weatherData = weatherSensor.getForecastWeather();
  let tideData = weatherData.tideData;
	 
  let forecastData = weatherData.forecastData;

  sunData = weatherData.tideData;
  if (sunData.count > 0) {
   today = sunData.data[0];
   sunriseMins = (today.sunrise.hour) * 60 + today.sunrise.minute;
   sunsetMins = (today.sunset.hour) * 60 + today.sunset.minute;
  } else {
   sunriseMins = sunriseMins_def;
   sunsetMins = sunsetMins_def;
  }
  curMins = timeSensor.hour * 60 + timeSensor.minute;
  let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

  if (isDayNow) {
   if (!isDayIcons) {
    isDayIcons = true;
   }
  } else {
   if (isDayIcons) {
    isDayIcons = false;
   }
  }

  shotWeaterhNames = isDayIcons ? ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"]:["Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью", "Пасмурно ночью", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];
	 
  let current = weatherSensor.current;
  let curAirIconIndex = weatherSensor.curAirIconIndex;
  normal_month_name_font.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex].toUpperCase());
  idle_month_name_font.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex].toUpperCase());
 }
		
		


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SFComRound.ttf; FontSize: 100
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 1250,
              h: 142,
              text_size: 100,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SFComRound.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: MrPalDadBold.ttf; FontSize: 39
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 484,
              h: 60,
              text_size: 39,
              char_space: 0,
              line_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: 0xFF9BACFA,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: MrPalDadBold.ttf; FontSize: 43
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 531,
              h: 66,
              text_size: 43,
              char_space: 0,
              line_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: MrPalDadBold.ttf; FontSize: 22
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 273,
              h: 33,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: 0xFFA8A7A7,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
            // FontName: MrPalDadBold.ttf; FontSize: 47; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 56,
              h: 56,
              text_size: 47,
              char_space: 0,
              line_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: 0xFF9BACFA,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });				
				

            //#region SwitchBG_Color
            console.log('SwitchBG_Color');
            function switchBG_Color() {
              bgColorIndex++;
              if (bgColorIndex >= bgColorList.length) bgColorIndex = 0;
              hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
              let toastText = bgColorToastList[bgColorIndex].replace('%s', `${bgColorIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
				normal_month_name_font.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);	
				idle_month_name_font.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);	

				
            normal_battery_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 31,
              y: 324,
              w: 150,
              h: 70,
              text_size: 39,
              char_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: bgColorList[bgColorIndex],
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		
				
              vibro(28);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFFFA9B9B',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 144,
              y: 109,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
				
            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 170,
              month_startY: 385,
              month_sc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_tc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_en_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });				
				

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -21,
              y: -1,
              w: 400,
              h: 120,
              text_size: 100,
              char_space: 0,
              font: 'fonts/SFComRound.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 228,
              day_startY: 125,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 315,
              font_array: ["dig_s_0.png","dig_s_1.png","dig_s_2.png","dig_s_3.png","dig_s_4.png","dig_s_5.png","dig_s_6.png","dig_s_7.png","dig_s_8.png","dig_s_9.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 31,
              y: 324,
              w: 150,
              h: 70,
              text_size: 39,
              char_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: 0xFF9BACFA,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 28,
              y: 116,
              image_array: ["wi_0.png","wi_1.png","wi_2.png","wi_3.png","wi_4.png","wi_5.png","wi_6.png","wi_7.png","wi_8.png","wi_9.png","wi_10.png","wi_11.png","wi_12.png","wi_13.png","wi_14.png","wi_15.png","wi_16.png","wi_17.png","wi_18.png","wi_19.png","wi_20.png","wi_21.png","wi_22.png","wi_23.png","wi_24.png","wi_25.png","wi_26.png","wi_27.png","wi_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -12,
              y: 170,
              w: 150,
              h: 70,
              text_size: 43,
              char_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 29,
              y: 326,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 7,
              anim_size: 7,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 214,
              w: 374,
              h: 70,
              text_size: 47,
              char_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: 0xFF9BACFA,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.RIGHT,
              // unit_string: ЯНВАРЬ, ФЕВРАЛБ, МАРТ, АПРЕЛЬ, МАЙ, ИЮНЬ, ИЮЛЬ, АВГУСТ, СЕНТЯБРЬ, ОКТЯБРЬ, НОЯБРЬ, ДЕКАБРЬ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
								
            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 44,
              y: 29,
              src: 'stat_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 8,
              y: 59,
              font_array: ["AL_0.png","AL_1.png","AL_2.png","AL_3.png","AL_4.png","AL_5.png","AL_6.png","AL_7.png","AL_8.png","AL_9.png"],
              padding: true,
              h_space: -1,
              invalid_image: 'AL_v.png',
              dot_image: 'AL_dot2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 176,
              y: 274-1,
              w: 150,
              h: 50,
              text_size: 22,
              char_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: 0xFFA8A7A7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -57,
              y: 274-1,
              w: 150,
              h: 50,
              text_size: 22,
              char_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: 0xFFA8A7A7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 73,
              y: 274-1,
              w: 150,
              h: 50,
              text_size: 22,
              char_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: 0xFFA8A7A7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFFFA9B9B',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 144,
              y: 109,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 170,
              month_startY: 385,
              month_sc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_tc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_en_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -21,
              y: -1,
              w: 400,
              h: 120,
              text_size: 100,
              char_space: 0,
              font: 'fonts/SFComRound.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 228,
              day_startY: 125,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 315,
              font_array: ["dig_s_0.png","dig_s_1.png","dig_s_2.png","dig_s_3.png","dig_s_4.png","dig_s_5.png","dig_s_6.png","dig_s_7.png","dig_s_8.png","dig_s_9.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 31,
              y: 324,
              w: 150,
              h: 70,
              text_size: 39,
              char_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: 0xFF9BACFA,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 28,
              y: 116,
              image_array: ["wi_0.png","wi_1.png","wi_2.png","wi_3.png","wi_4.png","wi_5.png","wi_6.png","wi_7.png","wi_8.png","wi_9.png","wi_10.png","wi_11.png","wi_12.png","wi_13.png","wi_14.png","wi_15.png","wi_16.png","wi_17.png","wi_18.png","wi_19.png","wi_20.png","wi_21.png","wi_22.png","wi_23.png","wi_24.png","wi_25.png","wi_26.png","wi_27.png","wi_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -12,
              y: 170,
              w: 150,
              h: 70,
              text_size: 43,
              char_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
				
            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 214,
              w: 374,
              h: 70,
              text_size: 47,
              char_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: 0xFF9BACFA,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.RIGHT,
              // unit_string: ЯНВАРЬ, ФЕВРАЛБ, МАРТ, АПРЕЛЬ, МАЙ, ИЮНЬ, ИЮЛЬ, АВГУСТ, СЕНТЯБРЬ, ОКТЯБРЬ, НОЯБРЬ, ДЕКАБРЬ,
              show_level: hmUI.show_level.ONLY_AOD,
            });
				

/*            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: -12,
              y: 222,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });
*/
            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 44,
              y: 29,
              src: 'stat_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 8,
              y: 59,
              font_array: ["AL_0.png","AL_1.png","AL_2.png","AL_3.png","AL_4.png","AL_5.png","AL_6.png","AL_7.png","AL_8.png","AL_9.png"],
              padding: true,
              h_space: -1,
              invalid_image: 'AL_v.png',
              dot_image: 'AL_dot2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 176,
              y: 274-1,
              w: 150,
              h: 50,
              text_size: 22,
              char_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: 0xFFA8A7A7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -57,
              y: 274-1,
              w: 150,
              h: 50,
              text_size: 22,
              char_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: 0xFFA8A7A7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 73,
              y: 274-1,
              w: 150,
              h: 50,
              text_size: 22,
              char_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: 0xFFA8A7A7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.SwitchBG_Color');
            // Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.SwitchBG_Color, {
              // x: 145,
              // y: 175,
              // w: 100,
              // h: 100,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '0.png',
              // normal_src: '0.png',
              // color_list: 0xFFFA9B9B|0xFFFAD19B|0xFFFAF99B|0xFFA6FA9B|0xFF9BFAF9|0xFF9BACFA,
              // toast_list: Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s,
              // use_crown: False,
              // use_in_AOD: True,
              // vibro: True,
            // });

            Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 145,
              y: 175,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                switchBG_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_HourMinStr = 'pm ' + normal_HourMinStr
                  else normal_HourMinStr = 'am ' + normal_HourMinStr
                };
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let idle_HourMinStr = format_hour.toString();
                idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) idle_HourMinStr = 'pm ' + idle_HourMinStr
                  else idle_HourMinStr = 'am ' + idle_HourMinStr
                };
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
				  autoToggleWeatherIcons();				  
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                //SwitchBgColor
                if (hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`) === undefined) {
                  bgColorIndex = 0;
                  hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
                } else {
                  bgColorIndex = hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg) normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
                if (screenType == hmSetting.screen_type.AOD && idle_background_bg) idle_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
				  normal_month_name_font.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
				  idle_month_name_font.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);

            normal_battery_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 31,
              y: 324,
              w: 150,
              h: 70,
              text_size: 39,
              char_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: bgColorList[bgColorIndex],
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
				  
            idle_battery_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 31,
              y: 324,
              w: 150,
              h: 70,
              text_size: 39,
              char_space: 0,
              font: 'fonts/MrPalDadBold.ttf',
              color: bgColorList[bgColorIndex],
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });				  
				  
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}