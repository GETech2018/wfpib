﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 164,
              month_startY: 279,
              month_sc_array: ["chars_C208295A_000.png","chars_C208295A_001.png","chars_C208295A_002.png","chars_C208295A_003.png","chars_C208295A_004.png","chars_C208295A_005.png","chars_C208295A_006.png","chars_C208295A_007.png","chars_C208295A_008.png","chars_C208295A_009.png","chars_C208295A_010.png","chars_C208295A_011.png"],
              month_tc_array: ["chars_C208295A_000.png","chars_C208295A_001.png","chars_C208295A_002.png","chars_C208295A_003.png","chars_C208295A_004.png","chars_C208295A_005.png","chars_C208295A_006.png","chars_C208295A_007.png","chars_C208295A_008.png","chars_C208295A_009.png","chars_C208295A_010.png","chars_C208295A_011.png"],
              month_en_array: ["chars_C208295A_000.png","chars_C208295A_001.png","chars_C208295A_002.png","chars_C208295A_003.png","chars_C208295A_004.png","chars_C208295A_005.png","chars_C208295A_006.png","chars_C208295A_007.png","chars_C208295A_008.png","chars_C208295A_009.png","chars_C208295A_010.png","chars_C208295A_011.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 3,
              hour_startY: 62,
              hour_array: ["chars_FA6BFC54_000.png","chars_FA6BFC54_001.png","chars_FA6BFC54_002.png","chars_FA6BFC54_003.png","chars_FA6BFC54_004.png","chars_FA6BFC54_005.png","chars_FA6BFC54_006.png","chars_FA6BFC54_007.png","chars_FA6BFC54_008.png","chars_FA6BFC54_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 201,
              minute_startY: 62,
              minute_array: ["chars_8D834B9_000.png","chars_8D834B9_001.png","chars_8D834B9_002.png","chars_8D834B9_003.png","chars_8D834B9_004.png","chars_8D834B9_005.png","chars_8D834B9_006.png","chars_8D834B9_007.png","chars_8D834B9_008.png","chars_8D834B9_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 46,
              y: 216,
              week_en: ["chars_84414107_000.png","chars_84414107_001.png","chars_84414107_002.png","chars_84414107_003.png","chars_84414107_004.png","chars_84414107_005.png","chars_84414107_006.png"],
              week_tc: ["chars_84414107_000.png","chars_84414107_001.png","chars_84414107_002.png","chars_84414107_003.png","chars_84414107_004.png","chars_84414107_005.png","chars_84414107_006.png"],
              week_sc: ["chars_84414107_000.png","chars_84414107_001.png","chars_84414107_002.png","chars_84414107_003.png","chars_84414107_004.png","chars_84414107_005.png","chars_84414107_006.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 321,
              day_startY: 218,
              day_sc_array: ["chars_20D8F33_000.png","chars_20D8F33_001.png","chars_20D8F33_002.png","chars_20D8F33_003.png","chars_20D8F33_004.png","chars_20D8F33_005.png","chars_20D8F33_006.png","chars_20D8F33_007.png","chars_20D8F33_008.png","chars_20D8F33_009.png"],
              day_tc_array: ["chars_20D8F33_000.png","chars_20D8F33_001.png","chars_20D8F33_002.png","chars_20D8F33_003.png","chars_20D8F33_004.png","chars_20D8F33_005.png","chars_20D8F33_006.png","chars_20D8F33_007.png","chars_20D8F33_008.png","chars_20D8F33_009.png"],
              day_en_array: ["chars_20D8F33_000.png","chars_20D8F33_001.png","chars_20D8F33_002.png","chars_20D8F33_003.png","chars_20D8F33_004.png","chars_20D8F33_005.png","chars_20D8F33_006.png","chars_20D8F33_007.png","chars_20D8F33_008.png","chars_20D8F33_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 111,
              y: 421,
              image_array: ["set_21_165x23_h360s200b83_img_level_1.png","set_21_165x23_h360s200b83_img_level_2.png","set_21_165x23_h360s200b83_img_level_3.png","set_21_165x23_h360s200b83_img_level_4.png","set_21_165x23_h360s200b83_img_level_5.png","set_21_165x23_h360s200b83_img_level_6.png","set_21_165x23_h360s200b83_img_level_7.png","set_21_165x23_h360s200b83_img_level_8.png","set_21_165x23_h360s200b83_img_level_9.png","set_21_165x23_h360s200b83_img_level_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 336,
              font_array: ["chars_D2AB2E66_000.png","chars_D2AB2E66_001.png","chars_D2AB2E66_002.png","chars_D2AB2E66_003.png","chars_D2AB2E66_004.png","chars_D2AB2E66_005.png","chars_D2AB2E66_006.png","chars_D2AB2E66_007.png","chars_D2AB2E66_008.png","chars_D2AB2E66_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_D2AB2E66_011.png',
              unit_tc: 'chars_D2AB2E66_011.png',
              unit_en: 'chars_D2AB2E66_011.png',
              negative_image: 'chars_D2AB2E66_010.png',
              invalid_image: 'chars_D2AB2E66_012.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 335,
              y: 336,
              image_array: ["WEATHER_00.png","WEATHER_01.png","WEATHER_02.png","WEATHER_03.png","WEATHER_04.png","WEATHER_05.png","WEATHER_06.png","WEATHER_07.png","WEATHER_08.png","WEATHER_09.png","WEATHER_10.png","WEATHER_11.png","WEATHER_12.png","WEATHER_13.png","WEATHER_14.png","WEATHER_15.png","WEATHER_16.png","WEATHER_17.png","WEATHER_18.png","WEATHER_19.png","WEATHER_20.png","WEATHER_21.png","WEATHER_22.png","WEATHER_23.png","WEATHER_24.png","WEATHER_25.png","WEATHER_26.png","WEATHER_27.png","WEATHER_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 3,
              hour_startY: 150,
              hour_array: ["chars_43913703_000.png","chars_43913703_001.png","chars_43913703_002.png","chars_43913703_003.png","chars_43913703_004.png","chars_43913703_005.png","chars_43913703_006.png","chars_43913703_007.png","chars_43913703_008.png","chars_43913703_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 201,
              minute_startY: 150,
              minute_array: ["chars_8B4BEAE2_000.png","chars_8B4BEAE2_001.png","chars_8B4BEAE2_002.png","chars_8B4BEAE2_003.png","chars_8B4BEAE2_004.png","chars_8B4BEAE2_005.png","chars_8B4BEAE2_006.png","chars_8B4BEAE2_007.png","chars_8B4BEAE2_008.png","chars_8B4BEAE2_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}