# Sidecar Wide — Amazfit Bip 6 watch face (Zepp OS API 4.2)

Ready-to-build Zeus project. Every static part is a pre-rendered PNG; the watch only fills in live values.

## Build and get the QR (on a computer with internet)

```bash
npm i -g @zeppos/zeus-cli        # Node 18+
zeus login                       # Zepp developer account, once
cd SidecarWide
# bump version every rebuild (also regenerates JS, app.json and previews):
python3 tools/build.py . 2       # 2 = new version.code; use 3, 4, ... next time
zeus preview                     # pick "Amazfit Bip 6" → prints a QR in the terminal
```
Save the QR as a PNG and confirm it decodes to a `watchface://` link. QRs expire after about 7 days.
Install: Zepp app → Profile → Bip 6 → Developer Mode → Scan.

`tools/build.py` needs Python 3 + Pillow only. `tools/assets.py` (re-renders all PNGs) also needs Playwright + Chrome and the Roboto variable font path set at the top of the file; you only need it if you change the art.

## Layout
- Top left: weekday, date, month, and the weather city.
- Top right: weather icon and temperature. The top-centre notification bubble zone (x 165–225, y 0–46) is kept empty.
- LCD panel: time (HH:MM, seconds attached, AM/PM tag shown only in 12-hour mode), and the week strip. Past days are filled, and today's box is larger and fills bottom-to-top through the day.
- Under the LCD: month and year progress (`MO 9D 68%`, `YR 40D 89%`).
- Body column: Hybrid Charge (cyan, 10-segment meter), heart rate (number and heart in zone colour, plus a zone ladder), and sleep h:mm.
- Side column, top (sky group under the weather): moon phase with lit %, today's high/low, and the next sun event (sunset while the sun is up, otherwise the next sunrise).
- Side column, bottom: steps ring, steps, km, PAI (weekly), and VO₂ max.
- Bottom: alarm time, plus battery (icon fill resized by %, red at ≤20%).
- Tap areas open Heart, Sleep, Weather, Moon, Steps, PAI, VO₂ max, and Alarm.
- AOD: large grey time only.

## Rules applied
- Content stays inside x 14–376 / y 28–436, ≥8 px clear of the 86 px corner curve. `build.py` checks this on every build, plus badge-zone intrusion, overlaps, and image w/h ≥ pixel size.
- All outlined and art images carry 2 px transparent padding and are placed 2 px up/left.
- Text boxes are sized for the widest value. Numbers have no commas (8412). TEXT_IMG overflow fails the build.
- Bar tracks use #30353D; borders use ≥ #3E444E.
- Every progress bar (month, year, sleep, charge, battery, zone ladder) is a FILL_RECT whose width is set from the live value, or an IMG cropped by width.
- IMG_LEVEL is 1-based, and the weekday list starts on Monday. Weather uses 29 icons in Zepp's 0-based code order (0 cloudy, 3 sunny, 28 clear night).
- HR zones are computed from live HR, max 190: <95 relaxed #7c9fbb, 95–113 light, 114–132 intensive, 133–151 aerobic, 152–170 anaerobic, 171–190 VO₂ max.
- No SpO₂ and no history graphs.

## Check these on the real watch (could not be verified without a device)
1. **Hybrid Charge.** The number and the fallback meter are bound to `data_type.BIO_CHARGE`. If `@zos/sensor` exposes a `BioCharge` class, the code reads it, draws the width-resized bar, and shows `--` for 0. If it doesn't, the number stays data-bound, and the meter falls back to an IMG_LEVEL bound to BIO_CHARGE. If the watch shows 0 rather than "no data", the system number will read 0, not `--`.
2. **VO₂ max.** Bound to `data_type.VO2MAX` with a `--` invalid image. It is only rewritten from JS if a `Vo2Max` sensor class exists.
3. **Alarm.** Bound to `data_type.ALARM_CLOCK` with the colon as the dot image. If it renders oddly, read the alarm in JS instead.
4. **Permissions.** Uses heart_rate, step, distance, sleep, and pai (the `data:user.hd.*` set). Add any your Zeus version asks for.
5. **IMG_TIME AM/PM keys.** Uses `am_x/am_y/am_en_path/am_sc_path` (and the pm equivalents).
6. **appId** 1093517 is a placeholder. Replace it with an ID from your developer account if Zeus rejects it.

## Files
- `watchface/index.js`: generated, so don't hand-edit it. Edit `tools/build.py` (layout) or `tools/index.template.js` (logic).
- `assets/bip6/`: all PNGs.
- `preview/`: `sample.png`, `worst_case.png`, `zeros.png`, and `aod.png` from the same layout and assets.
