﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_heart_rate_text_text_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'fondo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 30,
              font_array: ["P_00.png","P_01.png","P_02.png","P_03.png","P_04.png","P_05.png","P_06.png","P_07.png","P_08.png","P_09.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'P_ico.png',
              unit_tc: 'P_ico.png',
              unit_en: 'P_ico.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 61,
              hour_startY: 149,
              hour_array: ["H_00.png","H_01.png","H_02.png","H_03.png","H_04.png","H_05.png","H_06.png","H_07.png","H_08.png","H_09.png"],
              hour_zero: 1,
              hour_space: -9,
              hour_angle: 0,
              hour_unit_sc: 'H_10.png',
              hour_unit_tc: 'H_10.png',
              hour_unit_en: 'H_10.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 230,
              minute_startY: 149,
              minute_array: ["H_00.png","H_01.png","H_02.png","H_03.png","H_04.png","H_05.png","H_06.png","H_07.png","H_08.png","H_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 118,
              y: 300,
              font_array: ["C_00.png","C_01.png","C_02.png","C_03.png","C_04.png","C_05.png","C_06.png","C_07.png","C_08.png","C_09.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'C_ico.png',
              unit_tc: 'C_ico.png',
              unit_en: 'C_ico.png',
              invalid_image: 'C_00.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 61,
              hour_startY: 149,
              hour_array: ["AOD_H_01.png","AOD_H_02.png","AOD_H_03.png","AOD_H_04.png","AOD_H_05.png","AOD_H_06.png","AOD_H_07.png","AOD_H_08.png","AOD_H_09.png","AOD_H_10.png"],
              hour_zero: 1,
              hour_space: 9,
              hour_angle: 0,
              hour_unit_sc: 'AOD_H_10.png',
              hour_unit_tc: 'AOD_H_10.png',
              hour_unit_en: 'AOD_H_10.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 230,
              minute_startY: 149,
              minute_array: ["AOD_H_01.png","AOD_H_02.png","AOD_H_03.png","AOD_H_04.png","AOD_H_05.png","AOD_H_06.png","AOD_H_07.png","AOD_H_08.png","AOD_H_09.png","AOD_H_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}