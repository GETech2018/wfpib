﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_distance_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_stress_icon_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 98,
              y: 26,
              src: 'BTRond.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 257,
              y: 33,
              src: 'AlarmRond.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 154,
              month_startY: 42,
              month_sc_array: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
              month_tc_array: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
              month_en_array: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 171,
              day_startY: 8,
              day_sc_array: ["chars_F1D8A724_000.png","chars_F1D8A724_001.png","chars_F1D8A724_002.png","chars_F1D8A724_003.png","chars_F1D8A724_004.png","chars_F1D8A724_005.png","chars_F1D8A724_006.png","chars_F1D8A724_007.png","chars_F1D8A724_008.png","chars_F1D8A724_009.png"],
              day_tc_array: ["chars_F1D8A724_000.png","chars_F1D8A724_001.png","chars_F1D8A724_002.png","chars_F1D8A724_003.png","chars_F1D8A724_004.png","chars_F1D8A724_005.png","chars_F1D8A724_006.png","chars_F1D8A724_007.png","chars_F1D8A724_008.png","chars_F1D8A724_009.png"],
              day_en_array: ["chars_F1D8A724_000.png","chars_F1D8A724_001.png","chars_F1D8A724_002.png","chars_F1D8A724_003.png","chars_F1D8A724_004.png","chars_F1D8A724_005.png","chars_F1D8A724_006.png","chars_F1D8A724_007.png","chars_F1D8A724_008.png","chars_F1D8A724_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 89,
              y: 67,
              week_en: ["0220.png","0221.png","0222.png","0223.png","0224.png","0225.png","0226.png"],
              week_tc: ["0220.png","0221.png","0222.png","0223.png","0224.png","0225.png","0226.png"],
              week_sc: ["0220.png","0221.png","0222.png","0223.png","0224.png","0225.png","0226.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 107,
              hour_array: ["chars_A8DD3CE5_000.png","chars_A8DD3CE5_001.png","chars_A8DD3CE5_002.png","chars_A8DD3CE5_003.png","chars_A8DD3CE5_004.png","chars_A8DD3CE5_005.png","chars_A8DD3CE5_006.png","chars_A8DD3CE5_007.png","chars_A8DD3CE5_008.png","chars_A8DD3CE5_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 44,
              minute_startY: 297,
              minute_array: ["chars_58E87177_000.png","chars_58E87177_001.png","chars_58E87177_002.png","chars_58E87177_003.png","chars_58E87177_004.png","chars_58E87177_005.png","chars_58E87177_006.png","chars_58E87177_007.png","chars_58E87177_008.png","chars_58E87177_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 100,
              second_startY: 250,
              second_array: ["chars_A72FAC3A_000.png","chars_A72FAC3A_001.png","chars_A72FAC3A_002.png","chars_A72FAC3A_003.png","chars_A72FAC3A_004.png","chars_A72FAC3A_005.png","chars_A72FAC3A_006.png","chars_A72FAC3A_007.png","chars_A72FAC3A_008.png","chars_A72FAC3A_009.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 244,
              y: 98,
              image_array: ["set_10_100x100_meteo_1.png","set_10_100x100_meteo_2.png","set_10_100x100_meteo_3.png","set_10_100x100_meteo_4.png","set_10_100x100_meteo_5.png","set_10_100x100_meteo_6.png","set_10_100x100_meteo_7.png","set_10_100x100_meteo_8.png","set_10_100x100_meteo_9.png","set_10_100x100_meteo_10.png","set_10_100x100_meteo_11.png","set_10_100x100_meteo_12.png","set_10_100x100_meteo_13.png","set_10_100x100_meteo_14.png","set_10_100x100_meteo_15.png","set_10_100x100_meteo_16.png","set_10_100x100_meteo_17.png","set_10_100x100_meteo_18.png","set_10_100x100_meteo_19.png","set_10_100x100_meteo_20.png","set_10_100x100_meteo_21.png","set_10_100x100_meteo_22.png","set_10_100x100_meteo_23.png","set_10_100x100_meteo_24.png","set_10_100x100_meteo_25.png","set_10_100x100_meteo_26.png","set_10_100x100_meteo_27.png","set_10_100x100_meteo_28.png","set_10_100x100_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 180,
              font_array: ["chars_DE0EEF6D_000.png","chars_DE0EEF6D_001.png","chars_DE0EEF6D_002.png","chars_DE0EEF6D_003.png","chars_DE0EEF6D_004.png","chars_DE0EEF6D_005.png","chars_DE0EEF6D_006.png","chars_DE0EEF6D_007.png","chars_DE0EEF6D_008.png","chars_DE0EEF6D_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_DE0EEF6D_011.png',
              unit_tc: 'chars_DE0EEF6D_011.png',
              unit_en: 'chars_DE0EEF6D_011.png',
              negative_image: 'chars_DE0EEF6D_010.png',
              invalid_image: 'chars_DE0EEF6D_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 283,
              font_array: ["chars_3BEB7765_000.png","chars_3BEB7765_001.png","chars_3BEB7765_002.png","chars_3BEB7765_003.png","chars_3BEB7765_004.png","chars_3BEB7765_005.png","chars_3BEB7765_006.png","chars_3BEB7765_007.png","chars_3BEB7765_008.png","chars_3BEB7765_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 232,
              y: 337,
              src: '0003.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 223,
              y: 283,
              src: 'step_2_44x29_a230.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 233,
              y: 336,
              image_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 368,
              font_array: ["chars_A85AEE40_000.png","chars_A85AEE40_001.png","chars_A85AEE40_002.png","chars_A85AEE40_003.png","chars_A85AEE40_004.png","chars_A85AEE40_005.png","chars_A85AEE40_006.png","chars_A85AEE40_007.png","chars_A85AEE40_008.png","chars_A85AEE40_009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'chars_A85AEE40_010.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 336,
              y: 368,
              src: 'km_4_29x30_a159.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 145,
              y: 416,
              font_array: ["chars_2141A26A_000.png","chars_2141A26A_001.png","chars_2141A26A_002.png","chars_2141A26A_003.png","chars_2141A26A_004.png","chars_2141A26A_005.png","chars_2141A26A_006.png","chars_2141A26A_007.png","chars_2141A26A_008.png","chars_2141A26A_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 211,
              y: 413,
              src: 'chars_662C1306_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 227,
              font_array: ["chars_8BE8F656_000.png","chars_8BE8F656_001.png","chars_8BE8F656_002.png","chars_8BE8F656_003.png","chars_8BE8F656_004.png","chars_8BE8F656_005.png","chars_8BE8F656_006.png","chars_8BE8F656_007.png","chars_8BE8F656_008.png","chars_8BE8F656_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 344,
              y: 244,
              src: 'heart_12_27x27_h360s200b61.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 327,
              y: 206,
              image_array: ["set_30_67x67_img_level_1.png","set_30_67x67_img_level_2.png","set_30_67x67_img_level_3.png","set_30_67x67_img_level_4.png","set_30_67x67_img_level_5.png","set_30_67x67_img_level_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 98,
              y: 26,
              src: 'BTRond.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 257,
              y: 33,
              src: 'AlarmRond.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 247,
              y: 98,
              src: 'icon3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 154,
              month_startY: 42,
              month_sc_array: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
              month_tc_array: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
              month_en_array: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 171,
              day_startY: 8,
              day_sc_array: ["chars_F1D8A724_000.png","chars_F1D8A724_001.png","chars_F1D8A724_002.png","chars_F1D8A724_003.png","chars_F1D8A724_004.png","chars_F1D8A724_005.png","chars_F1D8A724_006.png","chars_F1D8A724_007.png","chars_F1D8A724_008.png","chars_F1D8A724_009.png"],
              day_tc_array: ["chars_F1D8A724_000.png","chars_F1D8A724_001.png","chars_F1D8A724_002.png","chars_F1D8A724_003.png","chars_F1D8A724_004.png","chars_F1D8A724_005.png","chars_F1D8A724_006.png","chars_F1D8A724_007.png","chars_F1D8A724_008.png","chars_F1D8A724_009.png"],
              day_en_array: ["chars_F1D8A724_000.png","chars_F1D8A724_001.png","chars_F1D8A724_002.png","chars_F1D8A724_003.png","chars_F1D8A724_004.png","chars_F1D8A724_005.png","chars_F1D8A724_006.png","chars_F1D8A724_007.png","chars_F1D8A724_008.png","chars_F1D8A724_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 89,
              y: 67,
              week_en: ["0220.png","0221.png","0222.png","0223.png","0224.png","0225.png","0226.png"],
              week_tc: ["0220.png","0221.png","0222.png","0223.png","0224.png","0225.png","0226.png"],
              week_sc: ["0220.png","0221.png","0222.png","0223.png","0224.png","0225.png","0226.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 106,
              hour_array: ["chars_A8DD3CE5_000.png","chars_A8DD3CE5_001.png","chars_A8DD3CE5_002.png","chars_A8DD3CE5_003.png","chars_A8DD3CE5_004.png","chars_A8DD3CE5_005.png","chars_A8DD3CE5_006.png","chars_A8DD3CE5_007.png","chars_A8DD3CE5_008.png","chars_A8DD3CE5_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 156,
              minute_startY: 265,
              minute_array: ["chars_58E87177_000.png","chars_58E87177_001.png","chars_58E87177_002.png","chars_58E87177_003.png","chars_58E87177_004.png","chars_58E87177_005.png","chars_58E87177_006.png","chars_58E87177_007.png","chars_58E87177_008.png","chars_58E87177_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 145,
              y: 411,
              font_array: ["chars_2141A26A_000.png","chars_2141A26A_001.png","chars_2141A26A_002.png","chars_2141A26A_003.png","chars_2141A26A_004.png","chars_2141A26A_005.png","chars_2141A26A_006.png","chars_2141A26A_007.png","chars_2141A26A_008.png","chars_2141A26A_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 211,
              y: 403,
              src: 'chars_662C1306_000.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'smarr.png',
              // center_x: 306,
              // center_y: 156,
              // x: 11,
              // y: 60,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 306 - 11,
              pos_y: 156 - 60,
              center_x: 306,
              center_y: 156,
              src: 'smarr.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 227,
              y: 252,
              w: 81,
              h: 81,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 325,
              y: 208,
              w: 57,
              h: 57,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 244,
              y: 326,
              w: 65,
              h: 81,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 69,
              y: 45,
              w: 81,
              h: 81,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 236,
              y: 130,
              w: 81,
              h: 81,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 8,
              y: 154,
              w: 81,
              h: 81,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 146,
              y: 154,
              w: 81,
              h: 81,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 99,
              y: 241,
              w: 57,
              h: 57,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 240,
              y: 45,
              w: 81,
              h: 81,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 154,
              y: 8,
              w: 81,
              h: 81,
              text: '',
              color: 0xFFFF8C00,
              text_size: 20,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 161,
              y: 373,
              w: 81,
              h: 81,
              text: '',
              color: 0xFFFF8C00,
              text_size: 20,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              // Second Pointer
              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*second/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}