﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bk12.ong.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 107,
              y: 52,
              src: 'lock_closed.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 48,
              y: 50,
              src: 'dnd_on.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 310,
              y: 50,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 255,
              y: 53,
              src: 'clock-alarm_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 328,
              y: 210,
              image_array: ["CLIMA03_0.png","CLIMA03_1.png","CLIMA03_2.png","CLIMA03_3.png","CLIMA03_4.png","CLIMA03_5.png","CLIMA03_6.png","CLIMA03_7.png","CLIMA03_8.png","CLIMA03_9.png","CLIMA03_10.png","CLIMA03_11.png","CLIMA03_12.png","CLIMA03_13.png","CLIMA03_14.png","CLIMA03_15.png","CLIMA03_16.png","CLIMA03_17.png","CLIMA03_18.png","CLIMA03_19.png","CLIMA03_20.png","CLIMA03_21.png","CLIMA03_22.png","CLIMA03_23.png","CLIMA03_24.png","CLIMA03_25.png","CLIMA03_26.png","CLIMA03_27.png","CLIMA03_28.png"],
              image_length: 29,
              // alpha: 190,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level.setAlpha(190);

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 170,
              font_array: ["fclima3_0.png","fclima3_1.png","fclima3_2.png","fclima3_3.png","fclima3_4.png","fclima3_5.png","fclima3_6.png","fclima3_7.png","fclima3_8.png","fclima3_9.png"],
              padding: false,
              h_space: -7,
              unit_sc: 'fclima3_10.png',
              unit_tc: 'fclima3_10.png',
              unit_en: 'fclima3_10.png',
              negative_image: 'fclima3_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 169,
              day_startY: 31,
              day_sc_array: ["DIA01_0.png","DIA01_1.png","DIA01_2.png","DIA01_3.png","DIA01_4.png","DIA01_5.png","DIA01_6.png","DIA01_7.png","DIA01_8.png","DIA01_9.png"],
              day_tc_array: ["DIA01_0.png","DIA01_1.png","DIA01_2.png","DIA01_3.png","DIA01_4.png","DIA01_5.png","DIA01_6.png","DIA01_7.png","DIA01_8.png","DIA01_9.png"],
              day_en_array: ["DIA01_0.png","DIA01_1.png","DIA01_2.png","DIA01_3.png","DIA01_4.png","DIA01_5.png","DIA01_6.png","DIA01_7.png","DIA01_8.png","DIA01_9.png"],
              day_zero: 0,
              day_space: -13,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              // alpha: 220,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day.setAlpha(220);

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'AGUJA_01.png',
              center_x: 70,
              center_y: 220,
              x: 8,
              y: 8,
              start_angle: 124,
              end_angle: 192,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 38,
              y: 303,
              font_array: ["DATOS3_0.png","DATOS3_1.png","DATOS3_2.png","DATOS3_3.png","DATOS3_4.png","DATOS3_5.png","DATOS3_6.png","DATOS3_7.png","DATOS3_8.png","DATOS3_9.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 23,
              y: 365,
              font_array: ["datosmin_0.png","datosmin_1.png","datosmin_2.png","datosmin_3.png","datosmin_4.png","datosmin_5.png","datosmin_6.png","datosmin_7.png","datosmin_8.png","datosmin_9.png"],
              padding: false,
              h_space: -11,
              dot_image: 'datosmin_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 365,
              font_array: ["datosmin_0.png","datosmin_1.png","datosmin_2.png","datosmin_3.png","datosmin_4.png","datosmin_5.png","datosmin_6.png","datosmin_7.png","datosmin_8.png","datosmin_9.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 303,
              font_array: ["DATOS3_0.png","DATOS3_1.png","DATOS3_2.png","DATOS3_3.png","DATOS3_4.png","DATOS3_5.png","DATOS3_6.png","DATOS3_7.png","DATOS3_8.png","DATOS3_9.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 236,
              font_array: ["DATOS3_0.png","DATOS3_1.png","DATOS3_2.png","DATOS3_3.png","DATOS3_4.png","DATOS3_5.png","DATOS3_6.png","DATOS3_7.png","DATOS3_8.png","DATOS3_9.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 11,
              month_startY: 11,
              month_sc_array: ["2001_ENE.png","2002_FEB.png","2003_MAR.png","2004_ABR.png","2005_MAY.png","2006_JUN.png","2007_JUL.png","2008_AGO.png","2009_SEP.png","2010_OCT.png","2011_NOV.png","2012_DIC.png"],
              month_tc_array: ["2001_ENE.png","2002_FEB.png","2003_MAR.png","2004_ABR.png","2005_MAY.png","2006_JUN.png","2007_JUL.png","2008_AGO.png","2009_SEP.png","2010_OCT.png","2011_NOV.png","2012_DIC.png"],
              month_en_array: ["2001_ENE.png","2002_FEB.png","2003_MAR.png","2004_ABR.png","2005_MAY.png","2006_JUN.png","2007_JUL.png","2008_AGO.png","2009_SEP.png","2010_OCT.png","2011_NOV.png","2012_DIC.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 6,
              y: 380,
              week_en: ["1001.png","1002.png","1003.png","1004.png","1005.png","1006.png","1007.png"],
              week_tc: ["1001.png","1002.png","1003.png","1004.png","1005.png","1006.png","1007.png"],
              week_sc: ["1001.png","1002.png","1003.png","1004.png","1005.png","1006.png","1007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 1,
              am_y: 155,
              am_sc_path: 'AMF.png',
              am_en_path: 'AMF.png',
              pm_x: 1,
              pm_y: 155,
              pm_sc_path: 'PMF.png',
              pm_en_path: 'PMF.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 43,
              hour_startY: 106,
              hour_array: ["HORS7_0.png","HORS7_1.png","HORS7_2.png","HORS7_3.png","HORS7_4.png","HORS7_5.png","HORS7_6.png","HORS7_7.png","HORS7_8.png","HORS7_9.png"],
              hour_zero: 1,
              hour_space: -30,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 172,
              minute_startY: 106,
              minute_array: ["MINS4_0.png","MINS4_1.png","MINS4_2.png","MINS4_3.png","MINS4_4.png","MINS4_5.png","MINS4_6.png","MINS4_7.png","MINS4_8.png","MINS4_9.png"],
              minute_zero: 1,
              minute_space: -30,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'aod03.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 107,
              y: 52,
              src: 'lock_closed.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 48,
              y: 50,
              src: 'dnd_on.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 310,
              y: 50,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 255,
              y: 53,
              src: 'clock-alarm_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 43,
              hour_startY: 106,
              hour_array: ["HORS7_0.png","HORS7_1.png","HORS7_2.png","HORS7_3.png","HORS7_4.png","HORS7_5.png","HORS7_6.png","HORS7_7.png","HORS7_8.png","HORS7_9.png"],
              hour_zero: 1,
              hour_space: -30,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 172,
              minute_startY: 106,
              minute_array: ["MINS4_0.png","MINS4_1.png","MINS4_2.png","MINS4_3.png","MINS4_4.png","MINS4_5.png","MINS4_6.png","MINS4_7.png","MINS4_8.png","MINS4_9.png"],
              minute_zero: 1,
              minute_space: -30,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 154,
              y: 213,
              w: 100,
              h: 80,
              src: 'z_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 6,
              y: 210,
              w: 75,
              h: 75,
              src: 'z_Empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 158,
              y: 25,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'z_Empty.png',
              normal_src: 'z_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 211,
              y: 127,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'z_Empty.png',
              normal_src: 'z_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 246,
              y: 26,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'z_Empty.png',
              normal_src: 'z_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 254,
              y: 368,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'z_Empty.png',
              normal_src: 'z_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 313,
              y: 201,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'z_Empty.png',
              normal_src: 'z_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 51,
              y: 24,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'z_Empty.png',
              normal_src: 'z_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'MusicCommonScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 258,
              y: 290,
              w: 110,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'z_Empty.png',
              normal_src: 'z_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 43,
              y: 373,
              w: 110,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'z_Empty.png',
              normal_src: 'z_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 60,
              y: 131,
              w: 110,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'z_Empty.png',
              normal_src: 'z_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}