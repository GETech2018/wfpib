﻿    /*
    ** Watch_Face_Editor tool v 18.3
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// Start color change
        let colornumber = 1
        let totalcolors = 12
        let namecolor = ''
        let array_min = ''
        let array_hour = ''
        let timedot = ''

        function click_Dot() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "WHITE"}
if ( colornumber == 2) { namecolor = "BLUE"}
if ( colornumber == 3) { namecolor = "GREEN"}
if ( colornumber == 4) { namecolor = "ORANGE"}
if ( colornumber == 5) { namecolor = "YELLOW"}
if ( colornumber == 6) { namecolor = "RED"}
if ( colornumber == 7) { namecolor = "BLUE SHADE"}
if ( colornumber == 8) { namecolor = "GREEN SHADE"}
if ( colornumber == 9) { namecolor = "ORANGE SHADE"}
if ( colornumber == 10) { namecolor = "YELLOW SHADE"}
if ( colornumber == 11) { namecolor = "RED SHADE"}
if ( colornumber == 12) { namecolor = "Multi Color"}
if (colornumber <= totalcolors){

hmUI.showToast({text: namecolor});


            normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.MORE, {
              x: 175,
              y: 385,
              src: "TIME_DOT_"+colornumber+".png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


}

                         
        }








        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "WHITE"
array_min = ["Time_1_0.png","Time_1_1.png","Time_1_2.png","Time_1_3.png","Time_1_4.png","Time_1_5.png","Time_1_6.png","Time_1_7.png","Time_1_8.png","Time_1_9.png"];
array_hour = ["Time_1_0.png","Time_1_1.png","Time_1_2.png","Time_1_3.png","Time_1_4.png","Time_1_5.png","Time_1_6.png","Time_1_7.png","Time_1_8.png","Time_1_9.png"];
timedot = 'TIME_DOT_1.png'
}
if ( colornumber == 2) { namecolor = "BLUE"
array_min = ["Time2_0.png","Time2_1.png","Time2_2.png","Time2_3.png","Time2_4.png","Time2_5.png","Time2_6.png","Time2_7.png","Time2_8.png","Time2_9.png"];
array_hour =["Time2_0.png","Time2_1.png","Time2_2.png","Time2_3.png","Time2_4.png","Time2_5.png","Time2_6.png","Time2_7.png","Time2_8.png","Time2_9.png"];
timedot = 'TIME_DOT_2.png'
}
if ( colornumber == 3) { namecolor = "GREEN"
array_min = ["Time3_0.png","Time3_1.png","Time3_2.png","Time3_3.png","Time3_4.png","Time3_5.png","Time3_6.png","Time3_7.png","Time3_8.png","Time3_9.png"];
array_hour = ["Time3_0.png","Time3_1.png","Time3_2.png","Time3_3.png","Time3_4.png","Time3_5.png","Time3_6.png","Time3_7.png","Time3_8.png","Time3_9.png"];
timedot = 'TIME_DOT_3.png'
}
if ( colornumber == 4) { namecolor = "ORANGE"
array_min = ["Time4_0.png","Time4_1.png","Time4_2.png","Time4_3.png","Time4_4.png","Time4_5.png","Time4_6.png","Time4_7.png","Time4_8.png","Time4_9.png"];
array_hour = ["Time4_0.png","Time4_1.png","Time4_2.png","Time4_3.png","Time4_4.png","Time4_5.png","Time4_6.png","Time4_7.png","Time4_8.png","Time4_9.png"];
timedot = 'TIME_DOT_4.png'
}
if ( colornumber == 5) { namecolor = "YELLOW"
array_min = ["Time5_0.png","Time5_1.png","Time5_2.png","Time5_3.png","Time5_4.png","Time5_5.png","Time5_6.png","Time5_7.png","Time5_8.png","Time5_9.png"];
array_hour = ["Time5_0.png","Time5_1.png","Time5_2.png","Time5_3.png","Time5_4.png","Time5_5.png","Time5_6.png","Time5_7.png","Time5_8.png","Time5_9.png"];
timedot = 'TIME_DOT_5.png'
}
if ( colornumber == 6) { namecolor = "RED"
array_min = ["Time6_0.png","Time6_1.png","Time6_2.png","Time6_3.png","Time6_4.png","Time6_5.png","Time6_6.png","Time6_7.png","Time6_8.png","Time6_9.png"];
array_hour = ["Time6_0.png","Time6_1.png","Time6_2.png","Time6_3.png","Time6_4.png","Time6_5.png","Time6_6.png","Time6_7.png","Time6_8.png","Time6_9.png"];
timedot = 'TIME_DOT_6.png'
}
if ( colornumber == 7) { namecolor = "BLUE SHADE"
array_min = ["Time7_0.png","Time7_1.png","Time7_2.png","Time7_3.png","Time7_4.png","Time7_5.png","Time7_6.png","Time7_7.png","Time7_8.png","Time7_9.png"];
array_hour = ["Time7_0.png","Time7_1.png","Time7_2.png","Time7_3.png","Time7_4.png","Time7_5.png","Time7_6.png","Time7_7.png","Time7_8.png","Time7_9.png"];
timedot = 'TIME_DOT_7.png'
}
if ( colornumber == 8) { namecolor = "GREEN SHADE"
array_min = ["Time8_0.png","Time8_1.png","Time8_2.png","Time8_3.png","Time8_4.png","Time8_5.png","Time8_6.png","Time8_7.png","Time8_8.png","Time8_9.png"];
array_hour = ["Time8_0.png","Time8_1.png","Time8_2.png","Time8_3.png","Time8_4.png","Time8_5.png","Time8_6.png","Time8_7.png","Time8_8.png","Time8_9.png"];
timedot = 'TIME_DOT_8.png'
}
if ( colornumber == 9) { namecolor = "ORANGE SHADE"
array_min = ["Time9_0.png","Time9_1.png","Time9_2.png","Time9_3.png","Time9_4.png","Time9_5.png","Time9_6.png","Time9_7.png","Time9_8.png","Time9_9.png"];
array_hour = ["Time9_0.png","Time9_1.png","Time9_2.png","Time9_3.png","Time9_4.png","Time9_5.png","Time9_6.png","Time9_7.png","Time9_8.png","Time9_9.png"];
timedot = 'TIME_DOT_9.png'
}
if ( colornumber == 10) { namecolor = "YELLOW SHADE"
array_min = ["Time10_0.png","Time10_1.png","Time10_2.png","Time10_3.png","Time10_4.png","Time10_5.png","Time10_6.png","Time10_7.png","Time10_8.png","Time10_9.png"];
array_hour = ["Time10_0.png","Time10_1.png","Time10_2.png","Time10_3.png","Time10_4.png","Time10_5.png","Time10_6.png","Time10_7.png","Time10_8.png","Time10_9.png"];
timedot = 'TIME_DOT_10.png'
}
if ( colornumber == 11) { namecolor = "RED SHADE"
array_min = ["Time11_0.png","Time11_1.png","Time11_2.png","Time11_3.png","Time11_4.png","Time11_5.png","Time11_6.png","Time11_7.png","Time11_8.png","Time11_9.png"];
array_hour = ["Time11_0.png","Time11_1.png","Time11_2.png","Time11_3.png","Time11_4.png","Time11_5.png","Time11_6.png","Time11_7.png","Time11_8.png","Time11_9.png"];
timedot = 'TIME_DOT_11.png'
}
if ( colornumber == 12) { namecolor = "Multi Color"
array_min = ["Time12_0.png","Time12_1.png","Time12_2.png","Time12_3.png","Time12_4.png","Time12_5.png","Time12_6.png","Time12_7.png","Time12_8.png","Time12_9.png"];
array_hour = ["Time12_0.png","Time12_1.png","Time12_2.png","Time12_3.png","Time12_4.png","Time12_5.png","Time12_6.png","Time12_7.png","Time12_8.png","Time12_9.png"];
timedot = 'TIME_DOT_12.png'
}




if (colornumber <= totalcolors){
hmUI.showToast({text: namecolor});

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 186,
              minute_startY: 375,
              minute_array: array_min,
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.MORE, {
              x: 175,
              y: 385,
              src: timedot,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 70,
              hour_startY: 375,
              hour_array: array_hour,
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

}

                         
        }


        function click_Color2() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }


if ( colornumber == 1) { namecolor = "WHITE"
array_min = ["Time_1_0.png","Time_1_1.png","Time_1_2.png","Time_1_3.png","Time_1_4.png","Time_1_5.png","Time_1_6.png","Time_1_7.png","Time_1_8.png","Time_1_9.png"];
array_hour = ["Time_1_0.png","Time_1_1.png","Time_1_2.png","Time_1_3.png","Time_1_4.png","Time_1_5.png","Time_1_6.png","Time_1_7.png","Time_1_8.png","Time_1_9.png"];
timedot = 'TIME_DOT_1.png'
}
if ( colornumber == 2) { namecolor = "BLUE"
array_min = ["Time2_0.png","Time2_1.png","Time2_2.png","Time2_3.png","Time2_4.png","Time2_5.png","Time2_6.png","Time2_7.png","Time2_8.png","Time2_9.png"];
array_hour =["Time2_0.png","Time2_1.png","Time2_2.png","Time2_3.png","Time2_4.png","Time2_5.png","Time2_6.png","Time2_7.png","Time2_8.png","Time2_9.png"];
timedot = 'TIME_DOT_2.png'
}
if ( colornumber == 3) { namecolor = "GREEN"
array_min = ["Time3_0.png","Time3_1.png","Time3_2.png","Time3_3.png","Time3_4.png","Time3_5.png","Time3_6.png","Time3_7.png","Time3_8.png","Time3_9.png"];
array_hour = ["Time3_0.png","Time3_1.png","Time3_2.png","Time3_3.png","Time3_4.png","Time3_5.png","Time3_6.png","Time3_7.png","Time3_8.png","Time3_9.png"];
timedot = 'TIME_DOT_3.png'
}
if ( colornumber == 4) { namecolor = "ORANGE"
array_min = ["Time4_0.png","Time4_1.png","Time4_2.png","Time4_3.png","Time4_4.png","Time4_5.png","Time4_6.png","Time4_7.png","Time4_8.png","Time4_9.png"];
array_hour = ["Time4_0.png","Time4_1.png","Time4_2.png","Time4_3.png","Time4_4.png","Time4_5.png","Time4_6.png","Time4_7.png","Time4_8.png","Time4_9.png"];
timedot = 'TIME_DOT_4.png'
}
if ( colornumber == 5) { namecolor = "YELLOW"
array_min = ["Time5_0.png","Time5_1.png","Time5_2.png","Time5_3.png","Time5_4.png","Time5_5.png","Time5_6.png","Time5_7.png","Time5_8.png","Time5_9.png"];
array_hour = ["Time5_0.png","Time5_1.png","Time5_2.png","Time5_3.png","Time5_4.png","Time5_5.png","Time5_6.png","Time5_7.png","Time5_8.png","Time5_9.png"];
timedot = 'TIME_DOT_5.png'
}
if ( colornumber == 6) { namecolor = "RED"
array_min = ["Time6_0.png","Time6_1.png","Time6_2.png","Time6_3.png","Time6_4.png","Time6_5.png","Time6_6.png","Time6_7.png","Time6_8.png","Time6_9.png"];
array_hour = ["Time6_0.png","Time6_1.png","Time6_2.png","Time6_3.png","Time6_4.png","Time6_5.png","Time6_6.png","Time6_7.png","Time6_8.png","Time6_9.png"];
timedot = 'TIME_DOT_6.png'
}
if ( colornumber == 7) { namecolor = "BLUE SHADE"
array_min = ["Time7_0.png","Time7_1.png","Time7_2.png","Time7_3.png","Time7_4.png","Time7_5.png","Time7_6.png","Time7_7.png","Time7_8.png","Time7_9.png"];
array_hour = ["Time7_0.png","Time7_1.png","Time7_2.png","Time7_3.png","Time7_4.png","Time7_5.png","Time7_6.png","Time7_7.png","Time7_8.png","Time7_9.png"];
timedot = 'TIME_DOT_7.png'
}
if ( colornumber == 8) { namecolor = "GREEN SHADE"
array_min = ["Time8_0.png","Time8_1.png","Time8_2.png","Time8_3.png","Time8_4.png","Time8_5.png","Time8_6.png","Time8_7.png","Time8_8.png","Time8_9.png"];
array_hour = ["Time8_0.png","Time8_1.png","Time8_2.png","Time8_3.png","Time8_4.png","Time8_5.png","Time8_6.png","Time8_7.png","Time8_8.png","Time8_9.png"];
timedot = 'TIME_DOT_8.png'
}
if ( colornumber == 9) { namecolor = "ORANGE SHADE"
array_min = ["Time9_0.png","Time9_1.png","Time9_2.png","Time9_3.png","Time9_4.png","Time9_5.png","Time9_6.png","Time9_7.png","Time9_8.png","Time9_9.png"];
array_hour = ["Time9_0.png","Time9_1.png","Time9_2.png","Time9_3.png","Time9_4.png","Time9_5.png","Time9_6.png","Time9_7.png","Time9_8.png","Time9_9.png"];
timedot = 'TIME_DOT_9.png'
}
if ( colornumber == 10) { namecolor = "YELLOW SHADE"
array_min = ["Time10_0.png","Time10_1.png","Time10_2.png","Time10_3.png","Time10_4.png","Time10_5.png","Time10_6.png","Time10_7.png","Time10_8.png","Time10_9.png"];
array_hour = ["Time10_0.png","Time10_1.png","Time10_2.png","Time10_3.png","Time10_4.png","Time10_5.png","Time10_6.png","Time10_7.png","Time10_8.png","Time10_9.png"];
timedot = 'TIME_DOT_10.png'
}
if ( colornumber == 11) { namecolor = "RED SHADE"
array_min = ["Time11_0.png","Time11_1.png","Time11_2.png","Time11_3.png","Time11_4.png","Time11_5.png","Time11_6.png","Time11_7.png","Time11_8.png","Time11_9.png"];
array_hour = ["Time11_0.png","Time11_1.png","Time11_2.png","Time11_3.png","Time11_4.png","Time11_5.png","Time11_6.png","Time11_7.png","Time11_8.png","Time11_9.png"];
timedot = 'TIME_DOT_11.png'
}
if ( colornumber == 12) { namecolor = "Multi Color"
array_min = ["Time12_0.png","Time12_1.png","Time12_2.png","Time12_3.png","Time12_4.png","Time12_5.png","Time12_6.png","Time12_7.png","Time12_8.png","Time12_9.png"];
array_hour = ["Time12_0.png","Time12_1.png","Time12_2.png","Time12_3.png","Time12_4.png","Time12_5.png","Time12_6.png","Time12_7.png","Time12_8.png","Time12_9.png"];
timedot = 'TIME_DOT_12.png'
}



if (colornumber <= totalcolors){
hmUI.showToast({text: namecolor});


            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 70,
              hour_startY: 375,
              hour_array: array_hour,
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

}                     
        }


        function click_Color3() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }


if ( colornumber == 1) { namecolor = "WHITE"
array_min = ["Time_1_0.png","Time_1_1.png","Time_1_2.png","Time_1_3.png","Time_1_4.png","Time_1_5.png","Time_1_6.png","Time_1_7.png","Time_1_8.png","Time_1_9.png"];
array_hour = ["Time_1_0.png","Time_1_1.png","Time_1_2.png","Time_1_3.png","Time_1_4.png","Time_1_5.png","Time_1_6.png","Time_1_7.png","Time_1_8.png","Time_1_9.png"];
timedot = 'TIME_DOT_1.png'
}
if ( colornumber == 2) { namecolor = "BLUE"
array_min = ["Time2_0.png","Time2_1.png","Time2_2.png","Time2_3.png","Time2_4.png","Time2_5.png","Time2_6.png","Time2_7.png","Time2_8.png","Time2_9.png"];
array_hour =["Time2_0.png","Time2_1.png","Time2_2.png","Time2_3.png","Time2_4.png","Time2_5.png","Time2_6.png","Time2_7.png","Time2_8.png","Time2_9.png"];
timedot = 'TIME_DOT_2.png'
}
if ( colornumber == 3) { namecolor = "GREEN"
array_min = ["Time3_0.png","Time3_1.png","Time3_2.png","Time3_3.png","Time3_4.png","Time3_5.png","Time3_6.png","Time3_7.png","Time3_8.png","Time3_9.png"];
array_hour = ["Time3_0.png","Time3_1.png","Time3_2.png","Time3_3.png","Time3_4.png","Time3_5.png","Time3_6.png","Time3_7.png","Time3_8.png","Time3_9.png"];
timedot = 'TIME_DOT_3.png'
}
if ( colornumber == 4) { namecolor = "ORANGE"
array_min = ["Time4_0.png","Time4_1.png","Time4_2.png","Time4_3.png","Time4_4.png","Time4_5.png","Time4_6.png","Time4_7.png","Time4_8.png","Time4_9.png"];
array_hour = ["Time4_0.png","Time4_1.png","Time4_2.png","Time4_3.png","Time4_4.png","Time4_5.png","Time4_6.png","Time4_7.png","Time4_8.png","Time4_9.png"];
timedot = 'TIME_DOT_4.png'
}
if ( colornumber == 5) { namecolor = "YELLOW"
array_min = ["Time5_0.png","Time5_1.png","Time5_2.png","Time5_3.png","Time5_4.png","Time5_5.png","Time5_6.png","Time5_7.png","Time5_8.png","Time5_9.png"];
array_hour = ["Time5_0.png","Time5_1.png","Time5_2.png","Time5_3.png","Time5_4.png","Time5_5.png","Time5_6.png","Time5_7.png","Time5_8.png","Time5_9.png"];
timedot = 'TIME_DOT_5.png'
}
if ( colornumber == 6) { namecolor = "RED"
array_min = ["Time6_0.png","Time6_1.png","Time6_2.png","Time6_3.png","Time6_4.png","Time6_5.png","Time6_6.png","Time6_7.png","Time6_8.png","Time6_9.png"];
array_hour = ["Time6_0.png","Time6_1.png","Time6_2.png","Time6_3.png","Time6_4.png","Time6_5.png","Time6_6.png","Time6_7.png","Time6_8.png","Time6_9.png"];
timedot = 'TIME_DOT_6.png'
}
if ( colornumber == 7) { namecolor = "BLUE SHADE"
array_min = ["Time7_0.png","Time7_1.png","Time7_2.png","Time7_3.png","Time7_4.png","Time7_5.png","Time7_6.png","Time7_7.png","Time7_8.png","Time7_9.png"];
array_hour = ["Time7_0.png","Time7_1.png","Time7_2.png","Time7_3.png","Time7_4.png","Time7_5.png","Time7_6.png","Time7_7.png","Time7_8.png","Time7_9.png"];
timedot = 'TIME_DOT_7.png'
}
if ( colornumber == 8) { namecolor = "GREEN SHADE"
array_min = ["Time8_0.png","Time8_1.png","Time8_2.png","Time8_3.png","Time8_4.png","Time8_5.png","Time8_6.png","Time8_7.png","Time8_8.png","Time8_9.png"];
array_hour = ["Time8_0.png","Time8_1.png","Time8_2.png","Time8_3.png","Time8_4.png","Time8_5.png","Time8_6.png","Time8_7.png","Time8_8.png","Time8_9.png"];
timedot = 'TIME_DOT_8.png'
}
if ( colornumber == 9) { namecolor = "ORANGE SHADE"
array_min = ["Time9_0.png","Time9_1.png","Time9_2.png","Time9_3.png","Time9_4.png","Time9_5.png","Time9_6.png","Time9_7.png","Time9_8.png","Time9_9.png"];
array_hour = ["Time9_0.png","Time9_1.png","Time9_2.png","Time9_3.png","Time9_4.png","Time9_5.png","Time9_6.png","Time9_7.png","Time9_8.png","Time9_9.png"];
timedot = 'TIME_DOT_9.png'
}
if ( colornumber == 10) { namecolor = "YELLOW SHADE"
array_min = ["Time10_0.png","Time10_1.png","Time10_2.png","Time10_3.png","Time10_4.png","Time10_5.png","Time10_6.png","Time10_7.png","Time10_8.png","Time10_9.png"];
array_hour = ["Time10_0.png","Time10_1.png","Time10_2.png","Time10_3.png","Time10_4.png","Time10_5.png","Time10_6.png","Time10_7.png","Time10_8.png","Time10_9.png"];
timedot = 'TIME_DOT_10.png'
}
if ( colornumber == 11) { namecolor = "RED SHADE"
array_min = ["Time11_0.png","Time11_1.png","Time11_2.png","Time11_3.png","Time11_4.png","Time11_5.png","Time11_6.png","Time11_7.png","Time11_8.png","Time11_9.png"];
array_hour = ["Time11_0.png","Time11_1.png","Time11_2.png","Time11_3.png","Time11_4.png","Time11_5.png","Time11_6.png","Time11_7.png","Time11_8.png","Time11_9.png"];
timedot = 'TIME_DOT_11.png'
}
if ( colornumber == 12) { namecolor = "Multi Color"
array_min = ["Time12_0.png","Time12_1.png","Time12_2.png","Time12_3.png","Time12_4.png","Time12_5.png","Time12_6.png","Time12_7.png","Time12_8.png","Time12_9.png"];
array_hour = ["Time12_0.png","Time12_1.png","Time12_2.png","Time12_3.png","Time12_4.png","Time12_5.png","Time12_6.png","Time12_7.png","Time12_8.png","Time12_9.png"];
timedot = 'TIME_DOT_12.png'
}



if (colornumber <= totalcolors){
const deviceInfo = hmSetting.getDeviceInfo();

hmUI.showToast({text: namecolor});


            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 186,
              minute_startY: 375,
              minute_array: array_min,
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


}
                        
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_min_text_img = ''
        let normal_heart_rate_max_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_background_bg_img = ''
        let idle_system_clock_img = ''
        let idle_city_name_text = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_spo2_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_heart_rate_min_text_img = ''
        let idle_heart_rate_max_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_linear_scale = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let normal_cal_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 41,
              y: 391,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 167,
              y: 457,
              w: 170,
              h: 46,
              text_size: 33,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 47,
              y: 459,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 472,
              font_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Weather_Symbo2.png',
              unit_tc: 'Weather_Symbo2.png',
              unit_en: 'Weather_Symbo2.png',
              negative_image: 'Weather_Symbo1.png',
              invalid_image: 'Weather_Symbo1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 343,
              y: 462,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 110,
              font_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 155,
              font_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Batt_Unit.png',
              unit_tc: 'Batt_Unit.png',
              unit_en: 'Batt_Unit.png',
              invalid_image: 'Weather_Symbo1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 313,
              y: 112,
              font_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: '0_Empty.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 239,
              y: 46,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_min_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 368,
              y: 67,
              font_array: ["Pulse_S_0.png","Pulse_S_1.png","Pulse_S_2.png","Pulse_S_3.png","Pulse_S_4.png","Pulse_S_5.png","Pulse_S_6.png","Pulse_S_7.png","Pulse_S_8.png","Pulse_S_9.png"],
              padding: false,
              h_space: 0,
              negative_image: '0_Empty.png',
              align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HEART_MIN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_max_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291,
              y: 32,
              font_array: ["Pulse_S_0.png","Pulse_S_1.png","Pulse_S_2.png","Pulse_S_3.png","Pulse_S_4.png","Pulse_S_5.png","Pulse_S_6.png","Pulse_S_7.png","Pulse_S_8.png","Pulse_S_9.png"],
              padding: false,
              h_space: 0,
              negative_image: '0_Empty.png',
              align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HEART_MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 205,
              font_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Act_KM.png',
              unit_tc: 'Act_KM.png',
              unit_en: 'Act_KM.png',
              imperial_unit_sc: 'Act_Mi.png',
              imperial_unit_tc: 'Act_Mi.png',
              imperial_unit_en: 'Act_Mi.png',
              dot_image: 'Act_Dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_step_linear_scale.setAlpha(171);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 198,
              // start_y: 169,
              // color: 0xFF000000,
              // lenght: -123,
              // line_width: 17,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: True,
              // alpha: 171,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 157,
              font_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 192,
              day_startY: 206,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 342,
              year_startY: 226,
              year_sc_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              year_tc_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              year_en_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              year_zero: 0,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 83,
              y: 331,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 334,
              font_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Unit.png',
              unit_tc: 'Batt_Unit.png',
              unit_en: 'Batt_Unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 348,
              y: 289,
              image_array: ["Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png","Batt_06.png","Batt_07.png","Batt_08.png","Batt_09.png","Batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 285,
              month_startY: 226,
              month_sc_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              month_tc_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              month_en_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 6,
              month_startY: 276,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 352,
              am_y: 380,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 352,
              pm_y: 380,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 295,
              second_startY: 411,
              second_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 295,
              y: 385,
              src: 'SEC_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 186,
              minute_startY: 375,
              minute_array: ["Time_1_0.png","Time_1_1.png","Time_1_2.png","Time_1_3.png","Time_1_4.png","Time_1_5.png","Time_1_6.png","Time_1_7.png","Time_1_8.png","Time_1_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 385,
              src: 'TIME_DOT_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 70,
              hour_startY: 375,
              hour_array: ["Time_1_0.png","Time_1_1.png","Time_1_2.png","Time_1_3.png","Time_1_4.png","Time_1_5.png","Time_1_6.png","Time_1_7.png","Time_1_8.png","Time_1_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 41,
              y: 391,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 167,
              y: 457,
              w: 170,
              h: 46,
              text_size: 33,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 47,
              y: 459,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 472,
              font_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Weather_Symbo2.png',
              unit_tc: 'Weather_Symbo2.png',
              unit_en: 'Weather_Symbo2.png',
              negative_image: 'Weather_Symbo1.png',
              invalid_image: 'Weather_Symbo1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 343,
              y: 462,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 110,
              font_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 155,
              font_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Batt_Unit.png',
              unit_tc: 'Batt_Unit.png',
              unit_en: 'Batt_Unit.png',
              invalid_image: 'Weather_Symbo1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 313,
              y: 112,
              font_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: '0_Empty.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 239,
              y: 46,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_min_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 368,
              y: 67,
              font_array: ["Pulse_S_0.png","Pulse_S_1.png","Pulse_S_2.png","Pulse_S_3.png","Pulse_S_4.png","Pulse_S_5.png","Pulse_S_6.png","Pulse_S_7.png","Pulse_S_8.png","Pulse_S_9.png"],
              padding: false,
              h_space: 0,
              negative_image: '0_Empty.png',
              align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HEART_MIN,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_max_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291,
              y: 32,
              font_array: ["Pulse_S_0.png","Pulse_S_1.png","Pulse_S_2.png","Pulse_S_3.png","Pulse_S_4.png","Pulse_S_5.png","Pulse_S_6.png","Pulse_S_7.png","Pulse_S_8.png","Pulse_S_9.png"],
              padding: false,
              h_space: 0,
              negative_image: '0_Empty.png',
              align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HEART_MAX,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 205,
              font_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Act_KM.png',
              unit_tc: 'Act_KM.png',
              unit_en: 'Act_KM.png',
              imperial_unit_sc: 'Act_Mi.png',
              imperial_unit_tc: 'Act_Mi.png',
              imperial_unit_en: 'Act_Mi.png',
              dot_image: 'Act_Dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            idle_step_linear_scale.setAlpha(171);
            };

            // idle_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 198,
              // start_y: 169,
              // color: 0xFF000000,
              // lenght: -123,
              // line_width: 17,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: True,
              // alpha: 171,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 157,
              font_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 192,
              day_startY: 206,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 342,
              year_startY: 226,
              year_sc_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              year_tc_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              year_en_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              year_zero: 0,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 83,
              y: 331,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 334,
              font_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Unit.png',
              unit_tc: 'Batt_Unit.png',
              unit_en: 'Batt_Unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 348,
              y: 289,
              image_array: ["Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png","Batt_06.png","Batt_07.png","Batt_08.png","Batt_09.png","Batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 285,
              month_startY: 226,
              month_sc_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              month_tc_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              month_en_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 6,
              month_startY: 276,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 352,
              am_y: 380,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 352,
              pm_y: 380,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 186,
              minute_startY: 375,
              minute_array: ["Time_1_0.png","Time_1_1.png","Time_1_2.png","Time_1_3.png","Time_1_4.png","Time_1_5.png","Time_1_6.png","Time_1_7.png","Time_1_8.png","Time_1_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 385,
              src: 'TIME_DOT_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 70,
              hour_startY: 375,
              hour_array: ["Time_1_0.png","Time_1_1.png","Time_1_2.png","Time_1_3.png","Time_1_4.png","Time_1_5.png","Time_1_6.png","Time_1_7.png","Time_1_8.png","Time_1_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 6,
              y: 102,
              w: 161,
              h: 30,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 343,
              y: 277,
              w: 85,
              h: 75,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 322,
              y: 459,
              w: 95,
              h: 48,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 394,
              y: 206,
              w: 47,
              h: 53,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 293,
              y: 382,
              w: 45,
              h: 56,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 7,
              y: 376,
              w: 61,
              h: 44,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 35,
              y: 463,
              w: 130,
              h: 38,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 283,
              y: 148,
              w: 140,
              h: 39,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 288,
              y: 13,
              w: 141,
              h: 121,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 5,
              y: 149,
              w: 134,
              h: 38,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 209,
              y: 391,
              w: 48,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // Change color Minute
click_Color3()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 95,
              y: 391,
              w: 48,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // Change color Hour
click_Color2()

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 98,
              y: 234,
              w: 74,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // Change color H/M
click_Color()

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 168,
              y: 375,
              w: 22,
              h: 67,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Dot()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 3,
              y: 195,
              w: 164,
              h: 36,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 193,
              y: 191,
              w: 187,
              h: 62,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js




// HEART HISTORY GRAPH - Bip Max

// Heart Sensor
const heart = hmSensor.createSensor(hmSensor.id.HEART);

// Graph Settings
const HEART_X = 66;
const HEART_Y = 20;
const HEART_W = 100;
const HEART_H = 60;

const BAR_COUNT = 24;
const BAR_GAP = 2;

const BAR_WIDTH = Math.floor(
    (HEART_W - (BAR_COUNT - 1) * BAR_GAP) / BAR_COUNT
);

let heartBars = [];
let hourlyMax = new Array(BAR_COUNT).fill(0);
let heartBarsCreated = false;

// Heart Color
function getHeartColor(bpm) {
    if (bpm < 60) return 0xFF2196FF;
    if (bpm < 80) return 0xFF00BCD4;
    if (bpm < 100) return 0xFF4CAF50;
    if (bpm < 120) return 0xFFFFEB3B;
    if (bpm < 140) return 0xFFFF9800;
    return 0xFFF44336;
}

// Create Bars
function createHeartBars() {

    if (heartBarsCreated) return;

    for (let i = 0; i < BAR_COUNT; i++) {

        heartBars[i] = hmUI.createWidget(hmUI.widget.FILL_RECT, {
            x: HEART_X + i * (BAR_WIDTH + BAR_GAP),
            y: HEART_Y + HEART_H,
            w: BAR_WIDTH,
            h: 0,
            color: 0xFF555555,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
    }

    heartBarsCreated = true;
}

// Draw Heart History
function drawHeartHistory() {

    const data = heart.today;

    if (!data || !data.length) return;

    // Collect valid heart-rate values
    let validData = [];

    for (let i = 0; i < data.length; i++) {

        let value = data[i];

        if (value > 30 && value < 250) {
            validData.push(value);
        }
    }

    if (validData.length === 0) return;

    // Distribute available data into 30 positions
    for (let i = 0; i < BAR_COUNT; i++) {

        let bpm = 0;

        if (validData.length === 1) {

            bpm = validData[0];

        } else {

            let pos = i * (validData.length - 1) / (BAR_COUNT - 1);

            let left = Math.floor(pos);
            let right = Math.min(validData.length - 1, left + 1);

            let fraction = pos - left;

            // Linear interpolation
            bpm = Math.round(
                validData[left] +
                (validData[right] - validData[left]) * fraction
            );
        }

        hourlyMax[i] = bpm;
    }

    // Find Min / Max BPM
    let minBPM = 250;
    let maxBPM = 0;

    for (let i = 0; i < BAR_COUNT; i++) {

        let bpm = hourlyMax[i];

        if (bpm > 0) {
            if (bpm < minBPM) minBPM = bpm;
            if (bpm > maxBPM) maxBPM = bpm;
        }
    }

    const span = Math.max(1, maxBPM - minBPM);

    // Draw 30 Bars
    for (let i = 0; i < BAR_COUNT; i++) {

        let bpm = hourlyMax[i];

        let barHeight = Math.round(
            6 + ((bpm - minBPM) / span) * (HEART_H - 6)
        );

        barHeight = Math.max(6, Math.min(HEART_H, barHeight));

        let barColor = getHeartColor(bpm);

        heartBars[i].setProperty(hmUI.prop.MORE, {
            x: HEART_X + i * (BAR_WIDTH + BAR_GAP),
            y: HEART_Y + HEART_H - barHeight,
            w: BAR_WIDTH,
            h: barHeight,
            color: barColor
        });
    }
}

// Initial creation and drawing
    createHeartBars();
    drawHeartHistory();

            // end user_script_end.js

            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text HEART max/min');
              let heartArr = hmSensor.createSensor(hmSensor.id.HEART).today;
              let heartArrValid = heartArr ? heartArr.filter(v => v > 0 && v < 255) : [];
              let max_heart = heartArrValid.length > 0 ? Math.max(...heartArrValid) : undefined;
              let min_heart = heartArrValid.length > 0 ? Math.min(...heartArrValid) : undefined;

              if (screenType != hmSetting.screen_type.AOD) {
                let normal_heart_rate_min_text_img_value = '-';
                if (min_heart != undefined) normal_heart_rate_min_text_img_value = String(min_heart);
                normal_heart_rate_min_text_img.setProperty(hmUI.prop.TEXT, normal_heart_rate_min_text_img_value);
              };

              if (screenType != hmSetting.screen_type.AOD) {
                let normal_heart_rate_max_text_img_value = '-';
                if (max_heart != undefined) normal_heart_rate_max_text_img_value = String(max_heart);
                normal_heart_rate_max_text_img.setProperty(hmUI.prop.TEXT, normal_heart_rate_max_text_img_value);
              };

              if (screenType == hmSetting.screen_type.AOD) {
                let idle_heart_rate_min_text_img_value = '-';
                if (min_heart != undefined) idle_heart_rate_min_text_img_value = String(min_heart);
                idle_heart_rate_min_text_img.setProperty(hmUI.prop.TEXT, idle_heart_rate_min_text_img_value);
              };

              if (screenType == hmSetting.screen_type.AOD) {
                let idle_heart_rate_max_text_img_value = '-';
                if (max_heart != undefined) idle_heart_rate_max_text_img_value = String(max_heart);
                idle_heart_rate_max_text_img.setProperty(hmUI.prop.TEXT, idle_heart_rate_max_text_img_value);
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 198;
                  let start_y_normal_step = 46;
                  let lenght_ls_normal_step = 123;
                  let line_width_ls_normal_step = 17;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = line_width_ls_normal_step;
                  let line_width_ls_normal_step_draw = lenght_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    line_width_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_y_normal_step_draw = start_y_normal_step_draw - line_width_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

              console.log('Weather city name');
              let idle_cityNameStr = weatherData.cityName;
              idle_city_name_text.setProperty(hmUI.prop.TEXT, idle_cityNameStr);

                console.log('update scales STEP');
                let progress_ls_idle_step = 1 - progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_linear_scale
                  // initial parameters
                  let start_x_idle_step = 198;
                  let start_y_idle_step = 46;
                  let lenght_ls_idle_step = 123;
                  let line_width_ls_idle_step = 17;
                  let color_ls_idle_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_idle_step_draw = start_x_idle_step;
                  let start_y_idle_step_draw = start_y_idle_step;
                  lenght_ls_idle_step = lenght_ls_idle_step * progress_ls_idle_step;
                  let lenght_ls_idle_step_draw = line_width_ls_idle_step;
                  let line_width_ls_idle_step_draw = lenght_ls_idle_step;
                  if (lenght_ls_idle_step < 0){
                    line_width_ls_idle_step_draw = -lenght_ls_idle_step;
                    start_y_idle_step_draw = start_y_idle_step_draw - line_width_ls_idle_step_draw;
                  };
                  
                  idle_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step_draw,
                    y: start_y_idle_step_draw,
                    w: lenght_ls_idle_step_draw,
                    h: line_width_ls_idle_step_draw,
                    color: color_ls_idle_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();

                console.log('resume_call.js');
                // start resume_call.js

drawHeartHistory();
                // end resume_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}