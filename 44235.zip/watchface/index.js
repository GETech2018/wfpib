﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// for vibration feedback
const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
let timer_StopVibrate = null;

function makeVibrate(level = 1) {
  let stopDelay = 50;
  stopVibrate();
  vibrate.stop();
  
  // after oct 23 update im gonna use increasing levels, where 1 is the lowest (for buttons),
  // 2 is mid level (for open settings) and 3 is the highest (for closing settings).
  const levelToScene = {
    1: 26,
    2: 27,
    3: 29
  };

  let scene = levelToScene[level] || 25;
  vibrate.scene = scene;
  if (scene > 25) stopDelay = 1300;
  vibrate.start();
  timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibrate, {});
}

function stopVibrate() {
  vibrate.stop();
  if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
}

const colorsSet = [
    "blue", "yellow", "green", "grey"
];
const progressBarColors = [
  0xFF1F2E33, 0xFF32302A, 0xFF26332D, 0xFF333333
]
let colorIndex = 0;
let currColorClockSRC;

let currWFColor = colorsSet[colorIndex]
let currProgressbarColor = progressBarColors[colorIndex]
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_current_text_font = ''
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['LUN', 'MAR', 'MIÉ', 'JUE', 'VIE', 'SÁB', 'DOM'];
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_font = ''
        let normal_time_second_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: ProductSans-Medium.ttf; FontSize: 22
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 300,
              h: 33,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/ProductSans-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: ProductSans-Medium.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 327,
              h: 36,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/ProductSans-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: ProductSans-Medium.ttf; FontSize: 24; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 28,
              h: 28,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/ProductSans-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: ProductSans-Medium.ttf; FontSize: 20
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 273,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/ProductSans-Medium.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG_blue.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 133,
              // center_y: 225,
              // start_angle: 219,
              // end_angle: 165,
              // radius: 153,
              // line_width: 10,
              // line_cap: Rounded,
              // color: currProgressbarColor,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 133,
              center_y: 225,
              start_angle: 219,
              end_angle: 165,
              radius: 148,
              line_width: 10,
              corner_flag: 0,
              color: currProgressbarColor,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 91,
              y: 385,
              w: 80,
              h: 30,
              text_size: 22,
              char_space: 0,
              font: 'fonts/ProductSans-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 276,
              y: 238,
              w: 80,
              h: 50,
              text_size: 24,
              char_space: 0,
              font: 'fonts/ProductSans-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 276,
              y: 212,
              w: 80,
              h: 50,
              text_size: 24,
              char_space: 0,
              font: 'fonts/ProductSans-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: LUN, MAR, MIÉ, JUE, VIE, SÁB, DOM,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 245,
              y: 62,
              image_array: ["WEATHERICON_1.png","WEATHERICON_2.png","WEATHERICON_3.png","WEATHERICON_4.png","WEATHERICON_5.png","WEATHERICON_6.png","WEATHERICON_7.png","WEATHERICON_8.png","WEATHERICON_9.png","WEATHERICON_10.png","WEATHERICON_11.png","WEATHERICON_12.png","WEATHERICON_13.png","WEATHERICON_14.png","WEATHERICON_15.png","WEATHERICON_16.png","WEATHERICON_17.png","WEATHERICON_18.png","WEATHERICON_19.png","WEATHERICON_20.png","WEATHERICON_21.png","WEATHERICON_22.png","WEATHERICON_23.png","WEATHERICON_24.png","WEATHERICON_25.png","WEATHERICON_26.png","WEATHERICON_27.png","WEATHERICON_28.png","WEATHERICON_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 220,
              y: 100,
              w: 80,
              h: 50,
              text_size: 24,
              char_space: 0,
              font: 'fonts/ProductSans-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 133,
              // center_y: 225,
              // start_angle: -39,
              // end_angle: 14,
              // radius: 153,
              // line_width: 10,
              // line_cap: Rounded,
              // color: currProgressbarColor,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 133,
              center_y: 225,
              start_angle: -39,
              end_angle: 14,
              radius: 148,
              line_width: 10,
              corner_flag: 0,
              color: currProgressbarColor,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 91,
              y: 39,
              w: 80,
              h: 30,
              text_size: 22,
              char_space: 0,
              font: 'fonts/ProductSans-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 0,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/ProductSans-Medium.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 62,
              hour_startY: 138,
              hour_array: ["CLOCK_AOD_0.png","CLOCK_AOD_1.png","CLOCK_AOD_2.png","CLOCK_AOD_3.png","CLOCK_AOD_4.png","CLOCK_AOD_5.png","CLOCK_AOD_6.png","CLOCK_AOD_7.png","CLOCK_AOD_8.png","CLOCK_AOD_9.png"],
              hour_zero: 1,
              hour_space: -36,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 62,
              minute_startY: 212,
              minute_array: ["CLOCK_AOD_0.png","CLOCK_AOD_1.png","CLOCK_AOD_2.png","CLOCK_AOD_3.png","CLOCK_AOD_4.png","CLOCK_AOD_5.png","CLOCK_AOD_6.png","CLOCK_AOD_7.png","CLOCK_AOD_8.png","CLOCK_AOD_9.png"],
              minute_zero: 1,
              minute_space: -36,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

currColorClockSRC = "clock/" + currWFColor;

// normal digits
let clockDigitHrHigh = hmUI.createWidget(hmUI.widget.IMG, {
    src: currColorClockSRC+"/hr_high/CLOCK_0.png",
    x: 62,
    y: 138,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockDigitHrLow = hmUI.createWidget(hmUI.widget.IMG, {
    src: currColorClockSRC+"/hr_low/CLOCK_0.png",
    x: 116,
    y: 138,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockDigitMinHigh = hmUI.createWidget(hmUI.widget.IMG, {
    src: currColorClockSRC+"/min_high/CLOCK_0.png",
    x: 62,
    y: 212,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockDigitMinLow = hmUI.createWidget(hmUI.widget.IMG, {
    src: currColorClockSRC+"/min_low/CLOCK_0.png",
    x: 116,
    y: 212,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

function updateMins(){
    let currHourFormat = hmSetting.getTimeFormat(); // 0 = 12h, 1 = 24h
    let clockHr = timeSensor.hour;
    let clockMin = timeSensor.minute;
    currColorClockSRC = "clock/" + currWFColor;

    //convert clock depending on format
    if (currHourFormat == 0){
        if (clockHr == 0){
            clockHr = 12;
        }else if (clockHr > 12){
            clockHr -= 12;
        }
    }

    //add zeros if its less than 10
    let clockHrTXT = clockHr.toString().padStart(2, "0");
    let clockMinsTXT = clockMin.toString().padStart(2, "0");

    //extract digits
    let clockHrHighSRC = currColorClockSRC + "/hr_high/CLOCK_" + clockHrTXT[0] + ".png";
    let clockHrLowSRC = currColorClockSRC + "/hr_low/CLOCK_" + clockHrTXT[1] + ".png";
    let clockMinsHighSRC = currColorClockSRC + "/min_high/CLOCK_" + clockMinsTXT[0] + ".png";
    let clockMinsLowSRC = currColorClockSRC + "/min_low/CLOCK_" + clockMinsTXT[1] + ".png";

    //update digits
    clockDigitHrHigh.setProperty(hmUI.prop.SRC, clockHrHighSRC);
    clockDigitHrLow.setProperty(hmUI.prop.SRC, clockHrLowSRC);
    clockDigitMinHigh.setProperty(hmUI.prop.SRC, clockMinsHighSRC);
    clockDigitMinLow.setProperty(hmUI.prop.SRC, clockMinsLowSRC);
}
updateMins();
            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 30,
              y: 40,
              w: 150,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 30,
              y: 340,
              w: 150,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 215,
              y: 50,
              w: 90,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 265,
              y: 180,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 310,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'MusicCommonScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 310,
              y: 0,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                showSettings()
makeVibrate(2)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 145,
              w: 100,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 225,
              w: 100,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let settingsBG = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    w: 390,
    h: 450,
    src: "settings/SETTINGS_BG.png",
});

let prevColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 23,
    y: 132,
    w: 90,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_SELECTOR_PREV_PRESSED.png',
    normal_src: 'settings/BTN_SELECTOR_PREV_NORMAL.png',
    click_func: (button_widget) => {
    prevColor()
    makeVibrate(1)
    }, // end func
}); // end button

let nextColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 153,
    y: 132,
    w: 90,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_SELECTOR_NEXT_PRESSED.png',
    normal_src: 'settings/BTN_SELECTOR_NEXT_NORMAL.png',
    click_func: (button_widget) => {
    nextColor()
    makeVibrate(1)
    }, // end func
}); // end button

let Confirmbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 73,
    y: 229,
    w: 120,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_CONFIRM_PRESSED.png',
    normal_src: 'settings/BTN_CONFIRM_NORMAL.png',
    click_func: (button_widget) => {
    hideSettings()
    makeVibrate(3)
    }, // end func
}); // end button

// functions to change colors
function prevColor(){
    colorIndex = (colorIndex - 1 + colorsSet.length) % colorsSet.length;
    updateWatchface();
}

function nextColor(){
    colorIndex = (colorIndex + 1) % colorsSet.length;
    updateWatchface();
}

function updateWatchface(){
    currWFColor = colorsSet[colorIndex]
    currProgressbarColor = progressBarColors[colorIndex]

    let bgWFSRC = "BG_" + currWFColor + ".png";
    normal_background_bg_img.setProperty(hmUI.prop.SRC, bgWFSRC);

    // colors for progressbars
    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
        center_x: 133,
        center_y: 225,
        start_angle: -39,
        end_angle: 14,
        radius: 148,
        line_width: 10,
        corner_flag: 0,
        color: currProgressbarColor,
        show_level: hmUI.show_level.ONLY_NORMAL,
    })

    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
        center_x: 133,
        center_y: 225,
        start_angle: 219,
        end_angle: 165,
        radius: 148,
        line_width: 10,
        corner_flag: 0,
        color: currProgressbarColor,
        show_level: hmUI.show_level.ONLY_NORMAL,
    })

    //update clock with new color
    updateMins();
}

function hideSettings(){
    // buttons over clock
    Button_7.setProperty(hmUI.prop.VISIBLE, true);
    Button_8.setProperty(hmUI.prop.VISIBLE, true);

    // settings layout
    settingsBG.setProperty(hmUI.prop.VISIBLE, false);
    prevColorbtn.setProperty(hmUI.prop.VISIBLE, false);
    nextColorbtn.setProperty(hmUI.prop.VISIBLE, false);
    Confirmbtn.setProperty(hmUI.prop.VISIBLE, false);
}
hideSettings();

function showSettings(){   
    // buttons over clock
    Button_7.setProperty(hmUI.prop.VISIBLE, false);
    Button_8.setProperty(hmUI.prop.VISIBLE, false);

    // settings layout
    settingsBG.setProperty(hmUI.prop.VISIBLE, true);
    prevColorbtn.setProperty(hmUI.prop.VISIBLE, true);
    nextColorbtn.setProperty(hmUI.prop.VISIBLE, true);
    Confirmbtn.setProperty(hmUI.prop.VISIBLE, true);
}
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 133,
                      center_y: 225,
                      start_angle: 219,
                      end_angle: 165,
                      radius: 148,
                      line_width: 10,
                      corner_flag: 0,
                      color: currProgressbarColor,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 133,
                      center_y: 225,
                      start_angle: -39,
                      end_angle: 14,
                      radius: 148,
                      line_width: 10,
                      corner_flag: 0,
                      color: currProgressbarColor,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                      updateMins();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

updateMins();
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

                console.log('pause_call.js');
                // start pause_call.js

hideSettings();
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}