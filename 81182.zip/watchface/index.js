﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_digital_clock_img_time = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 320,
              h: 380,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'batteryy.png',
              center_x: 259,
              center_y: 48,
              x: 50,
              y: 55,
              start_angle: -136,
              end_angle: 137,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 7,
              hour_array: ["CLOCK_0.png","CLOCK_1.png","CLOCK_2.png","CLOCK_3.png","CLOCK_4.png","CLOCK_5.png","CLOCK_6.png","CLOCK_7.png","CLOCK_8.png","CLOCK_9.png"],
              hour_zero: 1,
              hour_space: -8,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 126,
              minute_startY: 7,
              minute_array: ["CLOCK_0.png","CLOCK_1.png","CLOCK_2.png","CLOCK_3.png","CLOCK_4.png","CLOCK_5.png","CLOCK_6.png","CLOCK_7.png","CLOCK_8.png","CLOCK_9.png"],
              minute_zero: 1,
              minute_space: -8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'BATTERYLEVEL.png',
              center_x: 69,
              center_y: 159,
              x: 48,
              y: 63,
              start_angle: -367,
              end_angle: 225,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 154,
              font_array: ["NUMBERS_SMALL_0.png","NUMBERS_SMALL_1.png","NUMBERS_SMALL_2.png","NUMBERS_SMALL_3.png","NUMBERS_SMALL_4.png","NUMBERS_SMALL_5.png","NUMBERS_SMALL_6.png","NUMBERS_SMALL_7.png","NUMBERS_SMALL_8.png","NUMBERS_SMALL_9.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 141,
              y: 181,
              font_array: ["NUMBERS_SMALL_0.png","NUMBERS_SMALL_1.png","NUMBERS_SMALL_2.png","NUMBERS_SMALL_3.png","NUMBERS_SMALL_4.png","NUMBERS_SMALL_5.png","NUMBERS_SMALL_6.png","NUMBERS_SMALL_7.png","NUMBERS_SMALL_8.png","NUMBERS_SMALL_9.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 154,
              font_array: ["NUMBERS_SMALL_0.png","NUMBERS_SMALL_1.png","NUMBERS_SMALL_2.png","NUMBERS_SMALL_3.png","NUMBERS_SMALL_4.png","NUMBERS_SMALL_5.png","NUMBERS_SMALL_6.png","NUMBERS_SMALL_7.png","NUMBERS_SMALL_8.png","NUMBERS_SMALL_9.png"],
              padding: false,
              h_space: -7,
              unit_sc: 'ICON_KM.png',
              unit_tc: 'ICON_KM.png',
              unit_en: 'ICON_KM.png',
              dot_image: 'NUMBERS_SMALL_DOT.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 46,
              y: 232,
              week_en: ["DAYS_ES_1.png","DAYS_ES_2.png","DAYS_ES_3.png","DAYS_ES_4.png","DAYS_ES_5.png","DAYS_ES_6.png","DAYS_ES_7.png"],
              week_tc: ["DAYS_ES_1.png","DAYS_ES_2.png","DAYS_ES_3.png","DAYS_ES_4.png","DAYS_ES_5.png","DAYS_ES_6.png","DAYS_ES_7.png"],
              week_sc: ["DAYS_ES_1.png","DAYS_ES_2.png","DAYS_ES_3.png","DAYS_ES_4.png","DAYS_ES_5.png","DAYS_ES_6.png","DAYS_ES_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 237,
              day_startY: 230,
              day_sc_array: ["NUMBERS_BIG_0.png","NUMBERS_BIG_1.png","NUMBERS_BIG_2.png","NUMBERS_BIG_3.png","NUMBERS_BIG_4.png","NUMBERS_BIG_5.png","NUMBERS_BIG_6.png","NUMBERS_BIG_7.png","NUMBERS_BIG_8.png","NUMBERS_BIG_9.png"],
              day_tc_array: ["NUMBERS_BIG_0.png","NUMBERS_BIG_1.png","NUMBERS_BIG_2.png","NUMBERS_BIG_3.png","NUMBERS_BIG_4.png","NUMBERS_BIG_5.png","NUMBERS_BIG_6.png","NUMBERS_BIG_7.png","NUMBERS_BIG_8.png","NUMBERS_BIG_9.png"],
              day_en_array: ["NUMBERS_BIG_0.png","NUMBERS_BIG_1.png","NUMBERS_BIG_2.png","NUMBERS_BIG_3.png","NUMBERS_BIG_4.png","NUMBERS_BIG_5.png","NUMBERS_BIG_6.png","NUMBERS_BIG_7.png","NUMBERS_BIG_8.png","NUMBERS_BIG_9.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 95,
              y: 294,
              image_array: ["WEATHERICON_1.png","WEATHERICON_2.png","WEATHERICON_3.png","WEATHERICON_4.png","WEATHERICON_5.png","WEATHERICON_6.png","WEATHERICON_7.png","WEATHERICON_8.png","WEATHERICON_9.png","WEATHERICON_10.png","WEATHERICON_11.png","WEATHERICON_12.png","WEATHERICON_13.png","WEATHERICON_14.png","WEATHERICON_15.png","WEATHERICON_16.png","WEATHERICON_17.png","WEATHERICON_18.png","WEATHERICON_19.png","WEATHERICON_20.png","WEATHERICON_21.png","WEATHERICON_22.png","WEATHERICON_23.png","WEATHERICON_24.png","WEATHERICON_25.png","WEATHERICON_26.png","WEATHERICON_27.png","WEATHERICON_28.png","WEATHERICON_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 170,
              y: 286,
              font_array: ["NUMBERS_MINI_0.png","NUMBERS_MINI_1.png","NUMBERS_MINI_2.png","NUMBERS_MINI_3.png","NUMBERS_MINI_4.png","NUMBERS_MINI_5.png","NUMBERS_MINI_6.png","NUMBERS_MINI_7.png","NUMBERS_MINI_8.png","NUMBERS_MINI_9.png"],
              padding: false,
              h_space: -5,
              negative_image: 'ICON_NEGATIVE_MINI.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 170,
              y: 313,
              font_array: ["NUMBERS_MINI_0.png","NUMBERS_MINI_1.png","NUMBERS_MINI_2.png","NUMBERS_MINI_3.png","NUMBERS_MINI_4.png","NUMBERS_MINI_5.png","NUMBERS_MINI_6.png","NUMBERS_MINI_7.png","NUMBERS_MINI_8.png","NUMBERS_MINI_9.png"],
              padding: false,
              h_space: -5,
              negative_image: 'ICON_NEGATIVE_MINI.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 294,
              font_array: ["NUMBERS_MEDIUM_0.png","NUMBERS_MEDIUM_1.png","NUMBERS_MEDIUM_2.png","NUMBERS_MEDIUM_3.png","NUMBERS_MEDIUM_4.png","NUMBERS_MEDIUM_5.png","NUMBERS_MEDIUM_6.png","NUMBERS_MEDIUM_7.png","NUMBERS_MEDIUM_8.png","NUMBERS_MEDIUM_9.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'ICON_TEMP.png',
              unit_tc: 'ICON_TEMP.png',
              unit_en: 'ICON_TEMP.png',
              negative_image: 'ICON_NEGATIVE.png',
              invalid_image: 'NUMBERS_MEDIUM_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 34,
              y: 21,
              w: 82,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 130,
              y: 21,
              w: 82,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 217,
              y: 21,
              w: 82,
              h: 103,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 138,
              y: 146,
              w: 77,
              h: 34,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 138,
              y: 186,
              w: 77,
              h: 32,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportRecordListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 43,
              y: 231,
              w: 246,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 90,
              y: 290,
              w: 197,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 26,
              y: 292,
              w: 54,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 21,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}