﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//////Vibration feedback for buttons
const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
let timer_StopVibrate = null;

function makeVibrate(level = 1) {
  stopVibrate();

  //The values are used as follows: 1 for buttons, 2 for open settings menu, 3 for close settings menu
  const levelToScene = {
    1: 26,
    2: 27,
    3: 29
  };

  let scene = levelToScene[level] || 25;
  let stopDelay = scene > 25 ? 1300 : 50;

  vibrate.scene = scene;
  vibrate.start();

  timer_StopVibrate = timer.createTimer(stopDelay, 0, stopVibrate, {});
}

function stopVibrate() {
  vibrate.stop();
  if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
  timer_StopVibrate = null;
}

//////Watchface Language Sets (Uppercase)
const watchfaceLangs = {
  EN:{
    WEEKDAYS_SHORT: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
  },

  ES:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MIÉ", "JUE", "VIE", "SÁB", "DOM"],
  },

  IT:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MER", "GIO", "VEN", "SAB", "DOM"],
  },

  PT:{
    WEEKDAYS_SHORT: ["SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM"],
  },

  FR:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MER", "JEU", "VEN", "SAM", "DIM"],
  },

  DE:{
    WEEKDAYS_SHORT: ["MON", "DIE", "MIT", "DON", "FRE", "SAM", "SON"],
  },
  
  RU:{
    WEEKDAYS_SHORT: ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"],
  },
};
let currWatchfaceLang;
let currLangCode;

const colorSet_hrs = [
    0xFF4D4DFF, // Blue
    0xFF00A3A3, // Cyan
    0xFF00A854, // Turquoise
    0xFF66B300, // Lime
    0xFF009900, // Green
    0xFFB39900, // Yellow
    0xFFE66B00, // Orange
    0xFFFF3333, // Red
    0xFFE600E6, // Pink
    0xFF9933FF, // Violet
    0xFFFFFFFF, // White
    0xFF000000, // Black
];

const colorSet_mins_black = [
    0xFF33A5FF, // Blue
    0xFF33DEFF, // Cyan
    0xFF33FFC1, // Turquoise
    0xFFA1FF33, // Lime
    0xFFD6FF33, // Green
    0xFFFFE433, // Yellow
    0xFFFF9C33, // Orange
    0xFFFF3333, // Red
    0xFFFF3385, // Pink
    0xFF7B33FF, // Violet
    0xFF999999, // Gray
    0xFFFFFFFF, // White
];

const colorSet_secs_black = [
    0xFF0066CC, // Blue
    0xFF00CCCC, // Cyan
    0xFF00CC7A, // Turquoise
    0xFF66CC00, // Lime
    0xFF99CC00, // Green
    0xFFCCCC00, // Yellow
    0xFFCC6600, // Orange
    0xFFCC0000, // Red
    0xFFCC0066, // Pink
    0xFF7300CC, // Violet
    0xFF999999, // Gray
    0xFFFFFFFF, // White
];

const colorSet_mins_white = [
    0xFF0267B7, // Blue
    0xFF0299B7, // Cyan
    0xFF02B780, // Turquoise
    0xFF63B702, // Lime
    0xFF92B702, // Green
    0xFFB79F02, // Yellow
    0xFFB76002, // Orange
    0xFFB70202, // Red
    0xFFB7024B, // Pink
    0xFF4202B7, // Violet
    0xFF5D5D5D, // Gray
    0xFFFFFFFF, // White
];

const colorSet_secs_white = [
    0xFF1C9BFF, // Blue
    0xFF1CDAFF, // Cyan
    0xFF1CFFBA, // Turquoise
    0xFF96FF1C, // Lime
    0xFFD1FF1C, // Green
    0xFFFFE11C, // Yellow
    0xFFFF911C, // Orange
    0xFFFF1C1C, // Red
    0xFFFF1C77, // Pink
    0xFF6D1CFF, // Violet
    0xFF8E8E8E, // Gray
    0xFFFFFFFF, // White
];

let isWhiteThemeEnabled = false;
let colorSet_Mins_active = isWhiteThemeEnabled ? colorSet_mins_white : colorSet_mins_black;
let colorSet_Secs_active = isWhiteThemeEnabled ? colorSet_secs_white : colorSet_secs_black;

let colorIndex_Hrs = 10;
let colorIndex_Mins = 4;
let colorIndex_Secs = 10;

let currColor_Hrs = colorSet_hrs[colorIndex_Hrs];
let currColor_Mins = colorSet_Mins_active[colorIndex_Mins];
let currColor_Secs = colorSet_Secs_active[colorIndex_Secs];
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_digital_clock_img_time = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SF-Compact-Rounded-Bold.ttf; FontSize: 28; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 33,
              h: 33,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

//////Function to detect current language from system
function detectLanguage() {
    const zeppAvailableLangs = [
        "ZH", // 0  Chinese (Simplified)
        "ZH", // 1  Chinese (Traditional)
        "EN", // 2  English
        "ES", // 3  Spanish
        "RU", // 4  Russian
        "KO", // 5  Korean
        "FR", // 6  French
        "DE", // 7  German
        "ID", // 8  Indonesian
        "PL", // 9  Polish
        "IT", // 10 Italian
        "JA", // 11 Japanese
        "TH", // 12 Thai
        "AR", // 13 Arabic
        "VI", // 14 Vietnamese
        "PT", // 15 Portuguese (Portugal)
        "NL", // 16 Dutch
        "TR", // 17 Turkish
        "UK", // 18 Ukrainian
        "HE", // 19 Hebrew
        "PT", // 20 Portuguese (Brazil)
        "RO", // 21 Romanian
        "CS", // 22 Czech
        "EL", // 23 Greek
        "SR", // 24 Serbian
        "CA", // 25 Catalan
        "FI", // 26 Finnish
        "NO", // 27 Norwegian
        "DA", // 28 Danish
        "SV", // 29 Swedish
        "HU", // 30 Hungarian
        "MS", // 31 Malay
        "SK", // 32 Slovak
        "HI"  // 33 Hindi
    ];
    let langCode = zeppAvailableLangs[hmSetting.getLanguage()]; //Get current language on watch

    currLangCode = watchfaceLangs[langCode] ? langCode : "EN";
    currWatchfaceLang = watchfaceLangs[currLangCode];
}
detectLanguage();

let bgColor_clockHrs = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 0,
    y: 0,
    w: 200,
    h: 450,
    color: currColor_Hrs,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let bgColor_clockMins = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 200,
    y: 175,
    w: 190,
    h: 275,
    color: currColor_Mins,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let bgColor_clockSecs = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 200,
    y: 0,
    w: 190,
    h: 174,
    color: currColor_Secs,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG_PREVIEW.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 21,
              hour_array: ["HRDIGITS_BLACK_0.png","HRDIGITS_BLACK_1.png","HRDIGITS_BLACK_2.png","HRDIGITS_BLACK_3.png","HRDIGITS_BLACK_4.png","HRDIGITS_BLACK_5.png","HRDIGITS_BLACK_6.png","HRDIGITS_BLACK_7.png","HRDIGITS_BLACK_8.png","HRDIGITS_BLACK_9.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 206,
              minute_startY: 176,
              minute_array: ["MINDIGITS_BLACK_0.png","MINDIGITS_BLACK_1.png","MINDIGITS_BLACK_2.png","MINDIGITS_BLACK_3.png","MINDIGITS_BLACK_4.png","MINDIGITS_BLACK_5.png","MINDIGITS_BLACK_6.png","MINDIGITS_BLACK_7.png","MINDIGITS_BLACK_8.png","MINDIGITS_BLACK_9.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 206,
              second_startY: 21,
              second_array: ["SECDIGITS_BLACK_0.png","SECDIGITS_BLACK_1.png","SECDIGITS_BLACK_2.png","SECDIGITS_BLACK_3.png","SECDIGITS_BLACK_4.png","SECDIGITS_BLACK_5.png","SECDIGITS_BLACK_6.png","SECDIGITS_BLACK_7.png","SECDIGITS_BLACK_8.png","SECDIGITS_BLACK_9.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 415,
              w: 150,
              h: 50,
              text_size: 28,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 21,
              hour_array: ["HRDIGITS_BLACK_0.png","HRDIGITS_BLACK_1.png","HRDIGITS_BLACK_2.png","HRDIGITS_BLACK_3.png","HRDIGITS_BLACK_4.png","HRDIGITS_BLACK_5.png","HRDIGITS_BLACK_6.png","HRDIGITS_BLACK_7.png","HRDIGITS_BLACK_8.png","HRDIGITS_BLACK_9.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 206,
              minute_startY: 176,
              minute_array: ["MINDIGITS_BLACK_0.png","MINDIGITS_BLACK_1.png","MINDIGITS_BLACK_2.png","MINDIGITS_BLACK_3.png","MINDIGITS_BLACK_4.png","MINDIGITS_BLACK_5.png","MINDIGITS_BLACK_6.png","MINDIGITS_BLACK_7.png","MINDIGITS_BLACK_8.png","MINDIGITS_BLACK_9.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 206,
              second_startY: 21,
              second_array: ["SECDIGITS_BLACK_0.png","SECDIGITS_BLACK_1.png","SECDIGITS_BLACK_2.png","SECDIGITS_BLACK_3.png","SECDIGITS_BLACK_4.png","SECDIGITS_BLACK_5.png","SECDIGITS_BLACK_6.png","SECDIGITS_BLACK_7.png","SECDIGITS_BLACK_8.png","SECDIGITS_BLACK_9.png"],
              second_zero: 1,
              second_space: 9,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 415,
              w: 150,
              h: 50,
              text_size: 28,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

let digitalClock_white = hmUI.createWidget(hmUI.widget.IMG_TIME, {
    hour_startX: 27,
    hour_startY: 21,
    hour_array: ["HRDIGITS_WHITE_0.png","HRDIGITS_WHITE_1.png","HRDIGITS_WHITE_2.png","HRDIGITS_WHITE_3.png","HRDIGITS_WHITE_4.png","HRDIGITS_WHITE_5.png","HRDIGITS_WHITE_6.png","HRDIGITS_WHITE_7.png","HRDIGITS_WHITE_8.png","HRDIGITS_WHITE_9.png"],
    hour_zero: 1,
    hour_space: 10,
    hour_angle: 0,
    hour_align: hmUI.align.LEFT,

    minute_startX: 206,
    minute_startY: 176,
    minute_array: ["MINDIGITS_WHITE_0.png","MINDIGITS_WHITE_1.png","MINDIGITS_WHITE_2.png","MINDIGITS_WHITE_3.png","MINDIGITS_WHITE_4.png","MINDIGITS_WHITE_5.png","MINDIGITS_WHITE_6.png","MINDIGITS_WHITE_7.png","MINDIGITS_WHITE_8.png","MINDIGITS_WHITE_9.png"],
    minute_zero: 1,
    minute_space: 8,
    minute_angle: 0,
    minute_follow: 0,
    minute_align: hmUI.align.LEFT,

    second_startX: 206,
    second_startY: 21,
    second_array: ["SECDIGITS_WHITE_0.png","SECDIGITS_WHITE_1.png","SECDIGITS_WHITE_2.png","SECDIGITS_WHITE_3.png","SECDIGITS_WHITE_4.png","SECDIGITS_WHITE_5.png","SECDIGITS_WHITE_6.png","SECDIGITS_WHITE_7.png","SECDIGITS_WHITE_8.png","SECDIGITS_WHITE_9.png"],
    second_zero: 1,
    second_space: 4,
    second_angle: 0,
    second_follow: 0,
    second_align: hmUI.align.LEFT,

    show_level: hmUI.show_level.ONLY_NORMAL,
});
digitalClock_white.setProperty(hmUI.prop.VISIBLE, false);

let watchfaceCutout = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: "WATCHFACE_CUTOUT.png",
    show_level: hmUI.show_level.ONLY_NORMAL,
})
            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 310,
              y: 0,
              w: 80,
              h: 150,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              longpress_func: (button_widget) => {
                settingsMenu(true)
makeVibrate(2)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 41,
              y: 33,
              w: 120,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 33,
              w: 100,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 188,
              w: 100,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 149,
              y: 380,
              w: 100,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let settingsBG = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: "settings/SETTINGS_BG.png",
    show_level: hmUI.show_level.ONLY_NORMAL
});

let changeHrDigitsColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 32,
    y: 36,
    w: 160,
    h: 140,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BUTTON.png',
    normal_src: 'settings/BUTTON.png',
    click_func: (button_widget) => {
    changeColor("Hrs")
    makeVibrate(1)
    },
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let changeMinsDigitsColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 212,
    y: 176,
    w: 140,
    h: 120,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BUTTON.png',
    normal_src: 'settings/BUTTON.png',
    click_func: (button_widget) => {
    changeColor("Mins")
    makeVibrate(1)
    },
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let changeSecsDigitsColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 212,
    y: 36,
    w: 120,
    h: 120,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BUTTON.png',
    normal_src: 'settings/BUTTON.png',
    click_func: (button_widget) => {
    changeColor("Secs")
    makeVibrate(1)
    },
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let changeWatchfaceThemebtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 75,
    y: 330,
    w: 100,
    h: 100,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_WATCHFACESTYLE_PRESSED.png',
    normal_src: 'settings/BTN_WATCHFACESTYLE_NORMAL.png',
    click_func: (button_widget) => {
    changeWatchfaceTheme()
    makeVibrate(1)
    },
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let Confirmbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 190,
    y: 335,
    w: 120,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_CONFIRM_PRESSED.png',
    normal_src: 'settings/BTN_CONFIRM_NORMAL.png',
    click_func: (button_widget) => {
    settingsMenu(false)
    makeVibrate(3)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let watchfaceButtons = [ Button_1, Button_2, Button_3, Button_4, Button_5 ]
let settingMenuLayout = [ settingsBG, changeHrDigitsColorbtn, changeMinsDigitsColorbtn, changeSecsDigitsColorbtn, changeWatchfaceThemebtn, Confirmbtn ];

function changeColor(digitsLayer){
    switch (digitsLayer){
        case "Hrs":
            colorIndex_Hrs = (colorIndex_Hrs + 1) % colorSet_hrs.length;
            while(
                (isWhiteThemeEnabled && colorSet_hrs[colorIndex_Hrs] === 0xFFFFFFFF) ||
                (!isWhiteThemeEnabled && colorSet_hrs[colorIndex_Hrs] === 0xFF000000)
            ){
                colorIndex_Hrs = (colorIndex_Hrs + 1) % colorSet_hrs.length;
            }
            break;

        case "Mins":
            colorIndex_Mins = (colorIndex_Mins + 1) % colorSet_Mins_active.length;
            while (
                (isWhiteThemeEnabled  && colorSet_Mins_active[colorIndex_Mins] === 0xFFFFFFFF) ||
                (!isWhiteThemeEnabled && colorSet_Mins_active[colorIndex_Mins] === 0xFF000000)
            ) {
                colorIndex_Mins = (colorIndex_Mins + 1) % colorSet_Mins_active.length;
            }
            break;

        case "Secs":
            colorIndex_Secs = (colorIndex_Secs + 1) % colorSet_Secs_active.length;
            while (
                (isWhiteThemeEnabled  && colorSet_Secs_active[colorIndex_Secs] === 0xFFFFFFFF) ||
                (!isWhiteThemeEnabled && colorSet_Secs_active[colorIndex_Secs] === 0xFF000000)
            ) {
                colorIndex_Secs = (colorIndex_Secs + 1) % colorSet_Secs_active.length;
            }
            break;
    }
    updateWatchface(digitsLayer);
}

function changeWatchfaceTheme(){
    isWhiteThemeEnabled = !isWhiteThemeEnabled

    updateWatchface("Hrs");
    updateWatchface("Mins");
    updateWatchface("Secs");
}

function updateWatchface(digitsLayer){
    while (
        (isWhiteThemeEnabled  && colorSet_hrs[colorIndex_Hrs] === 0xFFFFFFFF) ||
        (!isWhiteThemeEnabled && colorSet_hrs[colorIndex_Hrs] === 0xFF000000)
    ) {
        colorIndex_Hrs = (colorIndex_Hrs + 1) % colorSet_hrs.length;
    }
    currColor_Hrs = colorSet_hrs[colorIndex_Hrs];

    colorSet_Mins_active = isWhiteThemeEnabled ? colorSet_mins_white : colorSet_mins_black;

    while (
        (isWhiteThemeEnabled  && colorSet_Mins_active[colorIndex_Mins] === 0xFFFFFFFF) ||
        (!isWhiteThemeEnabled && colorSet_Mins_active[colorIndex_Mins] === 0xFF000000)
    ) {
        colorIndex_Mins = (colorIndex_Mins + 1) % colorSet_Mins_active.length;
    }
    currColor_Mins = colorSet_Mins_active[colorIndex_Mins];

    colorSet_Secs_active = isWhiteThemeEnabled ? colorSet_secs_white : colorSet_secs_black;

    while (
        (isWhiteThemeEnabled  && colorSet_Secs_active[colorIndex_Secs] === 0xFFFFFFFF) ||
        (!isWhiteThemeEnabled && colorSet_Secs_active[colorIndex_Secs] === 0xFF000000)
    ) {
        colorIndex_Secs = (colorIndex_Secs + 1) % colorSet_Secs_active.length;
    }
    currColor_Secs = colorSet_Secs_active[colorIndex_Secs];

    switch (digitsLayer){
        case "Hrs":
            bgColor_clockHrs.setProperty(hmUI.prop.COLOR, currColor_Hrs);
            break;
        
        case "Mins":
            bgColor_clockMins.setProperty(hmUI.prop.COLOR, currColor_Mins);
            break;

        case "Secs":
            bgColor_clockSecs.setProperty(hmUI.prop.COLOR, currColor_Secs);
            break;
    }

    //Change watchface theme
    normal_background_bg_img.setProperty(hmUI.prop.SRC, isWhiteThemeEnabled ? "BG_WHITE.png" : "BG_BLACK.png")
    normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, !isWhiteThemeEnabled);
    digitalClock_white.setProperty(hmUI.prop.VISIBLE, isWhiteThemeEnabled);
    normal_dow_text_font.setProperty(hmUI.prop.MORE, {
        x: 120,
        y: 415,
        w: 150,
        h: 50,
        text_size: 28,
        char_space: 0,
        font: 'fonts/SF-Compact-Rounded-Bold.ttf',
        color: isWhiteThemeEnabled ? 0xFF000000 : 0xFFFFFFFF,
        line_space: 0,
        align_v: hmUI.align.TOP,
        text_style: hmUI.text_style.ELLIPSIS,
        align_h: hmUI.align.CENTER_H,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
}

function settingsMenu(isMenuVisible){
    watchfaceButtons.forEach(element => element.setProperty(hmUI.prop.VISIBLE, !isMenuVisible));
    settingMenuLayout.forEach(element => element.setProperty(hmUI.prop.VISIBLE, isMenuVisible));
};

settingsMenu(false);
            // end user_script_end.js

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = currWatchfaceLang.WEEKDAYS_SHORT[timeSensor.week-1];
                let normal_Day_Str = timeSensor.day.toString();

                let normal_FullDate_Str = normal_DOW_Str + " " + normal_Day_Str;
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_FullDate_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = currWatchfaceLang.WEEKDAYS_SHORT[timeSensor.week-1];
                let idle_Day_Str = timeSensor.day.toString();

                let idle_FullDate_Str = idle_DOW_Str + " " + idle_Day_Str;
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_FullDate_Str );
              };
            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}