﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

	    const hour_1 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_1.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "1.png",
                    });
		  const hour_2 = hmUI.createWidget(hmUI.widget.IMG)
                  hour_2.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "2.png",
                    });
		  const hour_3 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_3.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "3.png",
                    });
		  const hour_4 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_4.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "4.png",
                    });
		  const hour_5 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_5.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "5.png",
                    });
		  const hour_6 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_6.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "6.png",
                    });
		  const hour_7 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_7.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "7.png",
                    });
		  const hour_8 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_8.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "8.png",
                    });
		  const hour_9 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_9.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "9.png",
                    });
		  const hour_10 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_10.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "10.png",
                    });
		  const hour_11 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_11.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "11.png",
                    });
		  const hour_12 = hmUI.createWidget(hmUI.widget.IMG)
                    hour_12.setProperty(hmUI.prop.MORE,{
                        x: 0,
                        y: 0,
                        src:  "12.png",
                    });
                    hour_12.setProperty(hmUI.prop.VISIBLE,false);
                    hour_11.setProperty(hmUI.prop.VISIBLE,false);
                    hour_10.setProperty(hmUI.prop.VISIBLE,false);
                    hour_9.setProperty(hmUI.prop.VISIBLE,false);
                    hour_8.setProperty(hmUI.prop.VISIBLE,false);
                    hour_7.setProperty(hmUI.prop.VISIBLE,false);
                    hour_6.setProperty(hmUI.prop.VISIBLE,false);
                    hour_5.setProperty(hmUI.prop.VISIBLE,false);
                    hour_4.setProperty(hmUI.prop.VISIBLE,false);
                    hour_3.setProperty(hmUI.prop.VISIBLE,false);
                    hour_2.setProperty(hmUI.prop.VISIBLE,false);
                    hour_1.setProperty(hmUI.prop.VISIBLE,false);

  // change_background
	let now;
	now = hmSensor.createSensor(hmSensor.id.TIME);
	switch (now.hour) {
		case 1: hour_1.setProperty(hmUI.prop.VISIBLE,true); break;
		case 2: hour_2.setProperty(hmUI.prop.VISIBLE,true); break;
		case 3: hour_3.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 4: hour_4.setProperty(hmUI.prop.VISIBLE,true); break;
  		case 5: hour_5.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 6: hour_6.setProperty(hmUI.prop.VISIBLE,true); break;
		case 7: hour_7.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 8: hour_8.setProperty(hmUI.prop.VISIBLE,true); break; 
  		case 9: hour_9.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 10: hour_10.setProperty(hmUI.prop.VISIBLE,true); break;
		case 11: hour_11.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 12: hour_12.setProperty(hmUI.prop.VISIBLE,true); break;
		case 13: hour_1.setProperty(hmUI.prop.VISIBLE,true); break;
		case 14: hour_2.setProperty(hmUI.prop.VISIBLE,true); break;
		case 15: hour_3.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 16: hour_4.setProperty(hmUI.prop.VISIBLE,true); break;
  		case 17: hour_5.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 18: hour_6.setProperty(hmUI.prop.VISIBLE,true); break;
		case 19: hour_7.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 20: hour_8.setProperty(hmUI.prop.VISIBLE,true); break; 
  		case 21: hour_9.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 22: hour_10.setProperty(hmUI.prop.VISIBLE,true); break;
		case 23: hour_11.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 0: hour_12.setProperty(hmUI.prop.VISIBLE,true); break;
		}
	let diffTime = 1;
	const timer1 = timer.createTimer(
	0,
	1000,
  	function (option) {
		if (now.hour != diffTime) {
                    hour_12.setProperty(hmUI.prop.VISIBLE,false);
                    hour_11.setProperty(hmUI.prop.VISIBLE,false);
                    hour_10.setProperty(hmUI.prop.VISIBLE,false);
                    hour_9.setProperty(hmUI.prop.VISIBLE,false);
                    hour_8.setProperty(hmUI.prop.VISIBLE,false);
                    hour_7.setProperty(hmUI.prop.VISIBLE,false);
                    hour_6.setProperty(hmUI.prop.VISIBLE,false);
                    hour_5.setProperty(hmUI.prop.VISIBLE,false);
                    hour_4.setProperty(hmUI.prop.VISIBLE,false);
                    hour_3.setProperty(hmUI.prop.VISIBLE,false);
                    hour_2.setProperty(hmUI.prop.VISIBLE,false);
                    hour_1.setProperty(hmUI.prop.VISIBLE,false);
	switch (now.hour) {
		case 1: hour_1.setProperty(hmUI.prop.VISIBLE,true); break;
		case 2: hour_2.setProperty(hmUI.prop.VISIBLE,true); break;
		case 3: hour_3.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 4: hour_4.setProperty(hmUI.prop.VISIBLE,true); break;
  		case 5: hour_5.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 6: hour_6.setProperty(hmUI.prop.VISIBLE,true); break;
		case 7: hour_7.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 8: hour_8.setProperty(hmUI.prop.VISIBLE,true); break; 
  		case 9: hour_9.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 10: hour_10.setProperty(hmUI.prop.VISIBLE,true); break;
		case 11: hour_11.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 12: hour_12.setProperty(hmUI.prop.VISIBLE,true); break;
		case 13: hour_1.setProperty(hmUI.prop.VISIBLE,true); break;
		case 14: hour_2.setProperty(hmUI.prop.VISIBLE,true); break;
		case 15: hour_3.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 16: hour_4.setProperty(hmUI.prop.VISIBLE,true); break;
  		case 17: hour_5.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 18: hour_6.setProperty(hmUI.prop.VISIBLE,true); break;
		case 19: hour_7.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 20: hour_8.setProperty(hmUI.prop.VISIBLE,true); break; 
  		case 21: hour_9.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 22: hour_10.setProperty(hmUI.prop.VISIBLE,true); break;
		case 23: hour_11.setProperty(hmUI.prop.VISIBLE,true); break;
 		case 0: hour_12.setProperty(hmUI.prop.VISIBLE,true); break;
		}
			diffTime = now.hour;
		}
  	},
	)
  // -----
             let screenType = hmSetting.getScreenType();

            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 249,
              y: 324,
              src: '0130.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 367,
              font_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 324,
              src: '0129.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 367,
              font_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 245,
              font_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0126.png',
              unit_tc: '0126.png',
              unit_en: '0126.png',
              negative_image: '0127.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 274,
              y: 194,
              image_array: ["0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 85,
              y: 253,
              src: '0128.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 65,
              y: 212,
              font_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 50,
              y: 185,
              image_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 259,
              y: 3,
              src: '0096.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 186,
              y: 295,
              src: '0131.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 221,
              day_startY: 70,
              day_sc_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              day_tc_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              day_en_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 206,
              y: 70,
              src: '0093.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 127,
              y: 70,
              week_en: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              week_tc: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              week_sc: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '68.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 30,
              hour_posY: 114,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '66.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 30,
              minute_posY: 139,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '67.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 12,
              second_posY: 150,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '0095.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 221,
              day_startY: 70,
              day_sc_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              day_tc_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              day_en_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 206,
              y: 70,
              src: '0093.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 127,
              y: 70,
              week_en: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              week_tc: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              week_sc: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '68.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 30,
              hour_posY: 114,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '66.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 30,
              minute_posY: 139,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 176,
              y: 281,
              w: 40,
              h: 40,
              src: '0072.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 247,
              y: 343,
              w: 50,
              h: 50,
              src: '0072.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 97,
              y: 343,
              w: 50,
              h: 50,
              src: '0072.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 280,
              y: 203,
              w: 40,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneContactsScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 74,
              y: 203,
              w: 40,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 139,
              y: 72,
              w: 120,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({ appid: 1076308, url: 'page/gtr/home/index.page'});

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 172,
              y: 207,
              w: 40,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleListScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}