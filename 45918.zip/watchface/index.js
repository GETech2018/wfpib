try{(()=>{var __$$app$$__=__$$hmAppManager$$__.currentApp;var __$$module$$__=__$$app$$__.current;var e=new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__,__$$module$$__),"atlas");"use strict";
__$$module$$__.module=DeviceRuntimeCore.WatchFace({
init_view(){
const N=hmUI.show_level.ONLY_NORMAL, AOD=hmUI.show_level.ONLY_AOD, DT=hmUI.data_type, L=hmUI.align.LEFT, CH=hmUI.align.CENTER_H;
const safe=(f)=>{try{f()}catch(err){console.log(err)}};
const img=(x,y,w,h,src,lv)=>safe(()=>hmUI.createWidget(hmUI.widget.IMG,{x:x,y:y,w:w,h:h,src:src,show_level:lv||N}));
const level=(x,y,arr,type)=>safe(()=>hmUI.createWidget(hmUI.widget.IMG_LEVEL,{x:x,y:y,image_array:arr,image_length:arr.length,type:type,show_level:N}));
const text=(x,y,w,h,arr,type,al,extra)=>safe(()=>{if(type===undefined)return;hmUI.createWidget(hmUI.widget.TEXT_IMG,Object.assign({x:x,y:y,w:w,h:h,font_array:arr,h_space:0,align_h:al,type:type,show_level:N},extra||{}))});
const un=(u)=>({unit_sc:u,unit_tc:u,unit_en:u,imperial_unit_sc:u,imperial_unit_tc:u,imperial_unit_en:u});
img(0,0,390,450,"0255.png");
// calorias (barra naranja) y su cifra
level(60,14,["0159.png", "0160.png", "0161.png", "0162.png", "0163.png", "0164.png", "0165.png", "0166.png", "0167.png", "0168.png", "0169.png", "0170.png", "0171.png", "0172.png", "0173.png", "0174.png", "0175.png", "0176.png", "0177.png", "0178.png", "0179.png", "0180.png", "0181.png", "0182.png", "0183.png"],DT.CAL);
text(145,26,100,26,["0081.png", "0082.png", "0083.png", "0084.png", "0085.png", "0086.png", "0087.png", "0088.png", "0089.png", "0090.png"],DT.CAL,CH);
// distancia / presion / humedad
text(65,64,90,24,["0061.png", "0062.png", "0063.png", "0064.png", "0065.png", "0066.png", "0067.png", "0068.png", "0069.png", "0070.png"],DT.DISTANCE,CH,{dot_image:"0141.png"});
text(150,64,90,24,["0061.png", "0062.png", "0063.png", "0064.png", "0065.png", "0066.png", "0067.png", "0068.png", "0069.png", "0070.png"],DT.STAND,CH,{invalid_image:"0142.png"});
text(237,64,90,24,["0061.png", "0062.png", "0063.png", "0064.png", "0065.png", "0066.png", "0067.png", "0068.png", "0069.png", "0070.png"],DT.HUMIDITY,CH,{invalid_image:"0142.png"});
// pasos: barra
level(62,96,["0184.png", "0185.png", "0186.png", "0187.png", "0188.png", "0189.png", "0190.png", "0191.png", "0192.png", "0193.png", "0194.png", "0195.png", "0196.png", "0197.png", "0198.png", "0199.png", "0200.png", "0201.png", "0202.png", "0203.png", "0204.png", "0205.png", "0206.png", "0207.png", "0208.png"],DT.STEP);
// altitud y pasos
// amanecer / atardecer (cambia solo)
(function(){
var DG=["0031.png", "0032.png", "0033.png", "0034.png", "0035.png", "0036.png", "0037.png", "0038.png", "0039.png", "0040.png"], COL="0149.png", BL="0150.png", UP="0151.png", DN="0152.png";
var CX=66, Y=120, DW=17, CW=9, slots=[], icon=null, tm=null, ws=null;
for(var i=0;i<5;i++){try{slots.push(hmUI.createWidget(hmUI.widget.IMG,{x:CX-40+i*17,y:Y,w:17,h:28,src:BL,show_level:N}))}catch(err){console.log(err)}}
try{icon=hmUI.createWidget(hmUI.widget.IMG,{x:28,y:149,w:16,h:12,src:DN,show_level:N})}catch(err){console.log(err)}
try{ws=hmSensor.createSensor(hmSensor.id.WEATHER)}catch(err){console.log(err)}
try{tm=hmSensor.createSensor(hmSensor.id.TIME)}catch(err){console.log(err)}
var set=function(w,o){try{w.setProperty(hmUI.prop.MORE,o)}catch(err){try{if(o.src)w.setProperty(hmUI.prop.SRC,o.src)}catch(e2){}}};
var nowMin=function(){try{if(tm&&typeof tm.hour==="number")return tm.hour*60+tm.minute}catch(err){}var d=new Date();return d.getHours()*60+d.getMinutes()};
var up=function(){try{
 var f=ws.getForecastWeather(), t=f.tideData.data[0], sr=t.sunrise.hour*60+t.sunrise.minute, ss=t.sunset.hour*60+t.sunset.minute, n=nowMin();
 var day=(n>=sr&&n<ss), v=day?t.sunset:t.sunrise, h=v.hour%12; if(h===0)h=12;
 var chars=[]; if(h>=10)chars.push(DG[Math.floor(h/10)]); chars.push(DG[h%10]); chars.push(COL); chars.push(DG[Math.floor(v.minute/10)]); chars.push(DG[v.minute%10]);
 var w=0; for(var i=0;i<chars.length;i++)w+=(chars[i]===COL?CW:DW); var x=CX-Math.floor(w/2);
 for(var j=0;j<5;j++){ if(j<chars.length){var cw=(chars[j]===COL?CW:DW); set(slots[j],{x:x,y:Y,w:cw,h:28,src:chars[j]}); x+=cw}else{set(slots[j],{x:0,y:Y,w:17,h:28,src:BL})} }
 set(icon,{x:28,y:149,w:16,h:12,src:day?DN:UP});
}catch(err){console.log(err)}};
up();
try{tm.addEventListener(hmSensor.event.MINUTEEND,up)}catch(err){}
try{hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE,{resume_call:up})}catch(err){}
})();
text(117,120,90,28,["0031.png", "0032.png", "0033.png", "0034.png", "0035.png", "0036.png", "0037.png", "0038.png", "0039.png", "0040.png"],DT.STEP,CH);
// dial de pulso (anillo por sensor)
(function(){var arr=["0234.png", "0235.png", "0236.png", "0237.png", "0238.png", "0239.png", "0240.png", "0241.png", "0242.png", "0243.png", "0244.png", "0245.png", "0246.png", "0247.png", "0248.png", "0249.png", "0250.png", "0251.png", "0252.png", "0253.png", "0254.png"],w=null,sn=null;
try{w=hmUI.createWidget(hmUI.widget.IMG,{x:258,y:96,src:arr[0],show_level:N})}catch(err){console.log(err)}
try{sn=hmSensor.createSensor(hmSensor.id.HEART)}catch(err){console.log(err)}
var up=function(){try{var v=(sn&&(sn.last||sn.current))||0;var f=Math.max(0,Math.min(arr.length-1,Math.round((v-40)/140*(arr.length-1))));w.setProperty(hmUI.prop.SRC,arr[f])}catch(err){console.log(err)}};
up();try{sn.addEventListener(hmSensor.event.LAST,up)}catch(err){}
try{sn.addEventListener(hmSensor.event.CHANGE,up)}catch(err){}
try{hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE,{resume_call:up})}catch(err){}
})();
text(260,120,80,30,["0071.png", "0072.png", "0073.png", "0074.png", "0075.png", "0076.png", "0077.png", "0078.png", "0079.png", "0080.png"],DT.HEART,CH,{invalid_image:"0142.png"});
// dia completo
safe(()=>hmUI.createWidget(hmUI.widget.IMG_WEEK,{x:80,y:172,week_en:["0134.png", "0135.png", "0136.png", "0137.png", "0138.png", "0139.png", "0140.png"],week_tc:["0134.png", "0135.png", "0136.png", "0137.png", "0138.png", "0139.png", "0140.png"],week_sc:["0134.png", "0135.png", "0136.png", "0137.png", "0138.png", "0139.png", "0140.png"],show_level:N}));
// clima y fecha
text(90,198,56,34,["0041.png", "0042.png", "0043.png", "0044.png", "0045.png", "0046.png", "0047.png", "0048.png", "0049.png", "0050.png"],DT.WEATHER_CURRENT,L,Object.assign({negative_image:"0143.png",invalid_image:"0142.png"},un("0144.png")));
safe(()=>hmUI.createWidget(hmUI.widget.IMG_DATE,{
 day_startX:160,day_startY:198,day_sc_array:["0051.png", "0052.png", "0053.png", "0054.png", "0055.png", "0056.png", "0057.png", "0058.png", "0059.png", "0060.png"],day_tc_array:["0051.png", "0052.png", "0053.png", "0054.png", "0055.png", "0056.png", "0057.png", "0058.png", "0059.png", "0060.png"],day_en_array:["0051.png", "0052.png", "0053.png", "0054.png", "0055.png", "0056.png", "0057.png", "0058.png", "0059.png", "0060.png"],day_zero:1,day_space:0,day_align:L,
 month_startX:206,month_startY:199,month_sc_array:["0115.png", "0116.png", "0117.png", "0118.png", "0119.png", "0120.png", "0121.png", "0122.png", "0123.png", "0124.png", "0125.png", "0126.png"],month_tc_array:["0115.png", "0116.png", "0117.png", "0118.png", "0119.png", "0120.png", "0121.png", "0122.png", "0123.png", "0124.png", "0125.png", "0126.png"],month_en_array:["0115.png", "0116.png", "0117.png", "0118.png", "0119.png", "0120.png", "0121.png", "0122.png", "0123.png", "0124.png", "0125.png", "0126.png"],month_is_character:true,month_align:L,show_level:N}));
text(298,196,64,24,["0101.png", "0102.png", "0103.png", "0104.png", "0105.png", "0106.png", "0107.png", "0108.png", "0109.png", "0110.png"],DT.WEATHER_HIGH,L,Object.assign({negative_image:"0143.png"},un("0145.png")));
text(298,220,64,24,["0101.png", "0102.png", "0103.png", "0104.png", "0105.png", "0106.png", "0107.png", "0108.png", "0109.png", "0110.png"],DT.WEATHER_LOW,L,Object.assign({negative_image:"0143.png"},un("0145.png")));
// hora grande con segundos y AM/PM
img(188,247,16,92,"0111.png");
safe(()=>hmUI.createWidget(hmUI.widget.IMG_TIME,{
 hour_startX:76,hour_startY:247,hour_array:["0001.png", "0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png"],hour_zero:1,hour_space:0,hour_align:L,
 minute_startX:204,minute_startY:247,minute_array:["0001.png", "0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png"],minute_zero:1,minute_space:0,minute_align:L,
 second_startX:322,second_startY:280,second_array:["0021.png", "0022.png", "0023.png", "0024.png", "0025.png", "0026.png", "0027.png", "0028.png", "0029.png", "0030.png"],second_zero:1,second_space:0,second_align:L,
 am_x:28,am_y:262,am_sc_path:"0113.png",am_tc_path:"0113.png",am_en_path:"0113.png",
 pm_x:28,pm_y:262,pm_sc_path:"0114.png",pm_tc_path:"0114.png",pm_en_path:"0114.png",show_level:N}));
safe(()=>hmUI.createWidget(hmUI.widget.IMG_WEEK,{x:35,y:357,week_en:["0127.png", "0128.png", "0129.png", "0130.png", "0131.png", "0132.png", "0133.png"],week_tc:["0127.png", "0128.png", "0129.png", "0130.png", "0131.png", "0132.png", "0133.png"],week_sc:["0127.png", "0128.png", "0129.png", "0130.png", "0131.png", "0132.png", "0133.png"],show_level:N}));
// bateria
level(70,392,["0209.png", "0210.png", "0211.png", "0212.png", "0213.png", "0214.png", "0215.png", "0216.png", "0217.png", "0218.png", "0219.png", "0220.png", "0221.png", "0222.png", "0223.png", "0224.png", "0225.png", "0226.png", "0227.png", "0228.png", "0229.png", "0230.png", "0231.png", "0232.png", "0233.png"],DT.BATTERY);
text(176,410,70,24,["0091.png", "0092.png", "0093.png", "0094.png", "0095.png", "0096.png", "0097.png", "0098.png", "0099.png", "0100.png"],DT.BATTERY,L,un("0147.png"));
// AOD
img(0,0,390,450,"0256.png",AOD);
img(188,247,16,92,"0112.png",AOD);
safe(()=>hmUI.createWidget(hmUI.widget.IMG_TIME,{
 hour_startX:76,hour_startY:247,hour_array:["0011.png", "0012.png", "0013.png", "0014.png", "0015.png", "0016.png", "0017.png", "0018.png", "0019.png", "0020.png"],hour_zero:1,hour_space:0,hour_align:L,
 minute_startX:204,minute_startY:247,minute_array:["0011.png", "0012.png", "0013.png", "0014.png", "0015.png", "0016.png", "0017.png", "0018.png", "0019.png", "0020.png"],minute_zero:1,minute_space:0,minute_align:L,show_level:AOD}));
},
onInit(){this.init_view()},onReady(){},onShow(){},onHide(){},onDestroy(){}
})})()}catch(e){console.log(e)}
