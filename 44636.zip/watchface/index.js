﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 242,
              // start_y: 369,
              // color: 0xFF74E800,
              // lenght: 26,
              // line_width: 15,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 282,
              y: 367,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 238,
              y: 367,
              src: 'icon_Battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 150,
              month_startY: 367,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 98,
              day_startY: 366,
              day_sc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_tc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_en_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 24,
              y: 367,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 28,
              hour_startY: 283,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 212,
              minute_startY: 283,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 185,
              y: 272,
              src: 'TimeDot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
// อ่านประเภทหน้าจอ (เช่น AOD หรือหน้าจอปกติ)


// ถ้าไม่ใช่ Always On Display → ให้รันเกม
if (screenType != hmSetting.screen_type.AOD) {


// ======================
// SCREEN
// ======================

const SCREEN_W = 390;
const SCREEN_H = 450;

const SCALE = 0.8;

const GAME_W = SCREEN_W;
const GAME_H = SCREEN_H * SCALE;


// ======================
// HI SCORE KEY
// ======================

const HI_KEY = "inv_hi_score";


// ======================
// PLAYER
// ======================

const PLAYER_W = 29 * SCALE;
const PLAYER_H = 29 * SCALE;

let player;
let playerX = GAME_W / 2 - PLAYER_W / 2;
let playerY = GAME_H - 181 * SCALE;


// ======================
// BULLETS
// ======================

let bullets = [];
let enemyBullets = [];

const BULLET_W = 4 * SCALE;
const BULLET_H = 10 * SCALE;

const BULLET_SPEED = 10 * SCALE;
const ENEMY_BULLET_SPEED = 6 * SCALE;

const PLAYER_SHOOT_DELAY = 300;
let lastShootTime = 0;

const ENEMY_SHOOT_DELAY = 2000;
let lastEnemyShootTime = 0;


// ======================
// ENEMY IMAGES
// ======================

const ENEMY_IMAGES = [
"enemy1.png",
"enemy2.png",
"enemy3.png",
"enemy4.png",
"enemy5.png"
];


// ======================
// ENEMIES
// ======================

let enemies = [];

const ENEMY_W = 40 * SCALE;
const ENEMY_H = 20 * SCALE;

const ENEMY_ROWS = 4;
const ENEMY_COLS = 6;

const ENEMY_SPACING_X = 50 * SCALE;
const ENEMY_SPACING_Y = 40 * SCALE;

const ENEMY_START_Y = 40 * SCALE;

let enemyDir = 1;

let wave = 1;


// ======================
// SCORE
// ======================

let score = 0;

let hiScore = hmFS.SysProGetInt(HI_KEY);
if (hiScore === undefined || hiScore === null)
hiScore = 0;

let scoreText;
let hiText;


// ======================
// STATE
// ======================

let isGameOver = false;
let gameOverText;


// ======================
// PLAYER CREATE
// ======================

function createPlayer() {

player =
hmUI.createWidget(
hmUI.widget.IMG,
{
x: playerX,
y: playerY,
w: PLAYER_W,
h: PLAYER_H,
src: "player.png"
});

}


// ======================
// ENEMY CREATE
// ======================

function createEnemies() {

enemies = [];

enemyDir = 1;

let rows = Math.min(ENEMY_ROWS + (wave - 1), 5);

for (let r = 0; r < rows; r++) {

let img = ENEMY_IMAGES[r];

for (let c = 0; c < ENEMY_COLS; c++) {

let x = 40 * SCALE + c * ENEMY_SPACING_X;
let y = ENEMY_START_Y + r * ENEMY_SPACING_Y;

let enemy =
hmUI.createWidget(
hmUI.widget.IMG,
{
x,
y,
w: ENEMY_W,
h: ENEMY_H,
src: img
});

enemies.push({
x,
y,
widget: enemy,
alive: true
});

}
}

wave++;

}


// ======================
// SHOOT PLAYER (แก้เป็น IMG)
// ======================

function shoot() {

if (isGameOver) {
startGame();
return;
}

let now = Date.now();

if (now - lastShootTime < PLAYER_SHOOT_DELAY)
return;

lastShootTime = now;

let x = playerX + PLAYER_W / 2;
let y = playerY;

let bullet =
hmUI.createWidget(
hmUI.widget.IMG,
{
x,
y,
w: BULLET_W,
h: BULLET_H,
src: "bullet_player.png"
});

bullets.push({ x, y, widget: bullet });

}


// ======================
// ENEMY SHOOT (แก้เป็น IMG)
// ======================

function enemyShoot() {

let now = Date.now();

if (now - lastEnemyShootTime < ENEMY_SHOOT_DELAY)
return;

lastEnemyShootTime = now;

let alive = enemies.filter(e => e.alive);

if (alive.length === 0)
return;

let shooter =
alive[Math.floor(Math.random() * alive.length)];

let x = shooter.x + ENEMY_W / 2;
let y = shooter.y + ENEMY_H;

let bullet =
hmUI.createWidget(
hmUI.widget.IMG,
{
x,
y,
w: BULLET_W,
h: BULLET_H,
src: "bullet_enemy.png"
});

enemyBullets.push({ x, y, widget: bullet });

}


// ======================
// UPDATE BULLETS
// ======================

function updateBullets() {

for (let i = bullets.length - 1; i >= 0; i--) {

let b = bullets[i];

b.y -= BULLET_SPEED;

if (b.y < 0) {

hmUI.deleteWidget(b.widget);
bullets.splice(i, 1);
continue;

}

b.widget.setProperty(hmUI.prop.MORE,{ x: b.x, y: b.y });

}
}


// ======================
// UPDATE ENEMY BULLETS
// ======================

function updateEnemyBullets() {

for (let i = enemyBullets.length - 1; i >= 0; i--) {

let b = enemyBullets[i];

b.y += ENEMY_BULLET_SPEED;

if (
b.x < playerX + PLAYER_W &&
b.x + BULLET_W > playerX &&
b.y < playerY + PLAYER_H &&
b.y + BULLET_H > playerY
) {
gameOver();
}

if (b.y > playerY + PLAYER_H) {

hmUI.deleteWidget(b.widget);
enemyBullets.splice(i, 1);
continue;

}

b.widget.setProperty(hmUI.prop.MORE,{ x: b.x, y: b.y });

}
}


// ======================
// UPDATE ENEMIES
// ======================

function updateEnemies() {

let hitEdge = false;

enemies.forEach(e => {

if (!e.alive) return;

e.x += enemyDir * 2 * SCALE;

if (e.x < 0 || e.x > GAME_W - ENEMY_W)
hitEdge = true;

if (
e.x < playerX + PLAYER_W &&
e.x + ENEMY_W > playerX &&
e.y < playerY + PLAYER_H &&
e.y + ENEMY_H > playerY
) {
gameOver();
}

if (e.y + ENEMY_H >= playerY) {
gameOver();
}

});

if (hitEdge) {

enemyDir *= -1;

enemies.forEach(e => {
e.y += 3 * SCALE;
});

}

enemies.forEach(e => {

if (!e.alive) return;

e.widget.setProperty(
hmUI.prop.MORE,
{ x: e.x, y: e.y }
);

});

}


// ======================
// COLLISION
// ======================

function checkCollision() {

bullets.forEach((b, bi) => {

enemies.forEach((e) => {

if (!e.alive) return;

if (
b.x < e.x + ENEMY_W &&
b.x + BULLET_W > e.x &&
b.y < e.y + ENEMY_H &&
b.y + BULLET_H > e.y
) {

e.alive = false;

hmUI.deleteWidget(e.widget);
hmUI.deleteWidget(b.widget);

bullets.splice(bi, 1);

score += 10;

scoreText.setProperty(
hmUI.prop.TEXT,
"Score: " + score
);

}

});

});

let aliveCount = enemies.filter(e => e.alive).length;

if (aliveCount === 0) {

enemies.forEach(e=>{
if(e.widget) hmUI.deleteWidget(e.widget);
});

createEnemies();

}

}


// ======================
// GAME OVER
// ======================

function gameOver() {

if (isGameOver) return;

isGameOver = true;

if (score > hiScore) {

hmFS.SysProSetInt(HI_KEY, score);
hiScore = score;

hiText.setProperty(
hmUI.prop.TEXT,
"HI: " + hiScore
);

}

gameOverText.setProperty(
hmUI.prop.VISIBLE,
true
);

}


// ======================
// LOOP
// ======================

function gameLoop() {

if (isGameOver) return;

updateBullets();
updateEnemyBullets();
updateEnemies();
enemyShoot();
checkCollision();

}

timer.createTimer(0, 30, gameLoop);


// ======================
// UI
// ======================

scoreText =
hmUI.createWidget(
hmUI.widget.TEXT,
{
x: 63,
y: 5,
w: 200,
h: 20,
text: "Score: 0",
text_size: 18,
color: 0xFFFFFF
}
);

hiText =
hmUI.createWidget(
hmUI.widget.TEXT,
{
x: GAME_W -157,
y: 5,
w: 70,
h: 20,
text: "HI: " + hiScore,
text_size: 18,
color: 0xFFFF00
}
);

gameOverText =
hmUI.createWidget(
hmUI.widget.TEXT,
{
x: 19,
y: (GAME_H / 2)+60,
w: GAME_W,
h: 40,
text: ".:GAME OVER:.  PLAY AGAIN PRESS SHOOT BUTTON ",
text_size: 14,
color: 0xFF0000
}
);

gameOverText.setProperty(hmUI.prop.VISIBLE,false);


// ======================
// BUTTONS
// ======================

hmUI.createWidget(hmUI.widget.BUTTON,{
x:20,y:SCREEN_H-50,w:100,h:40,text:"◀",
click_func:()=>{
if(playerX>0){
playerX-=20*SCALE;
player.setProperty(hmUI.prop.MORE,{x: playerX,y: playerY});
}}
});

hmUI.createWidget(hmUI.widget.BUTTON,{
x:SCREEN_W/2-50,y:SCREEN_H-50,w:100,h:40,text:"●",
click_func:shoot
});

hmUI.createWidget(hmUI.widget.BUTTON,{
x:SCREEN_W-120,y:SCREEN_H-50,w:100,h:40,text:"▶",
click_func:()=>{
if(playerX<GAME_W-PLAYER_W){
playerX+=20*SCALE;
player.setProperty(hmUI.prop.MORE,{x: playerX,y: playerY});
}}
});


// ======================
// START GAME
// ======================

function startGame(){

isGameOver=false;

score=0;
wave=1;

scoreText.setProperty(hmUI.prop.TEXT,"Score: 0");

gameOverText.setProperty(hmUI.prop.VISIBLE,false);

bullets.forEach(b=>hmUI.deleteWidget(b.widget));
enemyBullets.forEach(b=>hmUI.deleteWidget(b.widget));

bullets=[];
enemyBullets=[];

enemies.forEach(e=>hmUI.deleteWidget(e.widget));

createEnemies();

}

createPlayer();
createEnemies();

}
            // end user_script.js


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 242,
              // start_y: 369,
              // color: 0xFF74E800,
              // lenght: 26,
              // line_width: 15,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 282,
              y: 367,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 238,
              y: 367,
              src: 'icon_Battery.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 150,
              month_startY: 367,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 98,
              day_startY: 366,
              day_sc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_tc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_en_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 24,
              y: 367,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 28,
              hour_startY: 283,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 212,
              minute_startY: 283,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 185,
              y: 272,
              src: 'TimeDot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 242;
                  let start_y_normal_battery = 369;
                  let lenght_ls_normal_battery = 26;
                  let line_width_ls_normal_battery = 15;
                  let color_ls_normal_battery = 0xFF74E800;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 242;
                  let start_y_idle_battery = 369;
                  let lenght_ls_idle_battery = 26;
                  let line_width_ls_idle_battery = 15;
                  let color_ls_idle_battery = 0xFF74E800;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}