try {
    (() => {
        var n = __$$hmAppManager$$__.currentApp;
        const g = n.current,
            {
                px: p
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(n, g)), n.app.__globals__),
            e = Logger.getLogger("watchface6");
        g.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: "4.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: "",
                    anim_prefix: "first_anim_vbbgv",
                    anim_ext: "png",
                    anim_fps: 41,
                    anim_size: 60,
                    display_on_restart: !1,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 88,
                    hour_startY: 190,
                    hour_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 208,
                    minute_startY: 190,
                    minute_array: ["15.png", "16.png", "17.png", "18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png"],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 88,
                    second_startY: 352,
                    second_array: ["25.png", "26.png", "27.png", "28.png", "29.png", "30.png", "31.png", "32.png", "33.png", "34.png"],
                    second_space: 0,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 185,
                    y: 206,
                    w: 20,
                    h: 60,
                    src: "35.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 243,
                    y: 267,
                    type: hmUI.data_type.HEART,
                    font_array: ["36.png", "37.png", "38.png", "39.png", "40.png", "41.png", "42.png", "43.png", "44.png", "45.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: "46.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 200,
                    y: 263,
                    w: 110,
                    h: 30,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 123,
                    y: 267,
                    type: hmUI.data_type.CAL,
                    font_array: ["47.png", "48.png", "49.png", "50.png", "51.png", "52.png", "53.png", "54.png", "55.png", "56.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: "57.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 84,
                    y: 263,
                    w: 110,
                    h: 30,
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 161,
                    y: 308,
                    type: hmUI.data_type.DISTANCE,
                    font_array: ["58.png", "59.png", "60.png", "61.png", "62.png", "63.png", "64.png", "65.png", "66.png", "67.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: "69.png",
                    invalid_image: "68.png",
                    padding: !0,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 155,
                    y: 305,
                    w: 80,
                    h: 50,
                    type: hmUI.data_type.DISTANCE,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 174,
                    y: 102,
                    image_array: ["70.png", "71.png", "72.png", "73.png", "74.png", "75.png", "76.png", "77.png", "78.png", "79.png", "80.png", "81.png", "82.png", "83.png", "84.png", "85.png", "86.png", "87.png", "88.png", "89.png", "90.png", "91.png", "92.png", "93.png", "94.png", "95.png", "96.png", "97.png", "98.png"],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 97,
                    y: 102,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: ["99.png", "100.png", "101.png", "102.png", "103.png", "104.png", "105.png", "106.png", "107.png", "108.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "111.png",
                    unit_tc: "111.png",
                    unit_en: "111.png",
                    negative_image: "110.png",
                    invalid_image: "109.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 90,
                    y: 95,
                    w: 55,
                    h: 30,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 239,
                    y: 115,
                    image_array: ["112.png", "113.png", "114.png", "115.png", "116.png", "117.png", "118.png", "119.png", "120.png", "121.png"],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 276,
                    y: 81,
                    type: hmUI.data_type.BATTERY,
                    font_array: ["122.png", "123.png", "124.png", "125.png", "126.png", "127.png", "128.png", "129.png", "130.png", "131.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "132.png",
                    unit_tc: "132.png",
                    unit_en: "132.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 159,
                    y: 399,
                    type: hmUI.data_type.STEP,
                    font_array: ["133.png", "134.png", "135.png", "136.png", "137.png", "138.png", "139.png", "140.png", "141.png", "142.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: "143.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 237,
                    y: 238,
                    image_array: ["144.png", "145.png", "146.png", "147.png", "148.png", "149.png", "150.png", "151.png", "152.png", "153.png"],
                    image_length: 10,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 155,
                    y: 395,
                    w: 80,
                    h: 30,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 227,
                    y: 162,
                    week_en: ["154.png", "155.png", "156.png", "157.png", "158.png", "159.png", "160.png"],
                    week_tc: ["161.png", "162.png", "163.png", "164.png", "165.png", "166.png", "167.png"],
                    week_sc: ["168.png", "169.png", "170.png", "171.png", "172.png", "173.png", "174.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 90,
                    month_startY: 164,
                    month_sc_array: ["175.png", "176.png", "177.png", "178.png", "179.png", "180.png", "181.png", "182.png", "183.png", "184.png"],
                    month_tc_array: ["175.png", "176.png", "177.png", "178.png", "179.png", "180.png", "181.png", "182.png", "183.png", "184.png"],
                    month_en_array: ["175.png", "176.png", "177.png", "178.png", "179.png", "180.png", "181.png", "182.png", "183.png", "184.png"],
                    month_unit_sc: "185.png",
                    month_unit_tc: "185.png",
                    month_unit_en: "185.png",
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: !1,
                    day_startX: 138,
                    day_startY: 164,
                    day_sc_array: ["186.png", "187.png", "188.png", "189.png", "190.png", "191.png", "192.png", "193.png", "194.png", "195.png"],
                    day_tc_array: ["186.png", "187.png", "188.png", "189.png", "190.png", "191.png", "192.png", "193.png", "194.png", "195.png"],
                    day_en_array: ["186.png", "187.png", "188.png", "189.png", "190.png", "191.png", "192.png", "193.png", "194.png", "195.png"],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 1,
                    day_space: 0,
                    day_is_character: !1,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 33,
                    y: 156,
                    src: "196.png",
                    type: hmUI.system_status.DISTURB,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 33,
                    y: 35,
                    src: "197.png",
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }),hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 336,
                    y: 200,
                    w: 55,
                    h: 260,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 160,
                    y: 80,
                    w: 70,
                    h: 80,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }),hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 88,
                    hour_startY: 190,
                    hour_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 208,
                    minute_startY: 190,
                    minute_array: ["15.png", "16.png", "17.png", "18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png"],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 185,
                    y: 206,
                    w: 20,
                    h: 60,
                    src: "35.png",
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 227,
                    y: 162,
                    week_en: ["154.png", "155.png", "156.png", "157.png", "158.png", "159.png", "160.png"],
                    week_tc: ["161.png", "162.png", "163.png", "164.png", "165.png", "166.png", "167.png"],
                    week_sc: ["168.png", "169.png", "170.png", "171.png", "172.png", "173.png", "174.png"],
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 90,
                    month_startY: 164,
                    month_sc_array: ["175.png", "176.png", "177.png", "178.png", "179.png", "180.png", "181.png", "182.png", "183.png", "184.png"],
                    month_tc_array: ["175.png", "176.png", "177.png", "178.png", "179.png", "180.png", "181.png", "182.png", "183.png", "184.png"],
                    month_en_array: ["175.png", "176.png", "177.png", "178.png", "179.png", "180.png", "181.png", "182.png", "183.png", "184.png"],
                    month_unit_sc: "198.png",
                    month_unit_tc: "198.png",
                    month_unit_en: "198.png",
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: !1,
                    day_startX: 138,
                    day_startY: 164,
                    day_sc_array: ["186.png", "187.png", "188.png", "189.png", "190.png", "191.png", "192.png", "193.png", "194.png", "195.png"],
                    day_tc_array: ["186.png", "187.png", "188.png", "189.png", "190.png", "191.png", "192.png", "193.png", "194.png", "195.png"],
                    day_en_array: ["186.png", "187.png", "188.png", "189.png", "190.png", "191.png", "192.png", "193.png", "194.png", "195.png"],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 1,
                    day_space: 0,
                    day_is_character: !1,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                })
            },
            onInit() {
                e.log("index page.js on init invoke")
            },
            build() {
                this.init_view(), e.log("index page.js on ready invoke")
            },
            onDestory() {
                e.log("index page.js on destory invoke")
            }
        })
    })()
} catch (n) {
    console.log(n)
}