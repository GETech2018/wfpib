﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//////Watchface Language Sets (Uppercase)
const watchfaceLangs = {
  EN:{
    WEEKDAYS_SHORT: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
    WEEKDAYS_FULL:  ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"],
    MONTHS_SHORT:   ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"],
    MONTHS_FULL:    ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"],

    STEPSLABEL: "STEPS",
    BATTERYLABEL: "BATTERY",
    HEARTRATELABEL: "BPM",
    CALORIESLABEL: "CALORIES",
  },

  ES:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MIÉ", "JUE", "VIE", "SÁB", "DOM"],
    WEEKDAYS_FULL:  ["LUNES", "MARTES", "MIÉRCOLES", "JUEVES", "VIERNES", "SÁBADO", "DOMINGO"],
    MONTHS_SHORT:   ["ENE", "FEB", "MAR", "ABR", "MAY", "JUN", "JUL", "AGO", "SEP", "OCT", "NOV", "DIC"],
    MONTHS_FULL:    ["ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"],

    STEPSLABEL: "PASOS",
    BATTERYLABEL: "BATERÍA",
    HEARTRATELABEL: "BPM",
    CALORIESLABEL: "CALORÍAS",
  },

  IT:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MER", "GIO", "VEN", "SAB", "DOM"],
    WEEKDAYS_FULL:  ["LUNEDÌ", "MARTEDÌ", "MERCOLEDÌ", "GIOVEDÌ", "VENERDÌ", "SABATO", "DOMENICA"],
    MONTHS_SHORT:   ["GEN", "FEB", "MAR", "APR", "MAG", "GIU", "LUG", "AGO", "SET", "OTT", "NOV", "DIC"],
    MONTHS_FULL:    ["GENNAIO", "FEBBRAIO", "MARZO", "APRILE", "MAGGIO", "GIUGNO", "LUGLIO", "AGOSTO", "SETTEMBRE", "OTTOBRE", "NOVEMBRE", "DICEMBRE"],

    STEPSLABEL: "PASSI",
    BATTERYLABEL: "BATTERIA",
    HEARTRATELABEL: "BPM",
    CALORIESLABEL: "CALORIE",
  },

  PT:{
    WEEKDAYS_SHORT: ["SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM"],
    WEEKDAYS_FULL:  ["SEGUNDA-FEIRA", "TERÇA-FEIRA", "QUARTA-FEIRA", "QUINTA-FEIRA", "SEXTA-FEIRA", "SÁBADO", "DOMINGO"],
    MONTHS_SHORT:   ["JAN", "FEV", "MAR", "ABR", "MAI", "JUN", "JUL", "AGO", "SET", "OUT", "NOV", "DEZ"],
    MONTHS_FULL:    ["JANEIRO", "FEVEREIRO", "MARÇO", "ABRIL", "MAIO", "JUNHO", "JULHO", "AGOSTO", "SETEMBRO", "OUTUBRO", "NOVEMBRO", "DEZEMBRO"],

    STEPSLABEL: "PASSOS",
    BATTERYLABEL: "BATERIA",
    HEARTRATELABEL: "BPM",
    CALORIESLABEL: "CALORIAS",
  },

  FR:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MER", "JEU", "VEN", "SAM", "DIM"],
    WEEKDAYS_FULL:  ["LUNDI", "MARDI", "MERCREDI", "JEUDI", "VENDREDI", "SAMEDI", "DIMANCHE"],
    MONTHS_SHORT:   ["JAN", "FÉV", "MAR", "AVR", "MAI", "JUN", "JUI", "AOÛ", "SEP", "OCT", "NOV", "DÉC"],
    MONTHS_FULL:    ["JANVIER", "FÉVRIER", "MARS", "AVRIL", "MAI", "JUIN", "JUILLET", "AOÛT", "SEPTEMBRE", "OCTOBRE", "NOVEMBRE", "DÉCEMBRE"],

    STEPSLABEL: "PAS",
    BATTERYLABEL: "BATTERIE",
    HEARTRATELABEL: "BPM",
    CALORIESLABEL: "CALORIES",
  },

  DE:{
    WEEKDAYS_SHORT: ["MON", "DIE", "MIT", "DON", "FRE", "SAM", "SON"],
    WEEKDAYS_FULL:  ["MONTAG", "DIENSTAG", "MITTWOCH", "DONNERSTAG", "FREITAG", "SAMSTAG", "SONNTAG"],
    MONTHS_SHORT:   ["JAN", "FEB", "MÄR", "APR", "MAI", "JUN", "JUL", "AUG", "SEP", "OKT", "NOV", "DEZ"],
    MONTHS_FULL:    ["JANUAR", "FEBRUAR", "MÄRZ", "APRIL", "MAI", "JUNI", "JULI", "AUGUST", "SEPTEMBER", "OKTOBER", "NOVEMBER", "DEZEMBER"],

    STEPSLABEL: "SCHRITTE",
    BATTERYLABEL: "BATTERIE",
    HEARTRATELABEL: "BPM",
    CALORIESLABEL: "KALORIEN",
  },
};
let currWatchfaceLang;

const colorsSet = [
    "BLUE", "CYAN", "TURQUOISE", "GREEN", "YELLOW", "ORANGE", "RED", "VIOLET", "PINK", "GRAY"
];

let colorIndex = 0;
let currColor = colorsSet[colorIndex];
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_time_pointer_smooth_second = ''
        let normal_image_img = ''
        let normal_heart_rate_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_image_img = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let idle_time_hour_min_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SF-Compact-Rounded-Bold.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 322,
              h: 34,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF-Compact-Rounded-Bold.ttf; FontSize: 26; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 31,
              h: 31,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF-Compact-Rounded-Bold.ttf; FontSize: 34
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 456,
              h: 48,
              text_size: 34,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

function detectLanguage() {
    const currLangIndex = hmSetting.getLanguage();
    let currLangCode = "EN"; // Default (English)

    switch (currLangIndex) { //List of available languages on ZeppOS
        case 0:  currLangCode = "ZH"; break; // Chinese (Simplified)
        case 1:  currLangCode = "ZH"; break; // Chinese (Traditional)
        case 2:  currLangCode = "EN"; break; // English
        case 3:  currLangCode = "ES"; break; // Spanish
        case 4:  currLangCode = "RU"; break; // Russian
        case 5:  currLangCode = "KO"; break; // Korean
        case 6:  currLangCode = "FR"; break; // French
        case 7:  currLangCode = "DE"; break; // German
        case 8:  currLangCode = "ID"; break; // Indonesian
        case 9:  currLangCode = "PL"; break; // Polish
        case 10: currLangCode = "IT"; break; // Italian
        case 11: currLangCode = "JA"; break; // Japanese
        case 12: currLangCode = "TH"; break; // Thai
        case 13: currLangCode = "AR"; break; // Arabic
        case 14: currLangCode = "VI"; break; // Vietnamese
        case 15: currLangCode = "PT"; break; // Portuguese (Portugal)
        case 16: currLangCode = "NL"; break; // Dutch
        case 17: currLangCode = "TR"; break; // Turkish
        case 18: currLangCode = "UK"; break; // Ukrainian
        case 19: currLangCode = "HE"; break; // Hebrew
        case 20: currLangCode = "PT"; break; // Portuguese (Brazil)
        case 21: currLangCode = "RO"; break; // Romanian
        case 22: currLangCode = "CS"; break; // Czech
        case 23: currLangCode = "EL"; break; // Greek
        case 24: currLangCode = "SR"; break; // Serbian
        case 25: currLangCode = "CA"; break; // Catalan
        case 26: currLangCode = "FI"; break; // Finnish
        case 27: currLangCode = "NO"; break; // Norwegian
        case 28: currLangCode = "DA"; break; // Danish
        case 29: currLangCode = "SV"; break; // Swedish
        case 30: currLangCode = "HU"; break; // Hungarian
        case 31: currLangCode = "MS"; break; // Malay
        case 32: currLangCode = "SK"; break; // Slovak
        case 33: currLangCode = "HI"; break; // Hindi
    }
    currWatchfaceLang = watchfaceLangs[currLangCode] || watchfaceLangs.EN;
}
detectLanguage();
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BACKGROUND_BLUE.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_HR_BLUE.png',
              // center_x: 195,
              // center_y: 225,
              // x: 25,
              // y: 195,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 25,
              pos_y: 225 - 195,
              center_x: 195,
              center_y: 225,
              src: 'HAND_HR_BLUE.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_MINS_BLUE.png',
              // center_x: 195,
              // center_y: 225,
              // x: 25,
              // y: 195,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 25,
              pos_y: 225 - 195,
              center_x: 195,
              center_y: 225,
              src: 'HAND_MINS_BLUE.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_SECS_BLUE.png',
              // center_x: 195,
              // center_y: 225,
              // x: 25,
              // y: 200,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'HAND_SECS_BLUE.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 25,
              second_posY: 200,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'FOREGROUND_BLUE.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 10,
              y: 92,
              w: 80,
              h: 50,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 32,
              y: 380,
              w: 80,
              h: 50,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 206,
              y: 230,
              w: 150,
              h: 90,
              text_size: 26,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              // unit_end: 1,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 206,
              y: 197,
              w: 150,
              h: 90,
              text_size: 34,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 312,
              y: 60,
              image_array: ["WEATHERICON_1.png","WEATHERICON_2.png","WEATHERICON_3.png","WEATHERICON_4.png","WEATHERICON_5.png","WEATHERICON_6.png","WEATHERICON_7.png","WEATHERICON_8.png","WEATHERICON_9.png","WEATHERICON_10.png","WEATHERICON_11.png","WEATHERICON_12.png","WEATHERICON_13.png","WEATHERICON_14.png","WEATHERICON_15.png","WEATHERICON_16.png","WEATHERICON_17.png","WEATHERICON_18.png","WEATHERICON_19.png","WEATHERICON_20.png","WEATHERICON_21.png","WEATHERICON_22.png","WEATHERICON_23.png","WEATHERICON_24.png","WEATHERICON_25.png","WEATHERICON_26.png","WEATHERICON_27.png","WEATHERICON_28.png","WEATHERICON_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 287,
              y: 92,
              w: 80,
              h: 30,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_HR_AOD.png',
              // center_x: 195,
              // center_y: 225,
              // x: 25,
              // y: 195,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 25,
              pos_y: 225 - 195,
              center_x: 195,
              center_y: 225,
              src: 'HAND_HR_AOD.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_MINS_AOD.png',
              // center_x: 195,
              // center_y: 225,
              // x: 25,
              // y: 195,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 25,
              pos_y: 225 - 195,
              center_x: 195,
              center_y: 225,
              src: 'HAND_MINS_AOD.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'FG_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 206,
              y: 230,
              w: 150,
              h: 90,
              text_size: 26,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              // unit_end: 1,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 206,
              y: 197,
              w: 150,
              h: 90,
              text_size: 34,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

let iconsOVerlay = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: "ICONS_OVERLAY.png",
    show_level: hmUI.show_level.ONLY_NORMAL,
})
            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 55,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 276,
              y: 38,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 22,
              y: 340,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 270,
              y: 332,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'MusicCommonScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 180,
              w: 110,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 235,
              w: 110,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 170,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                showSettings()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let prevColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 0,
    y: 34,
    w: 134,
    h: 382,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/EDGEBTN_PREV_PRESSED.png',
    normal_src: 'settings/EDGEBTN_PREV_NORMAL.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    click_func: (button_widget) => {
    prevColor()
    }, // end func
}); // end button

let nextColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 256,
    y: 34,
    w: 134,
    h: 382,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/EDGEBTN_NEXT_PRESSED.png',
    normal_src: 'settings/EDGEBTN_NEXT_NORMAL.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    click_func: (button_widget) => {
    nextColor()
    }, // end func
}); // end button

let Confirmbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 135,
    y: 340,
    w: 120,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_CONFIRM_PRESSED.png',
    normal_src: 'settings/BTN_CONFIRM_NORMAL.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
    click_func: (button_widget) => {
    hideSettings()
    }, // end func
}); // end button

// functions to change colors
function prevColor(){
    colorIndex = (colorIndex - 1 + colorsSet.length) % colorsSet.length;
    updateWatchface();
}

function nextColor(){
    colorIndex = (colorIndex + 1) % colorsSet.length;
    updateWatchface();
}

function updateWatchface(){
    // Set new color for elements
    currColor = colorsSet[colorIndex];
    let currBG_SRC = "BACKGROUND_" + currColor + ".png";
    let currFG_SRC = "FOREGROUND_" + currColor + ".png";
    let currHANDhr_SRC = "HAND_HR_" + currColor + ".png";
    let currHANDmin_SRC = "HAND_MINS_" + currColor + ".png";
    let currHANDsec_SRC = "HAND_SECS_" + currColor + ".png";

    // Get current angles
    let currHANDhr_angle = normal_analog_clock_pro_hour_pointer_img.getProperty(hmUI.prop.ANGLE);
    let currHANDmin_angle = normal_analog_clock_pro_minute_pointer_img.getProperty(hmUI.prop.ANGLE);

    // Set background and foreground
    normal_background_bg_img.setProperty(hmUI.prop.SRC, currBG_SRC);
    normal_image_img.setProperty(hmUI.prop.SRC, currFG_SRC);

    normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.MORE, {
        x: 0,
        y: 0,
        w: deviceInfo.width,
        h: deviceInfo.height,
        pos_x: 195 - 25,
        pos_y: 225 - 195,
        center_x: 195,
        center_y: 225,
        src: currHANDhr_SRC,
        angle: currHANDhr_angle,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.MORE, {
        x: 0,
        y: 0,
        w: deviceInfo.width,
        h: deviceInfo.height,
        pos_x: 195 - 25,
        pos_y: 225 - 195,
        center_x: 195,
        center_y: 225,
        src: currHANDmin_SRC,
        angle: currHANDmin_angle,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.MORE, {
        second_path: currHANDsec_SRC,
        second_centerX: 195,
        second_centerY: 225,
        second_posX: 25,
        second_posY: 200,
        fresh_frequency: 15,
        fresh_freqency: 15,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
}

function hideSettings(){
    // normal buttons
    Button_1.setProperty(hmUI.prop.VISIBLE, true);
    Button_2.setProperty(hmUI.prop.VISIBLE, true);
    Button_3.setProperty(hmUI.prop.VISIBLE, true);
    Button_4.setProperty(hmUI.prop.VISIBLE, true);
    Button_5.setProperty(hmUI.prop.VISIBLE, true); //Menu button
    
    // settings layout
    prevColorbtn.setProperty(hmUI.prop.VISIBLE, false);
    nextColorbtn.setProperty(hmUI.prop.VISIBLE, false);
    Confirmbtn.setProperty(hmUI.prop.VISIBLE, false);
}
hideSettings();

function showSettings(){
    // normal buttons
    Button_1.setProperty(hmUI.prop.VISIBLE, false); 
    Button_2.setProperty(hmUI.prop.VISIBLE, false);
    Button_3.setProperty(hmUI.prop.VISIBLE, false);
    Button_4.setProperty(hmUI.prop.VISIBLE, false);
    Button_5.setProperty(hmUI.prop.VISIBLE, false); //Menu button
    
    // settings layout
    prevColorbtn.setProperty(hmUI.prop.VISIBLE, true);
    nextColorbtn.setProperty(hmUI.prop.VISIBLE, true);
    Confirmbtn.setProperty(hmUI.prop.VISIBLE, true);
}
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) { // Hour Pointer
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              
              console.log('full date font normal');
              if (updateHour) {
                let normal_DOW_Str = currWatchfaceLang.WEEKDAYS_SHORT[timeSensor.week-1];
                let normal_dayStr = timeSensor.day.toString();
                
                let fullDate_Str = normal_DOW_Str + " " + normal_dayStr;
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, fullDate_Str);
              };

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0');
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              if (updateMinute) { // Hour Pointer
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) { // Minute Pointer
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

              console.log('full date font idle');
              if (updateHour) {
                let idle_DOW_Str = currWatchfaceLang.WEEKDAYS_SHORT[timeSensor.week-1];
                let idle_dayStr = timeSensor.day.toString();

                let fullDate_idleStr = idle_DOW_Str + " " + idle_dayStr;
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, fullDate_idleStr);
              };

              console.log('hour:min font');
              if (updateMinute) {
                let idle_HourMinStr = format_hour.toString();
                idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0');
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr );
              };
            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}