﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_date_img_date_day = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['JAN', 'FEB', 'MRT', 'APR', 'MEI', 'JUN', 'JUL', 'AUG', 'SEP', 'OKT', 'NOV', 'DEC', ];
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_heart_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: ndot-47-inspired-by-nothing.ttf; FontSize: 30; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 36,
              h: 36,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/ndot-47-inspired-by-nothing.ttf',
              color: 0xFFF0FF19,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bk02EN.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 49,
              y: 388,
              image_array: ["IC01.png","IC02.png","IC03.png","IC04.png","IC05.png","IC06.png","IC07.png","IC08.png","IC09.png","IC10.png","IC11.png","IC12.png","IC13.png","IC14.png","IC15.png","IC16.png","IC17.png","IC18.png","IC19.png","IC20.png","IC21.png","IC22.png","IC23.png","IC24.png","IC25.png","IC26.png","IC27.png","IC28.png","IC29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 409,
              font_array: ["TEMP0.png","TEMP1.png","TEMP2.png","TEMP3.png","TEMP4.png","TEMP5.png","TEMP6.png","TEMP7.png","TEMP8.png","TEMP9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'PUNTOGRADO.png',
              unit_tc: 'PUNTOGRADO.png',
              unit_en: 'PUNTOGRADO.png',
              negative_image: 'negativili.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 18,
              y: 340,
              src: 'lock_closed.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 54,
              y: 336,
              src: 'dnd_on.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 152,
              y: 340,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 106,
              y: 342,
              src: 'alarm_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 24,
              y: 12,
              w: 150,
              h: 35,
              text_size: 30,
              char_space: 0,
              font: 'fonts/ndot-47-inspired-by-nothing.ttf',
              color: 0xFFF0FF19,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 91,
              day_startY: 22,
              day_sc_array: ["d2_0.png","d2_1.png","d2_2.png","d2_3.png","d2_4.png","d2_5.png","d2_6.png","d2_7.png","d2_8.png","d2_9.png"],
              day_tc_array: ["d2_0.png","d2_1.png","d2_2.png","d2_3.png","d2_4.png","d2_5.png","d2_6.png","d2_7.png","d2_8.png","d2_9.png"],
              day_en_array: ["d2_0.png","d2_1.png","d2_2.png","d2_3.png","d2_4.png","d2_5.png","d2_6.png","d2_7.png","d2_8.png","d2_9.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 143,
              y: 12,
              w: 150,
              h: 38,
              text_size: 30,
              char_space: 0,
              font: 'fonts/ndot-47-inspired-by-nothing.ttf',
              color: 0xFFF0FF19,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: JAN, FEB, MRT, APR, MEI, JUN, JUL, AUG, SEP, OKT, NOV, DEC,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291,
              y: 371,
              font_array: ["pul_0.png","pul_1.png","pul_2.png","pul_3.png","pul_4.png","pul_5.png","pul_6.png","pul_7.png","pul_8.png","pul_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 211,
              font_array: ["dist_0.png","dist_1.png","dist_2.png","dist_3.png","dist_4.png","dist_5.png","dist_6.png","dist_7.png","dist_8.png","dist_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'KM.png',
              unit_tc: 'KM.png',
              unit_en: 'KM.png',
              imperial_unit_sc: 'MI.png',
              imperial_unit_tc: 'MI.png',
              imperial_unit_en: 'MI.png',
              dot_image: 'punto_2.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 264,
              y: 297,
              font_array: ["bat_0.png","bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'bat_percent.png',
              unit_tc: 'bat_percent.png',
              unit_en: 'bat_percent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 131,
              font_array: ["pas_0.png","pas_1.png","pas_2.png","pas_3.png","pas_4.png","pas_5.png","pas_6.png","pas_7.png","pas_8.png","pas_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 53,
              font_array: ["cal_0.png","cal_1.png","cal_2.png","cal_3.png","cal_4.png","cal_5.png","cal_6.png","cal_7.png","cal_8.png","cal_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 27,
              am_y: 187,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 27,
              pm_y: 187,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 72,
              hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              hour_zero: 1,
              hour_space: 16,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 21,
              minute_startY: 225,
              minute_array: ["MIN0.png","MIN1.png","MIN2.png","MIN3.png","MIN4.png","MIN5.png","MIN6.png","MIN7.png","MIN8.png","MIN9.png"],
              minute_zero: 1,
              minute_space: 16,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'NOTHING_V2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 52,
              y: 388,
              image_array: ["icaod_IC01_01.png","icaod_IC02_02.png","icaod_IC03_03.png","icaod_IC04_04.png","icaod_IC05_05.png","icaod_IC06_06.png","icaod_IC07_07.png","icaod_IC08_08.png","icaod_IC09_09.png","icaod_IC10_10.png","icaod_IC11_11.png","icaod_IC12_12.png","icaod_IC13_13.png","icaod_IC14_14.png","icaod_IC15_15.png","icaod_IC16_16.png","icaod_IC17_17.png","icaod_IC18_18.png","icaod_IC19_19.png","icaod_IC20_20.png","icaod_IC21_21.png","icaod_IC22_22.png","icaod_IC23_23.png","icaod_IC24_24.png","icaod_IC25_25.png","icaod_IC26_26.png","icaod_IC27_27.png","icaod_IC28_28.png","icaod_IC29_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 409,
              font_array: ["adist_0.png","adist_1.png","adist_2.png","adist_3.png","adist_4.png","adist_5.png","adist_6.png","adist_7.png","adist_8.png","adist_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'icaod_PUNTOGRADO_.png',
              unit_tc: 'icaod_PUNTOGRADO_.png',
              unit_en: 'icaod_PUNTOGRADO_.png',
              imperial_unit_sc: 'icaod_PUNTOGRADO_.png',
              imperial_unit_tc: 'icaod_PUNTOGRADO_.png',
              imperial_unit_en: 'icaod_PUNTOGRADO_.png',
              negative_image: 'icaod_negativili_.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 120,
                y: 409,
                font_array: ["adist_0.png","adist_1.png","adist_2.png","adist_3.png","adist_4.png","adist_5.png","adist_6.png","adist_7.png","adist_8.png","adist_9.png"],
                padding: false,
                h_space: 5,
                unit_sc: 'icaod_PUNTOGRADO_.png',
                unit_tc: 'icaod_PUNTOGRADO_.png',
                unit_en: 'icaod_PUNTOGRADO_.png',
                imperial_unit_sc: 'icaod_PUNTOGRADO_.png',
                imperial_unit_tc: 'icaod_PUNTOGRADO_.png',
                imperial_unit_en: 'icaod_PUNTOGRADO_.png',
                negative_image: 'icaod_negativili_.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 18,
              y: 340,
              src: 'lock_closed.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 54,
              y: 336,
              src: 'dnd_on.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 152,
              y: 340,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 106,
              y: 342,
              src: 'alarm_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 29,
              y: 27,
              week_en: ["X_01.png","X_02.png","X_03.png","X_04.png","X_05.png","X_06.png","X_07.png"],
              week_tc: ["X_01.png","X_02.png","X_03.png","X_04.png","X_05.png","X_06.png","X_07.png"],
              week_sc: ["X_01.png","X_02.png","X_03.png","X_04.png","X_05.png","X_06.png","X_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 89,
              day_startY: 22,
              day_sc_array: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png"],
              day_tc_array: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png"],
              day_en_array: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 139,
              month_startY: 27,
              month_sc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_tc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_en_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291,
              y: 371,
              font_array: ["adist_0.png","adist_1.png","adist_2.png","adist_3.png","adist_4.png","adist_5.png","adist_6.png","adist_7.png","adist_8.png","adist_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 211,
              font_array: ["adist_0.png","adist_1.png","adist_2.png","adist_3.png","adist_4.png","adist_5.png","adist_6.png","adist_7.png","adist_8.png","adist_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'aKM.png',
              unit_tc: 'aKM.png',
              unit_en: 'aKM.png',
              imperial_unit_sc: 'aMI.png',
              imperial_unit_tc: 'aMI.png',
              imperial_unit_en: 'aMI.png',
              dot_image: 'apunto_2.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 267,
              y: 293,
              font_array: ["adist_0.png","adist_1.png","adist_2.png","adist_3.png","adist_4.png","adist_5.png","adist_6.png","adist_7.png","adist_8.png","adist_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Abat_percent.png',
              unit_tc: 'Abat_percent.png',
              unit_en: 'Abat_percent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 131,
              font_array: ["adist_0.png","adist_1.png","adist_2.png","adist_3.png","adist_4.png","adist_5.png","adist_6.png","adist_7.png","adist_8.png","adist_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 53,
              font_array: ["adist_0.png","adist_1.png","adist_2.png","adist_3.png","adist_4.png","adist_5.png","adist_6.png","adist_7.png","adist_8.png","adist_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 27,
              am_y: 187,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 27,
              pm_y: 187,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 72,
              hour_array: ["MIN0.png","MIN1.png","MIN2.png","MIN3.png","MIN4.png","MIN5.png","MIN6.png","MIN7.png","MIN8.png","MIN9.png"],
              hour_zero: 1,
              hour_space: 16,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 21,
              minute_startY: 225,
              minute_array: ["MIN0.png","MIN1.png","MIN2.png","MIN3.png","MIN4.png","MIN5.png","MIN6.png","MIN7.png","MIN8.png","MIN9.png"],
              minute_zero: 1,
              minute_space: 16,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Desconectado,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: Conectado,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Desconectado"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Conectado"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion
            console.log('Watch_Face.Shortcuts');

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 214,
              y: 335,
              w: 166,
              h: 70,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 44,
              y: 392,
              w: 156,
              h: 52,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 16,
              y: 222,
              w: 182,
              h: 110,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 16,
              y: 68,
              w: 182,
              h: 110,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 214,
              y: 95,
              w: 156,
              h: 68,
              src: 'z_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 214,
              y: 258,
              w: 166,
              h: 70,
              src: 'z_Empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 214,
              y: 171,
              w: 170,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'z_Empty.png',
              normal_src: 'z_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 25,
              y: 10,
              w: 178,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'z_Empty.png',
              normal_src: 'z_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 15,
              y: 340,
              w: 178,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'z_Empty.png',
              normal_src: 'z_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}