try{(()=>{var __$$app$$__=__$$hmAppManager$$__.currentApp;var __$$module$$__=__$$app$$__.current;var e=new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__,__$$module$$__),"ola");"use strict";
__$$module$$__.module=DeviceRuntimeCore.WatchFace({
init_view(){
const N=hmUI.show_level.ONLY_NORMAL, AOD=hmUI.show_level.ONLY_AOD, DT=hmUI.data_type, L=hmUI.align.LEFT;
const safe=(f)=>{try{f()}catch(err){console.log(err)}};
const img=(x,y,w,h,src,lv)=>safe(()=>hmUI.createWidget(hmUI.widget.IMG,{x:x,y:y,w:w,h:h,src:src,show_level:lv||N}));
img(0,0,390,450,"0001.png");
safe(()=>hmUI.createWidget(hmUI.widget.IMG_LEVEL,{x:246,y:404,image_array:["0020.png", "0021.png", "0022.png", "0023.png", "0024.png"],image_length:5,type:DT.BATTERY,show_level:N}));
safe(()=>hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:286,y:398,w:62,h:30,font_array:["0009.png", "0010.png", "0011.png", "0012.png", "0013.png", "0014.png", "0015.png", "0016.png", "0017.png", "0018.png"],h_space:0,align_h:L,type:DT.BATTERY,unit_sc:"0019.png",unit_tc:"0019.png",unit_en:"0019.png",show_level:N}));
safe(()=>hmUI.createWidget(hmUI.widget.TIME_POINTER,{
 hour_centerX:192,hour_centerY:204,hour_posX:12,hour_posY:92,hour_path:"0004.png",
 minute_centerX:192,minute_centerY:204,minute_posX:12,minute_posY:144,minute_path:"0003.png",
 second_centerX:192,second_centerY:204,second_posX:6,second_posY:174,second_path:"0005.png",show_level:N}));
img(181,193,22,22,"0008.png");
img(0,0,390,450,"0002.png",AOD);
safe(()=>hmUI.createWidget(hmUI.widget.TIME_POINTER,{
 hour_centerX:192,hour_centerY:204,hour_posX:12,hour_posY:92,hour_path:"0007.png",
 minute_centerX:192,minute_centerY:204,minute_posX:12,minute_posY:144,minute_path:"0006.png",show_level:AOD}));
},
onInit(){this.init_view()},onReady(){},onShow(){},onHide(){},onDestroy(){}
})})()}catch(e){console.log(e)}
