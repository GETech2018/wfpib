﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '0_fundo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 281,
              y: 375,
              src: '9_lock_on.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 211,
              y: 375,
              src: '9_mute_on.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 70,
              y: 375,
              src: '8_blue_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 140,
              y: 375,
              src: '9_alarm_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 250,
              y: 65,
              image_array: ["5_batt01.png","5_batt02.png","5_batt03.png","5_batt04.png","5_batt05.png","5_batt06.png","5_batt07.png","5_batt08.png","5_batt09.png","5_batt10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 301,
              month_startY: 235,
              month_sc_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              month_tc_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              month_en_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 246,
              day_startY: 235,
              day_sc_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              day_tc_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              day_en_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 258,
              y: 187,
              week_en: ["4_week2.png","4_week3.png","4_week4.png","4_week5.png","4_week6.png","4_week7.png","4_week8.png"],
              week_tc: ["4_week2.png","4_week3.png","4_week4.png","4_week5.png","4_week6.png","4_week7.png","4_week8.png"],
              week_sc: ["4_week2.png","4_week3.png","4_week4.png","4_week5.png","4_week6.png","4_week7.png","4_week8.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 56,
              am_y: 301,
              am_sc_path: '6_am.png',
              am_en_path: '6_am.png',
              pm_x: 56,
              pm_y: 301,
              pm_sc_path: '7_pm.png',
              pm_en_path: '7_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 95,
              hour_startY: 301,
              hour_array: ["1_hrs0.png","1_hrs1.png","1_hrs2.png","1_hrs3.png","1_hrs4.png","1_hrs5.png","1_hrs6.png","1_hrs7.png","1_hrs8.png","1_hrs9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 185,
              minute_startY: 301,
              minute_array: ["1_hrs0.png","1_hrs1.png","1_hrs2.png","1_hrs3.png","1_hrs4.png","1_hrs5.png","1_hrs6.png","1_hrs7.png","1_hrs8.png","1_hrs9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 275,
              second_startY: 319,
              second_array: ["2_sec0.png","2_sec1.png","2_sec2.png","2_sec3.png","2_sec4.png","2_sec5.png","2_sec6.png","2_sec7.png","2_sec8.png","2_sec9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '10_pointer_hs.png',
              hour_centerX: 131,
              hour_centerY: 149,
              hour_posX: 3,
              hour_posY: 82,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '10_pointer_min.png',
              minute_centerX: 131,
              minute_centerY: 149,
              minute_posX: 3,
              minute_posY: 82,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '10_pointer_sec.png',
              second_centerX: 131,
              second_centerY: 149,
              second_posX: 3,
              second_posY: 82,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '0_fundo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 281,
              y: 375,
              src: '9_lock_on.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 211,
              y: 375,
              src: '9_mute_on.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 70,
              y: 375,
              src: '8_blue_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 140,
              y: 375,
              src: '9_alarm_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 250,
              y: 65,
              image_array: ["5_batt01.png","5_batt02.png","5_batt03.png","5_batt04.png","5_batt05.png","5_batt06.png","5_batt07.png","5_batt08.png","5_batt09.png","5_batt10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 301,
              month_startY: 235,
              month_sc_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              month_tc_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              month_en_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 246,
              day_startY: 235,
              day_sc_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              day_tc_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              day_en_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 258,
              y: 187,
              week_en: ["4_week2.png","4_week3.png","4_week4.png","4_week5.png","4_week6.png","4_week7.png","4_week8.png"],
              week_tc: ["4_week2.png","4_week3.png","4_week4.png","4_week5.png","4_week6.png","4_week7.png","4_week8.png"],
              week_sc: ["4_week2.png","4_week3.png","4_week4.png","4_week5.png","4_week6.png","4_week7.png","4_week8.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 56,
              am_y: 301,
              am_sc_path: '6_am.png',
              am_en_path: '6_am.png',
              pm_x: 56,
              pm_y: 301,
              pm_sc_path: '7_pm.png',
              pm_en_path: '7_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 95,
              hour_startY: 301,
              hour_array: ["1_hrs0.png","1_hrs1.png","1_hrs2.png","1_hrs3.png","1_hrs4.png","1_hrs5.png","1_hrs6.png","1_hrs7.png","1_hrs8.png","1_hrs9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 185,
              minute_startY: 301,
              minute_array: ["1_hrs0.png","1_hrs1.png","1_hrs2.png","1_hrs3.png","1_hrs4.png","1_hrs5.png","1_hrs6.png","1_hrs7.png","1_hrs8.png","1_hrs9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 275,
              second_startY: 319,
              second_array: ["2_sec0.png","2_sec1.png","2_sec2.png","2_sec3.png","2_sec4.png","2_sec5.png","2_sec6.png","2_sec7.png","2_sec8.png","2_sec9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '10_pointer_hs.png',
              hour_centerX: 131,
              hour_centerY: 149,
              hour_posX: 3,
              hour_posY: 82,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '10_pointer_min.png',
              minute_centerX: 131,
              minute_centerY: 149,
              minute_posX: 3,
              minute_posY: 82,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '10_pointer_sec.png',
              second_centerX: 131,
              second_centerY: 149,
              second_posX: 3,
              second_posY: 82,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}