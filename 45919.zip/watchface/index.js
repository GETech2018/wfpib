try{(()=>{var __$$app$$__=__$$hmAppManager$$__.currentApp;var __$$module$$__=__$$app$$__.current;var e=new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__,__$$module$$__),"navidad");"use strict";
__$$module$$__.module=DeviceRuntimeCore.WatchFace({
init_view(){
const N=hmUI.show_level.ONLY_NORMAL, AOD=hmUI.show_level.ONLY_AOD, DT=hmUI.data_type, L=hmUI.align.LEFT, CH=hmUI.align.CENTER_H;
const safe=(f)=>{try{f()}catch(err){console.log(err)}};
const img=(x,y,w,h,src,lv)=>safe(()=>hmUI.createWidget(hmUI.widget.IMG,{x:x,y:y,w:w,h:h,src:src,show_level:lv||N}));
const level=(x,y,arr,type)=>safe(()=>hmUI.createWidget(hmUI.widget.IMG_LEVEL,{x:x,y:y,image_array:arr,image_length:arr.length,type:type,show_level:N}));
const text=(x,y,w,h,arr,type,al,extra)=>safe(()=>hmUI.createWidget(hmUI.widget.TEXT_IMG,Object.assign({x:x,y:y,w:w,h:h,font_array:arr,h_space:0,align_h:al,type:type,show_level:N},extra||{})));
const un=(u)=>({unit_sc:u,unit_tc:u,unit_en:u,imperial_unit_sc:u,imperial_unit_tc:u,imperial_unit_en:u});
const NUM=["0025.png", "0026.png", "0027.png", "0028.png", "0029.png", "0030.png", "0031.png", "0032.png", "0033.png", "0034.png"], DG=["0035.png", "0036.png", "0037.png", "0038.png", "0039.png", "0040.png", "0041.png", "0042.png", "0043.png", "0044.png"];
img(0,0,390,450,"0106.png");
level(28,250,["0084.png", "0085.png", "0086.png", "0087.png", "0088.png", "0089.png", "0090.png", "0091.png", "0092.png", "0093.png", "0094.png"],DT.STEP);
level(266,250,["0095.png", "0096.png", "0097.png", "0098.png", "0099.png", "0100.png", "0101.png", "0102.png", "0103.png", "0104.png", "0105.png"],DT.BATTERY);
safe(()=>hmUI.createWidget(hmUI.widget.IMG_TIME,{
 hour_startX:77,hour_startY:68,hour_array:["0001.png", "0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png"],hour_zero:1,hour_space:0,hour_align:L,
 minute_startX:197,minute_startY:68,minute_array:["0001.png", "0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png"],minute_zero:1,minute_space:0,minute_align:L,
 am_x:305,am_y:80,am_sc_path:"0023.png",am_tc_path:"0023.png",am_en_path:"0023.png",
 pm_x:305,pm_y:80,pm_sc_path:"0024.png",pm_tc_path:"0024.png",pm_en_path:"0024.png",show_level:N}));
img(181,68,16,92,"0021.png");
safe(()=>hmUI.createWidget(hmUI.widget.IMG_WEEK,{x:92,y:40,week_en:["0055.png", "0056.png", "0057.png", "0058.png", "0059.png", "0060.png", "0061.png"],week_tc:["0055.png", "0056.png", "0057.png", "0058.png", "0059.png", "0060.png", "0061.png"],week_sc:["0055.png", "0056.png", "0057.png", "0058.png", "0059.png", "0060.png", "0061.png"],show_level:N}));
safe(()=>hmUI.createWidget(hmUI.widget.IMG_DATE,{
 month_startX:178,month_startY:40,month_sc_array:["0062.png", "0063.png", "0064.png", "0065.png", "0066.png", "0067.png", "0068.png", "0069.png", "0070.png", "0071.png", "0072.png", "0073.png"],month_tc_array:["0062.png", "0063.png", "0064.png", "0065.png", "0066.png", "0067.png", "0068.png", "0069.png", "0070.png", "0071.png", "0072.png", "0073.png"],month_en_array:["0062.png", "0063.png", "0064.png", "0065.png", "0066.png", "0067.png", "0068.png", "0069.png", "0070.png", "0071.png", "0072.png", "0073.png"],month_is_character:true,month_align:L,
 day_startX:242,day_startY:41,day_sc_array:["0045.png", "0046.png", "0047.png", "0048.png", "0049.png", "0050.png", "0051.png", "0052.png", "0053.png", "0054.png"],day_tc_array:["0045.png", "0046.png", "0047.png", "0048.png", "0049.png", "0050.png", "0051.png", "0052.png", "0053.png", "0054.png"],day_en_array:["0045.png", "0046.png", "0047.png", "0048.png", "0049.png", "0050.png", "0051.png", "0052.png", "0053.png", "0054.png"],day_zero:0,day_space:0,day_align:L,show_level:N}));
text(21,214,110,32,NUM,DT.STEP,CH);
text(21,296,110,32,NUM,DT.HEART,CH,{invalid_image:"0075.png"});
text(259,214,110,32,NUM,DT.BATTERY,CH,un("0079.png"));
text(259,296,110,32,NUM,DT.WEATHER_CURRENT,CH,Object.assign({negative_image:"0076.png",invalid_image:"0075.png"},un("0078.png")));
// cuenta regresiva a Navidad
(function(){
var CD=["0035.png", "0036.png", "0037.png", "0038.png", "0039.png", "0040.png", "0041.png", "0042.png", "0043.png", "0044.png"], DIAS="0080.png", DIA="0081.png", BL="0082.png", GR="0083.png";
var slots=[], word=null, greet=null, tm=null;
for(var i=0;i<3;i++){try{slots.push(hmUI.createWidget(hmUI.widget.IMG,{x:0,y:344,w:24,h:36,src:BL,show_level:N}))}catch(err){console.log(err)}}
try{word=hmUI.createWidget(hmUI.widget.IMG,{x:222,y:344,w:52,h:36,src:DIAS,show_level:N})}catch(err){console.log(err)}
try{greet=hmUI.createWidget(hmUI.widget.IMG,{x:36,y:338,w:318,h:56,src:BL,show_level:N})}catch(err){console.log(err)}
try{tm=hmSensor.createSensor(hmSensor.id.TIME)}catch(err){console.log(err)}
var set=function(w,o){try{w.setProperty(hmUI.prop.MORE,o)}catch(err){try{if(o.src)w.setProperty(hmUI.prop.SRC,o.src)}catch(e2){}}};
var up=function(){try{
 var d=new Date(), t0=new Date(d.getFullYear(),d.getMonth(),d.getDate()), xm=new Date(d.getFullYear(),11,25);
 if(t0.getTime()>xm.getTime())xm=new Date(d.getFullYear()+1,11,25);
 var n=Math.round((xm.getTime()-t0.getTime())/86400000);
 if(n===0){set(greet,{x:36,y:338,w:318,h:56,src:GR});for(var k=0;k<3;k++)set(slots[k],{x:0,y:344,w:24,h:36,src:BL});set(word,{x:222,y:344,w:52,h:36,src:BL});return}
 set(greet,{x:36,y:338,w:318,h:56,src:BL});
 var s=String(n), x=214-24*s.length;
 for(var j=0;j<3;j++){ if(j<s.length){set(slots[j],{x:x+24*j,y:344,w:24,h:36,src:CD[+s.charAt(j)]})}else{set(slots[j],{x:0,y:344,w:24,h:36,src:BL})} }
 set(word,{x:222,y:344,w:52,h:36,src:(n===1?DIA:DIAS)});
}catch(err){console.log(err)}};
up();
try{tm.addEventListener(hmSensor.event.MINUTEEND,up)}catch(err){}
try{hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE,{resume_call:up})}catch(err){}
})();
img(0,0,390,450,"0107.png",AOD);
safe(()=>hmUI.createWidget(hmUI.widget.IMG_TIME,{
 hour_startX:77,hour_startY:68,hour_array:["0011.png", "0012.png", "0013.png", "0014.png", "0015.png", "0016.png", "0017.png", "0018.png", "0019.png", "0020.png"],hour_zero:1,hour_space:0,hour_align:L,
 minute_startX:197,minute_startY:68,minute_array:["0011.png", "0012.png", "0013.png", "0014.png", "0015.png", "0016.png", "0017.png", "0018.png", "0019.png", "0020.png"],minute_zero:1,minute_space:0,minute_align:L,show_level:AOD}));
img(181,68,16,92,"0022.png",AOD);
},
onInit(){this.init_view()},onReady(){},onShow(){},onHide(){},onDestroy(){}
})})()}catch(e){console.log(e)}
