﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let colornumber_main = 1
        let totalcolors_main = 3
        let namecolor_main = ''
        let secstring = 'hand_sec1.png'
        let minstring = 'hand_min1.png'
        let hourstring = 'hand_hour1.png'
        let censtring = 'center1.png'


        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

			if ( colornumber_main == 1) { namecolor_main = "Original"
				hourstring = "hand_hour" + parseInt(colornumber_main) + ".png"
				minstring = "hand_min" + parseInt(colornumber_main) + ".png"
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
				censtring = "center" + parseInt(colornumber_main) + ".png"
			}


			if ( colornumber_main == 2) { namecolor_main = "Yellow"
				hourstring = "hand_hour" + parseInt(colornumber_main) + ".png"
				minstring = "hand_min" + parseInt(colornumber_main) + ".png"
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
				censtring = "center" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main == 3) { namecolor_main = "Gray"
				hourstring = "hand_hour" + parseInt(colornumber_main) + ".png"
				minstring = "hand_min" + parseInt(colornumber_main) + ".png"
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
				censtring = "center" + parseInt(colornumber_main) + ".png"
			}

			if ( colornumber_main <= 3) { 
			
              normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              pos_x: 197 - 30,
              pos_y: 225 - 140,
              center_x: 197,
              center_y: 225,
              src: hourstring,
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
              normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              pos_x: 197 - 31,
              pos_y: 225 - 195,
              center_x: 197,
              center_y: 225,
              src: minstring,
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.MORE, {
              second_path: secstring,
              second_centerX: 197,
              second_centerY: 225,
              second_posX: 12,
              second_posY: 228,
              fresh_frequency: 15,
              fresh_freqency: 15,
              second_cover_path: censtring,
              second_cover_x: 167,
              second_cover_y: 195,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		}

            hmUI.showToast({text: namecolor_main });
         
        }
		
		

        // end user_functions.js

        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_background_bg = ''
        let idle_stress_icon_img = ''
        let idle_digital_clock_img_time = ''
        let idle_step_icon_img = ''
        let normal_heart_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_Switch_BG_Color = ''

        let bgColorIndex = 0;
        let bgColorList = [0xFF464646, 0xFF00FFFF, 0xFF80FF00, 0xFFFF00FF, 0xFFFF0000, 0xFFEC7600, 0xFF0000FF];
        let bgColorToastList = ['Original', 'Cyan', 'Green', 'Purple', 'Red', 'Orange', 'Blue'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBG_Color
            console.log('SwitchBG_Color');
            function switchBG_Color() {
              bgColorIndex++;
              if (bgColorIndex >= bgColorList.length) bgColorIndex = 0;
              hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
              let toastText = bgColorToastList[bgColorIndex].replace('%s', `${bgColorIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 136,
              hour_startY: 56,
              hour_array: ["shadow_0001.png","shadow_0002.png","shadow_0003.png","shadow_0004.png","shadow_0005.png","shadow_0006.png","shadow_0007.png","shadow_0008.png","shadow_0009.png","shadow_0010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 136,
              minute_startY: 237,
              minute_array: ["shadow_0001.png","shadow_0002.png","shadow_0003.png","shadow_0004.png","shadow_0005.png","shadow_0006.png","shadow_0007.png","shadow_0008.png","shadow_0009.png","shadow_0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 5,
              day_startY: 136,
              day_sc_array: ["Date_share_28_0001.png","Date_share_28_0002.png","Date_share_28_0003.png","Date_share_28_0004.png","Date_share_28_0005.png","Date_share_28_0006.png","Date_share_28_0007.png","Date_share_28_0008.png","Date_share_28_0009.png","Date_share_28_0010.png"],
              day_tc_array: ["Date_share_28_0001.png","Date_share_28_0002.png","Date_share_28_0003.png","Date_share_28_0004.png","Date_share_28_0005.png","Date_share_28_0006.png","Date_share_28_0007.png","Date_share_28_0008.png","Date_share_28_0009.png","Date_share_28_0010.png"],
              day_en_array: ["Date_share_28_0001.png","Date_share_28_0002.png","Date_share_28_0003.png","Date_share_28_0004.png","Date_share_28_0005.png","Date_share_28_0006.png","Date_share_28_0007.png","Date_share_28_0008.png","Date_share_28_0009.png","Date_share_28_0010.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 23,
              y: -27,
              week_en: ["Day_share_28_0001.png","Day_share_28_0002.png","Day_share_28_0003.png","Day_share_28_0004.png","Day_share_28_0005.png","Day_share_28_0006.png","Day_share_28_0007.png"],
              week_tc: ["Day_share_28_0001.png","Day_share_28_0002.png","Day_share_28_0003.png","Day_share_28_0004.png","Day_share_28_0005.png","Day_share_28_0006.png","Day_share_28_0007.png"],
              week_sc: ["Day_share_28_0001.png","Day_share_28_0002.png","Day_share_28_0003.png","Day_share_28_0004.png","Day_share_28_0005.png","Day_share_28_0006.png","Day_share_28_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_hour1.png',
              // center_x: 197,
              // center_y: 225,
              // x: 30,
              // y: 140,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 197 - 30,
              pos_y: 225 - 140,
              center_x: 197,
              center_y: 225,
              src: 'hand_hour1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_min1.png',
              // center_x: 197,
              // center_y: 225,
              // x: 31,
              // y: 195,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 197 - 31,
              pos_y: 225 - 195,
              center_x: 197,
              center_y: 225,
              src: 'hand_min1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_sec1.png',
              // center_x: 197,
              // center_y: 225,
              // x: 12,
              // y: 228,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: 'center1.png',
              // cover_x: 167,
              // cover_y: 195,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_sec1.png',
              second_centerX: 197,
              second_centerY: 225,
              second_posX: 12,
              second_posY: 228,
              fresh_frequency: 15,
              fresh_freqency: 15,
              second_cover_path: 'center1.png',
              second_cover_x: 167,
              second_cover_y: 195,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'background2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 136,
              hour_startY: 56,
              hour_array: ["shadow_0001.png","shadow_0002.png","shadow_0003.png","shadow_0004.png","shadow_0005.png","shadow_0006.png","shadow_0007.png","shadow_0008.png","shadow_0009.png","shadow_0010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 136,
              minute_startY: 237,
              minute_array: ["shadow_0001.png","shadow_0002.png","shadow_0003.png","shadow_0004.png","shadow_0005.png","shadow_0006.png","shadow_0007.png","shadow_0008.png","shadow_0009.png","shadow_0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -37,
              y: 12,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 233,
              y: 56,
              w: 80,
              h: 100,
              src: 'Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 369,
              y: 55,
              w: 20,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'vertical.dots.png',
              normal_src: 'vertical.dots.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 171,
              y: 198,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                click_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 253,
              y: 430,
              w: 80,
              h: 20,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'horizontal.dots.png',
              normal_src: 'horizontal.dots.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBG_Color');
            // Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.SwitchBG_Color, {
              // x: 139,
              // y: 55,
              // w: 80,
              // h: 100,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'Empty.png',
              // normal_src: 'Empty.png',
              // color_list: 0xFF464646|0xFF00FFFF|0xFF80FF00|0xFFFF00FF|0xFFFF0000|0xFFEC7600|0xFF0000FF,
              // toast_list: Original|Cyan|Green|Purple|Red|Orange|Blue,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 139,
              y: 55,
              w: 80,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                switchBG_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) { // Hour Pointer
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                //SwitchBgColor
                if (hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`) === undefined) {
                  bgColorIndex = 0;
                  hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
                } else {
                  bgColorIndex = hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg) normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}