﻿    /*
    ** Watch_Face_Editor tool v 18.3
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let startDuckHuntGame = null;
let screenType = hmSetting.getScreenType();
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 319,
              y: 296,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 290,
              y: 297,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 364,
              y: 112,
              font_array: ["DATA18_0.png","DATA18_1.png","DATA18_2.png","DATA18_3.png","DATA18_4.png","DATA18_5.png","DATA18_6.png","DATA18_7.png","DATA18_8.png","DATA18_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'BATT_UNIT.png',
              unit_tc: 'BATT_UNIT.png',
              unit_en: 'BATT_UNIT.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 382,
              y: 371,
              font_array: ["DATA18_0.png","DATA18_1.png","DATA18_2.png","DATA18_3.png","DATA18_4.png","DATA18_5.png","DATA18_6.png","DATA18_7.png","DATA18_8.png","DATA18_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 226,
              y: 402,
              font_array: ["DATA18_0.png","DATA18_1.png","DATA18_2.png","DATA18_3.png","DATA18_4.png","DATA18_5.png","DATA18_6.png","DATA18_7.png","DATA18_8.png","DATA18_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'cal_unit.png',
              unit_tc: 'cal_unit.png',
              unit_en: 'cal_unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 225,
              y: 372,
              font_array: ["DATA18_0.png","DATA18_1.png","DATA18_2.png","DATA18_3.png","DATA18_4.png","DATA18_5.png","DATA18_6.png","DATA18_7.png","DATA18_8.png","DATA18_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 344,
              font_array: ["DATA18_0.png","DATA18_1.png","DATA18_2.png","DATA18_3.png","DATA18_4.png","DATA18_5.png","DATA18_6.png","DATA18_7.png","DATA18_8.png","DATA18_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 306,
              year_startY: 63,
              year_sc_array: ["DataW27_0.png","DataW27_1.png","DataW27_2.png","DataW27_3.png","DataW27_4.png","DataW27_5.png","DataW27_6.png","DataW27_7.png","DataW27_8.png","DataW27_9.png"],
              year_tc_array: ["DataW27_0.png","DataW27_1.png","DataW27_2.png","DataW27_3.png","DataW27_4.png","DataW27_5.png","DataW27_6.png","DataW27_7.png","DataW27_8.png","DataW27_9.png"],
              year_en_array: ["DataW27_0.png","DataW27_1.png","DataW27_2.png","DataW27_3.png","DataW27_4.png","DataW27_5.png","DataW27_6.png","DataW27_7.png","DataW27_8.png","DataW27_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 200,
              y: 63,
              week_en: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_tc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_sc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 131,
              day_startY: 63,
              day_sc_array: ["DataW27_0.png","DataW27_1.png","DataW27_2.png","DataW27_3.png","DataW27_4.png","DataW27_5.png","DataW27_6.png","DataW27_7.png","DataW27_8.png","DataW27_9.png"],
              day_tc_array: ["DataW27_0.png","DataW27_1.png","DataW27_2.png","DataW27_3.png","DataW27_4.png","DataW27_5.png","DataW27_6.png","DataW27_7.png","DataW27_8.png","DataW27_9.png"],
              day_en_array: ["DataW27_0.png","DataW27_1.png","DataW27_2.png","DataW27_3.png","DataW27_4.png","DataW27_5.png","DataW27_6.png","DataW27_7.png","DataW27_8.png","DataW27_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 26,
              month_startY: 63,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 17,
              y: 115,
              image_array: ["Weather_image_01.png","Weather_image_02.png","Weather_image_03.png","Weather_image_04.png","Weather_image_05.png","Weather_image_06.png","Weather_image_07.png","Weather_image_08.png","Weather_image_09.png","Weather_image_10.png","Weather_image_11.png","Weather_image_12.png","Weather_image_13.png","Weather_image_14.png","Weather_image_15.png","Weather_image_16.png","Weather_image_17.png","Weather_image_18.png","Weather_image_19.png","Weather_image_20.png","Weather_image_21.png","Weather_image_22.png","Weather_image_23.png","Weather_image_24.png","Weather_image_25.png","Weather_image_26.png","Weather_image_27.png","Weather_image_28.png","Weather_image_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,
              y: 126,
              font_array: ["Data27_0.png","Data27_1.png","Data27_2.png","Data27_3.png","Data27_4.png","Data27_5.png","Data27_6.png","Data27_7.png","Data27_8.png","Data27_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_unit.png',
              unit_tc: 'Temp_unit.png',
              unit_en: 'Temp_unit.png',
              imperial_unit_sc: 'Temp_unit.png',
              imperial_unit_tc: 'Temp_unit.png',
              imperial_unit_en: 'Temp_unit.png',
              negative_image: 'Temp_minus.png',
              invalid_image: 'Error27.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 69,
                y: 126,
                font_array: ["Data27_0.png","Data27_1.png","Data27_2.png","Data27_3.png","Data27_4.png","Data27_5.png","Data27_6.png","Data27_7.png","Data27_8.png","Data27_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Temp_unit.png',
                unit_tc: 'Temp_unit.png',
                unit_en: 'Temp_unit.png',
                imperial_unit_sc: 'Temp_unit.png',
                imperial_unit_tc: 'Temp_unit.png',
                imperial_unit_en: 'Temp_unit.png',
                negative_image: 'Temp_minus.png',
                invalid_image: 'Error27.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 135,
              second_startY: 298,
              second_array: ["Data27_0.png","Data27_1.png","Data27_2.png","Data27_3.png","Data27_4.png","Data27_5.png","Data27_6.png","Data27_7.png","Data27_8.png","Data27_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 288,
              minute_startY: 213,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 120,
              hour_startY: 215,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 251,
              y: 218,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 319,
              y: 296,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 290,
              y: 297,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 364,
              y: 112,
              font_array: ["DATA18_0.png","DATA18_1.png","DATA18_2.png","DATA18_3.png","DATA18_4.png","DATA18_5.png","DATA18_6.png","DATA18_7.png","DATA18_8.png","DATA18_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'BATT_UNIT.png',
              unit_tc: 'BATT_UNIT.png',
              unit_en: 'BATT_UNIT.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 382,
              y: 371,
              font_array: ["DATA18_0.png","DATA18_1.png","DATA18_2.png","DATA18_3.png","DATA18_4.png","DATA18_5.png","DATA18_6.png","DATA18_7.png","DATA18_8.png","DATA18_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 226,
              y: 402,
              font_array: ["DATA18_0.png","DATA18_1.png","DATA18_2.png","DATA18_3.png","DATA18_4.png","DATA18_5.png","DATA18_6.png","DATA18_7.png","DATA18_8.png","DATA18_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'cal_unit.png',
              unit_tc: 'cal_unit.png',
              unit_en: 'cal_unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 225,
              y: 372,
              font_array: ["DATA18_0.png","DATA18_1.png","DATA18_2.png","DATA18_3.png","DATA18_4.png","DATA18_5.png","DATA18_6.png","DATA18_7.png","DATA18_8.png","DATA18_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 344,
              font_array: ["DATA18_0.png","DATA18_1.png","DATA18_2.png","DATA18_3.png","DATA18_4.png","DATA18_5.png","DATA18_6.png","DATA18_7.png","DATA18_8.png","DATA18_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 306,
              year_startY: 63,
              year_sc_array: ["DataW27_0.png","DataW27_1.png","DataW27_2.png","DataW27_3.png","DataW27_4.png","DataW27_5.png","DataW27_6.png","DataW27_7.png","DataW27_8.png","DataW27_9.png"],
              year_tc_array: ["DataW27_0.png","DataW27_1.png","DataW27_2.png","DataW27_3.png","DataW27_4.png","DataW27_5.png","DataW27_6.png","DataW27_7.png","DataW27_8.png","DataW27_9.png"],
              year_en_array: ["DataW27_0.png","DataW27_1.png","DataW27_2.png","DataW27_3.png","DataW27_4.png","DataW27_5.png","DataW27_6.png","DataW27_7.png","DataW27_8.png","DataW27_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 200,
              y: 63,
              week_en: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_tc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_sc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 131,
              day_startY: 63,
              day_sc_array: ["DataW27_0.png","DataW27_1.png","DataW27_2.png","DataW27_3.png","DataW27_4.png","DataW27_5.png","DataW27_6.png","DataW27_7.png","DataW27_8.png","DataW27_9.png"],
              day_tc_array: ["DataW27_0.png","DataW27_1.png","DataW27_2.png","DataW27_3.png","DataW27_4.png","DataW27_5.png","DataW27_6.png","DataW27_7.png","DataW27_8.png","DataW27_9.png"],
              day_en_array: ["DataW27_0.png","DataW27_1.png","DataW27_2.png","DataW27_3.png","DataW27_4.png","DataW27_5.png","DataW27_6.png","DataW27_7.png","DataW27_8.png","DataW27_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 26,
              month_startY: 63,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 17,
              y: 115,
              image_array: ["Weather_image_01.png","Weather_image_02.png","Weather_image_03.png","Weather_image_04.png","Weather_image_05.png","Weather_image_06.png","Weather_image_07.png","Weather_image_08.png","Weather_image_09.png","Weather_image_10.png","Weather_image_11.png","Weather_image_12.png","Weather_image_13.png","Weather_image_14.png","Weather_image_15.png","Weather_image_16.png","Weather_image_17.png","Weather_image_18.png","Weather_image_19.png","Weather_image_20.png","Weather_image_21.png","Weather_image_22.png","Weather_image_23.png","Weather_image_24.png","Weather_image_25.png","Weather_image_26.png","Weather_image_27.png","Weather_image_28.png","Weather_image_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,
              y: 126,
              font_array: ["Data27_0.png","Data27_1.png","Data27_2.png","Data27_3.png","Data27_4.png","Data27_5.png","Data27_6.png","Data27_7.png","Data27_8.png","Data27_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_unit.png',
              unit_tc: 'Temp_unit.png',
              unit_en: 'Temp_unit.png',
              imperial_unit_sc: 'Temp_unit.png',
              imperial_unit_tc: 'Temp_unit.png',
              imperial_unit_en: 'Temp_unit.png',
              negative_image: 'Temp_minus.png',
              invalid_image: 'Error27.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 69,
                y: 126,
                font_array: ["Data27_0.png","Data27_1.png","Data27_2.png","Data27_3.png","Data27_4.png","Data27_5.png","Data27_6.png","Data27_7.png","Data27_8.png","Data27_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Temp_unit.png',
                unit_tc: 'Temp_unit.png',
                unit_en: 'Temp_unit.png',
                imperial_unit_sc: 'Temp_unit.png',
                imperial_unit_tc: 'Temp_unit.png',
                imperial_unit_en: 'Temp_unit.png',
                negative_image: 'Temp_minus.png',
                invalid_image: 'Error27.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 135,
              second_startY: 298,
              second_array: ["Data27_0.png","Data27_1.png","Data27_2.png","Data27_3.png","Data27_4.png","Data27_5.png","Data27_6.png","Data27_7.png","Data27_8.png","Data27_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 288,
              minute_startY: 213,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 120,
              hour_startY: 215,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 251,
              y: 218,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

/*
    Duck Hunt WatchFace for Zepp OS
    Multi Duck System
    Resolution: 432x514
*/

// ฟังก์ชันนี้ต้องอยู่ใน scope เดียวกับปุ่ม Watch Face
// let startDuckHuntGame = null;

// อ่านประเภทหน้าจอ
// let screenType = hmSetting.getScreenType();

// ไม่ทำงานบน Always On Display
if (screenType != hmSetting.screen_type.AOD) {


// ==========================================
// SCREEN SETTINGS
// ==========================================

const SCREEN_W = 432;
const SCREEN_H = 514;


// ==========================================
// GAME SETTINGS
// ==========================================

const DUCK_W = 48;
const DUCK_H = 48;

const DOG_W = 96;
const DOG_H = 96;

const ROUND_DUCKS = 10;
const REQUIRED_HITS = 6;

const MAX_AMMO = 3;
const MAX_DUCKS = 4;

const MAX_MISSES = 4;

const GAME_INTERVAL = 50;
const DUCK_SPEED = 3;

const SPAWN_INTERVAL = 10;

const FLIGHT_MIN_X = 20;
const FLIGHT_MAX_X = SCREEN_W - DUCK_W - 20;

//const FLIGHT_MAX_Y = 300;
const FLIGHT_MAX_Y = 404 - DUCK_H;


// ==========================================
// GAME STATE
// ==========================================

let isGameMode = false;
let isRunning = false;
let isGameOver = false;

let gameTimer = null;
let gameTimerVersion = 0;

let score = 0;
let round = 1;

let ducksPlayed = 0;
let ducksHit = 0;

let missCount = 0;

let spawnCooldown = 20;

let roundTransition = false;
let roundDelayTicks = 0;

let spawnOrderCounter = 0;

let dogDisplayTicks = 0;


// ==========================================
// WIDGET REFERENCES
// ==========================================

let gameGroupWidgets = [];

let gameBackground = null;

let gameHeaderText = null;
let gameStatusText = null;
let gameAmmoText = null;

let dogWidget = null;

let shootArea = null;


// ==========================================
// DUCK OBJECTS
// ==========================================

let ducks = [];


// ==========================================
// HELPER
// ==========================================

function randomRange(min, max) {

    return Math.floor(
        Math.random() * (max - min + 1)
    ) + min;
}


// จำนวนเป็ดสูงสุดตาม Level
function getMaxDucksForLevel() {

    return Math.min(round, MAX_DUCKS);
}


// ความเร็วเพิ่มตั้งแต่ Level 5 เป็นต้นไป
function getDuckSpeed() {

    return DUCK_SPEED + Math.max(0, round - 4);
}


// จำนวนเป็ดที่ยังทำงานอยู่
function getActiveDuckCount() {

    let count = 0;

    for (let i = 0; i < ducks.length; i++) {

        if (ducks[i].active) {
            count++;
        }
    }

    return count;
}


// ==========================================
// HEADER UI
// ==========================================

function updateHeaderUI() {

    if (gameHeaderText) {

        gameHeaderText.setProperty(
            hmUI.prop.TEXT,
            `R${round} SCORE ${score} HIT ${ducksHit}/${REQUIRED_HITS} MISS ${missCount}/${MAX_MISSES}`
        );
    }

    if (gameAmmoText) {

        let ammoText = '';

        for (let i = 0; i < ducks.length; i++) {

            let d = ducks[i];

            if (d.active && d.state === 'flying') {

                ammoText += `D${d.order}:${'●'.repeat(d.ammo)}  `;
            }
        }

        if (ammoText === '') {
            ammoText = 'AMMO: --';
        }

        gameAmmoText.setProperty(
            hmUI.prop.TEXT,
            ammoText
        );
    }
}


function setStatus(text) {

    if (!gameStatusText) return;

    gameStatusText.setProperty(
        hmUI.prop.TEXT,
        text
    );
}


// ==========================================
// DUCK VISIBILITY
// ==========================================

function setDuckVisible(duck, visible) {

    if (duck.widget) {

        duck.widget.setProperty(
            hmUI.prop.VISIBLE,
            visible
        );
    }

    if (duck.hitArea) {

        duck.hitArea.setProperty(
            hmUI.prop.VISIBLE,
            visible
        );
    }
}


// ==========================================
// UPDATE DUCK POSITION
// ==========================================

function updateDuckPosition(duck) {

    if (!duck.widget || !duck.hitArea) return;

    duck.widget.setProperty(
        hmUI.prop.MORE,
        {
            x: duck.x,
            y: duck.y,
            w: DUCK_W,
            h: DUCK_H
        }
    );

    duck.hitArea.setProperty(
        hmUI.prop.MORE,
        {
            x: duck.x,
            y: duck.y,
            w: DUCK_W,
            h: DUCK_H
        }
    );
}


// ==========================================
// DOG DISPLAY
// ==========================================

function showDog(mode) {

    if (!dogWidget) return;

    dogDisplayTicks = 30;

    dogWidget.setProperty(
        hmUI.prop.MORE,
        {
            src: mode === 'SUCCESS'
                ? 'DogSuccess.png'
                : 'DogLaugh.png',

            x: Math.floor((SCREEN_W - DOG_W) / 2),
            y: 340,
            w: DOG_W,
            h: DOG_H
        }
    );

    dogWidget.setProperty(
        hmUI.prop.VISIBLE,
        true
    );
}


function hideDog() {

    if (!dogWidget) return;

    dogWidget.setProperty(
        hmUI.prop.VISIBLE,
        false
    );

    dogDisplayTicks = 0;
}


// ==========================================
// SPAWN DUCK
// ==========================================

function spawnDuck() {

    if (!isGameMode || isGameOver) return;

    if (ducksPlayed >= ROUND_DUCKS) return;

    if (getActiveDuckCount() >= getMaxDucksForLevel()) return;


    // หา Slot เป็ดที่ว่าง
    let duck = null;

    for (let i = 0; i < ducks.length; i++) {

        if (!ducks[i].active) {

            duck = ducks[i];
            break;
        }
    }

    if (!duck) return;


    // เพิ่มจำนวนเป็ดที่ออกมาในรอบนี้
    ducksPlayed++;

    spawnOrderCounter++;


    // ตั้งค่าเป็ดใหม่
    duck.active = true;
    duck.state = 'flying';

    duck.order = spawnOrderCounter;

    duck.x = randomRange(
        FLIGHT_MIN_X,
        FLIGHT_MAX_X
    );

    duck.y = FLIGHT_MAX_Y;

    duck.dirX = Math.random() < 0.5 ? -1 : 1;
    duck.dirY = -1;

    // ความเร็วตาม Level
    duck.speedX = getDuckSpeed();
    duck.speedY = 1 + Math.max(0, round - 4);

    // กระสุนแยกของเป็ดแต่ละตัว
    duck.ammo = MAX_AMMO;

    duck.hitDisplayTicks = 0;


    // เลือกภาพเป็ดตามทิศทางการบิน
    duck.widget.setProperty(
        hmUI.prop.MORE,
        {
            src: duck.dirX < 0 ? 'DuckLeft.png' : 'Duck.png',
            x: duck.x,
            y: duck.y,
            w: DUCK_W,
            h: DUCK_H
        }
    );

    duck.hitArea.setProperty(
        hmUI.prop.MORE,
        {
            x: duck.x,
            y: duck.y,
            w: DUCK_W,
            h: DUCK_H
        }
    );


    setDuckVisible(duck, true);

    hideDog();

    updateHeaderUI();

    setStatus(
        `DUCK ${getActiveDuckCount()} / ${getMaxDucksForLevel()}`
    );
}


// ==========================================
// MOVE DUCK
// ==========================================

function moveDuck(duck) {

    if (!duck.active || duck.state !== 'flying') return;


    // เคลื่อนที่ตามทิศทางเดิมตลอด
    duck.x += duck.dirX * duck.speedX;
    duck.y += duck.dirY * duck.speedY;


    // บินพ้นขอบซ้าย ขวา หรือด้านบน = พลาด
    // ไม่มีการเด้งกลับ
    if (
        duck.x + DUCK_W <= 0 ||
        duck.x >= SCREEN_W ||
        duck.y + DUCK_H <= 0
    ) {

        escapeDuck(duck, true);
        return;
    }


    updateDuckPosition(duck);
}


// ==========================================
// DUCK ESCAPES
// ==========================================

function escapeDuck(duck, screenEscape) {

    if (!duck.active || duck.state !== 'flying') return;

    duck.active = false;
    duck.state = 'escaped';

    setDuckVisible(duck, false);


    // เพิ่มจำนวนครั้งที่พลาด
    missCount++;


    // อัปเดต Header
    updateHeaderUI();


    // ตรวจสอบว่าพลาดครบ 4 ครั้งหรือยัง
    if (missCount >= MAX_MISSES) {

        isGameOver = true;

        setStatus('GAME OVER');

        showDog('LAUGH');

        stopGameLoop();

        return;
    }


    if (screenEscape) {

        setStatus(`DUCK ESCAPED! MISS ${missCount}/${MAX_MISSES}`);

    } else {

        setStatus(`OUT OF AMMO! MISS ${missCount}/${MAX_MISSES}`);
    }


    showDog('LAUGH');


    // เว้นช่วงก่อนนำเป็ดตัวใหม่ออกมา
    spawnCooldown = Math.max(spawnCooldown, 20);
}


// ==========================================
// HIT DUCK
// ==========================================

function hitDuck(duck) {

    if (!isGameMode) return;
    if (!isRunning) return;
    if (isGameOver) return;
    if (!duck.active || duck.state !== 'flying') return;

    if (duck.ammo <= 0) return;


    // ใช้กระสุนของเป็ดตัวนี้
    duck.ammo--;


    // ยิงโดน
    duck.state = 'hit';

    ducksHit++;
    score += 100;

    updateHeaderUI();

    setStatus('GOT IT!');


    // แสดงภาพเป็ดถูกยิง
    duck.widget.setProperty(
        hmUI.prop.MORE,
        {
            src: 'DuckHit.png',
            x: duck.x,
            y: duck.y,
            w: DUCK_W,
            h: DUCK_H
        }
    );


    // ปิดพื้นที่กดยิงของเป็ดที่ถูกยิง
    duck.hitArea.setProperty(
        hmUI.prop.VISIBLE,
        false
    );

    duck.hitDisplayTicks = 15;
}


// ==========================================
// MISS SHOT
// ==========================================

function missShot() {

    if (!isGameMode) return;
    if (!isRunning) return;
    if (isGameOver) return;


    // เลือกเป็ดที่ออกมาก่อนสุดและยังบินอยู่
    let targetDuck = null;

    for (let i = 0; i < ducks.length; i++) {

        let d = ducks[i];

        if (!d.active || d.state !== 'flying') continue;

        if (
            targetDuck === null ||
            d.order < targetDuck.order
        ) {
            targetDuck = d;
        }
    }

    if (!targetDuck) return;


    // หักกระสุนเฉพาะเป็ดตัวที่เลือก
    targetDuck.ammo--;

    updateHeaderUI();


    if (targetDuck.ammo <= 0) {

        escapeDuck(targetDuck, false);
    }
}


// ==========================================
// FINISH ROUND
// ==========================================

function finishRound() {

    if (roundTransition || isGameOver) return;

    if (getActiveDuckCount() > 0) return;

    if (ducksPlayed < ROUND_DUCKS) return;


    roundTransition = true;


    if (ducksHit >= REQUIRED_HITS) {

        setStatus(`ROUND ${round} CLEAR!`);

        showDog('SUCCESS');


        // เริ่ม Level ใหม่
        round++;

        ducksPlayed = 0;
        ducksHit = 0;

        missCount = 0;

        spawnOrderCounter = 0;

        updateHeaderUI();


        // รอ 3 วินาทีก่อนเริ่ม Level ถัดไป
        roundDelayTicks = 60;

    } else {

        isGameOver = true;

        setStatus('GAME OVER');

        showDog('LAUGH');

        updateHeaderUI();

        stopGameLoop();
    }
}


// ==========================================
// MAIN GAME LOOP
// ==========================================

function stepGame() {

    if (!isRunning) return;
    if (!isGameMode || isGameOver) return;


    // DOG DISPLAY
    if (dogDisplayTicks > 0) {

        dogDisplayTicks--;

        if (dogDisplayTicks <= 0) {
            hideDog();
        }
    }


    // รอเริ่ม Level ใหม่
    if (roundTransition) {

        if (roundDelayTicks > 0) {

            roundDelayTicks--;
        }

        if (roundDelayTicks <= 0) {

            roundTransition = false;
            spawnCooldown = 0;
        }

        return;
    }


    // อัปเดตเป็ดแต่ละตัว
    for (let i = 0; i < ducks.length; i++) {

        let duck = ducks[i];


        if (!duck.active) continue;


        // เป็ดถูกยิงแล้ว แสดงภาพ DuckHit ชั่วคราว
        if (duck.state === 'hit') {

            duck.hitDisplayTicks--;

            if (duck.hitDisplayTicks <= 0) {

                duck.active = false;
                duck.state = 'idle';

                setDuckVisible(duck, false);

                spawnCooldown = Math.max(
                    spawnCooldown,
                    SPAWN_INTERVAL
                );
            }

            continue;
        }


        // เป็ดกำลังบิน
        if (duck.state === 'flying') {

            moveDuck(duck);

            // หยุดทำงานทันทีเมื่อ Game Over
            if (isGameOver) return;
        }
    }


    // ลดเวลารอก่อนปล่อยเป็ดตัวใหม่
    if (spawnCooldown > 0) {
        spawnCooldown--;
    }


    // ปล่อยเป็ดเพิ่มเมื่อยังมีจำนวนไม่ครบตาม Level
    if (
        ducksPlayed < ROUND_DUCKS &&
        getActiveDuckCount() < getMaxDucksForLevel() &&
        spawnCooldown <= 0
    ) {

        spawnDuck();

        spawnCooldown = SPAWN_INTERVAL;
    }


    // เป็ดครบ 10 ตัวและไม่มีเป็ดเหลือแล้ว
    if (
        ducksPlayed >= ROUND_DUCKS &&
        getActiveDuckCount() === 0
    ) {

        finishRound();
    }
}


// ==========================================
// START GAME LOOP
// ==========================================

function startGameLoop() {

    if (isRunning || !isGameMode) return;
    if (isGameOver) return;

    isRunning = true;

    if (gameTimer) {

        timer.stopTimer(gameTimer);
        gameTimer = null;
    }

    const myVersion = ++gameTimerVersion;

    gameTimer = timer.createTimer(
        0,
        GAME_INTERVAL,
        () => {

            if (myVersion !== gameTimerVersion) return;

            stepGame();
        }
    );
}


// ==========================================
// STOP GAME LOOP
// ==========================================

function stopGameLoop() {

    isRunning = false;

    gameTimerVersion++;

    if (gameTimer) {

        timer.stopTimer(gameTimer);
        gameTimer = null;
    }
}


// ==========================================
// SHOOT AREA
// ==========================================

function createShootArea() {

    shootArea = hmUI.createWidget(
        hmUI.widget.BUTTON,
        {
            x: 0,
            y: 115,
            w: SCREEN_W,
            h: SCREEN_H,

            text: '',
            color: 0xFFFFFFFF,
            text_size: 16,

            press_src: '0_Empty.png',
            normal_src: '0_Empty.png',

            click_func: () => {

                // คลิกครั้งแรกเพื่อเริ่มเกมเท่านั้น
                if (!isRunning) {

                    if (isGameMode && !isGameOver) {

                        setStatus('HUNT!');
                        startGameLoop();

                        if (
                            ducksPlayed === 0 &&
                            getActiveDuckCount() === 0
                        ) {
                            spawnCooldown = 20;
                        }
                    }

                    return;
                }

                // คลิกครั้งต่อไปจึงนับเป็นการยิงพลาด
                missShot();
            },

            show_level: hmUI.show_level.ONLY_NORMAL
        }
    );

    gameGroupWidgets.push(shootArea);
}


// ==========================================
// RESET GAME
// ==========================================

function resetGame() {

    stopGameLoop();

    score = 0;
    round = 1;

    ducksPlayed = 0;
    ducksHit = 0;

    missCount = 0;

    spawnCooldown = 20;

    roundTransition = false;
    roundDelayTicks = 0;

    spawnOrderCounter = 0;

    isGameOver = false;


    // รีเซ็ตเป็ดทั้ง 4 ตัว
    for (let i = 0; i < ducks.length; i++) {

        let duck = ducks[i];

        duck.active = false;
        duck.state = 'idle';

        duck.ammo = MAX_AMMO;
        duck.hitDisplayTicks = 0;

        duck.widget.setProperty(
            hmUI.prop.MORE,
            {
                src: 'Duck.png',
                x: -DUCK_W - 10,
                y: -DUCK_H - 10,
                w: DUCK_W,
                h: DUCK_H
            }
        );

        duck.hitArea.setProperty(
            hmUI.prop.MORE,
            {
                x: -DUCK_W - 10,
                y: -DUCK_H - 10,
                w: DUCK_W,
                h: DUCK_H
            }
        );

        setDuckVisible(duck, false);
    }


    hideDog();

    updateHeaderUI();

    // รีเซ็ตแล้วรอคลิกเพื่อเริ่มเกมใหม่
    setStatus('TAP TO START!');
}


// ==========================================
// SWITCH WATCH MODE / GAME MODE
// ==========================================

function setWatchMode(enableGame) {

    isGameMode = enableGame;

    if (!enableGame) {

        stopGameLoop();
    }

    gameGroupWidgets.forEach((w) => {

        w.setProperty(
            hmUI.prop.VISIBLE,
            enableGame
        );
    });


    if (enableGame) {

        updateHeaderUI();

        if (isGameOver) {

            setStatus('GAME OVER - PRESS RESET');

        } else if (!isRunning) {

            setStatus('TAP TO START!');

        } else {

            setStatus('HUNT!');
        }
    }
}


// ==========================================
// EXIT GAME
// ==========================================

function exitDuckHuntGame() {

    Button_1.setProperty(hmUI.prop.VISIBLE, true);
    Button_2.setProperty(hmUI.prop.VISIBLE, true);
    Button_3.setProperty(hmUI.prop.VISIBLE, true);

    normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
    normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
    normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
    normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
    normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
    normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
    normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
    normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
    normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

    setWatchMode(false);
}


// ==========================================
// BUILD GAME UI
// ==========================================

function buildUI() {


    // BACKGROUND
    // ใช้ภาพ Background.png แทนการสร้างสี

    gameBackground = hmUI.createWidget(
        hmUI.widget.IMG,
        {
            x: 0,
            y: 0,
            w: SCREEN_W,
            h: SCREEN_H,
            src: 'BgGame.png'
        }
    );

    gameGroupWidgets.push(gameBackground);




    // HEADER

    gameHeaderText = hmUI.createWidget(
        hmUI.widget.TEXT,
        {
            x: 20,
            y: 468,
            w: SCREEN_W - 40,
            h: 32,

            color: 0x000000,
            text_size: 20,

            align_h: hmUI.align.CENTER_H,

            text: 'R1 SCORE 0 HIT 0/6 MISS 0/4'
        }
    );

    gameGroupWidgets.push(gameHeaderText);


// AMMO

    gameAmmoText = hmUI.createWidget(
        hmUI.widget.TEXT,
        {
            x: 27,
            y: 54,
            w: SCREEN_W - 40,
            h: 29,

            color: 0xffffff,
            text_size: 20,

            align_h: hmUI.align.CENTER_H,

            text: 'AMMO: --'
        }
    );

    gameGroupWidgets.push(gameAmmoText);


    // STATUS

    gameStatusText = hmUI.createWidget(
        hmUI.widget.TEXT,
        {
            x: 20,
            y: 444,
            w: SCREEN_W - 40,
            h: 32,

            color: 0x000000,
            text_size: 20,

            align_h: hmUI.align.CENTER_H,

            text: 'GET READY!'
        }
    );

    gameGroupWidgets.push(gameStatusText);


    // DOG IMAGE

    dogWidget = hmUI.createWidget(
        hmUI.widget.IMG,
        {
            x: Math.floor((SCREEN_W - DOG_W) / 2),
            y: 330,
            w: DOG_W,
            h: DOG_H,

            src: 'DogLaugh.png'
        }
    );

    gameGroupWidgets.push(dogWidget);


    // SHOOT AREA
    // สร้างก่อนพื้นที่กดเป็ด

    createShootArea();


    // ======================================
    // CREATE DUCK IMAGES
    // สร้างภาพเป็ด 4 ตัวไว้ล่วงหน้า
    // เริ่มต้นอยู่นอกจอ
    // ======================================

    ducks = [];

    for (let i = 0; i < MAX_DUCKS; i++) {

        let duck = {

            active: false,
            state: 'idle',

            order: 0,

            x: -DUCK_W - 10,
            y: -DUCK_H - 10,

            dirX: 1,
            dirY: -1,

            speedX: DUCK_SPEED,
            speedY: 1,

            ammo: MAX_AMMO,

            hitDisplayTicks: 0,

            widget: null,
            hitArea: null
        };


        duck.widget = hmUI.createWidget(
            hmUI.widget.IMG,
            {
                x: -DUCK_W - 10,
                y: -DUCK_H - 10,
                w: DUCK_W,
                h: DUCK_H,

                src: 'Duck.png'
            }
        );

        gameGroupWidgets.push(duck.widget);

        ducks.push(duck);
    }


    // ======================================
    // CREATE DUCK HIT AREAS
    // สร้าง Hit Area หลังภาพเป็ดทั้งหมด
    // เริ่มต้นอยู่นอกจอ
    // ======================================

    for (let i = 0; i < MAX_DUCKS; i++) {

        let duck = ducks[i];

        duck.hitArea = hmUI.createWidget(
            hmUI.widget.BUTTON,
            {
                x: -DUCK_W - 10,
                y: -DUCK_H - 10,
                w: DUCK_W,
                h: DUCK_H,

                text: '',
                color: 0xFFFFFFFF,
                text_size: 16,

                press_src: 'shoot.png',
                normal_src: '0_Empty.png',

                click_func: () => {
                    hitDuck(duck);
                },

                show_level: hmUI.show_level.ONLY_NORMAL
            }
        );

        gameGroupWidgets.push(duck.hitArea);
    }


    // ======================================
    // EXIT BUTTON
    // ======================================

    const exitBtn = hmUI.createWidget(
        hmUI.widget.BUTTON,
        {
            x: 15,
            y: 54,
            w: 70,
            h: 38,

            radius: 10,

            text: 'EXIT',

            normal_color: 0x1f2937,
            press_color: 0x374151,

            color: 0xffffff,
            text_size: 15,

            click_func: () => {
                exitDuckHuntGame();
            }
        }
    );

    gameGroupWidgets.push(exitBtn);


    // ======================================
    // RESET BUTTON
    // ======================================

    const resetBtn = hmUI.createWidget(
        hmUI.widget.BUTTON,
        {
            x: SCREEN_W - 85,
            y: 54,
            w: 70,
            h: 38,

            radius: 10,

            text: 'RESET',

            normal_color: 0x1f2937,
            press_color: 0x374151,

            color: 0xffffff,
            text_size: 15,

            click_func: () => {
                resetGame();
            }
        }
    );

    gameGroupWidgets.push(resetBtn);


    // INITIAL STATE

    for (let i = 0; i < ducks.length; i++) {

        setDuckVisible(ducks[i], false);
    }

    hideDog();

    updateHeaderUI();

    setWatchMode(false);
}


// ==========================================
// PUBLIC START FUNCTION
// ==========================================

startDuckHuntGame = function() {

    // แสดงหน้าจอเกม แต่ยังไม่เริ่ม Timer
    setWatchMode(true);

    if (isGameOver) {

        resetGame();
        return;
    }

    // รอให้ผู้เล่นคลิกพื้นที่เล่นครั้งแรก
};




// ==========================================
// INITIALIZE
// ==========================================

buildUI();


} // END SCREEN TYPE CHECK
            // end user_script_beforeShortcuts.js
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 108,
              y: 339,
              w: 160,
              h: 24,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 109,
              y: 399,
              w: 214,
              h: 27,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 362,
              y: 342,
              w: 67,
              h: 53,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 253,
              y: 103,
              w: 174,
              h: 38,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 7,
              y: 108,
              w: 58,
              h: 56,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 73,
              y: 111,
              w: 90,
              h: 48,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 126,
              y: 293,
              w: 68,
              h: 39,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 249,
              y: 213,
              w: 42,
              h: 73,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 285,
              y: 292,
              w: 64,
              h: 40,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 22,
              y: 447,
              w: 100,
              h: 30,
              text: 'START GAME',
              color: 0xFFFFFFFF,
              text_size: 14,
              radius: 12,
              press_color: 0xFFA0A0A0,
              normal_color: 0xFF696969,
              click_func: (button_widget) => {
                    Button_1.setProperty(hmUI.prop.VISIBLE, !true);
    Button_2.setProperty(hmUI.prop.VISIBLE, !true);
    Button_3.setProperty(hmUI.prop.VISIBLE, !true);

    normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, !true);
    normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, !true);
    normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, !true);
    normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, !true);
    normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, !true);
    normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, !true);
    normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, !true);
    normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, !true);
    normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, !true);
 startDuckHuntGame();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 29,
              y: 60,
              w: 388,
              h: 34,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 14,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 109,
              y: 367,
              w: 235,
              h: 28,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 14,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}