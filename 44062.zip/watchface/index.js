﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_humidity_image_progress_img_level = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_calorie_linear_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_day = ''
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 63;
        let normal_timerTextUpdate = undefined;
        let normal_digital_clock_img_time_minute = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 63;
        let normal_digital_clock_img_time_hour = ''
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 63;
        let idle_timerTextUpdate = undefined;
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 63;
        let idle_digital_clock_img_time_hour = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['bg1.png', 'bg2.png', 'bg3.png', 'bg4.png', 'bg5.png', 'bg6.png'];
        let backgroundToastList = ['Dark Green', 'Blue', 'Yellow', 'Red', 'Violet', 'Green'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              normal_step_icon_img.setProperty(hmUI.prop.SRC, "bg_activity_" + parseInt(backgroundIndex+1) + ".png");
              normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "bg_weather_" + parseInt(backgroundIndex+1) + ".png");
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 2,
              y: 242,
              src: 'bg_weather_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 298,
              y: 251,
              image_array: ["WeatherF_01.png","WeatherF_02.png","WeatherF_03.png","WeatherF_04.png","WeatherF_05.png","WeatherF_06.png","WeatherF_07.png","WeatherF_08.png","WeatherF_09.png","WeatherF_10.png","WeatherF_11.png","WeatherF_12.png","WeatherF_13.png","WeatherF_14.png","WeatherF_15.png","WeatherF_16.png","WeatherF_17.png","WeatherF_18.png","WeatherF_19.png","WeatherF_20.png","WeatherF_21.png","WeatherF_22.png","WeatherF_23.png","WeatherF_24.png","WeatherF_25.png","WeatherF_26.png","WeatherF_27.png","WeatherF_28.png","WeatherF_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 372,
              font_array: ["Act_B_S_0.png","Act_B_S_1.png","Act_B_S_2.png","Act_B_S_3.png","Act_B_S_4.png","Act_B_S_5.png","Act_B_S_6.png","Act_B_S_7.png","Act_B_S_8.png","Act_B_S_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_unit.png',
              unit_tc: 'Temp_unit.png',
              unit_en: 'Temp_unit.png',
              imperial_unit_sc: 'Temp_unit.png',
              imperial_unit_tc: 'Temp_unit.png',
              imperial_unit_en: 'Temp_unit.png',
              negative_image: 'Temp_LH_error.png',
              invalid_image: 'Temp_LH_error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 256,
                y: 372,
                font_array: ["Act_B_S_0.png","Act_B_S_1.png","Act_B_S_2.png","Act_B_S_3.png","Act_B_S_4.png","Act_B_S_5.png","Act_B_S_6.png","Act_B_S_7.png","Act_B_S_8.png","Act_B_S_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Temp_unit.png',
                unit_tc: 'Temp_unit.png',
                unit_en: 'Temp_unit.png',
                imperial_unit_sc: 'Temp_unit.png',
                imperial_unit_tc: 'Temp_unit.png',
                imperial_unit_en: 'Temp_unit.png',
                negative_image: 'Temp_LH_error.png',
                invalid_image: 'Temp_LH_error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 373,
              font_array: ["Act_B_S_0.png","Act_B_S_1.png","Act_B_S_2.png","Act_B_S_3.png","Act_B_S_4.png","Act_B_S_5.png","Act_B_S_6.png","Act_B_S_7.png","Act_B_S_8.png","Act_B_S_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_unit.png',
              unit_tc: 'Temp_unit.png',
              unit_en: 'Temp_unit.png',
              imperial_unit_sc: 'Temp_unit.png',
              imperial_unit_tc: 'Temp_unit.png',
              imperial_unit_en: 'Temp_unit.png',
              negative_image: 'Temp_LH_error.png',
              invalid_image: 'Temp_LH_error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 207,
              y: 392,
              src: 'icon_Temp_HL.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 196,
                y: 373,
                font_array: ["Act_B_S_0.png","Act_B_S_1.png","Act_B_S_2.png","Act_B_S_3.png","Act_B_S_4.png","Act_B_S_5.png","Act_B_S_6.png","Act_B_S_7.png","Act_B_S_8.png","Act_B_S_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Temp_unit.png',
                unit_tc: 'Temp_unit.png',
                unit_en: 'Temp_unit.png',
                imperial_unit_sc: 'Temp_unit.png',
                imperial_unit_tc: 'Temp_unit.png',
                imperial_unit_en: 'Temp_unit.png',
                negative_image: 'Temp_LH_error.png',
                invalid_image: 'Temp_LH_error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 294,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'TempC.png',
              unit_tc: 'TempC.png',
              unit_en: 'TempC.png',
              imperial_unit_sc: 'TempF.png',
              imperial_unit_tc: 'TempF.png',
              imperial_unit_en: 'TempF.png',
              negative_image: 'Temp_error.png',
              invalid_image: 'Temp_error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 206,
                y: 294,
                font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
                padding: false,
                h_space: -2,
                unit_sc: 'TempF.png',
                unit_tc: 'TempF.png',
                unit_en: 'TempF.png',
                imperial_unit_sc: 'TempC.png',
                imperial_unit_tc: 'TempC.png',
                imperial_unit_en: 'TempC.png',
                negative_image: 'Temp_error.png',
                invalid_image: 'Temp_error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 151,
              y: 379,
              font_array: ["Act_S_0.png","Act_S_1.png","Act_S_2.png","Act_S_3.png","Act_S_4.png","Act_S_5.png","Act_S_6.png","Act_S_7.png","Act_S_8.png","Act_S_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '0_Empty.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 96,
              y: 262,
              image_array: ["Wind_D_1.png","Wind_D_2.png","Wind_D_3.png","Wind_D_4.png","Wind_D_5.png","Wind_D_6.png","Wind_D_7.png","Wind_D_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 295,
              font_array: ["Act_M_0.png","Act_M_1.png","Act_M_2.png","Act_M_3.png","Act_M_4.png","Act_M_5.png","Act_M_6.png","Act_M_7.png","Act_M_8.png","Act_M_9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 150,
              y: 334,
              image_array: ["Hum_progress_01.png","Hum_progress_02.png","Hum_progress_03.png","Hum_progress_04.png","Hum_progress_05.png","Hum_progress_06.png","Hum_progress_07.png","Hum_progress_08.png"],
              image_length: 8,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 339,
              font_array: ["Act_S_0.png","Act_S_1.png","Act_S_2.png","Act_S_3.png","Act_S_4.png","Act_S_5.png","Act_S_6.png","Act_S_7.png","Act_S_8.png","Act_S_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'Hum_Unit.png',
              unit_tc: 'Hum_Unit.png',
              unit_en: 'Hum_Unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 147,
              y: 332,
              src: 'Top_hum.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 2,
              y: 241,
              src: 'bg_activity_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 125,
              y: 363,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 364,
              y: 198,
              image_array: ["Step_Progress_01.png","Step_Progress_02.png","Step_Progress_03.png","Step_Progress_04.png","Step_Progress_05.png","Step_Progress_06.png","Step_Progress_07.png","Step_Progress_08.png","Step_Progress_09.png","Step_Progress_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 338,
              // start_y: 266,
              // color: 0xFFFFEA83,
              // lenght: -94,
              // line_width: 38,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 316,
              font_array: ["Act_S_0.png","Act_S_1.png","Act_S_2.png","Act_S_3.png","Act_S_4.png","Act_S_5.png","Act_S_6.png","Act_S_7.png","Act_S_8.png","Act_S_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 53,
              // start_y: 266,
              // color: 0xFFFFEA83,
              // lenght: 96,
              // line_width: 38,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 316,
              font_array: ["Act_S_0.png","Act_S_1.png","Act_S_2.png","Act_S_3.png","Act_S_4.png","Act_S_5.png","Act_S_6.png","Act_S_7.png","Act_S_8.png","Act_S_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 46,
              y: 266,
              src: 'top_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 1,
              y: 171,
              font_array: ["Batt_0.png","Batt_1.png","Batt_2.png","Batt_3.png","Batt_4.png","Batt_5.png","Batt_6.png","Batt_7.png","Batt_8.png","Batt_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 198,
              image_array: ["Batt_Progress_01.png","Batt_Progress_02.png","Batt_Progress_03.png","Batt_Progress_04.png","Batt_Progress_05.png","Batt_Progress_06.png","Batt_Progress_07.png","Batt_Progress_08.png","Batt_Progress_09.png","Batt_Progress_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 41,
              y: 222,
              font_array: ["Act_S_0.png","Act_S_1.png","Act_S_2.png","Act_S_3.png","Act_S_4.png","Act_S_5.png","Act_S_6.png","Act_S_7.png","Act_S_8.png","Act_S_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'ss_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 222,
              font_array: ["Act_S_0.png","Act_S_1.png","Act_S_2.png","Act_S_3.png","Act_S_4.png","Act_S_5.png","Act_S_6.png","Act_S_7.png","Act_S_8.png","Act_S_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'ss_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 175,
              y: 233,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 231,
              year_startY: 42,
              year_sc_array: ["Year_0.png","Year_1.png","Year_2.png","Year_3.png","Year_4.png","Year_5.png","Year_6.png","Year_7.png","Year_8.png","Year_9.png"],
              year_tc_array: ["Year_0.png","Year_1.png","Year_2.png","Year_3.png","Year_4.png","Year_5.png","Year_6.png","Year_7.png","Year_8.png","Year_9.png"],
              year_en_array: ["Year_0.png","Year_1.png","Year_2.png","Year_3.png","Year_4.png","Year_5.png","Year_6.png","Year_7.png","Year_8.png","Year_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 83,
              y: 62,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 118,
              month_startY: 41,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 166,
              y: 420,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 188,
              y: 104,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 171,
              day_startY: 23,
              day_sc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_tc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_en_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_zero: 0,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -122,
              // y: 109,
              // font_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 340,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'Time_0.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'Time_1.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'Time_2.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'Time_3.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'Time_4.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'Time_5.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'Time_6.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'Time_7.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'Time_8.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'Time_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: -122,
                center_y: 109,
                pos_x: -122,
                pos_y: 109,
                angle: 0,
                src: 'Time_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 208,
              minute_startY: 109,
              minute_array: ["Time_M_0.png","Time_M_1.png","Time_M_2.png","Time_M_3.png","Time_M_4.png","Time_M_5.png","Time_M_6.png","Time_M_7.png","Time_M_8.png","Time_M_9.png"],
              minute_zero: 1,
              minute_space: 340,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -116,
              // y: 109,
              // font_array: ["Time_M_0.png","Time_M_1.png","Time_M_2.png","Time_M_3.png","Time_M_4.png","Time_M_5.png","Time_M_6.png","Time_M_7.png","Time_M_8.png","Time_M_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 176,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'Time_M_0.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'Time_M_1.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'Time_M_2.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'Time_M_3.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'Time_M_4.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'Time_M_5.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'Time_M_6.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'Time_M_7.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'Time_M_8.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'Time_M_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: -116,
                center_y: 109,
                pos_x: -116,
                pos_y: 109,
                angle: 0,
                src: 'Time_M_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 52,
              hour_startY: 109,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 342,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -122,
              // y: 109,
              // font_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 340,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = 'Time_0.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = 'Time_1.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = 'Time_2.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = 'Time_3.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = 'Time_4.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = 'Time_5.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = 'Time_6.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = 'Time_7.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = 'Time_8.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = 'Time_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: -122,
                center_y: 109,
                pos_x: -122,
                pos_y: 109,
                angle: 0,
                src: 'Time_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 208,
              minute_startY: 109,
              minute_array: ["Time_M_0.png","Time_M_1.png","Time_M_2.png","Time_M_3.png","Time_M_4.png","Time_M_5.png","Time_M_6.png","Time_M_7.png","Time_M_8.png","Time_M_9.png"],
              minute_zero: 1,
              minute_space: 340,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 192,
              y: 140,
              src: 'Digital_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -116,
              // y: 109,
              // font_array: ["Time_M_0.png","Time_M_1.png","Time_M_2.png","Time_M_3.png","Time_M_4.png","Time_M_5.png","Time_M_6.png","Time_M_7.png","Time_M_8.png","Time_M_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 176,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = 'Time_M_0.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = 'Time_M_1.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = 'Time_M_2.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = 'Time_M_3.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = 'Time_M_4.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = 'Time_M_5.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = 'Time_M_6.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = 'Time_M_7.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = 'Time_M_8.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = 'Time_M_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: -116,
                center_y: 109,
                pos_x: -116,
                pos_y: 109,
                angle: 0,
                src: 'Time_M_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 52,
              hour_startY: 109,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 342,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 126,
              y: 361,
              w: 120,
              h: 45,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 94,
              y: 306,
              w: 65,
              h: 48,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 282,
              y: 269,
              w: 64,
              h: 81,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 42,
              y: 218,
              w: 313,
              h: 33,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 222,
              y: 281,
              w: 82,
              h: 63,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 43,
              y: 293,
              w: 47,
              h: 60,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 241,
              y: 126,
              w: 78,
              h: 62,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 84,
              y: 130,
              w: 77,
              h: 64,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 103,
              w: 21,
              h: 93,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 1,
              y: 132,
              w: 37,
              h: 62,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 84,
              y: 23,
              w: 225,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 315,
              y: 4,
              w: 70,
              h: 72,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 256,
              w: 32,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // weather
                        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
                        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
                        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
                        normal_temperature_low_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                        normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                        normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
                        normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                        normal_humidity_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
                        normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                        normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
                        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                        normal_calorie_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
                        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                        normal_heart_rate_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
                        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 361,
              y: 257,
              w: 32,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // activity info
                    normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
                        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
                        normal_temperature_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                        normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                        normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                        normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                        normal_humidity_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                        normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                        normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                        normal_calorie_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
                        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                        normal_heart_rate_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
                        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
                        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
                        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
                        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 146,
              // y: 415,
              // w: 100,
              // h: 34,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '0_Empty.png',
              // normal_src: '0_Empty.png',
              // bg_list: bg1|bg2|bg3|bg4|bg5|bg6,
              // toast_list: Dark Blue|Sky Blue|Yellow|Red|Violet|Green,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 146,
              y: 415,
              w: 100,
              h: 34,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, -122 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + 340;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, -116 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + 176;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, -122 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width + 340;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, -116 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width + 176;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_ls_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_linear_scale
                  // initial parameters
                  let start_x_normal_calorie = 338;
                  let start_y_normal_calorie = 266;
                  let lenght_ls_normal_calorie = -94;
                  let line_width_ls_normal_calorie = 38;
                  let color_ls_normal_calorie = 0xFFFFEA83;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw = start_x_normal_calorie;
                  let start_y_normal_calorie_draw = start_y_normal_calorie;
                  lenght_ls_normal_calorie = lenght_ls_normal_calorie * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw = lenght_ls_normal_calorie;
                  let line_width_ls_normal_calorie_draw = line_width_ls_normal_calorie;
                  if (lenght_ls_normal_calorie < 0){
                    lenght_ls_normal_calorie_draw = -lenght_ls_normal_calorie;
                    start_x_normal_calorie_draw = start_x_normal_calorie - lenght_ls_normal_calorie_draw;
                  };
                  
                  normal_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw,
                    y: start_y_normal_calorie_draw,
                    w: lenght_ls_normal_calorie_draw,
                    h: line_width_ls_normal_calorie_draw,
                    color: color_ls_normal_calorie,
                  });
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 184;
                let progressHeartRate = (valueHeartRate - 30)/(targetHeartRate - 30);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 53;
                  let start_y_normal_heart_rate = 266;
                  let lenght_ls_normal_heart_rate = 96;
                  let line_width_ls_normal_heart_rate = 38;
                  let color_ls_normal_heart_rate = 0xFFFFEA83;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    lenght_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_x_normal_heart_rate_draw = start_x_normal_heart_rate - lenght_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    color: color_ls_normal_heart_rate,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) {
normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              normal_step_icon_img.setProperty(hmUI.prop.SRC, "bg_activity_" + parseInt(backgroundIndex+1) + ".png");
              normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "bg_weather_" + parseInt(backgroundIndex+1) + ".png");
}
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}