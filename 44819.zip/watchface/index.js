﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//////Vibration feedback for buttons
const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
let timer_StopVibrate = null;

function makeVibrate(level = 1) {
  stopVibrate();

  //The values are used as follows: 1 for buttons, 2 for open settings menu, 3 for close settings menu
  const levelToScene = {
    1: 26,
    2: 27,
    3: 29
  };

  let scene = levelToScene[level] || 25;
  let stopDelay = scene > 25 ? 1300 : 50;

  vibrate.scene = scene;
  vibrate.start();

  timer_StopVibrate = timer.createTimer(stopDelay, 0, stopVibrate, {});
}

function stopVibrate() {
  vibrate.stop();
  if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
  timer_StopVibrate = null;
}

const colorHEXset = [
    0xFF74C0FC, // Blue
    0xFF66E6FF, // Cyan
    0xFF63E6BE, // Turquoise
    0xFFAEE66D, // Lime
    0xFF8BE78B, // Green
    0xFFFFEB66, // Yellow
    0xFFFFA94D, // Orange
    0xFFFF6B6B, // Red
    0xFFF58AB5, // Pink
    0xFFA68AD9, // Violet
    0xFFFFFFFF, // White
    0xFFC1C9E5, // Gray
];

let colorsIndex_top = 11;
let colorsIndex_bottom = 1;
let currColorHEX_top = colorHEXset[colorsIndex_top];
let currColorHEX_bottom = colorHEXset[colorsIndex_bottom];
let isDigitClockTop_outline = true;
let currDigitStyle_top = isDigitClockTop_outline ? "outline" : "normal";
let isDigitClockBottom_outline = false;
let currDigitStyle_bottom = isDigitClockBottom_outline ? "outline" : "normal";
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_time_second_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let idle_time_second_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'TRANSPARENT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 0,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
let bgColor_top = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 0,
    y: 0,
    w: 390,
    h: 225,
    color: 0xFFC1C9E5,
    show_level: hmUI.show_level.ONLY_NORMAL,
})

let bgColor_bottom = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 0,
    y: 225,
    w: 390,
    h: 225,
    color: 0xFF66E6FF,
    show_level: hmUI.show_level.ONLY_NORMAL,
})

let bgOverlay = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: "BG_OVERLAY.png",
    show_level: hmUI.show_level.ONLY_NORMAL,
})

let bgColor_top_AOD = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 0,
    y: 0,
    w: 390,
    h: 225,
    color: 0xFFC1C9E5,
    show_level: hmUI.show_level.ONLY_AOD,
})

let bgColor_bottom_AOD = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 0,
    y: 225,
    w: 390,
    h: 225,
    color: 0xFF66E6FF,
    show_level: hmUI.show_level.ONLY_AOD,
})

let bgOverlay_AOD = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 0,
    src: "BG_OVERLAY.png",
    show_level: hmUI.show_level.ONLY_AOD,
})
            // end user_script.js


            console.log('Watch_Face.ScreenAOD');

            idle_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 0,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

//////Clock layout
//Normal
let clockDigitHrHigh = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'numbers/outline/NUMBER_0.png',
    x: 38,
    y: 43,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockDigitHrLow = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'numbers/outline/NUMBER_0.png',
    x: 205,
    y: 43,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockDigitMinHigh = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'numbers/normal/NUMBER_0.png',
    x: 38,
    y: 235,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockDigitMinLow = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'numbers/normal/NUMBER_0.png',
    x: 205,
    y: 235,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
//AOD
let clockDigitHrHigh_AOD = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'numbers/outline/NUMBER_0.png',
    x: 38,
    y: 43,
    show_level: hmUI.show_level.ONLY_AOD,
});

let clockDigitHrLow_AOD = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'numbers/outline/NUMBER_0.png',
    x: 205,
    y: 43,
    show_level: hmUI.show_level.ONLY_AOD,
});

let clockDigitMinHigh_AOD = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'numbers/normal/NUMBER_0.png',
    x: 38,
    y: 235,
    show_level: hmUI.show_level.ONLY_AOD,
});

let clockDigitMinLow_AOD = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'numbers/normal/NUMBER_0.png',
    x: 205,
    y: 235,
    show_level: hmUI.show_level.ONLY_AOD,
});

//////Spaces between digits
//Normal
let hrHighSpace = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 0,
    y: 43,
    w: 22,
    h: 172,
    color: 0XFF000000,
    show_level: hmUI.show_level.ONLY_NORMAL
});

let hrLowSpace = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 184,
    y: 43,
    w: 22,
    h: 172,
    color: 0XFF000000,
    show_level: hmUI.show_level.ONLY_NORMAL
});

let minHighSpace = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 0,
    y: 235,
    w: 22,
    h: 172,
    color: 0XFF000000,
    show_level: hmUI.show_level.ONLY_NORMAL
});

let minLowSpace = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 184,
    y: 235,
    w: 22,
    h: 172,
    color: 0XFF000000,
    show_level: hmUI.show_level.ONLY_NORMAL
});
//AOD
let hrHighSpace_AOD = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 0,
    y: 43,
    w: 22,
    h: 172,
    color: 0XFF000000,
    show_level: hmUI.show_level.ONLY_AOD
});

let hrLowSpace_AOD = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 184,
    y: 43,
    w: 22,
    h: 172,
    color: 0XFF000000,
    show_level: hmUI.show_level.ONLY_AOD
});

let minHighSpace_AOD = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 0,
    y: 235,
    w: 22,
    h: 172,
    color: 0XFF000000,
    show_level: hmUI.show_level.ONLY_AOD
});

let minLowSpace_AOD = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 184,
    y: 235,
    w: 22,
    h: 172,
    color: 0XFF000000,
    show_level: hmUI.show_level.ONLY_AOD
});

let currHourFormat = hmSetting.getTimeFormat();
let digitXBase = 38;
let digitWidth_normal = 147;
let digitWidth_one = 87;
let digitOffset = digitWidth_normal - digitWidth_one;
let digitSpace = 20;

function digitX(char){
    return char === "1" ? digitXBase + digitOffset : digitXBase;
}

function updateClock(){
    //Current Clock
    let clockHr = timeSensor.hour;
    let clockMin = timeSensor.minute;

    //Convert clock depending on format (0 = 12h, 1 = 24h)
    if (currHourFormat == 0){
        if (clockHr == 0)       clockHr = 12;
        else if (clockHr > 12)  clockHr -= 12;
    }

    //Add zeros if its less than 10
    let clockHrTXT = clockHr.toString().padStart(2, "0");
    let clockMinsTXT = clockMin.toString().padStart(2, "0");

    //////Extract digits
    //Normal digits
    let clockHrHighSRC = "numbers/" + (hmFS.SysProGetChars('Minimal_DigitStyleTop') ?? "outline") + "/NUMBER_" + clockHrTXT[0] + ".png";
    let clockHrLowSRC = "numbers/" + (hmFS.SysProGetChars('Minimal_DigitStyleTop') ?? "outline") + "/NUMBER_" + clockHrTXT[1] + ".png";
    let clockMinsHighSRC = "numbers/" + (hmFS.SysProGetChars('Minimal_DigitStyleBottom') ?? "normal") + "/NUMBER_" + clockMinsTXT[0] + ".png";
    let clockMinsLowSRC = "numbers/" + (hmFS.SysProGetChars('Minimal_DigitStyleBottom') ?? "normal") + "/NUMBER_" + clockMinsTXT[1] + ".png";

    //Setting alignment
    let HrHighDigitIsZero = clockHrTXT[0] == "0";
    hmFS.SysProSetInt('Minimal_HrHighisZero', HrHighDigitIsZero);
    let hrHighX  = digitX(clockHrTXT[1]);
    hmFS.SysProSetInt('Minimal_HrHighXPos', hrHighX);
    let minHighX = digitX(clockMinsTXT[1]);
    hmFS.SysProSetInt('Minimal_MinHighXPos', minHighX);

    //////Clock
    //Normal
    clockDigitHrHigh.setProperty(hmUI.prop.VISIBLE, !HrHighDigitIsZero);
    clockDigitHrHigh.setProperty(hmUI.prop.MORE, {
        src: clockHrHighSRC,
        x: hrHighX
    });
    clockDigitHrLow.setProperty(hmUI.prop.SRC, clockHrLowSRC);
    clockDigitMinHigh.setProperty(hmUI.prop.MORE, {
        src: clockMinsHighSRC, 
        x: minHighX
    });
    clockDigitMinLow.setProperty(hmUI.prop.SRC, clockMinsLowSRC);
    //AOD
    clockDigitHrHigh_AOD.setProperty(hmUI.prop.VISIBLE, !(hmFS.SysProGetInt('Minimal_HrHighisZero')));
    clockDigitHrHigh_AOD.setProperty(hmUI.prop.MORE, {
        src: clockHrHighSRC,
        x: hmFS.SysProGetInt('Minimal_HrHighXPos')
    });
    clockDigitHrLow_AOD.setProperty(hmUI.prop.SRC, clockHrLowSRC);
    clockDigitMinHigh_AOD.setProperty(hmUI.prop.MORE, {
        src: clockMinsHighSRC, 
        x: hmFS.SysProGetInt('Minimal_MinHighXPos')
    });
    clockDigitMinLow_AOD.setProperty(hmUI.prop.SRC, clockMinsLowSRC);

    //Setting alignment
    let hrHighSpace_w = clockHrTXT[0] === "0" ? 
                        (hrHighX + digitWidth_normal): 
                        (hrHighX + (clockHrTXT[0] === "1" ? digitOffset : 0))
    hmFS.SysProSetInt('Minimal_HrHighSpaceW', hrHighSpace_w);
    let hrLowSpace_xPos = (hrHighX + digitWidth_normal) - 1
    hmFS.SysProSetInt('Minimal_HrLowSpaceXPos', hrLowSpace_xPos);
    let minHighSpace_w = minHighX + (clockMinsTXT[0] === "1" ? digitOffset : 0)
    hmFS.SysProSetInt('Minimal_MinHighSpaceW', minHighSpace_w);
    let minLowSpace_xPos = (minHighX + digitWidth_normal) - 1
    hmFS.SysProSetInt('Minimal_MinLowSpaceXPos', minLowSpace_xPos);
    
    //////Spaces
    //Normal
    hrHighSpace.setProperty(hmUI.prop.W, hrHighSpace_w)
    hrLowSpace.setProperty(hmUI.prop.X, hrLowSpace_xPos)
    minHighSpace.setProperty(hmUI.prop.W, minHighSpace_w)
    minLowSpace.setProperty(hmUI.prop.X, minLowSpace_xPos)
    //AOD
    hrHighSpace_AOD.setProperty(hmUI.prop.W, hmFS.SysProGetInt('Minimal_HrHighSpaceW'))
    hrLowSpace_AOD.setProperty(hmUI.prop.X, hmFS.SysProGetInt('Minimal_HrLowSpaceXPos'))
    minHighSpace_AOD.setProperty(hmUI.prop.W, hmFS.SysProGetInt('Minimal_MinHighSpaceW'))
    minLowSpace_AOD.setProperty(hmUI.prop.X, hmFS.SysProGetInt('Minimal_MinLowSpaceXPos'))
}
            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 95,
              y: 0,
              w: 200,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              longpress_func: (button_widget) => {
                settingsMenu(true)
makeVibrate(2)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 70,
              w: 120,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 220,
              y: 70,
              w: 120,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 260,
              w: 120,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 220,
              y: 260,
              w: 120,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'MusicCommonScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

//////Watchface menu
//Top
let prevColor_topbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 0,
    y: 42,
    w: 125,
    h: 174,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTNPREV_PRESSED.png',
    normal_src: 'settings/BTNPREV_NORMAL.png',
    click_func: (button_widget) => {
    prevColor_top()
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let nextColor_topbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 255,
    y: 42,
    w: 125,
    h: 174,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTNNEXT_PRESSED.png',
    normal_src: 'settings/BTNNEXT_NORMAL.png',
    click_func: (button_widget) => {
    nextColor_top()
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

//Bottom
let prevColor_bottombtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 0,
    y: 234,
    w: 125,
    h: 174,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTNPREV_PRESSED.png',
    normal_src: 'settings/BTNPREV_NORMAL.png',
    click_func: (button_widget) => {
    prevColor_bottom()
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let nextColor_bottombtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 255,
    y: 234,
    w: 125,
    h: 174,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTNNEXT_PRESSED.png',
    normal_src: 'settings/BTNNEXT_NORMAL.png',
    click_func: (button_widget) => {
    nextColor_bottom()
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let changeDigitStyle_topbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 120,
    y: 49,
    w: 150,
    h: 120,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BUTTON.png',
    normal_src: 'settings/BUTTON.png',
    click_func: (button_widget) => {
    changeDigitStyle_top()
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let changeDigitStyle_bottombtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 120,
    y: 281,
    w: 150,
    h: 120,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BUTTON.png',
    normal_src: 'settings/BUTTON.png',
    click_func: (button_widget) => {
    changeDigitStyle_bottom()
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let Confirmbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 135,
    y: 180,
    w: 120,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_CONFIRM_PRESSED.png',
    normal_src: 'settings/BTN_CONFIRM_NORMAL.png',
    click_func: (button_widget) => {
    settingsMenu(false)
    makeVibrate(3)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

function prevColor_top(){
    colorsIndex_top = (colorsIndex_top - 1 + colorHEXset.length) % colorHEXset.length;
    currColorHEX_top = colorHEXset[colorsIndex_top];
    updateWatchface()
}

function nextColor_top(){
    colorsIndex_top = (colorsIndex_top + 1) % colorHEXset.length;
    currColorHEX_top = colorHEXset[colorsIndex_top];
    updateWatchface()
}

function prevColor_bottom(){
    colorsIndex_bottom = (colorsIndex_bottom - 1 + colorHEXset.length) % colorHEXset.length;
    currColorHEX_bottom = colorHEXset[colorsIndex_bottom];
    updateWatchface()
}

function nextColor_bottom(){
    colorsIndex_bottom = (colorsIndex_bottom + 1) % colorHEXset.length;
    currColorHEX_bottom = colorHEXset[colorsIndex_bottom];
    updateWatchface()
}

function changeDigitStyle_top(){
    isDigitClockTop_outline = !isDigitClockTop_outline
    currDigitStyle_top = isDigitClockTop_outline ? "outline" : "normal";
    hmFS.SysProSetChars('Minimal_DigitStyleTop', currDigitStyle_top);
    updateClock()
}

function changeDigitStyle_bottom(){
    isDigitClockBottom_outline = !isDigitClockBottom_outline
    currDigitStyle_bottom = isDigitClockBottom_outline ? "outline" : "normal";
    hmFS.SysProSetChars('Minimal_DigitStyleBottom', currDigitStyle_bottom);
    updateClock()
}

function updateWatchface(){
    bgColor_top.setProperty(hmUI.prop.COLOR, currColorHEX_top)
    hmFS.SysProSetInt('Minimal_bgColorTop', currColorHEX_top);
    bgColor_bottom.setProperty(hmUI.prop.COLOR, currColorHEX_bottom)
    hmFS.SysProSetInt('Minimal_bgColorBottom', currColorHEX_bottom);
}

let watchfaceButtons = [ Button_1, Button_2, Button_3, Button_4, Button_5 ]

let settingMenuLayout = [ prevColor_topbtn, nextColor_topbtn, prevColor_bottombtn, nextColor_bottombtn,
                        changeDigitStyle_topbtn, changeDigitStyle_bottombtn, Confirmbtn ];

function settingsMenu(isMenuVisible){
    watchfaceButtons.forEach(element => element.setProperty(hmUI.prop.VISIBLE, !isMenuVisible));
    settingMenuLayout.forEach(element => element.setProperty(hmUI.prop.VISIBLE, isMenuVisible));
};

settingsMenu(false);

bgColor_top_AOD.setProperty(hmUI.prop.COLOR, hmFS.SysProGetInt('Minimal_bgColorTop') ?? 0xFFC1C9E5)
bgColor_bottom_AOD.setProperty(hmUI.prop.COLOR, hmFS.SysProGetInt('Minimal_bgColorBottom') ?? 0xFF66E6FF)
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
                updateClock()
            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

                console.log('pause_call.js');
                // start pause_call.js

settingsMenu(false)
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}