try {
    (() => {
        var e = __$$hmAppManager$$__.currentApp;
        const n = e.current,
            {
                px: _
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e, n)), e.app.__globals__),
            p = Logger.getLogger("watchface6");
        n.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                let anim = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: "images/anim",
                    anim_prefix: "first_anim_nnkjf",
                    anim_ext: "png",
                    anim_fps: 30,
                    anim_size: 90,
                    repeat_count: 1,
                    anim_repeat: !1,
                    // display_on_restart: !0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                 hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 154,
                    y: 168,
                    week_en: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png"],
                    week_tc: ["11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png"],
                    week_sc: ["18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 208,
                    day_startY: 169,
                    day_sc_array: ["25.png", "26.png", "27.png", "28.png", "29.png", "30.png", "31.png", "32.png", "33.png", "34.png"],
                    day_tc_array: ["25.png", "26.png", "27.png", "28.png", "29.png", "30.png", "31.png", "32.png", "33.png", "34.png"],
                    day_en_array: ["25.png", "26.png", "27.png", "28.png", "29.png", "30.png", "31.png", "32.png", "33.png", "34.png"],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: !1,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 174,
                    y: 273,
                    type: hmUI.data_type.BATTERY,
                    font_array: ["35.png", "36.png", "37.png", "38.png", "39.png", "40.png", "41.png", "42.png", "43.png", "44.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "45.png",
                    unit_tc: "45.png",
                    unit_en: "45.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 195,
                    hour_centerY: 225,
                    hour_posX: 7,
                    hour_posY: 136,
                    hour_path: "47.png",
                    hour_cover_path: "46.png",
                    hour_cover_x: 183,
                    hour_cover_y: 213,
                    minute_centerX: 195,
                    minute_centerY: 225,
                    minute_posX: 7,
                    minute_posY: 181,
                    minute_path: "49.png",
                    minute_cover_path: "48.png",
                    minute_cover_x: 187,
                    minute_cover_y: 217,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: "50.png",
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 195,
                    hour_centerY: 225,
                    hour_posX: 7,
                    hour_posY: 136,
                    hour_path: "47.png",
                    hour_cover_path: "46.png",
                    hour_cover_x: 183,
                    hour_cover_y: 213,
                    minute_centerX: 195,
                    minute_centerY: 225,
                    minute_posX: 7,
                    minute_posY: 181,
                    minute_path: "49.png",
                    minute_cover_path: "48.png",
                    minute_cover_x: 187,
                    minute_cover_y: 217,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                })
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                      console.log('ui resume');
                    //   anim.setProperty(
                    //     hmUI.prop.ANIM_STATUS,
                    //     hmUI.anim_status.STOP
                    //   );
                      anim.setProperty(
                        hmUI.prop.ANIM_STATUS,
                        hmUI.anim_status.START
                      );
                    },
                    pause_call: function () {
                      console.log('ui pause');
                    },
                  });
            },
            onInit() {
                p.log("index page.js on init invoke")
            },
            build() {
                this.init_view(), p.log("index page.js on ready invoke")
            },
            onDestory() {
                p.log("index page.js on destory invoke")
            }
        })
    })()
} catch (e) {
    console.log(e)
}