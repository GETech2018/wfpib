﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_TextRotate = new Array(4);
        let normal_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let normal_calorie_TextRotate_img_width = 37;
        let normal_stand_circle_scale = ''
        let normal_stand_TextRotate = new Array(2);
        let normal_stand_TextRotate_ASCIIARRAY = new Array(10);
        let normal_stand_TextRotate_img_width = 37;
        let normal_stand_TextRotate_unit = null;
        let normal_stand_TextRotate_unit_width = 31;
        let normal_step_circle_scale = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 37;
        let normal_step_TextRotate_unit = null;
        let normal_step_TextRotate_unit_width = 31;
        let normal_temperature_icon_img = ''
        let normal_temperature_high_TextRotate = new Array(4);
        let normal_temperature_high_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_high_TextRotate_img_width = 31;
        let normal_temperature_high_TextRotate_unit = null;
        let normal_temperature_high_TextRotate_unit_width = 25;
        let normal_temperature_high_TextRotate_dot_width = 27;
        let normal_temperature_high_TextRotate_error_img_width = 29;
        let normal_temperature_low_TextRotate = new Array(4);
        let normal_temperature_low_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_low_TextRotate_img_width = 31;
        let normal_temperature_low_TextRotate_unit = null;
        let normal_temperature_low_TextRotate_unit_width = 25;
        let normal_temperature_low_TextRotate_dot_width = 27;
        let normal_temperature_low_TextRotate_error_img_width = 29;
        let normal_temperature_current_TextRotate = new Array(4);
        let normal_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_current_TextRotate_img_width = 37;
        let normal_temperature_current_TextRotate_unit = null;
        let normal_temperature_current_TextRotate_unit_width = 27;
        let normal_temperature_current_TextRotate_dot_width = 31;
        let normal_temperature_current_TextRotate_error_img_width = 33;
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 37;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 40;
        let normal_battery_image_progress_img_level = ''
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 37;
        let normal_timerTextUpdate = undefined;
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 315,
              // center_y: 415,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 17,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFFD7FF5B,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 315,
              center_y: 415,
              start_angle: 0,
              end_angle: 360,
              radius: 15,
              line_width: 5,
              corner_flag: 0,
              color: 0xFFD7FF5B,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 309,
              // y: 345,
              // font_array: ["digits_neon_30_0.png","digits_neon_30_1.png","digits_neon_30_2.png","digits_neon_30_3.png","digits_neon_30_4.png","digits_neon_30_5.png","digits_neon_30_6.png","digits_neon_30_7.png","digits_neon_30_8.png","digits_neon_30_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: -24,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextRotate_ASCIIARRAY[0] = 'digits_neon_30_0.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = 'digits_neon_30_1.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = 'digits_neon_30_2.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = 'digits_neon_30_3.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = 'digits_neon_30_4.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = 'digits_neon_30_5.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = 'digits_neon_30_6.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = 'digits_neon_30_7.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = 'digits_neon_30_8.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = 'digits_neon_30_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 309,
                center_y: 345,
                pos_x: 309,
                pos_y: 345,
                angle: -24,
                src: 'digits_neon_30_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 315,
              // center_y: 415,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 9,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFFD7FF5B,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 315,
              center_y: 415,
              start_angle: 0,
              end_angle: 360,
              radius: 7,
              line_width: 5,
              corner_flag: 0,
              color: 0xFFD7FF5B,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_stand_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 292,
              // y: 350,
              // font_array: ["digits_neon_30_0.png","digits_neon_30_1.png","digits_neon_30_2.png","digits_neon_30_3.png","digits_neon_30_4.png","digits_neon_30_5.png","digits_neon_30_6.png","digits_neon_30_7.png","digits_neon_30_8.png","digits_neon_30_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: -17,
              // unit_en: 'minus_30_-.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_TextRotate_ASCIIARRAY[0] = 'digits_neon_30_0.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[1] = 'digits_neon_30_1.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[2] = 'digits_neon_30_2.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[3] = 'digits_neon_30_3.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[4] = 'digits_neon_30_4.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[5] = 'digits_neon_30_5.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[6] = 'digits_neon_30_6.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[7] = 'digits_neon_30_7.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[8] = 'digits_neon_30_8.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[9] = 'digits_neon_30_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_stand_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 292,
                center_y: 350,
                pos_x: 292,
                pos_y: 350,
                angle: -17,
                src: 'digits_neon_30_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_stand_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_stand_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 292,
              center_y: 350,
              pos_x: 292,
              pos_y: 350,
              angle: -17,
              src: 'minus_30_-.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_stand_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 315,
              // center_y: 415,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 25,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFFD7FF5B,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 315,
              center_y: 415,
              start_angle: 0,
              end_angle: 360,
              radius: 23,
              line_width: 5,
              corner_flag: 0,
              color: 0xFFD7FF5B,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 275,
              // y: 356,
              // font_array: ["digits_neon_30_0.png","digits_neon_30_1.png","digits_neon_30_2.png","digits_neon_30_3.png","digits_neon_30_4.png","digits_neon_30_5.png","digits_neon_30_6.png","digits_neon_30_7.png","digits_neon_30_8.png","digits_neon_30_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: -14,
              // unit_en: 'minus_30_-.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'digits_neon_30_0.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'digits_neon_30_1.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'digits_neon_30_2.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'digits_neon_30_3.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'digits_neon_30_4.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'digits_neon_30_5.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'digits_neon_30_6.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'digits_neon_30_7.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'digits_neon_30_8.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'digits_neon_30_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 275,
                center_y: 356,
                pos_x: 275,
                pos_y: 356,
                angle: -14,
                src: 'digits_neon_30_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_step_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 275,
              center_y: 356,
              pos_x: 275,
              pos_y: 356,
              angle: -14,
              src: 'minus_30_-.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_step_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -1,
              y: 2,
              src: 'TEMP.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_temperature_high_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 265,
              // y: 9,
              // font_array: ["digit_neon_20_0.png","digit_neon_20_1.png","digit_neon_20_2.png","digit_neon_20_3.png","digit_neon_20_4.png","digit_neon_20_5.png","digit_neon_20_6.png","digit_neon_20_7.png","digit_neon_20_8.png","digit_neon_20_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: 26,
              // unit_en: 'grade_20__.png',
              // invalid_image: 'error_20__.png',
              // dot_image: 'minus_20_-.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_high_TextRotate_ASCIIARRAY[0] = 'digit_neon_20_0.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[1] = 'digit_neon_20_1.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[2] = 'digit_neon_20_2.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[3] = 'digit_neon_20_3.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[4] = 'digit_neon_20_4.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[5] = 'digit_neon_20_5.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[6] = 'digit_neon_20_6.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[7] = 'digit_neon_20_7.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[8] = 'digit_neon_20_8.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[9] = 'digit_neon_20_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_temperature_high_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 265,
                center_y: 9,
                pos_x: 265,
                pos_y: 9,
                angle: 26,
                src: 'digit_neon_20_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_high_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 265,
              center_y: 9,
              pos_x: 265,
              pos_y: 9,
              angle: 26,
              src: 'grade_20__.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            // normal_temperature_low_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 374,
              // y: 88,
              // font_array: ["digit_neon_20_0.png","digit_neon_20_1.png","digit_neon_20_2.png","digit_neon_20_3.png","digit_neon_20_4.png","digit_neon_20_5.png","digit_neon_20_6.png","digit_neon_20_7.png","digit_neon_20_8.png","digit_neon_20_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: 49,
              // unit_en: 'grade_20__.png',
              // invalid_image: 'error_20__.png',
              // dot_image: 'minus_20_-.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_low_TextRotate_ASCIIARRAY[0] = 'digit_neon_20_0.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[1] = 'digit_neon_20_1.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[2] = 'digit_neon_20_2.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[3] = 'digit_neon_20_3.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[4] = 'digit_neon_20_4.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[5] = 'digit_neon_20_5.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[6] = 'digit_neon_20_6.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[7] = 'digit_neon_20_7.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[8] = 'digit_neon_20_8.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[9] = 'digit_neon_20_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_temperature_low_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 374,
                center_y: 88,
                pos_x: 374,
                pos_y: 88,
                angle: 49,
                src: 'digit_neon_20_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_low_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 374,
              center_y: 88,
              pos_x: 374,
              pos_y: 88,
              angle: 49,
              src: 'grade_20__.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            // normal_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 339,
              // y: 18,
              // font_array: ["digits_neon_30_0.png","digits_neon_30_1.png","digits_neon_30_2.png","digits_neon_30_3.png","digits_neon_30_4.png","digits_neon_30_5.png","digits_neon_30_6.png","digits_neon_30_7.png","digits_neon_30_8.png","digits_neon_30_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: 35,
              // unit_en: 'grade_30__.png',
              // invalid_image: 'error_30__.png',
              // dot_image: 'minus_30_-.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_current_TextRotate_ASCIIARRAY[0] = 'digits_neon_30_0.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[1] = 'digits_neon_30_1.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[2] = 'digits_neon_30_2.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[3] = 'digits_neon_30_3.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[4] = 'digits_neon_30_4.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[5] = 'digits_neon_30_5.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[6] = 'digits_neon_30_6.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[7] = 'digits_neon_30_7.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[8] = 'digits_neon_30_8.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[9] = 'digits_neon_30_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 339,
                center_y: 18,
                pos_x: 339,
                pos_y: 18,
                angle: 35,
                src: 'digits_neon_30_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 339,
              center_y: 18,
              pos_x: 339,
              pos_y: 18,
              angle: 35,
              src: 'grade_30__.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 74,
              // y: 377,
              // font_array: ["digits_neon_30_0.png","digits_neon_30_1.png","digits_neon_30_2.png","digits_neon_30_3.png","digits_neon_30_4.png","digits_neon_30_5.png","digits_neon_30_6.png","digits_neon_30_7.png","digits_neon_30_8.png","digits_neon_30_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: 26,
              // unit_en: 'percent_size_30__.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'digits_neon_30_0.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'digits_neon_30_1.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'digits_neon_30_2.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'digits_neon_30_3.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'digits_neon_30_4.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'digits_neon_30_5.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'digits_neon_30_6.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'digits_neon_30_7.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'digits_neon_30_8.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'digits_neon_30_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 74,
                center_y: 377,
                pos_x: 74,
                pos_y: 377,
                angle: 26,
                src: 'digits_neon_30_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 74,
              center_y: 377,
              pos_x: 74,
              pos_y: 377,
              angle: 26,
              src: 'percent_size_30__.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: -16,
              y: 337,
              image_array: ["BATTERY_0.png","BATTERY_10.png","BATTERY_20.png","BATTERY_30.png","BATTERY_40.png","BATTERY_50.png","BATTERY_60.png","BATTERY_70.png","BATTERY_80.png","BATTERY_90.png","BATTERY_100.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 49,
              // y: 18,
              // font_array: ["digits_neon_30_0.png","digits_neon_30_1.png","digits_neon_30_2.png","digits_neon_30_3.png","digits_neon_30_4.png","digits_neon_30_5.png","digits_neon_30_6.png","digits_neon_30_7.png","digits_neon_30_8.png","digits_neon_30_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: -32,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = 'digits_neon_30_0.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = 'digits_neon_30_1.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = 'digits_neon_30_2.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = 'digits_neon_30_3.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = 'digits_neon_30_4.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = 'digits_neon_30_5.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = 'digits_neon_30_6.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = 'digits_neon_30_7.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = 'digits_neon_30_8.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = 'digits_neon_30_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 49,
                center_y: 18,
                pos_x: 49,
                pos_y: 18,
                angle: -32,
                src: 'digits_neon_30_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 5,
              y: 5,
              week_en: ["DIA_1.png","DIA_2.png","DIA_3.png","DIA_4.png","DIA_5.png","DIA_6.png","DIA_7.png"],
              week_tc: ["DIA_1.png","DIA_2.png","DIA_3.png","DIA_4.png","DIA_5.png","DIA_6.png","DIA_7.png"],
              week_sc: ["DIA_1.png","DIA_2.png","DIA_3.png","DIA_4.png","DIA_5.png","DIA_6.png","DIA_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 90,
              hour_startY: 92,
              hour_array: ["digits_wh_140_0.png","digits_wh_140_1.png","digits_wh_140_2.png","digits_wh_140_3.png","digits_wh_140_4.png","digits_wh_140_5.png","digits_wh_140_6.png","digits_wh_140_7.png","digits_wh_140_8.png","digits_wh_140_9.png"],
              hour_zero: 1,
              hour_space: -19,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 123,
              minute_startY: 219,
              minute_array: ["digits_neon_140_0.png","digits_neon_140_1.png","digits_neon_140_2.png","digits_neon_140_3.png","digits_neon_140_4.png","digits_neon_140_5.png","digits_neon_140_6.png","digits_neon_140_7.png","digits_neon_140_8.png","digits_neon_140_9.png"],
              minute_zero: 1,
              minute_space: -19,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 90,
              hour_startY: 92,
              hour_array: ["digits_wh_140_0.png","digits_wh_140_1.png","digits_wh_140_2.png","digits_wh_140_3.png","digits_wh_140_4.png","digits_wh_140_5.png","digits_wh_140_6.png","digits_wh_140_7.png","digits_wh_140_8.png","digits_wh_140_9.png"],
              hour_zero: 1,
              hour_space: -19,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 123,
              minute_startY: 219,
              minute_array: ["digits_neon_140_0.png","digits_neon_140_1.png","digits_neon_140_2.png","digits_neon_140_3.png","digits_neon_140_4.png","digits_neon_140_5.png","digits_neon_140_6.png","digits_neon_140_7.png","digits_neon_140_8.png","digits_neon_140_9.png"],
              minute_zero: 1,
              minute_space: -19,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 184,
              y: 370,
              w: 88,
              h: 47,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 329,
              y: 331,
              w: 51,
              h: 47,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 29,
              y: 337,
              w: 121,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 251,
              y: 9,
              w: 122,
              h: 93,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 281,
              y: 345,
              w: 42,
              h: 44,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 134,
              y: 233,
              w: 159,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 117,
              y: 106,
              w: 138,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 24,
              y: 18,
              w: 120,
              h: 69,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 61,
              y: 208,
              w: 68,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'ring_1.png',
              normal_src: 'ring_1.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 288,
              y: 393,
              w: 57,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_rotate_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_rotate_string.length > 0 && normal_calorie_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 309 + img_offset);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, normal_calorie_TextRotate_ASCIIARRAY[charCode]);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_calorie_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate stand_STAND');
              let valueStand = stand.current;
              let normal_stand_rotate_string = parseInt(valueStand).toString();
              normal_stand_rotate_string = normal_stand_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_stand_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_stand_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueStand != null && valueStand != undefined && isFinite(valueStand) && normal_stand_rotate_string.length > 0 && normal_stand_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_stand_TextRotate_posOffset = normal_stand_TextRotate_img_width * normal_stand_rotate_string.length;
                  normal_stand_TextRotate_posOffset = normal_stand_TextRotate_posOffset + -20 * (normal_stand_rotate_string.length - 1);
                  img_offset -= normal_stand_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_stand_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_stand_TextRotate[index].setProperty(hmUI.prop.POS_X, 292 + img_offset);
                      normal_stand_TextRotate[index].setProperty(hmUI.prop.SRC, normal_stand_TextRotate_ASCIIARRAY[charCode]);
                      normal_stand_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_stand_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_stand_TextRotate_unit.setProperty(hmUI.prop.POS_X, 292 + img_offset);
                  normal_stand_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_step_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  normal_step_TextRotate_posOffset = normal_step_TextRotate_posOffset + -20 * (normal_step_rotate_string.length - 1);
                  img_offset -= normal_step_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 275 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_step_TextRotate_unit.setProperty(hmUI.prop.POS_X, 275 + img_offset);
                  normal_step_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let temperature_high_temp = -100;
              if (forecastData.count > 0) {
                temperature_high_temp = forecastData.data[0].high;
              }; // end forecastData;

              console.log('update text rotate temperature_high_forecastData');
              let temperatureHigh = undefined;
              let normal_temperature_high_rotate_string = undefined;
              if (temperature_high_temp > -100) {
                temperatureHigh = 0;
                normal_temperature_high_rotate_string = String(temperature_high_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && normal_temperature_high_rotate_string.length > 0 && normal_temperature_high_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_temperature_high_TextRotate_posOffset = normal_temperature_high_TextRotate_img_width * normal_temperature_high_rotate_string.length;
                  normal_temperature_high_TextRotate_posOffset = normal_temperature_high_TextRotate_posOffset + -20 * (normal_temperature_high_rotate_string.length - 1);
                  img_offset -= normal_temperature_high_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_high_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 265 + img_offset);
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_high_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_high_TextRotate_img_width + -20;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 265 + img_offset);
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.SRC, 'minus_20_-.png');
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_high_TextRotate_dot_width + -20;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.POS_X, 265 + img_offset);
                  normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_temperature_high_TextRotate[0].setProperty(hmUI.prop.POS_X, 265 - normal_temperature_high_TextRotate_error_img_width / 2);
                  normal_temperature_high_TextRotate[0].setProperty(hmUI.prop.SRC, 'error_20__.png');
                  normal_temperature_high_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let temperature_low_temp = -100;
              if (forecastData.count > 0) {
                temperature_low_temp = forecastData.data[0].low;
              }; // end forecastData;

              console.log('update text rotate temperature_low_forecastData');
              let temperatureLow = undefined;
              let normal_temperature_low_rotate_string = undefined;
              if (temperature_low_temp > -100) {
                temperatureLow = 0;
                normal_temperature_low_rotate_string = String(temperature_low_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && normal_temperature_low_rotate_string.length > 0 && normal_temperature_low_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_temperature_low_TextRotate_posOffset = normal_temperature_low_TextRotate_img_width * normal_temperature_low_rotate_string.length;
                  normal_temperature_low_TextRotate_posOffset = normal_temperature_low_TextRotate_posOffset + -20 * (normal_temperature_low_rotate_string.length - 1);
                  img_offset -= normal_temperature_low_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_low_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 374 + img_offset);
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_low_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_low_TextRotate_img_width + -20;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 374 + img_offset);
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.SRC, 'minus_20_-.png');
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_low_TextRotate_dot_width + -20;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.POS_X, 374 + img_offset);
                  normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_temperature_low_TextRotate[0].setProperty(hmUI.prop.POS_X, 374 - normal_temperature_low_TextRotate_error_img_width / 2);
                  normal_temperature_low_TextRotate[0].setProperty(hmUI.prop.SRC, 'error_20__.png');
                  normal_temperature_low_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let temperature_current_temp = -100;
              if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
                temperature_current_temp = weatherSensor.current;
              }; // end currentWeather;

              console.log('update text rotate temperature_current_currentWeather');
              let temperatureCurrent = undefined;
              let normal_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                normal_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && normal_temperature_current_rotate_string.length > 0 && normal_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_img_width * normal_temperature_current_rotate_string.length;
                  normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_posOffset + -20 * (normal_temperature_current_rotate_string.length - 1);
                  img_offset -= normal_temperature_current_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 339 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_img_width + -20;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 339 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'minus_30_-.png');
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_dot_width + -20;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 339 + img_offset);
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.POS_X, 339 - normal_temperature_current_TextRotate_error_img_width / 2);
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.SRC, 'error_30__.png');
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  normal_battery_TextRotate_posOffset = normal_battery_TextRotate_posOffset + -20 * (normal_battery_rotate_string.length - 1);
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 74 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 74 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();
              normal_day_rotate_string = normal_day_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
                  normal_day_TextRotate_posOffset = normal_day_TextRotate_posOffset + -20 * (normal_day_rotate_string.length - 1);
                  img_offset -= normal_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 49 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 315,
                      center_y: 415,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 15,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFFD7FF5B,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 315,
                      center_y: 415,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 7,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFFD7FF5B,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 315,
                      center_y: 415,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 23,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFFD7FF5B,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}