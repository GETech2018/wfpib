﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 357,
              font_array: ["HEARTDIGIT_0.png","HEARTDIGIT_1.png","HEARTDIGIT_2.png","HEARTDIGIT_3.png","HEARTDIGIT_4.png","HEARTDIGIT_5.png","HEARTDIGIT_6.png","HEARTDIGIT_7.png","HEARTDIGIT_8.png","HEARTDIGIT_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 357,
              font_array: ["BATTERYDIGIT_0.png","BATTERYDIGIT_1.png","BATTERYDIGIT_2.png","BATTERYDIGIT_3.png","BATTERYDIGIT_4.png","BATTERYDIGIT_5.png","BATTERYDIGIT_6.png","BATTERYDIGIT_7.png","BATTERYDIGIT_8.png","BATTERYDIGIT_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 261,
              font_array: ["STEPSCOUNT_0.png","STEPSCOUNT_1.png","STEPSCOUNT_2.png","STEPSCOUNT_3.png","STEPSCOUNT_4.png","STEPSCOUNT_5.png","STEPSCOUNT_6.png","STEPSCOUNT_7.png","STEPSCOUNT_8.png","STEPSCOUNT_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'DEGREEICON.png',
              unit_tc: 'DEGREEICON.png',
              unit_en: 'DEGREEICON.png',
              negative_image: 'BATTERYDIGIT_NEGATIVE.png',
              invalid_image: 'BATTERYDIGIT_NODATA.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 244,
              src: 'WEATHER_02.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 86,
              y: 261,
              font_array: ["STEPSCOUNT_0.png","STEPSCOUNT_1.png","STEPSCOUNT_2.png","STEPSCOUNT_3.png","STEPSCOUNT_4.png","STEPSCOUNT_5.png","STEPSCOUNT_6.png","STEPSCOUNT_7.png","STEPSCOUNT_8.png","STEPSCOUNT_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 208,
              day_startY: 178,
              day_sc_array: ["DATENUMBER_00.png","DATENUMBER_01.png","DATENUMBER_02.png","DATENUMBER_03.png","DATENUMBER_04.png","DATENUMBER_05.png","DATENUMBER_06.png","DATENUMBER_07.png","DATENUMBER_08.png","DATENUMBER_09.png"],
              day_tc_array: ["DATENUMBER_00.png","DATENUMBER_01.png","DATENUMBER_02.png","DATENUMBER_03.png","DATENUMBER_04.png","DATENUMBER_05.png","DATENUMBER_06.png","DATENUMBER_07.png","DATENUMBER_08.png","DATENUMBER_09.png"],
              day_en_array: ["DATENUMBER_00.png","DATENUMBER_01.png","DATENUMBER_02.png","DATENUMBER_03.png","DATENUMBER_04.png","DATENUMBER_05.png","DATENUMBER_06.png","DATENUMBER_07.png","DATENUMBER_08.png","DATENUMBER_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 140,
              month_startY: 177,
              month_sc_array: ["MONTHS_ES_01.png","MONTHS_ES_02.png","MONTHS_ES_03.png","MONTHS_ES_04.png","MONTHS_ES_05.png","MONTHS_ES_06.png","MONTHS_ES_07.png","MONTHS_ES_08.png","MONTHS_ES_09.png","MONTHS_ES_10.png","MONTHS_ES_11.png","MONTHS_ES_12.png"],
              month_tc_array: ["MONTHS_ES_01.png","MONTHS_ES_02.png","MONTHS_ES_03.png","MONTHS_ES_04.png","MONTHS_ES_05.png","MONTHS_ES_06.png","MONTHS_ES_07.png","MONTHS_ES_08.png","MONTHS_ES_09.png","MONTHS_ES_10.png","MONTHS_ES_11.png","MONTHS_ES_12.png"],
              month_en_array: ["MONTHS_ES_01.png","MONTHS_ES_02.png","MONTHS_ES_03.png","MONTHS_ES_04.png","MONTHS_ES_05.png","MONTHS_ES_06.png","MONTHS_ES_07.png","MONTHS_ES_08.png","MONTHS_ES_09.png","MONTHS_ES_10.png","MONTHS_ES_11.png","MONTHS_ES_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 95,
              y: 128,
              week_en: ["DAYS_ES_01.png","DAYS_ES_02.png","DAYS_ES_03.png","DAYS_ES_04.png","DAYS_ES_05.png","DAYS_ES_06.png","DAYS_ES_07.png"],
              week_tc: ["DAYS_ES_01.png","DAYS_ES_02.png","DAYS_ES_03.png","DAYS_ES_04.png","DAYS_ES_05.png","DAYS_ES_06.png","DAYS_ES_07.png"],
              week_sc: ["DAYS_ES_01.png","DAYS_ES_02.png","DAYS_ES_03.png","DAYS_ES_04.png","DAYS_ES_05.png","DAYS_ES_06.png","DAYS_ES_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 67,
              hour_startY: 41,
              hour_array: ["HRDIGIT_00.png","HRDIGIT_01.png","HRDIGIT_02.png","HRDIGIT_03.png","HRDIGIT_04.png","HRDIGIT_05.png","HRDIGIT_06.png","HRDIGIT_07.png","HRDIGIT_08.png","HRDIGIT_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 211,
              minute_startY: 41,
              minute_array: ["HRDIGIT_00.png","HRDIGIT_01.png","HRDIGIT_02.png","HRDIGIT_03.png","HRDIGIT_04.png","HRDIGIT_05.png","HRDIGIT_06.png","HRDIGIT_07.png","HRDIGIT_08.png","HRDIGIT_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 208,
              day_startY: 178,
              day_sc_array: ["DATENUMBER_00.png","DATENUMBER_01.png","DATENUMBER_02.png","DATENUMBER_03.png","DATENUMBER_04.png","DATENUMBER_05.png","DATENUMBER_06.png","DATENUMBER_07.png","DATENUMBER_08.png","DATENUMBER_09.png"],
              day_tc_array: ["DATENUMBER_00.png","DATENUMBER_01.png","DATENUMBER_02.png","DATENUMBER_03.png","DATENUMBER_04.png","DATENUMBER_05.png","DATENUMBER_06.png","DATENUMBER_07.png","DATENUMBER_08.png","DATENUMBER_09.png"],
              day_en_array: ["DATENUMBER_00.png","DATENUMBER_01.png","DATENUMBER_02.png","DATENUMBER_03.png","DATENUMBER_04.png","DATENUMBER_05.png","DATENUMBER_06.png","DATENUMBER_07.png","DATENUMBER_08.png","DATENUMBER_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 140,
              month_startY: 177,
              month_sc_array: ["MONTHS_ES_01.png","MONTHS_ES_02.png","MONTHS_ES_03.png","MONTHS_ES_04.png","MONTHS_ES_05.png","MONTHS_ES_06.png","MONTHS_ES_07.png","MONTHS_ES_08.png","MONTHS_ES_09.png","MONTHS_ES_10.png","MONTHS_ES_11.png","MONTHS_ES_12.png"],
              month_tc_array: ["MONTHS_ES_01.png","MONTHS_ES_02.png","MONTHS_ES_03.png","MONTHS_ES_04.png","MONTHS_ES_05.png","MONTHS_ES_06.png","MONTHS_ES_07.png","MONTHS_ES_08.png","MONTHS_ES_09.png","MONTHS_ES_10.png","MONTHS_ES_11.png","MONTHS_ES_12.png"],
              month_en_array: ["MONTHS_ES_01.png","MONTHS_ES_02.png","MONTHS_ES_03.png","MONTHS_ES_04.png","MONTHS_ES_05.png","MONTHS_ES_06.png","MONTHS_ES_07.png","MONTHS_ES_08.png","MONTHS_ES_09.png","MONTHS_ES_10.png","MONTHS_ES_11.png","MONTHS_ES_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 95,
              y: 128,
              week_en: ["DAYS_ES_01.png","DAYS_ES_02.png","DAYS_ES_03.png","DAYS_ES_04.png","DAYS_ES_05.png","DAYS_ES_06.png","DAYS_ES_07.png"],
              week_tc: ["DAYS_ES_01.png","DAYS_ES_02.png","DAYS_ES_03.png","DAYS_ES_04.png","DAYS_ES_05.png","DAYS_ES_06.png","DAYS_ES_07.png"],
              week_sc: ["DAYS_ES_01.png","DAYS_ES_02.png","DAYS_ES_03.png","DAYS_ES_04.png","DAYS_ES_05.png","DAYS_ES_06.png","DAYS_ES_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 67,
              hour_startY: 41,
              hour_array: ["HRDIGIT_00.png","HRDIGIT_01.png","HRDIGIT_02.png","HRDIGIT_03.png","HRDIGIT_04.png","HRDIGIT_05.png","HRDIGIT_06.png","HRDIGIT_07.png","HRDIGIT_08.png","HRDIGIT_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 211,
              minute_startY: 41,
              minute_array: ["HRDIGIT_00.png","HRDIGIT_01.png","HRDIGIT_02.png","HRDIGIT_03.png","HRDIGIT_04.png","HRDIGIT_05.png","HRDIGIT_06.png","HRDIGIT_07.png","HRDIGIT_08.png","HRDIGIT_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 48,
              y: 240,
              w: 119,
              h: 68,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 218,
              y: 334,
              w: 134,
              h: 68,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 41,
              y: 335,
              w: 130,
              h: 66,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 215,
              y: 238,
              w: 134,
              h: 66,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 213,
              y: 27,
              w: 111,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 67,
              y: 23,
              w: 111,
              h: 103,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 107,
              y: 139,
              w: 176,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}