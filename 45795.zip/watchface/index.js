﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_sleep_score_font = ''
        let idle_wakeup_count_font = ''
        let idle_wakeup_time_font = ''
        let idle_sleep_time_font = ''
        let idle_sleep_duration_total_font = ''
        let idle_sleep_end_font = ''
        let idle_sleep_start_font = ''
        let array_sleep_chart = []
        let idle_sleep_chart_group = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_alarm_clock_text_text_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let timeSensor = '';
        let sleepSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('user_script_start.js');
            // start user_script_start.js

let myNightTimer = null;

function checkDayNightTheme() {
    const date = new Date();
    const hours = date.getHours();
    
    // Kontrola, zda komponenta na obrazovce reálně existuje
    if (typeof normal_digital_clock_img_time !== 'undefined' && normal_digital_clock_img_time) {
        if (hours >= 22 || hours < 5) {
            // NOČNÍ REŽIM: Nastavíme průhlednost na hodnotu 70 (z rozsahu 0 až 255)
            // Hodiny budou v noci velmi tlumené a nebudou oslňovat
            normal_digital_clock_img_time.setProperty(hmUI.prop.ALPHA, 70); 
        } else {
            // DENNÍ REŽIM: Plný jas (hodnota 255)
            normal_digital_clock_img_time.setProperty(hmUI.prop.ALPHA, 255); 
        }
    }
}

            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'background_green.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 357,
              center_y: 418,
              start_angle: -148,
              end_angle: 148,
              radius: 48,
              line_width: 10,
              corner_flag: 3,
              type: hmUI.data_type.HEART,
              color: 0xFF7FFF00,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 300,
              y: 362,
              src: 'image_ring.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 412,
              font_array: ["act_green_0.png","act_green_1.png","act_green_2.png","act_green_3.png","act_green_4.png","act_green_5.png","act_green_6.png","act_green_7.png","act_green_8.png","act_green_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'dot_green.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 216,
              // center_y: 418,
              // start_angle: -148,
              // end_angle: 148,
              // radius: 53,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF7FFF00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 216,
              center_y: 418,
              start_angle: -148,
              end_angle: 148,
              radius: 48,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF7FFF00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 160,
              y: 362,
              src: 'image_ring.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 412,
              font_array: ["act_green_0.png","act_green_1.png","act_green_2.png","act_green_3.png","act_green_4.png","act_green_5.png","act_green_6.png","act_green_7.png","act_green_8.png","act_green_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 74,
              // center_y: 418,
              // start_angle: -148,
              // end_angle: 148,
              // radius: 53,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF7FFF00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 74,
              center_y: 418,
              start_angle: -148,
              end_angle: 148,
              radius: 48,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF7FFF00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 17,
              y: 362,
              src: 'image_ring.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 412,
              font_array: ["act_green_0.png","act_green_1.png","act_green_2.png","act_green_3.png","act_green_4.png","act_green_5.png","act_green_6.png","act_green_7.png","act_green_8.png","act_green_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 164,
              y: 0,
              w: 150,
              h: 30,
              text_size: 16,
              char_space: 0,
              color: 0xFF7FFF00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 50,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 126,
              font_array: ["act_green_0.png","act_green_1.png","act_green_2.png","act_green_3.png","act_green_4.png","act_green_5.png","act_green_6.png","act_green_7.png","act_green_8.png","act_green_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'pointer_2.png',
              unit_tc: 'pointer_2.png',
              unit_en: 'pointer_2.png',
              imperial_unit_sc: 'pointer_2.png',
              imperial_unit_tc: 'pointer_2.png',
              imperial_unit_en: 'pointer_2.png',
              negative_image: 'pointer_3.png',
              invalid_image: 'dot_green.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 202,
                y: 126,
                font_array: ["act_green_0.png","act_green_1.png","act_green_2.png","act_green_3.png","act_green_4.png","act_green_5.png","act_green_6.png","act_green_7.png","act_green_8.png","act_green_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'pointer_2.png',
                unit_tc: 'pointer_2.png',
                unit_en: 'pointer_2.png',
                imperial_unit_sc: 'pointer_2.png',
                imperial_unit_tc: 'pointer_2.png',
                imperial_unit_en: 'pointer_2.png',
                negative_image: 'pointer_3.png',
                invalid_image: 'dot_green.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 357,
              // center_y: 99,
              // start_angle: -148,
              // end_angle: 148,
              // radius: 53,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF7FFF00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 357,
              center_y: 99,
              start_angle: -148,
              end_angle: 148,
              radius: 48,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF7FFF00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 300,
              y: 44,
              src: 'image_ring.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 91,
              font_array: ["act_green_0.png","act_green_1.png","act_green_2.png","act_green_3.png","act_green_4.png","act_green_5.png","act_green_6.png","act_green_7.png","act_green_8.png","act_green_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'percent_green.png',
              unit_tc: 'percent_green.png',
              unit_en: 'percent_green.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 339,
              year_startY: 319,
              year_sc_array: ["date_green_0.png","date_green_1.png","date_green_2.png","date_green_3.png","date_green_4.png","date_green_5.png","date_green_6.png","date_green_7.png","date_green_8.png","date_green_9.png"],
              year_tc_array: ["date_green_0.png","date_green_1.png","date_green_2.png","date_green_3.png","date_green_4.png","date_green_5.png","date_green_6.png","date_green_7.png","date_green_8.png","date_green_9.png"],
              year_en_array: ["date_green_0.png","date_green_1.png","date_green_2.png","date_green_3.png","date_green_4.png","date_green_5.png","date_green_6.png","date_green_7.png","date_green_8.png","date_green_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 276,
              month_startY: 319,
              month_sc_array: ["date_green_0.png","date_green_1.png","date_green_2.png","date_green_3.png","date_green_4.png","date_green_5.png","date_green_6.png","date_green_7.png","date_green_8.png","date_green_9.png"],
              month_tc_array: ["date_green_0.png","date_green_1.png","date_green_2.png","date_green_3.png","date_green_4.png","date_green_5.png","date_green_6.png","date_green_7.png","date_green_8.png","date_green_9.png"],
              month_en_array: ["date_green_0.png","date_green_1.png","date_green_2.png","date_green_3.png","date_green_4.png","date_green_5.png","date_green_6.png","date_green_7.png","date_green_8.png","date_green_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 213,
              day_startY: 319,
              day_sc_array: ["date_green_0.png","date_green_1.png","date_green_2.png","date_green_3.png","date_green_4.png","date_green_5.png","date_green_6.png","date_green_7.png","date_green_8.png","date_green_9.png"],
              day_tc_array: ["date_green_0.png","date_green_1.png","date_green_2.png","date_green_3.png","date_green_4.png","date_green_5.png","date_green_6.png","date_green_7.png","date_green_8.png","date_green_9.png"],
              day_en_array: ["date_green_0.png","date_green_1.png","date_green_2.png","date_green_3.png","date_green_4.png","date_green_5.png","date_green_6.png","date_green_7.png","date_green_8.png","date_green_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 25,
              y: 303,
              week_en: ["day_green_1.png","day_green_2.png","day_green_3.png","day_green_4.png","day_green_5.png","day_green_6.png","day_green_7.png"],
              week_tc: ["day_green_1.png","day_green_2.png","day_green_3.png","day_green_4.png","day_green_5.png","day_green_6.png","day_green_7.png"],
              week_sc: ["day_green_1.png","day_green_2.png","day_green_3.png","day_green_4.png","day_green_5.png","day_green_6.png","day_green_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 22,
              hour_startY: 185,
              hour_array: ["time_green_0.png","time_green_1.png","time_green_2.png","time_green_3.png","time_green_4.png","time_green_5.png","time_green_6.png","time_green_7.png","time_green_8.png","time_green_9.png"],
              hour_zero: 0,
              hour_space: 4,
              hour_angle: 0,
              hour_unit_sc: 'pointer_0.png',
              hour_unit_tc: 'pointer_0.png',
              hour_unit_en: 'pointer_0.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 236,
              minute_startY: 185,
              minute_array: ["time_green_0.png","time_green_1.png","time_green_2.png","time_green_3.png","time_green_4.png","time_green_5.png","time_green_6.png","time_green_7.png","time_green_8.png","time_green_9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 97,
              hour_centerY: 82,
              hour_posX: 4,
              hour_posY: 34,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 97,
              minute_centerY: 82,
              minute_posX: 3,
              minute_posY: 51,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 97,
              second_centerY: 82,
              second_posX: 5,
              second_posY: 57,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'background_red.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sleep_score_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 360,
              y: 421,
              w: 60,
              h: 20,
              text_size: 18,
              char_space: 0,
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wakeup_count_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 9,
              y: 393,
              w: 60,
              h: 20,
              text_size: 18,
              char_space: 0,
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wakeup_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 9,
              y: 366,
              w: 60,
              h: 20,
              text_size: 18,
              char_space: 0,
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sleep_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 360,
              y: 393,
              w: 60,
              h: 20,
              text_size: 18,
              char_space: 0,
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sleep_duration_total_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 359,
              y: 366,
              w: 60,
              h: 20,
              text_size: 18,
              char_space: 0,
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sleep_end_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 293,
              y: 491,
              w: 60,
              h: 20,
              text_size: 14,
              char_space: 0,
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            idle_sleep_start_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 82,
              y: 491,
              w: 60,
              h: 20,
              text_size: 12,
              char_space: 0,
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_end: 1,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sleep_chart_group = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 112,
              y: 360,
              w: 213,
              h: 120,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 338,
              y: 36,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 256,
              y: 37,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 174,
              y: 37,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 375,
              y: 104,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 117,
              font_array: ["date_red_0.png","date_red_1.png","date_red_2.png","date_red_3.png","date_red_4.png","date_red_5.png","date_red_6.png","date_red_7.png","date_red_8.png","date_red_9.png"],
              padding: true,
              h_space: 3,
              invalid_image: 'dot_red.png',
              dot_image: 'pointer_4.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 81,
              // center_y: 95,
              // start_angle: -148,
              // end_angle: 148,
              // radius: 53,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 81,
              center_y: 95,
              start_angle: -148,
              end_angle: 148,
              radius: 48,
              line_width: 10,
              corner_flag: 3,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 25,
              y: 39,
              src: 'image_ring.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 53,
              y: 86,
              font_array: ["act_red_0.png","act_red_1.png","act_red_2.png","act_red_3.png","act_red_4.png","act_red_5.png","act_red_6.png","act_red_7.png","act_red_8.png","act_red_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'percent_red.png',
              unit_tc: 'percent_red.png',
              unit_en: 'percent_red.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 339,
              year_startY: 319,
              year_sc_array: ["date_red_0.png","date_red_1.png","date_red_2.png","date_red_3.png","date_red_4.png","date_red_5.png","date_red_6.png","date_red_7.png","date_red_8.png","date_red_9.png"],
              year_tc_array: ["date_red_0.png","date_red_1.png","date_red_2.png","date_red_3.png","date_red_4.png","date_red_5.png","date_red_6.png","date_red_7.png","date_red_8.png","date_red_9.png"],
              year_en_array: ["date_red_0.png","date_red_1.png","date_red_2.png","date_red_3.png","date_red_4.png","date_red_5.png","date_red_6.png","date_red_7.png","date_red_8.png","date_red_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 276,
              month_startY: 319,
              month_sc_array: ["date_red_0.png","date_red_1.png","date_red_2.png","date_red_3.png","date_red_4.png","date_red_5.png","date_red_6.png","date_red_7.png","date_red_8.png","date_red_9.png"],
              month_tc_array: ["date_red_0.png","date_red_1.png","date_red_2.png","date_red_3.png","date_red_4.png","date_red_5.png","date_red_6.png","date_red_7.png","date_red_8.png","date_red_9.png"],
              month_en_array: ["date_red_0.png","date_red_1.png","date_red_2.png","date_red_3.png","date_red_4.png","date_red_5.png","date_red_6.png","date_red_7.png","date_red_8.png","date_red_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 213,
              day_startY: 319,
              day_sc_array: ["date_red_0.png","date_red_1.png","date_red_2.png","date_red_3.png","date_red_4.png","date_red_5.png","date_red_6.png","date_red_7.png","date_red_8.png","date_red_9.png"],
              day_tc_array: ["date_red_0.png","date_red_1.png","date_red_2.png","date_red_3.png","date_red_4.png","date_red_5.png","date_red_6.png","date_red_7.png","date_red_8.png","date_red_9.png"],
              day_en_array: ["date_red_0.png","date_red_1.png","date_red_2.png","date_red_3.png","date_red_4.png","date_red_5.png","date_red_6.png","date_red_7.png","date_red_8.png","date_red_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 25,
              y: 303,
              week_en: ["day_red_1.png","day_red_2.png","day_red_3.png","day_red_4.png","day_red_5.png","day_red_6.png","day_red_7.png"],
              week_tc: ["day_red_1.png","day_red_2.png","day_red_3.png","day_red_4.png","day_red_5.png","day_red_6.png","day_red_7.png"],
              week_sc: ["day_red_1.png","day_red_2.png","day_red_3.png","day_red_4.png","day_red_5.png","day_red_6.png","day_red_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 22,
              hour_startY: 185,
              hour_array: ["time_red_0.png","time_red_1.png","time_red_2.png","time_red_3.png","time_red_4.png","time_red_5.png","time_red_6.png","time_red_7.png","time_red_8.png","time_red_9.png"],
              hour_zero: 0,
              hour_space: 4,
              hour_angle: 0,
              hour_unit_sc: 'pointer_1.png',
              hour_unit_tc: 'pointer_1.png',
              hour_unit_en: 'pointer_1.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 236,
              minute_startY: 185,
              minute_array: ["time_red_0.png","time_red_1.png","time_red_2.png","time_red_3.png","time_red_4.png","time_red_5.png","time_red_6.png","time_red_7.png","time_red_8.png","time_red_9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (!sleepSensor) sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
            //#region sleep_update
            function sleep_update() {
              console.log('sleep_update()');
              let sleepInfo = sleepSensor.getBasicInfo();

              console.log('sleep score');
              let sleepScore = sleepInfo.score;
              if (idle_sleep_score_font) idle_sleep_score_font.setProperty(hmUI.prop.TEXT, String(sleepScore));

              console.log('sleep wakeup count');
              let sleepTime = sleepSensor.getTotalTime();
              const modelData = sleepSensor.getSleepStageModel();
              let sleepStageArray = sleepSensor.getSleepStageData();
              let wakeupTime = 0;
              let wakeupCount = 0;

              for (let i = 0; i < sleepStageArray.length; i++) {
                let data = sleepStageArray[i];
                if (data.model == modelData.WAKE_STAGE) {
                  wakeupTime += data.stop + 1 - data.start;
                  wakeupCount++;
                };
              };
              sleepTime -= wakeupTime;
              if (idle_wakeup_count_font) idle_wakeup_count_font.setProperty(hmUI.prop.TEXT, String(wakeupCount));

              console.log('sleep wakeup time');
              let wakeupTimeHour = Math.floor(wakeupTime / 60);
              let wakeupTimeMin = wakeupTime % 60;

              if (idle_wakeup_time_font) idle_wakeup_time_font.setProperty(hmUI.prop.TEXT, wakeupTime.toString());

              console.log('sleep duration time');
              let sleepTimeHour = Math.floor(sleepTime / 60);
              let sleepTimeMin = sleepTime % 60;

              let idle_sleepTimeHourStr = sleepTimeHour.toString();
              idle_sleepTimeHourStr = idle_sleepTimeHourStr.padStart(2, '0');
              let idle_sleepTimeMinStr = sleepTimeMin.toString().padStart(2, '0');
              let idle_sleepTimeStr = idle_sleepTimeHourStr + ':' + idle_sleepTimeMinStr;
              if (idle_sleep_time_font) idle_sleep_time_font.setProperty(hmUI.prop.TEXT, idle_sleepTimeStr);

              console.log('sleep duration total time');
              let sleepDurationTotalTime = sleepSensor.getTotalTime();
              let sleepDurationTotalHour = Math.floor(sleepDurationTotalTime / 60);
              let sleepDurationTotalMin = sleepDurationTotalTime % 60;

              let idle_sleepDurationTotalHourStr = sleepDurationTotalHour.toString();
              idle_sleepDurationTotalHourStr = idle_sleepDurationTotalHourStr.padStart(2, '0');
              let idle_sleepDurationTotalMinStr = sleepDurationTotalMin.toString().padStart(2, '0');
              let idle_SleepDurationStr = idle_sleepDurationTotalHourStr + ':' + idle_sleepDurationTotalMinStr;
              if (idle_sleep_duration_total_font) idle_sleep_duration_total_font.setProperty(hmUI.prop.TEXT, idle_SleepDurationStr);

              console.log('sleep end time');
              let sleepEndTime = sleepInfo.endTime;
              if (sleepEndTime >= 24*60) sleepEndTime -= 24*60;
              let sleepEndHour = Math.floor(sleepEndTime / 60);
              if (!timeSensor.is24Hour) {
                if (sleepEndHour >= 12) sleepEndHour -= 12;
                if (sleepEndHour == 0) sleepEndHour = 12;
              };
              let sleepEndMin = sleepEndTime % 60;

              let idle_sleepEndHourStr = sleepEndHour.toString();
              let idle_SleepEndMinStr = sleepEndMin.toString().padStart(2, '0');
              let idle_SleepEndStr = idle_sleepEndHourStr + ':' + idle_SleepEndMinStr;
              if (!timeSensor.is24Hour) {
                if (Math.floor(sleepEndTime / 60) > 11) idle_SleepEndStr = 'pm ' + idle_SleepEndStr
                else idle_SleepEndStr = 'am ' + idle_SleepEndStr
              };
              if (idle_sleep_end_font) idle_sleep_end_font.setProperty(hmUI.prop.TEXT, idle_SleepEndStr);

              console.log('sleep start time');
              let sleepStartTime = sleepInfo.startTime;
              if (sleepStartTime >= 24*60) sleepStartTime -= 24*60;
              let sleepStartHour = Math.floor(sleepStartTime / 60);
              if (!timeSensor.is24Hour) {
                if (sleepStartHour >= 12) sleepStartHour -= 12;
                if (sleepStartHour == 0) sleepStartHour = 12;
              };
              let sleepStartMin = sleepStartTime % 60;

              let idle_SleepStartHourStr = sleepStartHour.toString();
              let idle_SleepStartMinStr = sleepStartMin.toString().padStart(2, '0');
              let idle_SleepStartStr = idle_SleepStartHourStr + ':' + idle_SleepStartMinStr;
              if (!timeSensor.is24Hour) {
                if (Math.floor(sleepStartTime / 60) > 11) idle_SleepStartStr = idle_SleepStartStr + ' pm';
                else idle_SleepStartStr = idle_SleepStartStr + ' am';
              };
              if (idle_sleep_start_font) idle_sleep_start_font.setProperty(hmUI.prop.TEXT, idle_SleepStartStr);

              console.log('sleep chart');
              let idle_sleepColors = [0xFF660000, 0xFFB30000, 0xFFFF4D4D, 0xFFFF0000];
              let idle_sleppChartWidth = 213;
              let idle_sleppChartHeight = 120;
              let idle_sleepScaleX = idle_sleppChartWidth / sleepSensor.getTotalTime();
              let idle_sleepScaleY = idle_sleppChartHeight / 4;
              let sleepChartStartTime = 0;
              if (array_sleep_chart.length > 0) {
                console.log('deleteWidget screen on');
                for (let i = 0; i < array_sleep_chart.length; i++) {
                  if (array_sleep_chart[i]) hmUI.deleteWidget(array_sleep_chart[i]);
                }
                array_sleep_chart = [];
              } // end if

              if (sleepStageArray != undefined && sleepStageArray.length > 0) sleepChartStartTime = sleepStageArray[0].start;
              // console.log('draw idle_sleep_chart');
              if (screenType == hmSetting.screen_type.AOD) {
                for (let i = 0; i < sleepStageArray.length; i++) { //ONLY_AOD
                  let data = sleepStageArray[i];
                  let idle_color = idle_sleepColors[0];
                  let idle_posY = 3 * idle_sleepScaleY;

                  switch (data.model) {
                    case modelData.WAKE_STAGE:
                      idle_color = idle_sleepColors[3];
                      idle_posY = 0;
                      break;
                    case modelData.REM_STAGE:
                      idle_color = idle_sleepColors[2];
                      idle_posY = idle_sleepScaleY; 
                      break;
                    case modelData.LIGHT_STAGE:
                      idle_color = idle_sleepColors[1];
                      idle_posY = 2 * idle_sleepScaleY; 
                      break;
                  };
                  let idle_x = (data.start - sleepChartStartTime) * idle_sleepScaleX;
                  let idle_w = (data.stop + 1 - data.start) * idle_sleepScaleX;
                  const fill_rect = idle_sleep_chart_group.createWidget(hmUI.widget.FILL_RECT, {
                    x: idle_x,
                    y: idle_posY,
                    w: idle_w < 2 ? 2 : idle_w,
                    h: idle_sleepScaleY,
                    radius: 0,
                    color: idle_color,
                  });
                  array_sleep_chart.push(fill_rect);
                }; // for
              }; // end screenType

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 216,
                      center_y: 418,
                      start_angle: -148,
                      end_angle: 148,
                      radius: 48,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF7FFF00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 74,
                      center_y: 418,
                      start_angle: -148,
                      end_angle: 148,
                      radius: 48,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF7FFF00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 357,
                      center_y: 99,
                      start_angle: -148,
                      end_angle: 148,
                      radius: 48,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF7FFF00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 81,
                      center_y: 95,
                      start_angle: -148,
                      end_angle: 148,
                      radius: 48,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                sleep_update();

                console.log('resume_call.js');
                // start resume_call.js

// Zavolá se ihned, jakmile otočíte zápěstím a displej se probudí
checkDayNightTheme();

// Nastartuje kontrolu každých 30 vteřin, kdyby hodinky svítily déle
if (!myNightTimer) {
    myNightTimer = timer.createTimer(0, 30000, function () {
        checkDayNightTheme();
    });
}
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');

                if (array_sleep_chart.length > 0) {
                console.log('deleteWidget screen off');
                  for (let i = 0; i < array_sleep_chart.length; i++) {
                    if (array_sleep_chart[i]) hmUI.deleteWidget(array_sleep_chart[i]);
                  }
                  array_sleep_chart = [];
                } // end if

                console.log('pause_call.js');
                // start pause_call.js

// Jakmile displej zhasne, stopneme časovač, aby nežral baterii T-Rex 3 / Bip Max
if (myNightTimer) {
    timer.stopTimer(myNightTimer);
    myNightTimer = null;
}
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}