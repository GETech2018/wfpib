﻿    /*
    ** Watch_Face_Editor tool v 17.2
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Change color Time

        let colornumber_mainT = 1
        let totalcolors_mainT = 6
        let namecolor_mainT = ''
        let path =''

        function click_time() {
            if(colornumber_mainT>=totalcolors_mainT) {
            colornumber_mainT=1;
                }
            else {
                colornumber_mainT=colornumber_mainT+1;
            }

if ( colornumber_mainT == 1) { namecolor_mainT = "WHITE"
path = ''
}
if ( colornumber_mainT == 2) { namecolor_mainT = "YELLOW"
path ="2YL/"
}
if ( colornumber_mainT == 3) { namecolor_mainT = "GREEN"
path = "3GR/"
}
if ( colornumber_mainT == 4) { namecolor_mainT = "RED"
path = "4RE/"
}
if ( colornumber_mainT == 5) { namecolor_mainT = "ORANGE"
path = "5OR/"
}
if ( colornumber_mainT == 6) { namecolor_mainT = "BLUE"
path = "6BL/"
}
hmUI.showToast({text: namecolor_mainT });


            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 263,
              hour_startY: 147,
              hour_array: [path+"Time_Font_HM_01.png",path+"Time_Font_HM_02.png",path+"Time_Font_HM_03.png",path+"Time_Font_HM_04.png",path+"Time_Font_HM_05.png",path+"Time_Font_HM_06.png",path+"Time_Font_HM_07.png",path+"Time_Font_HM_08.png",path+"Time_Font_HM_09.png",path+"Time_Font_HM_10.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
}



        function click_timeM() {
            if(colornumber_mainT>=totalcolors_mainT) {
            colornumber_mainT=1;
                }
            else {
                colornumber_mainT=colornumber_mainT+1;
            }

if ( colornumber_mainT == 1) { namecolor_mainT = "WHITE"
path = ''
}
if ( colornumber_mainT == 2) { namecolor_mainT = "YELLOW"
path ="2YL/"
}
if ( colornumber_mainT == 3) { namecolor_mainT = "GREEN"
path = "3GR/"
}
if ( colornumber_mainT == 4) { namecolor_mainT = "RED"
path = "4RE/"
}
if ( colornumber_mainT == 5) { namecolor_mainT = "ORANGE"
path = "5OR/"
}
if ( colornumber_mainT == 6) { namecolor_mainT = "BLUE"
path = "6BL/"
}
hmUI.showToast({text: namecolor_mainT });

             normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 259,
              minute_startY: 253,
              minute_array: [path+"Time_Font_HM_01.png",path+"Time_Font_HM_02.png",path+"Time_Font_HM_03.png",path+"Time_Font_HM_04.png",path+"Time_Font_HM_05.png",path+"Time_Font_HM_06.png",path+"Time_Font_HM_07.png",path+"Time_Font_HM_08.png",path+"Time_Font_HM_09.png",path+"Time_Font_HM_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


}

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Change color style
        let colornumber_main = 1
        let totalcolors_main = 6
        let namecolor_main = ''

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

if ( colornumber_main == 1) { namecolor_main = "BLACK"
path = ''
}
if ( colornumber_main == 2) { namecolor_main = "YELLOW"
path ="2YL/"
}
if ( colornumber_main == 3) { namecolor_main = "GREEN"
path = "3GR/"
}
if ( colornumber_main == 4) { namecolor_main = "RED"
path = "4RE/"
}
if ( colornumber_main == 5) { namecolor_main = "ORANGE"
path = "5OR/"
}
if ( colornumber_main == 6) { namecolor_main = "BLUE"
path = "6BL/"
}
hmUI.showToast({text: namecolor_main });

        normal_image_img.setProperty(hmUI.prop.SRC, "RingT" + parseInt(colornumber_main) + ".png");
        normal_battery_icon_img.setProperty(hmUI.prop.SRC, "RingB" + parseInt(colornumber_main) + ".png");

             normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 259,
              minute_startY: 253,
              minute_array: [path+"Time_Font_HM_01.png",path+"Time_Font_HM_02.png",path+"Time_Font_HM_03.png",path+"Time_Font_HM_04.png",path+"Time_Font_HM_05.png",path+"Time_Font_HM_06.png",path+"Time_Font_HM_07.png",path+"Time_Font_HM_08.png",path+"Time_Font_HM_09.png",path+"Time_Font_HM_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 263,
              hour_startY: 147,
              hour_array: [path+"Time_Font_HM_01.png",path+"Time_Font_HM_02.png",path+"Time_Font_HM_03.png",path+"Time_Font_HM_04.png",path+"Time_Font_HM_05.png",path+"Time_Font_HM_06.png",path+"Time_Font_HM_07.png",path+"Time_Font_HM_08.png",path+"Time_Font_HM_09.png",path+"Time_Font_HM_10.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
             
        }

/////////////////////////////////////////////////////////////////////////////////////////////////

        function click_ColorT() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

if ( colornumber_main == 1) { namecolor_main = "BLACK"}
if ( colornumber_main == 2) { namecolor_main = "YELLOW"}
if ( colornumber_main == 3) { namecolor_main = "GREEN"}
if ( colornumber_main == 4) { namecolor_main = "RED"}
if ( colornumber_main == 5) { namecolor_main = "ORANGE"}
if ( colornumber_main == 6) { namecolor_main = "BLUE"}
hmUI.showToast({text: namecolor_main });

        normal_image_img.setProperty(hmUI.prop.SRC, "RingT" + parseInt(colornumber_main) + ".png");
           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////

        function click_ColorB() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

if ( colornumber_main == 1) { namecolor_main = "BLACK"}
if ( colornumber_main == 2) { namecolor_main = "YELLOW"}
if ( colornumber_main == 3) { namecolor_main = "GREEN"}
if ( colornumber_main == 4) { namecolor_main = "RED"}
if ( colornumber_main == 5) { namecolor_main = "ORANGE"}
if ( colornumber_main == 6) { namecolor_main = "BLUE"}
hmUI.showToast({text: namecolor_main });

      normal_battery_icon_img.setProperty(hmUI.prop.SRC, "RingB" + parseInt(colornumber_main) + ".png");             
        }

/////////////////////////////////////////////////////////////////////////////////////////////////
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_system_clock_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_distance_TextRotate = new Array(5);
        let normal_distance_TextRotate_ASCIIARRAY = new Array(10);
        let normal_distance_TextRotate_img_width = 1;
        let normal_distance_TextRotate_unit = null;
        let normal_distance_TextRotate_unit_width = 31;
        let normal_distance_TextRotate_dot_width = 1;
        let normal_distance_TextRotate_error_img_width = 1;
        let normal_distance_text_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_system_clock_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_distance_TextRotate = new Array(5);
        let idle_distance_TextRotate_ASCIIARRAY = new Array(10);
        let idle_distance_TextRotate_img_width = 1;
        let idle_distance_TextRotate_unit = null;
        let idle_distance_TextRotate_unit_width = 31;
        let idle_distance_TextRotate_dot_width = 1;
        let idle_distance_TextRotate_error_img_width = 1;
        let idle_distance_text_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_step_current_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let normal_cal_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 92,
              y: 62,
              src: 'RingT1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 253,
              y: 479,
              week_en: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_tc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_sc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 91,
              month_startY: 478,
              month_sc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_tc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_en_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 181,
              day_startY: 473,
              day_sc_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              day_tc_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              day_en_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              day_zero: 1,
              day_space: 6,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 226,
              y: 252,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 73,
              y: 265,
              src: 'RingB1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 3,
              y: 143,
              font_array: ["Weather_fonts_01.png","Weather_fonts_02.png","Weather_fonts_03.png","Weather_fonts_04.png","Weather_fonts_05.png","Weather_fonts_06.png","Weather_fonts_07.png","Weather_fonts_08.png","Weather_fonts_09.png","Weather_fonts_10.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 1,
              y: 201,
              image_array: ["Battery_icons_01.png","Battery_icons_02.png","Battery_icons_03.png","Battery_icons_04.png","Battery_icons_05.png","Battery_icons_06.png","Battery_icons_07.png","Battery_icons_08.png","Battery_icons_09.png","Battery_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 130,
              y: 292,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 313,
              font_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 131,
              y: 307,
              src: 'Heart_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 160,
              // y: 263,
              // font_array: ["E0.png","E1.png","E2.png","E3.png","E4.png","E5.png","E6.png","E7.png","E8.png","E9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // unit_en: 'dis_KM.png',
              // imperial_unit_en: 'dis_Mi.png',
              // negative_image: 'E0.png',
              // invalid_image: 'E0.png',
              // dot_image: 'E0.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextRotate_ASCIIARRAY[0] = 'E0.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = 'E1.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = 'E2.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = 'E3.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = 'E4.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = 'E5.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = 'E6.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = 'E7.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = 'E8.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = 'E9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 432,
                h: 514,
                center_x: 160,
                center_y: 263,
                pos_x: 160,
                pos_y: 263,
                angle: 0,
                src: 'E0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              center_x: 160,
              center_y: 263,
              pos_x: 160,
              pos_y: 263,
              angle: 0,
              src: 'dis_KM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'dis_Mi.png');
            };
            //#endregion
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 48,
              y: 247,
              font_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Action_fonts_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 110,
              y: 78,
              image_array: ["Steps_icons_01.png","Steps_icons_02.png","Steps_icons_03.png","Steps_icons_04.png","Steps_icons_05.png","Steps_icons_06.png","Steps_icons_07.png","Steps_icons_08.png","Steps_icons_09.png","Steps_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 59,
              y: 189,
              font_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 274,
              y: 41,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 93,
              font_array: ["Weather_fonts_01.png","Weather_fonts_02.png","Weather_fonts_03.png","Weather_fonts_04.png","Weather_fonts_05.png","Weather_fonts_06.png","Weather_fonts_07.png","Weather_fonts_08.png","Weather_fonts_09.png","Weather_fonts_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_fonts_11.png',
              unit_tc: 'Weather_fonts_11.png',
              unit_en: 'Weather_fonts_11.png',
              imperial_unit_sc: 'Weather_fonts_11.png',
              imperial_unit_tc: 'Weather_fonts_11.png',
              imperial_unit_en: 'Weather_fonts_11.png',
              negative_image: 'Weather_fonts_12.png',
              invalid_image: 'Weather_fonts_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 270,
                y: 93,
                font_array: ["Weather_fonts_01.png","Weather_fonts_02.png","Weather_fonts_03.png","Weather_fonts_04.png","Weather_fonts_05.png","Weather_fonts_06.png","Weather_fonts_07.png","Weather_fonts_08.png","Weather_fonts_09.png","Weather_fonts_10.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Weather_fonts_11.png',
                unit_tc: 'Weather_fonts_11.png',
                unit_en: 'Weather_fonts_11.png',
                imperial_unit_sc: 'Weather_fonts_11.png',
                imperial_unit_tc: 'Weather_fonts_11.png',
                imperial_unit_en: 'Weather_fonts_11.png',
                negative_image: 'Weather_fonts_12.png',
                invalid_image: 'Weather_fonts_12.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 335,
              y: 88,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 230,
              am_y: 434,
              am_sc_path: 'Time_icon_AM.png',
              am_en_path: 'Time_icon_AM.png',
              pm_x: 230,
              pm_y: 434,
              pm_sc_path: 'Time_icon_PM.png',
              pm_en_path: 'Time_icon_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 269,
              second_startY: 372,
              second_array: ["Time_font_S_01.png","Time_font_S_02.png","Time_font_S_03.png","Time_font_S_04.png","Time_font_S_05.png","Time_font_S_06.png","Time_font_S_07.png","Time_font_S_08.png","Time_font_S_09.png","Time_font_S_10.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 259,
              minute_startY: 253,
              minute_array: ["Time_Font_HM_01.png","Time_Font_HM_02.png","Time_Font_HM_03.png","Time_Font_HM_04.png","Time_Font_HM_05.png","Time_Font_HM_06.png","Time_Font_HM_07.png","Time_Font_HM_08.png","Time_Font_HM_09.png","Time_Font_HM_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 263,
              hour_startY: 147,
              hour_array: ["Time_Font_HM_01.png","Time_Font_HM_02.png","Time_Font_HM_03.png","Time_Font_HM_04.png","Time_Font_HM_05.png","Time_Font_HM_06.png","Time_Font_HM_07.png","Time_Font_HM_08.png","Time_Font_HM_09.png","Time_Font_HM_10.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 92,
              y: 62,
              src: 'RingT1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 253,
              y: 479,
              week_en: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_tc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_sc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 91,
              month_startY: 478,
              month_sc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_tc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_en_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 181,
              day_startY: 473,
              day_sc_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              day_tc_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              day_en_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              day_zero: 1,
              day_space: 6,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 226,
              y: 252,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 73,
              y: 249,
              src: 'RingB1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 3,
              y: 143,
              font_array: ["Weather_fonts_01.png","Weather_fonts_02.png","Weather_fonts_03.png","Weather_fonts_04.png","Weather_fonts_05.png","Weather_fonts_06.png","Weather_fonts_07.png","Weather_fonts_08.png","Weather_fonts_09.png","Weather_fonts_10.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 1,
              y: 201,
              image_array: ["Battery_icons_01.png","Battery_icons_02.png","Battery_icons_03.png","Battery_icons_04.png","Battery_icons_05.png","Battery_icons_06.png","Battery_icons_07.png","Battery_icons_08.png","Battery_icons_09.png","Battery_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 130,
              y: 292,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 313,
              font_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 131,
              y: 307,
              src: 'Heart_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 160,
              // y: 263,
              // font_array: ["E0.png","E1.png","E2.png","E3.png","E4.png","E5.png","E6.png","E7.png","E8.png","E9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // unit_en: 'dis_KM.png',
              // imperial_unit_en: 'dis_Mi.png',
              // negative_image: 'E0.png',
              // invalid_image: 'E0.png',
              // dot_image: 'E0.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_distance_TextRotate_ASCIIARRAY[0] = 'E0.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[1] = 'E1.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[2] = 'E2.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[3] = 'E3.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[4] = 'E4.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[5] = 'E5.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[6] = 'E6.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[7] = 'E7.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[8] = 'E8.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[9] = 'E9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              idle_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 432,
                h: 514,
                center_x: 160,
                center_y: 263,
                pos_x: 160,
                pos_y: 263,
                angle: 0,
                src: 'E0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              center_x: 160,
              center_y: 263,
              pos_x: 160,
              pos_y: 263,
              angle: 0,
              src: 'dis_KM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (mileageUnit == 1) {
              idle_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'dis_Mi.png');
            };
            //#endregion

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 48,
              y: 247,
              font_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Action_fonts_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 110,
              y: 78,
              image_array: ["Steps_icons_01.png","Steps_icons_02.png","Steps_icons_03.png","Steps_icons_04.png","Steps_icons_05.png","Steps_icons_06.png","Steps_icons_07.png","Steps_icons_08.png","Steps_icons_09.png","Steps_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 59,
              y: 189,
              font_array: ["Action_fonts_01.png","Action_fonts_02.png","Action_fonts_03.png","Action_fonts_04.png","Action_fonts_05.png","Action_fonts_06.png","Action_fonts_07.png","Action_fonts_08.png","Action_fonts_09.png","Action_fonts_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 274,
              y: 41,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 93,
              font_array: ["Weather_fonts_01.png","Weather_fonts_02.png","Weather_fonts_03.png","Weather_fonts_04.png","Weather_fonts_05.png","Weather_fonts_06.png","Weather_fonts_07.png","Weather_fonts_08.png","Weather_fonts_09.png","Weather_fonts_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_fonts_11.png',
              unit_tc: 'Weather_fonts_11.png',
              unit_en: 'Weather_fonts_11.png',
              imperial_unit_sc: 'Weather_fonts_11.png',
              imperial_unit_tc: 'Weather_fonts_11.png',
              imperial_unit_en: 'Weather_fonts_11.png',
              negative_image: 'Weather_fonts_12.png',
              invalid_image: 'Weather_fonts_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 270,
                y: 93,
                font_array: ["Weather_fonts_01.png","Weather_fonts_02.png","Weather_fonts_03.png","Weather_fonts_04.png","Weather_fonts_05.png","Weather_fonts_06.png","Weather_fonts_07.png","Weather_fonts_08.png","Weather_fonts_09.png","Weather_fonts_10.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Weather_fonts_11.png',
                unit_tc: 'Weather_fonts_11.png',
                unit_en: 'Weather_fonts_11.png',
                imperial_unit_sc: 'Weather_fonts_11.png',
                imperial_unit_tc: 'Weather_fonts_11.png',
                imperial_unit_en: 'Weather_fonts_11.png',
                negative_image: 'Weather_fonts_12.png',
                invalid_image: 'Weather_fonts_12.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 335,
              y: 88,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 230,
              am_y: 434,
              am_sc_path: 'Time_icon_AM.png',
              am_en_path: 'Time_icon_AM.png',
              pm_x: 230,
              pm_y: 434,
              pm_sc_path: 'Time_icon_PM.png',
              pm_en_path: 'Time_icon_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 259,
              minute_startY: 253,
              minute_array: ["Time_Font_HM_01.png","Time_Font_HM_02.png","Time_Font_HM_03.png","Time_Font_HM_04.png","Time_Font_HM_05.png","Time_Font_HM_06.png","Time_Font_HM_07.png","Time_Font_HM_08.png","Time_Font_HM_09.png","Time_Font_HM_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 270,
              y: 385,
              src: 'AOD_ICON.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 263,
              hour_startY: 147,
              hour_array: ["Time_Font_HM_01.png","Time_Font_HM_02.png","Time_Font_HM_03.png","Time_Font_HM_04.png","Time_Font_HM_05.png","Time_Font_HM_06.png","Time_Font_HM_07.png","Time_Font_HM_08.png","Time_Font_HM_09.png","Time_Font_HM_10.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 82,
              y: 168,
              w: 140,
              h: 39,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 265,
              y: 30,
              w: 59,
              h: 54,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 372,
              y: 204,
              w: 60,
              h: 59,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 271,
              y: 353,
              w: 76,
              h: 52,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 219,
              y: 230,
              w: 38,
              h: 47,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 343,
              y: 24,
              w: 81,
              h: 81,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 282,
              y: 89,
              w: 45,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 72,
              y: 228,
              w: 109,
              h: 57,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 104,
              y: 279,
              w: 56,
              h: 43,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 20,
              y: 360,
              w: 160,
              h: 55,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 4,
              y: 137,
              w: 52,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 105,
              y: 458,
              w: 223,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 126,
              y: 89,
              w: 84,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 343,
              y: 423,
              w: 87,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // change 2 circle
                click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 2,
              y: 4,
              w: 83,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // change top circle
                click_ColorT()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 7,
              y: 427,
              w: 72,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // change low circle
                click_ColorB()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 274,
              y: 145,
              w: 54,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // change color Hour
                click_time()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 274,
              y: 248,
              w: 54,
              h: 94,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // change color minute
                click_timeM()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);
              if (mileageUnit == 1) normal_distance_rotate_string = (0.621371 * distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_rotate_string.length > 0 && normal_distance_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_distance_TextRotate_posOffset = normal_distance_TextRotate_img_width * normal_distance_rotate_string.length;
                  normal_distance_TextRotate_posOffset = normal_distance_TextRotate_posOffset - normal_distance_TextRotate_img_width + normal_distance_TextRotate_dot_width;
                  img_offset -= normal_distance_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 160 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, normal_distance_TextRotate_ASCIIARRAY[charCode]);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 160 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'E0.png');
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 160 + img_offset);
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 160 - normal_distance_TextRotate_error_img_width / 2);
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.SRC, 'E0.png');
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate DISTANCE');
              let idle_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);
              if (mileageUnit == 1) idle_distance_rotate_string = (0.621371 * distanceCurrent / 1000).toFixed(2);

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && idle_distance_rotate_string.length > 0 && idle_distance_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let idle_distance_TextRotate_posOffset = idle_distance_TextRotate_img_width * idle_distance_rotate_string.length;
                  idle_distance_TextRotate_posOffset = idle_distance_TextRotate_posOffset - idle_distance_TextRotate_img_width + idle_distance_TextRotate_dot_width;
                  img_offset -= idle_distance_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 160 + img_offset);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.SRC, idle_distance_TextRotate_ASCIIARRAY[charCode]);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 160 + img_offset);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'E0.png');
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 160 + img_offset);
                  idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 160 - idle_distance_TextRotate_error_img_width / 2);
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.SRC, 'E0.png');
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}