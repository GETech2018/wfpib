﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 242,
              // start_y: 385,
              // color: 0xFF71E100,
              // lenght: 28,
              // line_width: 14,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 381,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 240,
              y: 382,
              src: 'icon_Battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 161,
              month_startY: 383,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 107,
              day_startY: 383,
              day_sc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_tc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_en_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 34,
              y: 383,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 207,
              minute_startY: 311,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 34,
              hour_startY: 311,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 185,
              y: 302,
              src: 'TimeDot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
 

if (screenType != hmSetting.screen_type.AOD) {

// ======================
// SCREEN
// ======================

const SCREEN_W = 390;
const SCREEN_H = 450;

const GAME_H = SCREEN_H / 2;


// ======================
// STORAGE KEY
// ======================

const HI_KEY = "snake_hi_score";


// ======================
// GRID
// ======================

const CELL = 15;

const SIDE_MARGIN_BLOCKS = 2;

const COLS = Math.floor(SCREEN_W / CELL) - (SIDE_MARGIN_BLOCKS * 2);
const ROWS = Math.floor(GAME_H / CELL);

const offsetX = SIDE_MARGIN_BLOCKS * CELL;
const offsetY = 72;


// ======================
// SPEED SYSTEM
// ======================

let GAME_SPEED = 630;
let MIN_SPEED = 120;

let lastMoveTime = 0;


// ======================
// COLORS
// ======================

const COLOR_SNAKE = 0x00FF00;
const COLOR_HEAD  = 0xFFDD1F;
const COLOR_FOOD  = 0xFF0000;
const COLOR_OBSTACLE = 0x888888;


// ======================
// STATE
// ======================

let snake = [];

let foods = [];
let foodCount = 1;
let maxFoods = 5;

let obstacles = [];

let dirX = 1;
let dirY = 0;

let nextDirX = 1;
let nextDirY = 0;

let running = true;
let paused = false;

let widgets = [];


// ======================
// SCORE
// ======================

let score = 0;

let hiScore = hmFS.SysProGetInt(HI_KEY);
if(hiScore==undefined || hiScore==null)
hiScore=0;

let scoreText;
let hiText;
let gameOverText;


// ======================
// CLEAR
// ======================

function clearScreen(){

widgets.forEach(w=>hmUI.deleteWidget(w));

widgets = [];

}


// ======================
// DRAW BLOCK
// ======================

function drawBlock(x,y,color){

let w =
hmUI.createWidget(
hmUI.widget.FILL_RECT,
{
x: offsetX + x * CELL,
y: offsetY + y * CELL,
w: CELL,
h: CELL,
radius: 4,   // ⭐ ทำให้มนเต็มวง (circle)
color: color
});

widgets.push(w);

}



// ======================
// SPAWN FOOD
// ======================

function spawnFood(){

while(foods.length < foodCount){

let valid=false;
let fx,fy;

while(!valid){

fx = Math.floor(Math.random() * COLS);
fy = Math.floor(Math.random() * ROWS);

valid = true;

for(let s of snake)
if(s.x==fx && s.y==fy)
valid=false;

for(let o of obstacles)
if(o.x==fx && o.y==fy)
valid=false;

for(let f of foods)
if(f.x==fx && f.y==fy)
valid=false;

}

foods.push({x:fx,y:fy});

}

}


// ======================
// SPAWN OBSTACLES
// ======================

function spawnObstacles(){

obstacles = [];

for(let i=0;i<4;i++){

let valid=false;
let ox,oy;

while(!valid){

ox = Math.floor(Math.random()*COLS);
oy = Math.floor(Math.random()*ROWS);

valid = true;

for(let s of snake)
if(s.x==ox && s.y==oy)
valid=false;

for(let f of foods)
if(f.x==ox && f.y==oy)
valid=false;

}

obstacles.push({x:ox,y:oy});

}

}


// ======================
// RESET
// ======================

function resetGame(){

clearScreen();

snake = [];

snake.push({x:5,y:5});
snake.push({x:4,y:5});
snake.push({x:3,y:5});

foods = [];
foodCount = 1;

obstacles = [];

dirX = 1;
dirY = 0;

nextDirX = 1;
nextDirY = 0;

running = true;
paused = false;

score = 0;

GAME_SPEED = 630;

lastMoveTime = Date.now();

updateScore();

spawnFood();

draw();

gameOverText.setProperty(
hmUI.prop.VISIBLE,
false
);

}


// ======================
// SCORE UPDATE
// ======================

function updateScore(){

scoreText.setProperty(
hmUI.prop.TEXT,
"Score: " + score
);

if(score > hiScore){

hiScore = score;

hmFS.SysProSetInt(HI_KEY, hiScore);

hiText.setProperty(
hmUI.prop.TEXT,
"HI: " + hiScore
);

}

}


// ======================
// GAME OVER
// ======================

function gameOver(){

running = false;

gameOverText.setProperty(
hmUI.prop.VISIBLE,
true
);

}


// ======================
// GAME LOOP
// ======================

function gameLoop(){

if(!running) return;
if(paused) return;

let now = Date.now();

if(now - lastMoveTime < GAME_SPEED)
return;

lastMoveTime = now;

updateGame();

}


// ======================
// UPDATE GAME
// ======================

function updateGame(){

dirX = nextDirX;
dirY = nextDirY;

let head = {
x: snake[0].x + dirX,
y: snake[0].y + dirY
};


if(
head.x < 0 ||
head.x >= COLS ||
head.y < 0 ||
head.y >= ROWS
){
gameOver();
return;
}


for(let s of snake){

if(head.x==s.x && head.y==s.y){

gameOver();
return;

}

}


for(let o of obstacles){

if(head.x==o.x && head.y==o.y){

gameOver();
return;

}

}


// move snake

snake.unshift(head);

let ateFood = false;


// eat food

for(let i=foods.length-1;i>=0;i--){

let f = foods[i];

if(head.x==f.x && head.y==f.y){

foods.splice(i,1);

score += 10;

updateScore();

ateFood = true;

if(foodCount < maxFoods)
foodCount++;

spawnFood();

spawnObstacles();

if(GAME_SPEED > MIN_SPEED){

GAME_SPEED -= 10;

if(GAME_SPEED < MIN_SPEED)
GAME_SPEED = MIN_SPEED;

}

break;

}

}


if(!ateFood)
snake.pop();

if(foods.length < foodCount)
spawnFood();


draw();

}


// ======================
// DRAW
// ======================

function draw(){

clearScreen();

foods.forEach(f=>{
drawBlock(f.x,f.y,COLOR_FOOD);
});

obstacles.forEach(o=>{
drawBlock(o.x,o.y,COLOR_OBSTACLE);
});

snake.forEach((s,i)=>{
drawBlock(
s.x,
s.y,
i==0 ? COLOR_HEAD : COLOR_SNAKE
);
});

}


// ======================
// CONTROLS
// ======================

function setDir(x,y){

if(-x==dirX && -y==dirY) return;

nextDirX = x;
nextDirY = y;

}


// ======================
// BUTTONS
// ======================

/*

hmUI.createWidget(hmUI.widget.BUTTON,{
x:20,y:SCREEN_H-36,w:80,h:40,text:"◀",
click_func:()=>setDir(-1,0)
});

hmUI.createWidget(hmUI.widget.BUTTON,{
x:110,y:SCREEN_H-36,w:80,h:40,text:"▶",
click_func:()=>setDir(1,0)
});

hmUI.createWidget(hmUI.widget.BUTTON,{
x:200,y:SCREEN_H-36,w:80,h:40,text:"▲",
click_func:()=>setDir(0,-1)
});

hmUI.createWidget(hmUI.widget.BUTTON,{
x:290,y:SCREEN_H-36,w:80,h:40,text:"▼",
click_func:()=>setDir(0,1)
});
*/

//  Button control with image //
hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 20,
  y: SCREEN_H-36,
  w: 80,
  h: 40,
  text: '',
  normal_src: 'left.png',
  press_src: '0_Empty.png',
  click_func: () => {
    setDir(-1,0);
  },

});

hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 110,
  y: SCREEN_H-36,
  w: 80,
  h: 40,
  text: '',
  normal_src: 'right.png',
  press_src: '0_Empty.png',
  click_func: () => {
    setDir(1,0);
  },

});

hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 200,
  y: SCREEN_H-36,
  w: 80,
  h: 40,
  text: '',
  normal_src: 'up.png',
  press_src: '0_Empty.png',
  click_func: () => {
    setDir(0,-1);
  },

});

hmUI.createWidget(hmUI.widget.BUTTON, {
  x: 290,
  y: SCREEN_H-36,
  w: 80,
  h: 40,
  text: '',
  normal_src: 'down.png',
  press_src: '0_Empty.png',
  click_func: () => {
    setDir(0,1);
  },

});

//// End button control with image ////



hmUI.createWidget(hmUI.widget.BUTTON,{
x:29,
y:SCREEN_H-421,
w:100,
h:40,

normal_color: 0xFF8800,   // สีปกติ (ส้ม)
press_color:  0xCC6600,   // สีตอนกด (ส้มเข้ม)

color: 0x000000,          // สีตัวอักษร (ดำ)

text:"PAUSE",

click_func:()=>{
paused = !paused;
}
});

hmUI.createWidget(hmUI.widget.BUTTON,{
x:SCREEN_W-120,
y:SCREEN_H-421,
w:90,
h:40,
normal_color: 0xFF8800,   // สีปกติ (ส้ม)
press_color:  0xCC6600,   // สีตอนกด (ส้มเข้ม)

color: 0x000000,          // สีตัวอักษร (ขาว)

text:"RESET",
click_func:resetGame
});


// ======================
// SCORE UI
// ======================

scoreText =
hmUI.createWidget(
hmUI.widget.TEXT,
{
x:45,
y:5,
w:150,
h:21,
text:"Score: 0",
text_size:19,
color:0xFFFFFF
});

hiText =
hmUI.createWidget(
hmUI.widget.TEXT,
{
x:SCREEN_W-140,
y:5,
w:120,
h:21,
text:"HI: "+hiScore,
text_size:19,
color:0xFFFF00
});


// ======================
// GAME OVER TEXT
// ======================

gameOverText =
hmUI.createWidget(
hmUI.widget.TEXT,
{
x:0,
y: offsetY + (ROWS * CELL)/2 - 15,
w:SCREEN_W,
h:30,
text:"GAME OVER",
text_size:28,
align_h: hmUI.align.CENTER_H,
color:0xFF0000
}
);

gameOverText.setProperty(
hmUI.prop.VISIBLE,
false
);


// ======================
// TIMER
// ======================

timer.createTimer(
0,
20,
gameLoop
);


// ======================
// START GAME
// ======================

resetGame();

}
            // end user_script.js


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 242,
              // start_y: 385,
              // color: 0xFF71E100,
              // lenght: 28,
              // line_width: 14,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 381,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 240,
              y: 382,
              src: 'icon_Battery.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 161,
              month_startY: 383,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 107,
              day_startY: 383,
              day_sc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_tc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_en_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 34,
              y: 383,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 207,
              minute_startY: 311,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 34,
              hour_startY: 311,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 185,
              y: 302,
              src: 'TimeDot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 242;
                  let start_y_normal_battery = 385;
                  let lenght_ls_normal_battery = 28;
                  let line_width_ls_normal_battery = 14;
                  let color_ls_normal_battery = 0xFF71E100;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 242;
                  let start_y_idle_battery = 385;
                  let lenght_ls_idle_battery = 28;
                  let line_width_ls_idle_battery = 14;
                  let color_ls_idle_battery = 0xFF71E100;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}