﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

        
        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС'];
        let normal_group_ForecastWeather = ''
        let normal_forecast_date_week_font = new Array(5);
        let normal_forecast_date_week_font_Array = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС'];
        let normal_forecast_low_text_font = new Array(5);
        let normal_forecast_high_text_font = new Array(5);
        let normal_forecast_image_progress_img_level = new Array(5);
        let normal_forecast_image_array = ['ws_0.png', 'ws_1.png', 'ws_2.png', 'ws_3.png', 'ws_4.png', 'ws_5.png', 'ws_6.png', 'ws_7.png', 'ws_8.png', 'ws_9.png', 'ws_10.png', 'ws_11.png', 'ws_12.png', 'ws_13.png', 'ws_14.png', 'ws_15.png', 'ws_16.png', 'ws_17.png', 'ws_18.png', 'ws_19.png', 'ws_20.png', 'ws_21.png', 'ws_22.png', 'ws_23.png', 'ws_24.png', 'ws_25.png', 'ws_26.png', 'ws_27.png', 'ws_28.png'];
        let normal_battery_linear_scale = ''
        let normal_battery_current_text_font = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_alarm_clock_text_text_img = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_time_hour_min_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_day_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС'];
        let idle_group_ForecastWeather = ''
        let idle_forecast_date_week_font = new Array(5);
        let idle_forecast_date_week_font_Array = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС'];
        let idle_forecast_low_text_font = new Array(5);
        let idle_forecast_high_text_font = new Array(5);
        let idle_forecast_image_progress_img_level = new Array(5);
        let idle_forecast_image_array = ['ws_0.png', 'ws_1.png', 'ws_2.png', 'ws_3.png', 'ws_4.png', 'ws_5.png', 'ws_6.png', 'ws_7.png', 'ws_8.png', 'ws_9.png', 'ws_10.png', 'ws_11.png', 'ws_12.png', 'ws_13.png', 'ws_14.png', 'ws_15.png', 'ws_16.png', 'ws_17.png', 'ws_18.png', 'ws_19.png', 'ws_20.png', 'ws_21.png', 'ws_22.png', 'ws_23.png', 'ws_24.png', 'ws_25.png', 'ws_26.png', 'ws_27.png', 'ws_28.png'];
        let idle_battery_linear_scale = ''
        let idle_battery_current_text_font = ''
        let idle_temperature_icon_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_calorie_current_text_font = ''
        let idle_step_current_text_font = ''
        let idle_heart_rate_text_font = ''
        let idle_alarm_clock_text_text_img = ''
        let idle_system_disconnect_img = ''
        let Button_Switch_BG_Color = ''

        let bgColorIndex = 0;
        let bgColorList = [0xFF80FF00, 0xFFFF8C00, 0xFFFF0000, 0xFFFFFF00, 0xFF0080FF, 0xFF00FF40, 0xFFFFFFFF, 0xFFFF00FF, 0xFF8080FF, 0xFF8080C0];
        let bgColorToastList = ['Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SF_Compact_Rounded_Regular.ttf; FontSize: 105
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 1255,
              h: 150,
              text_size: 105,
              char_space: -2,
              line_space: 0,
              font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF_Compact_Rounded_Regular.ttf; FontSize: 45
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 567,
              h: 64,
              text_size: 45,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: BRoundBold.ttf; FontSize: 32; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 38,
              h: 38,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BRoundBold.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: BRoundBold.ttf; FontSize: 23
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 327,
              h: 34,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BRoundBold.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF_Compact_Rounded_Regular.ttf; FontSize: 28
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 360,
              h: 42,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF_Compact_Rounded_Regular.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 312,
              h: 36,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: BRoundBold.ttf; FontSize: 46
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 636,
              h: 69,
              text_size: 46,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BRoundBold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF_Compact_Rounded_Regular.ttf; FontSize: 44
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 567,
              h: 64,
              text_size: 44,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region SwitchBG_Color
            console.log('SwitchBG_Color');
            function switchBG_Color() {
              bgColorIndex++;
              if (bgColorIndex >= bgColorList.length) bgColorIndex = 0;
              hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
              let toastText = bgColorToastList[bgColorIndex].replace('%s', `${bgColorIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
              vibro(28);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF80FF00',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 79,
              y: -11,
              w: 300,
              h: 130,
              text_size: 105,
              char_space: -2,
              font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 269,
              y: 104,
              w: 150,
              h: 50,
              text_size: 45,
              char_space: 0,
              font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 209,
              y: 118+3,
              w: 150,
              h: 30,
              text_size: 32,
              char_space: 0,
              font: 'fonts/BRoundBold.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 0,
              // y: 0,
              // ColumnWidth: 66,
              // DaysCount: 5,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_date_week_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -82,
              // y: 273,
              // w: 150,
              // h: 30,
              // text_size: 23,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // font: 'fonts/BRoundBold.ttf',
              // color: 0xFFC0C0C0,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_date_week_img,
              // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_date_week_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -82 + i*66,
                  y: 273+3,
                  w: 150,
                  h: 30,
                  text_size: 23,
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/BRoundBold.ttf',
                  color: 0xFFC0C0C0,
                  // color_2: 0xFFFF0000,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            // normal_forecast_low_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -82,
              // y: 397,
              // w: 150,
              // h: 30,
              // text_size: 28,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              // color: 0xFFC0C0C0,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_low_text_font,
              // unit_type: 1,
              // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_low_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -82 + i*66,
                  y: 397,
                  w: 150,
                  h: 30,
                  text_size: 28,
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/SF_Compact_Rounded_Regular.ttf',
                  color: 0xFFC0C0C0,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            // normal_forecast_high_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -82,
              // y: 365,
              // w: 150,
              // h: 30,
              // text_size: 28,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              // color: 0xFFC0C0C0,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_high_text_font,
              // unit_type: 1,
              // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_high_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -82 + i*66,
                  y: 365,
                  w: 150,
                  h: 30,
                  text_size: 28,
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/SF_Compact_Rounded_Regular.ttf',
                  color: 0xFFC0C0C0,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: -25,
              // y: 312,
              // image_array: ["ws_0.png","ws_1.png","ws_2.png","ws_3.png","ws_4.png","ws_5.png","ws_6.png","ws_7.png","ws_8.png","ws_9.png","ws_10.png","ws_11.png","ws_12.png","ws_13.png","ws_14.png","ws_15.png","ws_16.png","ws_17.png","ws_18.png","ws_19.png","ws_20.png","ws_21.png","ws_22.png","ws_23.png","ws_24.png","ws_25.png","ws_26.png","ws_27.png","ws_28.png"],
              // image_length: 29,
              // alpha: 204,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: -25 + i*66,
                  y: 312,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
            normal_forecast_image_progress_img_level[i].setAlpha(204);
			  };
            };

            //#endregion

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_battery_linear_scale.setAlpha(204);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 77,
              // start_y: 130,
              // color: 0xFF000000,
              // lenght: 148,
              // line_width: 17,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 204,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 21,
              y: 123,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              alpha: 204,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 271,
              src: 'fix_w.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 309,
              y: 296,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              // alpha: 204,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level.setAlpha(204);

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 252,
              y: 375+3,
              w: 150,
              h: 70,
              text_size: 46,
              char_space: 0,
              font: 'fonts/BRoundBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 241,
              y: 196,
              w: 150,
              h: 50,
              text_size: 44,
              char_space: 0,
              font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 120,
              y: 196,
              w: 150,
              h: 50,
              text_size: 44,
              char_space: 0,
              font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -4,
              y: 196,
              w: 150,
              h: 50,
              text_size: 44,
              char_space: 0,
              font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 25,
              font_array: ["AL_0.png","AL_1.png","AL_2.png","AL_3.png","AL_4.png","AL_5.png","AL_6.png","AL_7.png","AL_8.png","AL_9.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'AL_13.png',
              dot_image: 'AL_0.png',
              // alpha: 204,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_text_text_img.setAlpha(204);

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 49,
              y: 25,
              src: 'AL_13.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img.setAlpha(204);


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF80FF00',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 79,
              y: -11,
              w: 300,
              h: 130,
              text_size: 105,
              char_space: -2,
              font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 269,
              y: 104,
              w: 150,
              h: 50,
              text_size: 45,
              char_space: 0,
              font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 209,
              y: 118+3,
              w: 150,
              h: 30,
              text_size: 32,
              char_space: 0,
              font: 'fonts/BRoundBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // idle_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 0,
              // y: 0,
              // ColumnWidth: 66,
              // DaysCount: 5,
            // });
            
            idle_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_forecast_date_week_font = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -82,
              // y: 273,
              // w: 150,
              // h: 30,
              // text_size: 23,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // font: 'fonts/BRoundBold.ttf',
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_date_week_img,
              // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 5; i++) {
                idle_forecast_date_week_font[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -82 + i*66,
                  y: 273+3,
                  w: 150,
                  h: 30,
                  text_size: 23,
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/BRoundBold.ttf',
                  color: 0xFFFFFFFF,
                  // color_2: 0xFFFF0000,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //#endregion

            // idle_forecast_low_text_font = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -82,
              // y: 397,
              // w: 150,
              // h: 30,
              // text_size: 28,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_low_text_font,
              // unit_type: 1,
              // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 5; i++) {
                idle_forecast_low_text_font[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -82 + i*66,
                  y: 397,
                  w: 150,
                  h: 30,
                  text_size: 28,
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/SF_Compact_Rounded_Regular.ttf',
                  color: 0xFFFFFFFF,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //#endregion

            // idle_forecast_high_text_font = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -82,
              // y: 365,
              // w: 150,
              // h: 30,
              // text_size: 28,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_high_text_font,
              // unit_type: 1,
              // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 5; i++) {
                idle_forecast_high_text_font[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -82 + i*66,
                  y: 365,
                  w: 150,
                  h: 30,
                  text_size: 28,
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/SF_Compact_Rounded_Regular.ttf',
                  color: 0xFFFFFFFF,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //#endregion

            // idle_forecast_image_progress_img_level = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: -25,
              // y: 312,
              // image_array: ["ws_0.png","ws_1.png","ws_2.png","ws_3.png","ws_4.png","ws_5.png","ws_6.png","ws_7.png","ws_8.png","ws_9.png","ws_10.png","ws_11.png","ws_12.png","ws_13.png","ws_14.png","ws_15.png","ws_16.png","ws_17.png","ws_18.png","ws_19.png","ws_20.png","ws_21.png","ws_22.png","ws_23.png","ws_24.png","ws_25.png","ws_26.png","ws_27.png","ws_28.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 5; i++) {
                idle_forecast_image_progress_img_level[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: -25 + i*66,
                  y: 312,
                  src: idle_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_AOD,
                });аврыавяии
              };
            };
            //#endregion

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            idle_battery_linear_scale.setAlpha(204);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 77,
              // start_y: 130,
              // color: 0xFF000000,
              // lenght: 148,
              // line_width: 17,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 204,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 21,
              y: 123,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 0,
              font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 271,
              src: 'fix_w.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 309,
              y: 296,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 252,
              y: 375+3,
              w: 150,
              h: 70,
              text_size: 46,
              char_space: 0,
              font: 'fonts/BRoundBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 241,
              y: 196,
              w: 150,
              h: 50,
              text_size: 44,
              char_space: 0,
              font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 120,
              y: 196,
              w: 150,
              h: 50,
              text_size: 44,
              char_space: 0,
              font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -4,
              y: 196,
              w: 150,
              h: 50,
              text_size: 44,
              char_space: 0,
              font: 'fonts/SF_Compact_Rounded_Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 25,
              font_array: ["AL_0.png","AL_1.png","AL_2.png","AL_3.png","AL_4.png","AL_5.png","AL_6.png","AL_7.png","AL_8.png","AL_9.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'AL_13.png',
              dot_image: 'AL_0.png',
              // alpha: 204,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_text_text_img.setAlpha(204);

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 49,
              y: 25,
              src: 'AL_13.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img.setAlpha(204);

            console.log('Watch_Face.SwitchBG_Color');
            // Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.SwitchBG_Color, {
              // x: 145,
              // y: 175,
              // w: 100,
              // h: 100,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'AL_0.png',
              // normal_src: 'AL_0.png',
              // color_list: 0xFF80FF00|0xFFFF8C00|0xFFFF0000|0xFFFFFF00|0xFF0080FF|0xFF00FF40|0xFFFFFFFF|0xFFFF00FF|0xFF8080FF|0xFF8080C0,
              // toast_list: Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s,
              // use_crown: False,
              // use_in_AOD: True,
              // vibro: True,
            // });

            Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 145,
              y: 175,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                switchBG_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

          const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            //#region weather_few_days
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 5; i++) {
                // DayOfWeek font
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, normal_forecast_date_week_font_Array[dowIndex]);
                };
              
                // Number_Font_Min
                let minTemperature = '-';
                if (i < forecastData.count) minTemperature = forecastData.data[i].low.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_low_text_font[i].setProperty(hmUI.prop.TEXT, minTemperature + '°');
                };
                
                // Number_Font_Max
                let maxTemperature = '-';
                if (i < forecastData.count) maxTemperature = forecastData.data[i].high.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_high_text_font[i].setProperty(hmUI.prop.TEXT, maxTemperature + '°');
                };
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
                // DayOfWeek font
                if (screenType == hmSetting.screen_type.AOD) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  idle_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, idle_forecast_date_week_font_Array[dowIndex]);
                };
              
                // Number_Font_Min
                if (screenType == hmSetting.screen_type.AOD) {
                  idle_forecast_low_text_font[i].setProperty(hmUI.prop.TEXT, minTemperature + '°');
                };
                
                // Number_Font_Max
                if (screenType == hmSetting.screen_type.AOD) {
                  idle_forecast_high_text_font[i].setProperty(hmUI.prop.TEXT, maxTemperature + '°');
                };
                
                // Images
                if (screenType == hmSetting.screen_type.AOD) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  idle_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, idle_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //#endregion

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_HourMinStr = 'pm ' + normal_HourMinStr
                  else normal_HourMinStr = 'am ' + normal_HourMinStr
                };
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let idle_HourMinStr = format_hour.toString();
                idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) idle_HourMinStr = 'pm ' + idle_HourMinStr
                  else idle_HourMinStr = 'am ' + idle_HourMinStr
                };
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 225;
                  let start_y_normal_battery = 130;
                  let lenght_ls_normal_battery = -148;
                  let line_width_ls_normal_battery = 17;
                  let color_ls_normal_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 225;
                  let start_y_idle_battery = 130;
                  let lenght_ls_idle_battery = -148;
                  let line_width_ls_idle_battery = 17;
                  let color_ls_idle_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                //SwitchBgColor
                if (hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`) === undefined) {
                  bgColorIndex = 0;
                  hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
                } else {
                  bgColorIndex = hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg) normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
                if (screenType == hmSetting.screen_type.AOD && idle_background_bg) idle_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}