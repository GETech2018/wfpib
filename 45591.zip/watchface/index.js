try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;

    new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "energymax_pe_v8"
    );

    "use strict";

    const NORMAL = hmUI.show_level.ONLY_NORMAL;
    const AOD = (hmUI.show_level.ONLY_AOD !== undefined)
      ? hmUI.show_level.ONLY_AOD
      : ((hmUI.show_level.ONAL_AOD !== undefined) ? hmUI.show_level.ONAL_AOD : 0);
    const BOTH = AOD ? (NORMAL | AOD) : NORMAL;

    const WHITE = 0xffffff;
    const GREY = 0x9b9b9b;
    const SOFT = 0xc5c5c5;
    const ORANGE = 0xff9f16;
    const GREEN = 0x31df73;
    const GREEN_TEXT = 0x101010;
    const RED = 0xe63b34;
    const BLUE = 0x2a86ff;
    const BLACK = 0x000000;
    const LINE = 0x383838;

    const BIG_VALUE = [
      "0041.png", "0042.png", "0043.png", "0044.png", "0045.png",
      "0046.png", "0047.png", "0048.png", "0049.png", "0050.png"
    ];

    const MID_VALUE = [
      "0075.png", "0076.png", "0077.png", "0078.png", "0079.png",
      "0080.png", "0081.png", "0082.png", "0083.png", "0084.png"
    ];

    const STEP_VALUE = [
      "0086.png", "0087.png", "0088.png", "0089.png", "0090.png",
      "0091.png", "0092.png", "0093.png", "0094.png", "0095.png"
    ];

    // Larger bottom digits to make better use of the lower row.
    const BOTTOM_VALUE = [
      "bot_0.png", "bot_1.png", "bot_2.png", "bot_3.png", "bot_4.png",
      "bot_5.png", "bot_6.png", "bot_7.png", "bot_8.png", "bot_9.png"
    ];

    const TINY_VALUE = [
      "0179.png", "0180.png", "0181.png", "0182.png", "0183.png",
      "0184.png", "0185.png", "0186.png", "0187.png", "0188.png"
    ];

    const TEMP_VALUE = [
      "0138.png", "0139.png", "0140.png", "0141.png", "0142.png",
      "0143.png", "0144.png", "0145.png", "0146.png", "0147.png"
    ];

    const BAT_VALUE = [
      "bat_0.png", "bat_1.png", "bat_2.png", "bat_3.png", "bat_4.png",
      "bat_5.png", "bat_6.png", "bat_7.png", "bat_8.png", "bat_9.png"
    ];

    const BAT_BOLD = [
      "batb_0.png", "batb_1.png", "batb_2.png", "batb_3.png", "batb_4.png",
      "batb_5.png", "batb_6.png", "batb_7.png", "batb_8.png", "batb_9.png"
    ];

    const WEATHER_ICONS = [
      "0109.png", "0110.png", "0111.png", "0112.png", "0113.png",
      "0114.png", "0115.png", "0116.png", "0117.png", "0118.png",
      "0119.png", "0120.png", "0121.png", "0122.png", "0123.png",
      "0124.png", "0125.png", "0126.png", "0127.png", "0128.png",
      "0129.png", "0130.png", "0131.png", "0132.png", "0133.png",
      "0134.png", "0135.png", "0136.png", "0137.png"
    ];

    // Arrays originales de Energymax para conservar EXACTAMENTE su estilo de hora.
    const HOUR_TENS = ["0019.png", "0020.png", "0021.png"];
    const DIGITS = ["0019.png", "0020.png", "0021.png", "0022.png", "0023.png", "0024.png", "0025.png", "0026.png", "0027.png", "0028.png"];
    const MINUTE_TENS = ["0019.png", "0020.png", "0021.png", "0022.png", "0023.png", "0024.png"];

    let timeSensor;
    let sleepSensor;
    let dateDay;
    let dateWeek;
    let dateMonth;
    let sleepValue;

    let hourTensImg;
    let hourOnesImg;
    let minuteTensImg;
    let minuteOnesImg;
    let secondText;
    let clockTimer;

    function text(value, x, y, w, h, size, color, align, level) {
      return hmUI.createWidget(hmUI.widget.TEXT, {
        x, y, w, h,
        text: value,
        color,
        text_size: size,
        align_h: align || hmUI.align.LEFT,
        align_v: hmUI.align.CENTER_V,
        text_style: hmUI.text_style.NONE,
        show_level: level === undefined ? BOTH : level
      });
    }

    function line(x, y, w) {
      return hmUI.createWidget(hmUI.widget.FILL_RECT, {
        x, y, w, h: 1,
        color: LINE,
        show_level: BOTH
      });
    }

    function data(type, x, y, fontArray, align, extra) {
      const cfg = {
        x,
        y,
        font_array: fontArray,
        padding: false,
        h_space: 0,
        align_h: align || hmUI.align.LEFT,
        type,
        show_level: BOTH
      };
      if (extra) Object.keys(extra).forEach((k) => { cfg[k] = extra[k]; });
      return hmUI.createWidget(hmUI.widget.TEXT_IMG, cfg);
    }

    function tap(type, x, y, w, h) {
      if (type === undefined || type === null) return;
      hmUI.createWidget(hmUI.widget.IMG_CLICK, {
        x, y, w, h,
        src: "",
        type,
        show_level: NORMAL
      });
    }

    function setSrc(widget, src) {
      if (widget) widget.setProperty(hmUI.prop.MORE, { src });
    }

    function updateClock() {
      if (!timeSensor) return;

      const h = Number(timeSensor.format_hour);
      const m = Number(timeSensor.minute);
      const s = Number(timeSensor.second || 0);

      const hh = h < 10 ? "0" + h : "" + h;
      const mm = m < 10 ? "0" + m : "" + m;
      const ss = s < 10 ? "0" + s : "" + s;

      // Same four-digit system as the original EnergyMax.
      setSrc(hourTensImg, HOUR_TENS[Number(hh.charAt(0))] || HOUR_TENS[0]);
      setSrc(hourOnesImg, DIGITS[Number(hh.charAt(1))] || DIGITS[0]);
      setSrc(minuteTensImg, MINUTE_TENS[Number(mm.charAt(0))] || MINUTE_TENS[0]);
      setSrc(minuteOnesImg, DIGITS[Number(mm.charAt(1))] || DIGITS[0]);

      // Small seconds in the free space between hour and minutes so they do not overlap any digit.
      if (secondText) secondText.setProperty(hmUI.prop.TEXT, ss);
    }

    function updateDate() {
      if (!timeSensor || !dateDay || !dateWeek || !dateMonth) return;
      const WEEK = ["", "SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM"];
      const MONTH = ["", "JAN", "FEV", "MAR", "ABR", "MAI", "JUN", "JUL", "AGO", "SET", "OUT", "NOV", "DEZ"];

      dateDay.setProperty(hmUI.prop.TEXT, timeSensor.day < 10 ? "0" + timeSensor.day : "" + timeSensor.day);
      dateWeek.setProperty(hmUI.prop.TEXT, WEEK[timeSensor.week] || "");
      dateMonth.setProperty(hmUI.prop.TEXT, MONTH[timeSensor.month] || "");
    }

    function updateSleep() {
      if (!sleepSensor || !sleepValue) return;
      try {
        if (sleepSensor.updateInfo) sleepSensor.updateInfo();
        const total = sleepSensor.getTotalTime ? sleepSensor.getTotalTime() : 0;
        sleepValue.setProperty(hmUI.prop.TEXT, total > 0 ? (total / 60).toFixed(1) : "--");
      } catch (e) {
        sleepValue.setProperty(hmUI.prop.TEXT, "--");
      }
    }

    function startClockTimer() {
      if (clockTimer) clearInterval(clockTimer);
      updateClock();
      clockTimer = setInterval(updateClock, 1000);
    }

    function stopClockTimer() {
      if (clockTimer) {
        clearInterval(clockTimer);
        clockTimer = undefined;
      }
    }

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);

        hmUI.createWidget(hmUI.widget.FILL_RECT, {
          x: 0, y: 0, w: 390, h: 450,
          color: BLACK,
          show_level: BOTH
        });

        // ===== TIME: ORIGINAL ENERGYMAX DESIGN =====
        hourTensImg = hmUI.createWidget(hmUI.widget.IMG, {
          x: 212, y: 38, w: 80, h: 99,
          src: "0019.png",
          enable: false,
          show_level: BOTH
        });
        hourOnesImg = hmUI.createWidget(hmUI.widget.IMG, {
          x: 288, y: 38, w: 80, h: 99,
          src: "0019.png",
          enable: false,
          show_level: BOTH
        });
        minuteTensImg = hmUI.createWidget(hmUI.widget.IMG, {
          x: 212, y: 152, w: 80, h: 99,
          src: "0019.png",
          enable: false,
          show_level: BOTH
        });
        minuteOnesImg = hmUI.createWidget(hmUI.widget.IMG, {
          x: 288, y: 152, w: 80, h: 99,
          src: "0019.png",
          enable: false,
          show_level: BOTH
        });

        // Segundos: en la franja libre entre la hora y los minutos.
        // This prevents overlap with the last minute digit.
        secondText = text("00", 329, 260, 40, 26, 22, WHITE, hmUI.align.RIGHT, NORMAL);

        // ===== BLOQUE SUPERIOR IZQUIERDO =====
        // Keep the stable positioning.
        data(hmUI.data_type.HEART, 6, 35, BIG_VALUE, hmUI.align.RIGHT, { invalid_image: "0051.png" });
        hmUI.createWidget(hmUI.widget.FILL_RECT, { x: 109, y: 41, w: 5, h: 38, color: RED, show_level: BOTH });
        text("FREQ.\nCARD.", 118, 33, 76, 54, 20, GREY, hmUI.align.LEFT);

        data(hmUI.data_type.BIO_CHARGE, 6, 91, BIG_VALUE, hmUI.align.RIGHT);
        hmUI.createWidget(hmUI.widget.FILL_RECT, { x: 109, y: 97, w: 5, h: 38, color: BLUE, show_level: BOTH });
        text("BIO", 118, 91, 90, 22, 18, GREY, hmUI.align.LEFT);
        text("CARGA", 118, 110, 90, 22, 18, GREY, hmUI.align.LEFT);

        line(37, 155, 143);

        // ===== EM PÉ / DISTÂNCIA =====
        data(hmUI.data_type.STAND, 34, 164, MID_VALUE, hmUI.align.RIGHT, { w: 28 });
        text("/", 67, 164, 12, 26, 21, WHITE, hmUI.align.CENTER_H);
        data(hmUI.data_type.STAND_TARGET, 79, 164, MID_VALUE, hmUI.align.LEFT);
        text("EM PÉ", 28, 191, 82, 26, 16, GREY, hmUI.align.CENTER_H);

        data(hmUI.data_type.DISTANCE, 122, 164, MID_VALUE, hmUI.align.LEFT, { dot_image: "0085.png" });
        text("DIST", 111, 191, 74, 26, 16, GREY, hmUI.align.CENTER_H);

        // ===== PASSOS / KCAL =====
        data(hmUI.data_type.STEP, 36, 229, STEP_VALUE, hmUI.align.LEFT);
        text("PASSOS", 27, 255, 84, 24, 16, GREY, hmUI.align.CENTER_H);

        data(hmUI.data_type.CAL, 126, 229, MID_VALUE, hmUI.align.LEFT);
        text("KCAL", 113, 255, 76, 24, 16, GREY, hmUI.align.CENTER_H);

        // ===== FECHA =====
        dateDay = text("30", 28, 284, 48, 44, 38, ORANGE, hmUI.align.LEFT);
        dateWeek = text("SUN", 73, 286, 56, 22, 17, WHITE, hmUI.align.LEFT);
        dateMonth = text("AUG", 73, 306, 56, 22, 17, GREY, hmUI.align.LEFT);

        // ===== BATERIA =====
        hmUI.createWidget(hmUI.widget.FILL_RECT, {
          x: 120, y: 290, w: 154, h: 36,
          radius: 17,
          color: GREEN,
          show_level: BOTH
        });
        hmUI.createWidget(hmUI.widget.IMG, {
          x: 129, y: 300, w: 73, h: 17,
          src: "bat_label.png",
          show_level: BOTH
        });
        data(hmUI.data_type.BATTERY, 214, 294, BAT_BOLD, hmUI.align.LEFT, { h_space: -3 });
        hmUI.createWidget(hmUI.widget.IMG, {
          x: 249, y: 300, w: 20, h: 17,
          src: "bat_pct.png",
          show_level: BOTH
        });

        // ===== CLIMA =====
        hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 278, y: 281,
          image_array: WEATHER_ICONS,
          image_length: 29,
          type: hmUI.data_type.WEATHER_CURRENT,
          enable: false,
          show_level: BOTH
        });
        data(hmUI.data_type.WEATHER_CURRENT, 315, 291, TEMP_VALUE, hmUI.align.LEFT, {
          h_space: -7,
          unit_sc: ["0149.png"], unit_tc: ["0149.png"], unit_en: ["0149.png"],
          negative_image: ["0148.png"], invalid_image: ["0148.png"]
        });

        line(18, 344, 354);

        // ===== FILA INFERIOR =====
        // Balanced size: larger than before without becoming oversized.
        data(hmUI.data_type.PAI_DAILY, 2, 355, BOTTOM_VALUE, hmUI.align.CENTER_H, { w: 98, h_space: -2, invalid_image: "bot_inv.png" });
        text("PAI", 2, 399, 98, 28, 18, GREY, hmUI.align.CENTER_H);

        data(hmUI.data_type.SPO2, 94, 355, BOTTOM_VALUE, hmUI.align.CENTER_H, { w: 90, h_space: -2, invalid_image: "bot_inv.png" });
        text("SPO2", 94, 399, 90, 28, 18, GREY, hmUI.align.CENTER_H);

        data(hmUI.data_type.STRESS, 178, 355, BOTTOM_VALUE, hmUI.align.CENTER_H, { w: 104, h_space: -2, invalid_image: "bot_inv.png" });
        text("ESTRESSE", 178, 399, 104, 28, 18, GREY, hmUI.align.CENTER_H);

        sleepValue = text("--", 280, 353, 88, 42, 34, WHITE, hmUI.align.CENTER_H);
        text("h", 357, 366, 14, 18, 13, SOFT, hmUI.align.LEFT);
        text("SONO", 280, 399, 106, 28, 18, GREY, hmUI.align.CENTER_H);

        // ===== AOD: UNIFORM DIMMING =====
        // The same elements are shown in NORMAL + AOD.
        // This layer only appears in AOD and reduces luminance without changing
        // positions, sizes, or the red/blue/green accents.
        hmUI.createWidget(hmUI.widget.IMG, {
          x: 0, y: 0, w: 390, h: 450,
          src: "aod_dim_overlay.png",
          show_level: AOD
        });

        // ===== TOUCH SHORTCUTS =====
        tap(hmUI.data_type.HEART, 4, 30, 188, 60);
        if (hmUI.data_type.BIO_CHARGE !== undefined) tap(hmUI.data_type.BIO_CHARGE, 4, 88, 188, 58);

        // EM PÉ e DISTÂNCIA ficam apenas como informação (sem ação táctil).

        tap(hmUI.data_type.STEP, 30, 224, 86, 60);
        tap(hmUI.data_type.CAL, 118, 224, 82, 60);

        // Bateria: usa o atalho nativo do Zepp OS associado à bateria.
        // Avoid PowerSaveScreen because it did not open the correct screen on Bip 6.
        tap(hmUI.data_type.BATTERY, 121, 286, 152, 44);

        tap(hmUI.data_type.WEATHER_CURRENT, 274, 278, 112, 62);
        tap(hmUI.data_type.PAI_DAILY, 0, 347, 100, 86);
        tap(hmUI.data_type.SPO2, 90, 347, 96, 86);
        tap(hmUI.data_type.STRESS, 176, 347, 106, 86);
        tap(hmUI.data_type.SLEEP, 274, 347, 112, 86);

        hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 22, y: 280, w: 104, h: 52,
          text: "", normal_src: "", press_src: "",
          click_func: () => { hmApp.startApp({ url: "ScheduleCalScreen", native: true }); },
          show_level: NORMAL
        });

        updateClock();
        updateDate();
        updateSleep();

        timeSensor.addEventListener(hmSensor.event.CHANGE, () => {
          updateClock();
          updateDate();
        });

        hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: () => {
            startClockTimer();
            updateDate();
            updateSleep();
          },
          pause_call: () => {
            stopClockTimer();
          }
        });
      },

      onInit() {
        this.init_view();
      },
      onReady() {},
      onShow() {
        startClockTimer();
        updateDate();
        updateSleep();
      },
      onHide() {
        stopClockTimer();
      },
      onDestroy() {
        stopClockTimer();
      }
    });
  })();
} catch (e) {
  console.log(e);
}
