try {
    (() => {
        var e = __$$hmAppManager$$__.currentApp;
        const n = e.current,
            {
                px: g
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e, n)), e.app.__globals__),
            _ = Logger.getLogger("watchface6");
        n.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: "4.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 174,
                    y: 150,
                    type: hmUI.data_type.HEART,
                    font_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: "15.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 177,
                    y: 95,
                    w: 40,
                    h: 80,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 234,
                    y: 212,
                    week_en: ["16.png", "17.png", "18.png", "19.png", "20.png", "21.png", "22.png"],
                    week_tc: ["23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    week_sc: ["30.png", "31.png", "32.png", "33.png", "34.png", "35.png", "36.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 313,
                    day_startY: 214,
                    day_sc_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    day_tc_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    day_en_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: !1,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 160,
                    y: 330,
                    type: hmUI.data_type.STEP,
                    font_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: "37.png",
                    padding: !1,
                    isCharacter: !1
                }),
                // hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                //     x: 144,
                //     y: 292,
                //     image_array: ["38.png", "39.png", "40.png", "41.png", "42.png", "43.png"],
                //     image_length: 6,
                //     type: hmUI.data_type.STEP,
                //     show_level: hmUI.show_level.ONLY_NORMAL
                // }),
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 101,  // 圆弧中心位置x坐标
                    center_y: 225,  // 圆弧中心位置y坐标
                    radius: 48,    // 圆弧内半径
                    start_angle: 221, // 开始角度
                    end_angle: 499,    // 结束角度 (小于'开始角度'时为逆时针)
                    color: 0x1564af,  // 填充色
                    line_width: 6,   // 弧形进度条宽度
                    corner_flag: 0,   // 可选, 默认0-两端圆角,1-仅起始圆角,2-仅终点圆角,其它值-两端直角

                    type: hmUI.data_type.BATTERY, // 设置数据类型来驱动进度,type和level至少要设置一个.
                }),
                hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 194,  // 圆弧中心位置x坐标
                    center_y: 343,  // 圆弧中心位置y坐标
                    radius: 48,    // 圆弧内半径
                    start_angle: 221, // 开始角度
                    end_angle: 499,    // 结束角度 (小于'开始角度'时为逆时针)
                    color: 0x1564af,  // 填充色
                    line_width: 6,   // 弧形进度条宽度
                    corner_flag: 0,   // 可选, 默认0-两端圆角,1-仅起始圆角,2-仅终点圆角,其它值-两端直角
                    type: hmUI.data_type.STEP, // 设置数据类型来驱动进度,type和level至少要设置一个.
                })
                , hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 160,
                    y: 330,
                    w: 70,
                    h: 62,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }),
                // hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                //     x: 51,
                //     y: 174,
                //     image_array: ["44.png", "45.png", "46.png", "47.png", "48.png", "49.png"],
                //     image_length: 6,
                //     type: hmUI.data_type.BATTERY,
                //     show_level: hmUI.show_level.ONLY_NORMAL
                // }),
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 74,
                    y: 214,
                    type: hmUI.data_type.BATTERY,
                    font_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "51.png",
                    unit_tc: "51.png",
                    unit_en: "51.png",
                    invalid_image: "50.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 195,
                    hour_centerY: 225,
                    hour_posX: 22,
                    hour_posY: 127,
                    hour_path: "52.png",
                    hour_cover_path: "",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 195,
                    minute_centerY: 225,
                    minute_posX: 18,
                    minute_posY: 163,
                    minute_path: "53.png",
                    minute_cover_path: "",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 195,
                    second_centerY: 225,
                    second_posX: 14,
                    second_posY: 196,
                    second_path: "54.png",
                    second_cover_path: "",
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: "55.png",
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 195,
                    hour_centerY: 225,
                    hour_posX: 17,
                    hour_posY: 123,
                    hour_path: "56.png",
                    hour_cover_path: "",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 195,
                    minute_centerY: 225,
                    minute_posX: 15,
                    minute_posY: 162,
                    minute_path: "57.png",
                    minute_cover_path: "",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                })
            },
            onInit() {
                _.log("index page.js on init invoke")
            },
            build() {
                this.init_view(), _.log("index page.js on ready invoke")
            },
            onDestory() {
                _.log("index page.js on destory invoke")
            }
        })
    })()
} catch (e) {
    console.log(e)
}