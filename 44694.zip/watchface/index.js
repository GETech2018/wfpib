﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_stand_circle_scale = ''
        let normal_stand_TextRotate = new Array(2);
        let normal_stand_TextRotate_ASCIIARRAY = new Array(10);
        let normal_stand_TextRotate_img_width = 32;
        let normal_calorie_circle_scale = ''
        let normal_calorie_TextRotate = new Array(4);
        let normal_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let normal_calorie_TextRotate_img_width = 32;
        let normal_step_circle_scale = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 32;
        let normal_battery_circle_scale = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 43;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 48;
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_TextRotate = new Array(4);
        let normal_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_current_TextRotate_img_width = 43;
        let normal_temperature_current_TextRotate_unit = null;
        let normal_temperature_current_TextRotate_unit_width = 36;
        let normal_temperature_current_TextRotate_dot_width = 48;
        let normal_time_hour_min_sec_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_background_bg_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_stand_circle_scale = ''
        let idle_stand_TextRotate = new Array(2);
        let idle_stand_TextRotate_ASCIIARRAY = new Array(10);
        let idle_stand_TextRotate_img_width = 32;
        let idle_calorie_circle_scale = ''
        let idle_calorie_TextRotate = new Array(4);
        let idle_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let idle_calorie_TextRotate_img_width = 32;
        let idle_step_circle_scale = ''
        let idle_step_TextRotate = new Array(5);
        let idle_step_TextRotate_ASCIIARRAY = new Array(10);
        let idle_step_TextRotate_img_width = 32;
        let idle_battery_circle_scale = ''
        let idle_battery_TextRotate = new Array(3);
        let idle_battery_TextRotate_ASCIIARRAY = new Array(10);
        let idle_battery_TextRotate_img_width = 43;
        let idle_battery_TextRotate_unit = null;
        let idle_battery_TextRotate_unit_width = 48;
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_TextRotate = new Array(4);
        let idle_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let idle_temperature_current_TextRotate_img_width = 43;
        let idle_temperature_current_TextRotate_unit = null;
        let idle_temperature_current_TextRotate_unit_width = 36;
        let idle_temperature_current_TextRotate_dot_width = 48;
        let idle_time_hour_min_sec_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SF-Compact-Rounded-Medium_compressed (1).ttf; FontSize: 45
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 577,
              h: 64,
              text_size: 45,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed (1).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 206,
              font_array: ["NUMBERS_SIZE_40_0.png","NUMBERS_SIZE_40_1.png","NUMBERS_SIZE_40_2.png","NUMBERS_SIZE_40_3.png","NUMBERS_SIZE_40_4.png","NUMBERS_SIZE_40_5.png","NUMBERS_SIZE_40_6.png","NUMBERS_SIZE_40_7.png","NUMBERS_SIZE_40_8.png","NUMBERS_SIZE_40_9.png"],
              padding: false,
              h_space: -20,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 82,
              y: 184,
              src: 'BPP.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 60,
              // center_y: 44,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 9,
              // line_width: 4,
              // line_cap: Rounded,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 60,
              center_y: 44,
              start_angle: 0,
              end_angle: 360,
              radius: 7,
              line_width: 4,
              corner_flag: 0,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_stand_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 85,
              // y: 48,
              // font_array: ["NUMBERS_SIZE_22_0.png","NUMBERS_SIZE_22_1.png","NUMBERS_SIZE_22_2.png","NUMBERS_SIZE_22_3.png","NUMBERS_SIZE_22_4.png","NUMBERS_SIZE_22_5.png","NUMBERS_SIZE_22_6.png","NUMBERS_SIZE_22_7.png","NUMBERS_SIZE_22_8.png","NUMBERS_SIZE_22_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: -31,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_TextRotate_ASCIIARRAY[0] = 'NUMBERS_SIZE_22_0.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[1] = 'NUMBERS_SIZE_22_1.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[2] = 'NUMBERS_SIZE_22_2.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[3] = 'NUMBERS_SIZE_22_3.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[4] = 'NUMBERS_SIZE_22_4.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[5] = 'NUMBERS_SIZE_22_5.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[6] = 'NUMBERS_SIZE_22_6.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[7] = 'NUMBERS_SIZE_22_7.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[8] = 'NUMBERS_SIZE_22_8.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[9] = 'NUMBERS_SIZE_22_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_stand_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 85,
                center_y: 48,
                pos_x: 85,
                pos_y: 48,
                angle: -31,
                src: 'NUMBERS_SIZE_22_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_stand_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 60,
              // center_y: 44,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 16,
              // line_width: 4,
              // line_cap: Rounded,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 60,
              center_y: 44,
              start_angle: 0,
              end_angle: 360,
              radius: 14,
              line_width: 4,
              corner_flag: 0,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 107,
              // y: 34,
              // font_array: ["NUMBERS_SIZE_22_0.png","NUMBERS_SIZE_22_1.png","NUMBERS_SIZE_22_2.png","NUMBERS_SIZE_22_3.png","NUMBERS_SIZE_22_4.png","NUMBERS_SIZE_22_5.png","NUMBERS_SIZE_22_6.png","NUMBERS_SIZE_22_7.png","NUMBERS_SIZE_22_8.png","NUMBERS_SIZE_22_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: -14,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextRotate_ASCIIARRAY[0] = 'NUMBERS_SIZE_22_0.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = 'NUMBERS_SIZE_22_1.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = 'NUMBERS_SIZE_22_2.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = 'NUMBERS_SIZE_22_3.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = 'NUMBERS_SIZE_22_4.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = 'NUMBERS_SIZE_22_5.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = 'NUMBERS_SIZE_22_6.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = 'NUMBERS_SIZE_22_7.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = 'NUMBERS_SIZE_22_8.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = 'NUMBERS_SIZE_22_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 107,
                center_y: 34,
                pos_x: 107,
                pos_y: 34,
                angle: -14,
                src: 'NUMBERS_SIZE_22_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 60,
              // center_y: 44,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 23,
              // line_width: 4,
              // line_cap: Rounded,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 60,
              center_y: 44,
              start_angle: 0,
              end_angle: 360,
              radius: 21,
              line_width: 4,
              corner_flag: 0,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 64,
              // y: 61,
              // font_array: ["NUMBERS_SIZE_22_0.png","NUMBERS_SIZE_22_1.png","NUMBERS_SIZE_22_2.png","NUMBERS_SIZE_22_3.png","NUMBERS_SIZE_22_4.png","NUMBERS_SIZE_22_5.png","NUMBERS_SIZE_22_6.png","NUMBERS_SIZE_22_7.png","NUMBERS_SIZE_22_8.png","NUMBERS_SIZE_22_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: -44,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'NUMBERS_SIZE_22_0.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'NUMBERS_SIZE_22_1.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'NUMBERS_SIZE_22_2.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'NUMBERS_SIZE_22_3.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'NUMBERS_SIZE_22_4.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'NUMBERS_SIZE_22_5.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'NUMBERS_SIZE_22_6.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'NUMBERS_SIZE_22_7.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'NUMBERS_SIZE_22_8.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'NUMBERS_SIZE_22_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 64,
                center_y: 61,
                pos_x: 64,
                pos_y: 61,
                angle: -44,
                src: 'NUMBERS_SIZE_22_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 225,
              // start_angle: 122,
              // end_angle: 171,
              // radius: 188,
              // line_width: 13,
              // line_cap: Rounded,
              // color: 0xFF600030,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 225,
              start_angle: 122,
              end_angle: 171,
              radius: 182,
              line_width: 13,
              corner_flag: 0,
              color: 0xFF600030,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 288,
              // y: 382,
              // font_array: ["NUMBERS_SIZE_40_0.png","NUMBERS_SIZE_40_1.png","NUMBERS_SIZE_40_2.png","NUMBERS_SIZE_40_3.png","NUMBERS_SIZE_40_4.png","NUMBERS_SIZE_40_5.png","NUMBERS_SIZE_40_6.png","NUMBERS_SIZE_40_7.png","NUMBERS_SIZE_40_8.png","NUMBERS_SIZE_40_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: -34,
              // unit_en: 'SYMBOLS_SIZE_40__.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'NUMBERS_SIZE_40_0.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'NUMBERS_SIZE_40_1.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'NUMBERS_SIZE_40_2.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'NUMBERS_SIZE_40_3.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'NUMBERS_SIZE_40_4.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'NUMBERS_SIZE_40_5.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'NUMBERS_SIZE_40_6.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'NUMBERS_SIZE_40_7.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'NUMBERS_SIZE_40_8.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'NUMBERS_SIZE_40_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 288,
                center_y: 382,
                pos_x: 288,
                pos_y: 382,
                angle: -34,
                src: 'NUMBERS_SIZE_40_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 288,
              center_y: 382,
              pos_x: 288,
              pos_y: 382,
              angle: -34,
              src: 'SYMBOLS_SIZE_40__.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 240,
              day_startY: 206,
              day_sc_array: ["NUMBERS_SIZE_40_0.png","NUMBERS_SIZE_40_1.png","NUMBERS_SIZE_40_2.png","NUMBERS_SIZE_40_3.png","NUMBERS_SIZE_40_4.png","NUMBERS_SIZE_40_5.png","NUMBERS_SIZE_40_6.png","NUMBERS_SIZE_40_7.png","NUMBERS_SIZE_40_8.png","NUMBERS_SIZE_40_9.png"],
              day_tc_array: ["NUMBERS_SIZE_40_0.png","NUMBERS_SIZE_40_1.png","NUMBERS_SIZE_40_2.png","NUMBERS_SIZE_40_3.png","NUMBERS_SIZE_40_4.png","NUMBERS_SIZE_40_5.png","NUMBERS_SIZE_40_6.png","NUMBERS_SIZE_40_7.png","NUMBERS_SIZE_40_8.png","NUMBERS_SIZE_40_9.png"],
              day_en_array: ["NUMBERS_SIZE_40_0.png","NUMBERS_SIZE_40_1.png","NUMBERS_SIZE_40_2.png","NUMBERS_SIZE_40_3.png","NUMBERS_SIZE_40_4.png","NUMBERS_SIZE_40_5.png","NUMBERS_SIZE_40_6.png","NUMBERS_SIZE_40_7.png","NUMBERS_SIZE_40_8.png","NUMBERS_SIZE_40_9.png"],
              day_zero: 0,
              day_space: -20,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 246,
              y: 184,
              week_en: ["DAYS_EN_1.png","DAYS_EN_2.png","DAYS_EN_3.png","DAYS_EN_4.png","DAYS_EN_5.png","DAYS_EN_6.png","DAYS_EN_7.png"],
              week_tc: ["DAYS_EN_1.png","DAYS_EN_2.png","DAYS_EN_3.png","DAYS_EN_4.png","DAYS_EN_5.png","DAYS_EN_6.png","DAYS_EN_7.png"],
              week_sc: ["DAYS_EN_1.png","DAYS_EN_2.png","DAYS_EN_3.png","DAYS_EN_4.png","DAYS_EN_5.png","DAYS_EN_6.png","DAYS_EN_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 162,
              y: 279,
              image_array: ["WEATHERICON_1.png","WEATHERICON_2.png","WEATHERICON_3.png","WEATHERICON_4.png","WEATHERICON_5.png","WEATHERICON_6.png","WEATHERICON_7.png","WEATHERICON_8.png","WEATHERICON_9.png","WEATHERICON_10.png","WEATHERICON_11.png","WEATHERICON_12.png","WEATHERICON_13.png","WEATHERICON_14.png","WEATHERICON_15.png","WEATHERICON_16.png","WEATHERICON_17.png","WEATHERICON_18.png","WEATHERICON_19.png","WEATHERICON_20.png","WEATHERICON_21.png","WEATHERICON_22.png","WEATHERICON_23.png","WEATHERICON_24.png","WEATHERICON_25.png","WEATHERICON_26.png","WEATHERICON_27.png","WEATHERICON_28.png","WEATHERICON_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 98,
              font_array: ["NUMBERS_SIZE_22_0.png","NUMBERS_SIZE_22_1.png","NUMBERS_SIZE_22_2.png","NUMBERS_SIZE_22_3.png","NUMBERS_SIZE_22_4.png","NUMBERS_SIZE_22_5.png","NUMBERS_SIZE_22_6.png","NUMBERS_SIZE_22_7.png","NUMBERS_SIZE_22_8.png","NUMBERS_SIZE_22_9.png"],
              padding: false,
              h_space: -20,
              angle: 56,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 15,
              font_array: ["NUMBERS_SIZE_22_0.png","NUMBERS_SIZE_22_1.png","NUMBERS_SIZE_22_2.png","NUMBERS_SIZE_22_3.png","NUMBERS_SIZE_22_4.png","NUMBERS_SIZE_22_5.png","NUMBERS_SIZE_22_6.png","NUMBERS_SIZE_22_7.png","NUMBERS_SIZE_22_8.png","NUMBERS_SIZE_22_9.png"],
              padding: false,
              h_space: -20,
              angle: 9,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 320,
              // y: 24,
              // font_array: ["NUMBERS_SIZE_40_0.png","NUMBERS_SIZE_40_1.png","NUMBERS_SIZE_40_2.png","NUMBERS_SIZE_40_3.png","NUMBERS_SIZE_40_4.png","NUMBERS_SIZE_40_5.png","NUMBERS_SIZE_40_6.png","NUMBERS_SIZE_40_7.png","NUMBERS_SIZE_40_8.png","NUMBERS_SIZE_40_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: 32,
              // unit_en: 'DEGREE_SIZE_40___(1).png',
              // negative_image: 'SYMBOLS_SIZE_40_-.png',
              // dot_image: 'SYMBOLS_SIZE_40_-.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_current_TextRotate_ASCIIARRAY[0] = 'NUMBERS_SIZE_40_0.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[1] = 'NUMBERS_SIZE_40_1.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[2] = 'NUMBERS_SIZE_40_2.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[3] = 'NUMBERS_SIZE_40_3.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[4] = 'NUMBERS_SIZE_40_4.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[5] = 'NUMBERS_SIZE_40_5.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[6] = 'NUMBERS_SIZE_40_6.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[7] = 'NUMBERS_SIZE_40_7.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[8] = 'NUMBERS_SIZE_40_8.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[9] = 'NUMBERS_SIZE_40_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 320,
                center_y: 24,
                pos_x: 320,
                pos_y: 24,
                angle: 32,
                src: 'NUMBERS_SIZE_40_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 320,
              center_y: 24,
              pos_x: 320,
              pos_y: 24,
              angle: 32,
              src: 'DEGREE_SIZE_40___(1).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            normal_time_hour_min_sec_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 87,
              y: 110,
              w: 215,
              h: 43,
              text_size: 45,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed (1).ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_HR.png',
              // center_x: 195,
              // center_y: 225,
              // x: 19,
              // y: 98,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 19,
              pos_y: 225 - 98,
              center_x: 195,
              center_y: 225,
              src: 'HAND_HR.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_MIN.png',
              // center_x: 195,
              // center_y: 225,
              // x: 19,
              // y: 172,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 19,
              pos_y: 225 - 172,
              center_x: 195,
              center_y: 225,
              src: 'HAND_MIN.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_SEC.png',
              // center_x: 195,
              // center_y: 225,
              // x: 20,
              // y: 200,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'HAND_SEC.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 20,
              second_posY: 200,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 206,
              font_array: ["NUMBERS_SIZE_40_0.png","NUMBERS_SIZE_40_1.png","NUMBERS_SIZE_40_2.png","NUMBERS_SIZE_40_3.png","NUMBERS_SIZE_40_4.png","NUMBERS_SIZE_40_5.png","NUMBERS_SIZE_40_6.png","NUMBERS_SIZE_40_7.png","NUMBERS_SIZE_40_8.png","NUMBERS_SIZE_40_9.png"],
              padding: false,
              h_space: -20,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 82,
              y: 184,
              src: 'BPP.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 60,
              // center_y: 44,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 9,
              // line_width: 4,
              // line_cap: Rounded,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 60,
              center_y: 44,
              start_angle: 0,
              end_angle: 360,
              radius: 7,
              line_width: 4,
              corner_flag: 0,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_stand_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 85,
              // y: 48,
              // font_array: ["NUMBERS_SIZE_22_0.png","NUMBERS_SIZE_22_1.png","NUMBERS_SIZE_22_2.png","NUMBERS_SIZE_22_3.png","NUMBERS_SIZE_22_4.png","NUMBERS_SIZE_22_5.png","NUMBERS_SIZE_22_6.png","NUMBERS_SIZE_22_7.png","NUMBERS_SIZE_22_8.png","NUMBERS_SIZE_22_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: -31,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_stand_TextRotate_ASCIIARRAY[0] = 'NUMBERS_SIZE_22_0.png';  // set of images with numbers
            idle_stand_TextRotate_ASCIIARRAY[1] = 'NUMBERS_SIZE_22_1.png';  // set of images with numbers
            idle_stand_TextRotate_ASCIIARRAY[2] = 'NUMBERS_SIZE_22_2.png';  // set of images with numbers
            idle_stand_TextRotate_ASCIIARRAY[3] = 'NUMBERS_SIZE_22_3.png';  // set of images with numbers
            idle_stand_TextRotate_ASCIIARRAY[4] = 'NUMBERS_SIZE_22_4.png';  // set of images with numbers
            idle_stand_TextRotate_ASCIIARRAY[5] = 'NUMBERS_SIZE_22_5.png';  // set of images with numbers
            idle_stand_TextRotate_ASCIIARRAY[6] = 'NUMBERS_SIZE_22_6.png';  // set of images with numbers
            idle_stand_TextRotate_ASCIIARRAY[7] = 'NUMBERS_SIZE_22_7.png';  // set of images with numbers
            idle_stand_TextRotate_ASCIIARRAY[8] = 'NUMBERS_SIZE_22_8.png';  // set of images with numbers
            idle_stand_TextRotate_ASCIIARRAY[9] = 'NUMBERS_SIZE_22_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_stand_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 85,
                center_y: 48,
                pos_x: 85,
                pos_y: 48,
                angle: -31,
                src: 'NUMBERS_SIZE_22_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_stand_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 60,
              // center_y: 44,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 16,
              // line_width: 4,
              // line_cap: Rounded,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 60,
              center_y: 44,
              start_angle: 0,
              end_angle: 360,
              radius: 14,
              line_width: 4,
              corner_flag: 0,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 107,
              // y: 34,
              // font_array: ["NUMBERS_SIZE_22_0.png","NUMBERS_SIZE_22_1.png","NUMBERS_SIZE_22_2.png","NUMBERS_SIZE_22_3.png","NUMBERS_SIZE_22_4.png","NUMBERS_SIZE_22_5.png","NUMBERS_SIZE_22_6.png","NUMBERS_SIZE_22_7.png","NUMBERS_SIZE_22_8.png","NUMBERS_SIZE_22_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: -14,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_TextRotate_ASCIIARRAY[0] = 'NUMBERS_SIZE_22_0.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[1] = 'NUMBERS_SIZE_22_1.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[2] = 'NUMBERS_SIZE_22_2.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[3] = 'NUMBERS_SIZE_22_3.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[4] = 'NUMBERS_SIZE_22_4.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[5] = 'NUMBERS_SIZE_22_5.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[6] = 'NUMBERS_SIZE_22_6.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[7] = 'NUMBERS_SIZE_22_7.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[8] = 'NUMBERS_SIZE_22_8.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[9] = 'NUMBERS_SIZE_22_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              idle_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 107,
                center_y: 34,
                pos_x: 107,
                pos_y: 34,
                angle: -14,
                src: 'NUMBERS_SIZE_22_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 60,
              // center_y: 44,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 23,
              // line_width: 4,
              // line_cap: Rounded,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 60,
              center_y: 44,
              start_angle: 0,
              end_angle: 360,
              radius: 21,
              line_width: 4,
              corner_flag: 0,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 64,
              // y: 61,
              // font_array: ["NUMBERS_SIZE_22_0.png","NUMBERS_SIZE_22_1.png","NUMBERS_SIZE_22_2.png","NUMBERS_SIZE_22_3.png","NUMBERS_SIZE_22_4.png","NUMBERS_SIZE_22_5.png","NUMBERS_SIZE_22_6.png","NUMBERS_SIZE_22_7.png","NUMBERS_SIZE_22_8.png","NUMBERS_SIZE_22_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: -44,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextRotate_ASCIIARRAY[0] = 'NUMBERS_SIZE_22_0.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[1] = 'NUMBERS_SIZE_22_1.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[2] = 'NUMBERS_SIZE_22_2.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[3] = 'NUMBERS_SIZE_22_3.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[4] = 'NUMBERS_SIZE_22_4.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[5] = 'NUMBERS_SIZE_22_5.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[6] = 'NUMBERS_SIZE_22_6.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[7] = 'NUMBERS_SIZE_22_7.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[8] = 'NUMBERS_SIZE_22_8.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[9] = 'NUMBERS_SIZE_22_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              idle_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 64,
                center_y: 61,
                pos_x: 64,
                pos_y: 61,
                angle: -44,
                src: 'NUMBERS_SIZE_22_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 225,
              // start_angle: 122,
              // end_angle: 171,
              // radius: 188,
              // line_width: 13,
              // line_cap: Rounded,
              // color: 0xFF600030,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 225,
              start_angle: 122,
              end_angle: 171,
              radius: 182,
              line_width: 13,
              corner_flag: 0,
              color: 0xFF600030,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 288,
              // y: 382,
              // font_array: ["NUMBERS_SIZE_40_0.png","NUMBERS_SIZE_40_1.png","NUMBERS_SIZE_40_2.png","NUMBERS_SIZE_40_3.png","NUMBERS_SIZE_40_4.png","NUMBERS_SIZE_40_5.png","NUMBERS_SIZE_40_6.png","NUMBERS_SIZE_40_7.png","NUMBERS_SIZE_40_8.png","NUMBERS_SIZE_40_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: -34,
              // unit_en: 'SYMBOLS_SIZE_40__.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextRotate_ASCIIARRAY[0] = 'NUMBERS_SIZE_40_0.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[1] = 'NUMBERS_SIZE_40_1.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[2] = 'NUMBERS_SIZE_40_2.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[3] = 'NUMBERS_SIZE_40_3.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[4] = 'NUMBERS_SIZE_40_4.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[5] = 'NUMBERS_SIZE_40_5.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[6] = 'NUMBERS_SIZE_40_6.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[7] = 'NUMBERS_SIZE_40_7.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[8] = 'NUMBERS_SIZE_40_8.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[9] = 'NUMBERS_SIZE_40_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              idle_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 288,
                center_y: 382,
                pos_x: 288,
                pos_y: 382,
                angle: -34,
                src: 'NUMBERS_SIZE_40_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 288,
              center_y: 382,
              pos_x: 288,
              pos_y: 382,
              angle: -34,
              src: 'SYMBOLS_SIZE_40__.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 240,
              day_startY: 206,
              day_sc_array: ["NUMBERS_SIZE_40_0.png","NUMBERS_SIZE_40_1.png","NUMBERS_SIZE_40_2.png","NUMBERS_SIZE_40_3.png","NUMBERS_SIZE_40_4.png","NUMBERS_SIZE_40_5.png","NUMBERS_SIZE_40_6.png","NUMBERS_SIZE_40_7.png","NUMBERS_SIZE_40_8.png","NUMBERS_SIZE_40_9.png"],
              day_tc_array: ["NUMBERS_SIZE_40_0.png","NUMBERS_SIZE_40_1.png","NUMBERS_SIZE_40_2.png","NUMBERS_SIZE_40_3.png","NUMBERS_SIZE_40_4.png","NUMBERS_SIZE_40_5.png","NUMBERS_SIZE_40_6.png","NUMBERS_SIZE_40_7.png","NUMBERS_SIZE_40_8.png","NUMBERS_SIZE_40_9.png"],
              day_en_array: ["NUMBERS_SIZE_40_0.png","NUMBERS_SIZE_40_1.png","NUMBERS_SIZE_40_2.png","NUMBERS_SIZE_40_3.png","NUMBERS_SIZE_40_4.png","NUMBERS_SIZE_40_5.png","NUMBERS_SIZE_40_6.png","NUMBERS_SIZE_40_7.png","NUMBERS_SIZE_40_8.png","NUMBERS_SIZE_40_9.png"],
              day_zero: 0,
              day_space: -20,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 246,
              y: 184,
              week_en: ["DAYS_EN_1.png","DAYS_EN_2.png","DAYS_EN_3.png","DAYS_EN_4.png","DAYS_EN_5.png","DAYS_EN_6.png","DAYS_EN_7.png"],
              week_tc: ["DAYS_EN_1.png","DAYS_EN_2.png","DAYS_EN_3.png","DAYS_EN_4.png","DAYS_EN_5.png","DAYS_EN_6.png","DAYS_EN_7.png"],
              week_sc: ["DAYS_EN_1.png","DAYS_EN_2.png","DAYS_EN_3.png","DAYS_EN_4.png","DAYS_EN_5.png","DAYS_EN_6.png","DAYS_EN_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 162,
              y: 279,
              image_array: ["WEATHERICON_1.png","WEATHERICON_2.png","WEATHERICON_3.png","WEATHERICON_4.png","WEATHERICON_5.png","WEATHERICON_6.png","WEATHERICON_7.png","WEATHERICON_8.png","WEATHERICON_9.png","WEATHERICON_10.png","WEATHERICON_11.png","WEATHERICON_12.png","WEATHERICON_13.png","WEATHERICON_14.png","WEATHERICON_15.png","WEATHERICON_16.png","WEATHERICON_17.png","WEATHERICON_18.png","WEATHERICON_19.png","WEATHERICON_20.png","WEATHERICON_21.png","WEATHERICON_22.png","WEATHERICON_23.png","WEATHERICON_24.png","WEATHERICON_25.png","WEATHERICON_26.png","WEATHERICON_27.png","WEATHERICON_28.png","WEATHERICON_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 98,
              font_array: ["NUMBERS_SIZE_22_0.png","NUMBERS_SIZE_22_1.png","NUMBERS_SIZE_22_2.png","NUMBERS_SIZE_22_3.png","NUMBERS_SIZE_22_4.png","NUMBERS_SIZE_22_5.png","NUMBERS_SIZE_22_6.png","NUMBERS_SIZE_22_7.png","NUMBERS_SIZE_22_8.png","NUMBERS_SIZE_22_9.png"],
              padding: false,
              h_space: -20,
              angle: 56,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 15,
              font_array: ["NUMBERS_SIZE_22_0.png","NUMBERS_SIZE_22_1.png","NUMBERS_SIZE_22_2.png","NUMBERS_SIZE_22_3.png","NUMBERS_SIZE_22_4.png","NUMBERS_SIZE_22_5.png","NUMBERS_SIZE_22_6.png","NUMBERS_SIZE_22_7.png","NUMBERS_SIZE_22_8.png","NUMBERS_SIZE_22_9.png"],
              padding: false,
              h_space: -20,
              angle: 9,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 320,
              // y: 24,
              // font_array: ["NUMBERS_SIZE_40_0.png","NUMBERS_SIZE_40_1.png","NUMBERS_SIZE_40_2.png","NUMBERS_SIZE_40_3.png","NUMBERS_SIZE_40_4.png","NUMBERS_SIZE_40_5.png","NUMBERS_SIZE_40_6.png","NUMBERS_SIZE_40_7.png","NUMBERS_SIZE_40_8.png","NUMBERS_SIZE_40_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: 32,
              // unit_en: 'DEGREE_SIZE_40___(1).png',
              // negative_image: 'SYMBOLS_SIZE_40_-.png',
              // dot_image: 'SYMBOLS_SIZE_40_-.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_temperature_current_TextRotate_ASCIIARRAY[0] = 'NUMBERS_SIZE_40_0.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[1] = 'NUMBERS_SIZE_40_1.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[2] = 'NUMBERS_SIZE_40_2.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[3] = 'NUMBERS_SIZE_40_3.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[4] = 'NUMBERS_SIZE_40_4.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[5] = 'NUMBERS_SIZE_40_5.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[6] = 'NUMBERS_SIZE_40_6.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[7] = 'NUMBERS_SIZE_40_7.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[8] = 'NUMBERS_SIZE_40_8.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[9] = 'NUMBERS_SIZE_40_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              idle_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 320,
                center_y: 24,
                pos_x: 320,
                pos_y: 24,
                angle: 32,
                src: 'NUMBERS_SIZE_40_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_temperature_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 320,
              center_y: 24,
              pos_x: 320,
              pos_y: 24,
              angle: 32,
              src: 'DEGREE_SIZE_40___(1).png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            idle_time_hour_min_sec_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 87,
              y: 110,
              w: 215,
              h: 43,
              text_size: 45,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed (1).ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_HR.png',
              // center_x: 195,
              // center_y: 225,
              // x: 19,
              // y: 98,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 19,
              pos_y: 225 - 98,
              center_x: 195,
              center_y: 225,
              src: 'HAND_HR.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND_MIN.png',
              // center_x: 195,
              // center_y: 225,
              // x: 19,
              // y: 172,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 19,
              pos_y: 225 - 172,
              center_x: 195,
              center_y: 225,
              src: 'HAND_MIN.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 20,
              y: 20,
              w: 143,
              h: 75,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 60,
              y: 185,
              w: 100,
              h: 79,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 222,
              y: 355,
              w: 138,
              h: 78,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 21,
              w: 155,
              h: 73,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 89,
              y: 116,
              w: 60,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 155,
              y: 116,
              w: 60,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 219,
              y: 116,
              w: 60,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 233,
              y: 184,
              w: 86,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 150,
              y: 271,
              w: 86,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 26,
              y: 359,
              w: 75,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('hour:min:sec font');
              let normal_HourMinSecStr = format_hour.toString();
              normal_HourMinSecStr = normal_HourMinSecStr + ':' + minute.toString().padStart(2, '0') + ':' + second.toString().padStart(2, '0');
              normal_time_hour_min_sec_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinSecStr );
              if (updateMinute) { // Hour Pointer
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              console.log('hour:min:sec font');
              let idle_HourMinSecStr = format_hour.toString();
              idle_HourMinSecStr = idle_HourMinSecStr + ':' + minute.toString().padStart(2, '0') + ':' + second.toString().padStart(2, '0');
              idle_time_hour_min_sec_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinSecStr );
              if (updateMinute) { // Hour Pointer
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) { // Minute Pointer
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate stand_STAND');
              let valueStand = stand.current;
              let normal_stand_rotate_string = parseInt(valueStand).toString();
              normal_stand_rotate_string = normal_stand_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_stand_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStand != null && valueStand != undefined && isFinite(valueStand) && normal_stand_rotate_string.length > 0 && normal_stand_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_stand_TextRotate_posOffset = normal_stand_TextRotate_img_width * normal_stand_rotate_string.length;
                  normal_stand_TextRotate_posOffset = normal_stand_TextRotate_posOffset + -20 * (normal_stand_rotate_string.length - 1);
                  img_offset -= normal_stand_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_stand_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_stand_TextRotate[index].setProperty(hmUI.prop.POS_X, 85 + img_offset);
                      normal_stand_TextRotate[index].setProperty(hmUI.prop.SRC, normal_stand_TextRotate_ASCIIARRAY[charCode]);
                      normal_stand_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_stand_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_rotate_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_rotate_string.length > 0 && normal_calorie_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 107 + img_offset);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, normal_calorie_TextRotate_ASCIIARRAY[charCode]);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_calorie_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  normal_step_TextRotate_posOffset = normal_step_TextRotate_posOffset + -20 * (normal_step_rotate_string.length - 1);
                  img_offset -= normal_step_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 64 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  normal_battery_TextRotate_posOffset = normal_battery_TextRotate_posOffset + -20 * (normal_battery_rotate_string.length - 1);
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 288 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 288 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };
              let weatherData = weatherSensor.getForecastWeather();
              let temperature_current_temp = -100;
              if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
                temperature_current_temp = weatherSensor.current;
              }; // end currentWeather;

              console.log('update text rotate temperature_current_currentWeather');
              let temperatureCurrent = undefined;
              let normal_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                normal_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && normal_temperature_current_rotate_string.length > 0 && normal_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_img_width * normal_temperature_current_rotate_string.length;
                  normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_posOffset + -20 * (normal_temperature_current_rotate_string.length - 1);
                  img_offset -= normal_temperature_current_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 320 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_img_width + -20;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 320 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'SYMBOLS_SIZE_40_-.png');
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_dot_width + -20;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 320 + img_offset);
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate stand_STAND');
              let idle_stand_rotate_string = parseInt(valueStand).toString();
              idle_stand_rotate_string = idle_stand_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_stand_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStand != null && valueStand != undefined && isFinite(valueStand) && idle_stand_rotate_string.length > 0 && idle_stand_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_stand_TextRotate_posOffset = idle_stand_TextRotate_img_width * idle_stand_rotate_string.length;
                  idle_stand_TextRotate_posOffset = idle_stand_TextRotate_posOffset + -20 * (idle_stand_rotate_string.length - 1);
                  img_offset -= idle_stand_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_stand_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_stand_TextRotate[index].setProperty(hmUI.prop.POS_X, 85 + img_offset);
                      idle_stand_TextRotate[index].setProperty(hmUI.prop.SRC, idle_stand_TextRotate_ASCIIARRAY[charCode]);
                      idle_stand_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_stand_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate calorie_CALORIE');
              let idle_calorie_rotate_string = parseInt(valueCalories).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && idle_calorie_rotate_string.length > 0 && idle_calorie_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 107 + img_offset);
                      idle_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, idle_calorie_TextRotate_ASCIIARRAY[charCode]);
                      idle_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_calorie_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let idle_step_rotate_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_rotate_string.length > 0 && idle_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let idle_step_TextRotate_posOffset = idle_step_TextRotate_img_width * idle_step_rotate_string.length;
                  idle_step_TextRotate_posOffset = idle_step_TextRotate_posOffset + -20 * (idle_step_rotate_string.length - 1);
                  img_offset -= idle_step_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 64 + img_offset);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.SRC, idle_step_TextRotate_ASCIIARRAY[charCode]);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_step_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let idle_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_rotate_string.length > 0 && idle_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_battery_TextRotate_posOffset = idle_battery_TextRotate_img_width * idle_battery_rotate_string.length;
                  idle_battery_TextRotate_posOffset = idle_battery_TextRotate_posOffset + -20 * (idle_battery_rotate_string.length - 1);
                  img_offset -= idle_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 288 + img_offset);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.SRC, idle_battery_TextRotate_ASCIIARRAY[charCode]);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_battery_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 288 + img_offset);
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate temperature_current_currentWeather');
              let idle_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                idle_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && idle_temperature_current_rotate_string.length > 0 && idle_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_temperature_current_TextRotate_posOffset = idle_temperature_current_TextRotate_img_width * idle_temperature_current_rotate_string.length;
                  idle_temperature_current_TextRotate_posOffset = idle_temperature_current_TextRotate_posOffset + -20 * (idle_temperature_current_rotate_string.length - 1);
                  img_offset -= idle_temperature_current_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 320 + img_offset);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, idle_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_current_TextRotate_img_width + -20;
                      index++;
                    }  // end if digit
                    else { 
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 320 + img_offset);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'SYMBOLS_SIZE_40_-.png');
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_current_TextRotate_dot_width + -20;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 320 + img_offset);
                  idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 60,
                      center_y: 44,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 7,
                      line_width: 4,
                      corner_flag: 0,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 60,
                      center_y: 44,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 14,
                      line_width: 4,
                      corner_flag: 0,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 60,
                      center_y: 44,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 21,
                      line_width: 4,
                      corner_flag: 0,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 225,
                      start_angle: 122,
                      end_angle: 171,
                      radius: 182,
                      line_width: 13,
                      corner_flag: 0,
                      color: 0xFF600030,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STAND');
                let progress_cs_idle_stand = progressStand;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_stand * 100);
                  if (idle_stand_circle_scale) {
                    idle_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 60,
                      center_y: 44,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 7,
                      line_width: 4,
                      corner_flag: 0,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_calorie * 100);
                  if (idle_calorie_circle_scale) {
                    idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 60,
                      center_y: 44,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 14,
                      line_width: 4,
                      corner_flag: 0,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 60,
                      center_y: 44,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 21,
                      line_width: 4,
                      corner_flag: 0,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 225,
                      start_angle: 122,
                      end_angle: 171,
                      radius: 182,
                      line_width: 13,
                      corner_flag: 0,
                      color: 0xFF600030,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}