try{(()=>{var __$$app$$__=__$$hmAppManager$$__.currentApp;var __$$module$$__=__$$app$$__.current;var e=new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__,__$$module$$__),"lluvia");"use strict";
__$$module$$__.module=DeviceRuntimeCore.WatchFace({
init_view(){
const N=hmUI.show_level.ONLY_NORMAL, AOD=hmUI.show_level.ONLY_AOD, DT=hmUI.data_type, L=hmUI.align.LEFT;
const safe=(f)=>{try{f()}catch(err){console.log(err)}};
const img=(x,y,w,h,src,lv)=>safe(()=>hmUI.createWidget(hmUI.widget.IMG,{x:x,y:y,w:w,h:h,src:src,show_level:lv||N}));
img(0,0,390,450,"0069.png");
safe(()=>hmUI.createWidget(hmUI.widget.IMG_LEVEL,{x:284,y:26,image_array:["0064.png", "0065.png", "0066.png", "0067.png", "0068.png"],image_length:5,type:DT.BATTERY,show_level:N}));
safe(()=>hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:322,y:20,w:46,h:32,font_array:["0052.png", "0053.png", "0054.png", "0055.png", "0056.png", "0057.png", "0058.png", "0059.png", "0060.png", "0061.png"],h_space:0,align_h:L,type:DT.BATTERY,unit_sc:"0062.png",unit_tc:"0062.png",unit_en:"0062.png",show_level:N}));
img(184,340,22,100,"0021.png");
safe(()=>hmUI.createWidget(hmUI.widget.IMG_TIME,{
 hour_startX:52,hour_startY:340,hour_array:["0001.png", "0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png"],hour_zero:1,hour_space:0,hour_align:L,
 minute_startX:206,minute_startY:340,minute_array:["0001.png", "0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png"],minute_zero:1,minute_space:0,minute_align:L,show_level:N}));
// fecha centrada (se recalcula cada minuto)
(function(){
var WA=["0023.png", "0024.png", "0025.png", "0026.png", "0027.png", "0028.png", "0029.png"], WWD=[69, 56, 58, 56, 57, 52, 59], MA=["0030.png", "0031.png", "0032.png", "0033.png", "0034.png", "0035.png", "0036.png", "0037.png", "0038.png", "0039.png", "0040.png", "0041.png"], MWD=[49, 48, 52, 50, 57, 49, 40, 55, 52, 48, 53, 42], DN=["0042.png", "0043.png", "0044.png", "0045.png", "0046.png", "0047.png", "0048.png", "0049.png", "0050.png", "0051.png"], BLK="0071.png", Y=24, CXD=160, GAP=8, DA=17;
var wS=null, mS=null, dS=[], tm=null;
try{wS=hmUI.createWidget(hmUI.widget.IMG,{x:0,y:Y,w:40,h:40,src:BLK,show_level:N})}catch(err){console.log(err)}
try{mS=hmUI.createWidget(hmUI.widget.IMG,{x:0,y:Y,w:40,h:40,src:BLK,show_level:N})}catch(err){console.log(err)}
for(var i=0;i<2;i++){try{dS.push(hmUI.createWidget(hmUI.widget.IMG,{x:0,y:Y,w:DA+2,h:40,src:BLK,show_level:N}))}catch(err){console.log(err)}}
try{tm=hmSensor.createSensor(hmSensor.id.TIME)}catch(err){console.log(err)}
var set=function(w,o){try{w.setProperty(hmUI.prop.MORE,o)}catch(err){try{if(o.src)w.setProperty(hmUI.prop.SRC,o.src)}catch(e2){}}};
var up=function(){try{
 var d=new Date(), wd=d.getDay(), mo=d.getMonth(), dy=String(d.getDate()), n=dy.length;
 var tot=WWD[wd]+GAP+DA*n+2+GAP+MWD[mo], x0=Math.floor(CXD-tot/2), dx=x0+WWD[wd]+GAP, mx=dx+DA*n+GAP;
 set(wS,{x:x0,y:Y,w:WWD[wd],h:40,src:WA[wd]});
 for(var j=0;j<2;j++){ if(j<n){set(dS[j],{x:dx+DA*j-1,y:Y,w:DA+2,h:40,src:DN[+dy.charAt(j)]})}else{set(dS[j],{x:0,y:Y,w:DA+2,h:40,src:BLK})} }
 set(mS,{x:mx,y:Y,w:MWD[mo],h:40,src:MA[mo]});
}catch(err){console.log(err)}};
up();
try{tm.addEventListener(hmSensor.event.MINUTEEND,up)}catch(err){}
try{hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE,{resume_call:up})}catch(err){}
})();
img(0,0,390,450,"0063.png",AOD);
img(184,340,22,100,"0022.png",AOD);
safe(()=>hmUI.createWidget(hmUI.widget.IMG_TIME,{
 hour_startX:52,hour_startY:340,hour_array:["0011.png", "0012.png", "0013.png", "0014.png", "0015.png", "0016.png", "0017.png", "0018.png", "0019.png", "0020.png"],hour_zero:1,hour_space:0,hour_align:L,
 minute_startX:206,minute_startY:340,minute_array:["0011.png", "0012.png", "0013.png", "0014.png", "0015.png", "0016.png", "0017.png", "0018.png", "0019.png", "0020.png"],minute_zero:1,minute_space:0,minute_align:L,show_level:AOD}));
},
onInit(){this.init_view()},onReady(){},onShow(){},onHide(){},onDestroy(){}
})})()}catch(e){console.log(e)}
