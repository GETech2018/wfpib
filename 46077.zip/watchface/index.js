﻿    /*
    ** Watch_Face_Editor tool v 18.2
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let startPacmanGame = null;
let gameBackground = null;
let gameTimerVersion = 0;
        // end user_functions.js

        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: -13,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 332,
              y: 75,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 32,
              y: 75,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 307,
              font_array: ["Data36_0.png","Data36_1.png","Data36_2.png","Data36_3.png","Data36_4.png","Data36_5.png","Data36_6.png","Data36_7.png","Data36_8.png","Data36_9.png"],
              padding: false,
              h_space: -9,
              invalid_image: 'Temp_Error.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 191,
              // start_y: 359,
              // color: 0xFF3AD629,
              // lenght: 118,
              // line_width: 11,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 356,
              font_array: ["Data18_0.png","Data18_1.png","Data18_2.png","Data18_3.png","Data18_4.png","Data18_5.png","Data18_6.png","Data18_7.png","Data18_8.png","Data18_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 239,
              y: 236,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 250,
              font_array: ["Data36_0.png","Data36_1.png","Data36_2.png","Data36_3.png","Data36_4.png","Data36_5.png","Data36_6.png","Data36_7.png","Data36_8.png","Data36_9.png"],
              padding: false,
              h_space: -8,
              unit_sc: 'Temp_unit.png',
              unit_tc: 'Temp_unit.png',
              unit_en: 'Temp_unit.png',
              imperial_unit_sc: 'Temp_unit.png',
              imperial_unit_tc: 'Temp_unit.png',
              imperial_unit_en: 'Temp_unit.png',
              negative_image: 'Temp_minus.png',
              invalid_image: 'Temp_Error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 280,
                y: 250,
                font_array: ["Data36_0.png","Data36_1.png","Data36_2.png","Data36_3.png","Data36_4.png","Data36_5.png","Data36_6.png","Data36_7.png","Data36_8.png","Data36_9.png"],
                padding: false,
                h_space: -8,
                unit_sc: 'Temp_unit.png',
                unit_tc: 'Temp_unit.png',
                unit_en: 'Temp_unit.png',
                imperial_unit_sc: 'Temp_unit.png',
                imperial_unit_tc: 'Temp_unit.png',
                imperial_unit_en: 'Temp_unit.png',
                negative_image: 'Temp_minus.png',
                invalid_image: 'Temp_Error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 302,
              font_array: ["Data36_0.png","Data36_1.png","Data36_2.png","Data36_3.png","Data36_4.png","Data36_5.png","Data36_6.png","Data36_7.png","Data36_8.png","Data36_9.png"],
              padding: false,
              h_space: -9,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 243,
              font_array: ["Data36_0.png","Data36_1.png","Data36_2.png","Data36_3.png","Data36_4.png","Data36_5.png","Data36_6.png","Data36_7.png","Data36_8.png","Data36_9.png"],
              padding: false,
              h_space: -9,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 232,
              y: 195,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 160,
              day_startY: 195,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: -11,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 27,
              month_startY: 195,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 209,
              minute_startY: 107,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: -24,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 14,
              hour_startY: 107,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: -24,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 176,
              y: 105,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 209,
              minute_startY: 188,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: -24,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 14,
              hour_startY: 188,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: -24,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 176,
              y: 187,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

/*
    Pac-Man WatchFace for Zepp OS
    Space Invaders Style
    Resolution: 390x450
*/

// ฟังก์ชันนี้ต้องอยู่ใน scope เดียวกับปุ่มของ Watch Face
let startPacmanGame = null;

// อ่านประเภทหน้าจอ


// ถ้าไม่ใช่ Always On Display → ให้รันเกม
if (screenType != hmSetting.screen_type.AOD) {


// ==========================================
// SCREEN SETTINGS
// ==========================================

const SCREEN_W = 390;
const SCREEN_H = 450;

const GRID_SIZE = 15;
const CELL_SIZE = 20;

const OFFSET_X = Math.floor(
    (SCREEN_W - GRID_SIZE * CELL_SIZE) / 2
);

const OFFSET_Y = 55;


// ==========================================
// GAME MAP
// ==========================================

// 0 = ทางว่าง
// 1 = กำแพง
// 2 = เม็ดจุด
// 3 = เม็ดพลัง (Power Pellet)

const MAP_TEMPLATE = [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,3,2,2,1,2,2,2,2,2,1,2,2,3,1],
    [1,2,1,2,1,2,1,1,1,2,1,2,1,2,1],
    [1,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,2,1,2,1,2,1,1,2,1],
    [1,2,2,2,2,1,2,2,2,1,2,2,2,2,1],
    [1,1,1,1,2,1,1,0,1,1,2,1,1,1,1],
    [0,2,2,2,2,0,0,0,0,0,2,2,2,2,0],
    [1,1,1,1,2,1,1,1,1,1,2,1,1,1,1],
    [1,2,2,2,2,2,2,0,2,2,2,2,2,2,1],
    [1,2,1,1,2,1,1,2,1,1,2,1,1,2,1],
    [1,2,2,1,2,2,2,2,2,2,2,1,2,2,1],
    [1,1,2,1,2,1,1,1,1,1,2,1,2,1,1],
    [1,3,2,2,2,2,2,1,2,2,2,2,2,3,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
];


// ==========================================
// GHOST CONFIGURATION
// ==========================================

const GHOST_CONFIGS = [
    { x: 7, y: 7, color: 0xef4444 },
    { x: 6, y: 7, color: 0xf472b6 },
    { x: 8, y: 7, color: 0x38bdf8 }
];


// ==========================================
// GAME STATE
// ==========================================

let isGameMode = false;
let isRunning = false;
let isGameOver = false;

let gameTimer = null;

let mapData = [];
let totalDots = 0;

let score = 0;
let level = 1;
let lives = 3;

let powerTimerTicks = 0;

// Ghost movement counter
let ghostMoveCounter = 0;
const GHOST_MOVE_INTERVAL = 2;

// Ghost power appearance
let ghostPowerMode = false;

// Pac-Man rotation angle
// PCman.png default direction: RIGHT
let pacAngle = 0;

let pac = {
    x: 7,
    y: 9,
    dirX: 0,
    dirY: 0,
    nextDirX: 0,
    nextDirY: 0
};

let ghosts = [];


// ==========================================
// WIDGET REFERENCES
// ==========================================

let gameGroupWidgets = [];

let dotWidgets = [];

let pacWidget = null;
let ghostWidgets = [];

let gameHeaderText = null;
let gameStatusBanner = null;

let gameBackground = null;


// ==========================================
// HELPER FUNCTIONS
// ==========================================

function wrapX(x) {

    if (x < 0) return GRID_SIZE - 1;
    if (x >= GRID_SIZE) return 0;

    return x;
}


function canMoveTo(nx, ny) {

    if (ny === 7 && (nx < 0 || nx >= GRID_SIZE)) {
        return true;
    }

    if (
        nx < 0 ||
        nx >= GRID_SIZE ||
        ny < 0 ||
        ny >= GRID_SIZE
    ) {
        return false;
    }

    return mapData[ny][nx] !== 1;
}


// ==========================================
// UPDATE GHOST APPEARANCE
// ==========================================

function updateGhostAppearance() {

    const powered = powerTimerTicks > 0;

    if (powered === ghostPowerMode) return;

    ghostPowerMode = powered;

    ghostWidgets.forEach((gw, idx) => {

        if (!gw) return;

        gw.setProperty(
            hmUI.prop.MORE,
            {
                src: powered
                    ? 'GhostX.png'
                    : `Ghost${idx + 1}.png`
            }
        );
    });
}


// ==========================================
// RESET PLAYER AND GHOST POSITIONS
// ==========================================

function resetPositions() {

    pac.x = 7;
    pac.y = 9;

    pac.dirX = 0;
    pac.dirY = 0;

    pac.nextDirX = 0;
    pac.nextDirY = 0;

    pacAngle = 0;

    ghostMoveCounter = 0;

    ghosts = GHOST_CONFIGS.map((cfg, idx) => ({

        x: cfg.x,
        y: cfg.y,

        dirX: idx === 0 ? 0 : (idx === 1 ? 1 : -1),
        dirY: idx === 0 ? -1 : 0,

        baseColor: cfg.color

    }));

    syncEntitiesUI();
}


// ==========================================
// LOAD LEVEL
// ==========================================

function loadLevel(resetScoreAndLives) {

    if (resetScoreAndLives) {

        score = 0;
        level = 1;
        lives = 3;

        isGameOver = false;
    }

    powerTimerTicks = 0;
    updateGhostAppearance();

    totalDots = 0;

    mapData = MAP_TEMPLATE.map((row) => row.slice());

    for (let y = 0; y < GRID_SIZE; y++) {

        for (let x = 0; x < GRID_SIZE; x++) {

            const val = mapData[y][x];

            const w = dotWidgets[y] && dotWidgets[y][x];

            if (val === 2 || val === 3) {

                totalDots++;

                if (w) {
                    w.setProperty(hmUI.prop.VISIBLE, true);
                }

            } else if (w) {

                w.setProperty(hmUI.prop.VISIBLE, false);
            }
        }
    }

    resetPositions();

    updateHeaderUI();

    setBanner('');
}


// ==========================================
// GAME STATUS BANNER
// ==========================================

function setBanner(text) {

    if (!gameStatusBanner) return;

    if (!text) {

        gameStatusBanner.setProperty(
            hmUI.prop.VISIBLE,
            false
        );

    } else {

        gameStatusBanner.setProperty(
            hmUI.prop.TEXT,
            text
        );

        gameStatusBanner.setProperty(
            hmUI.prop.VISIBLE,
            true
        );
    }
}


// ==========================================
// UPDATE GAME HEADER
// ==========================================

function updateHeaderUI() {

    if (gameHeaderText) {

        const hearts = '♥'.repeat(Math.max(0, lives));

        gameHeaderText.setProperty(
            hmUI.prop.TEXT,
            `LV.${level}  ${score}  ${hearts}`
        );
    }
}


// ==========================================
// UPDATE PLAYER AND GHOST WIDGETS
// ==========================================

function syncEntitiesUI() {

    // Update Pac-Man position and rotation

    if (pacWidget) {

        pacWidget.setProperty(
            hmUI.prop.MORE,
            {
                x: OFFSET_X + pac.x * CELL_SIZE + 2,
                y: OFFSET_Y + pac.y * CELL_SIZE + 2,
                w: CELL_SIZE - 4,
                h: CELL_SIZE - 4,

                angle: pacAngle,

                center_x: (CELL_SIZE - 4) / 2,
                center_y: (CELL_SIZE - 4) / 2
            }
        );
    }

    // Update Ghost positions

    ghosts.forEach((g, idx) => {

        const gw = ghostWidgets[idx];

        if (!gw) return;

        gw.setProperty(
            hmUI.prop.MORE,
            {
                x: OFFSET_X + g.x * CELL_SIZE + 2,
                y: OFFSET_Y + g.y * CELL_SIZE + 2,
                w: CELL_SIZE - 4,
                h: CELL_SIZE - 4
            }
        );
    });
}


// ==========================================
// GHOST AI
// ORIGINAL AI - UNCHANGED
// ==========================================

function moveSingleGhost(g) {

    const dirs = [

        { dx: 0, dy: -1 },
        { dx: 0, dy: 1 },
        { dx: -1, dy: 0 },
        { dx: 1, dy: 0 }

    ];

    let validDirs = dirs.filter((d) => {

        if (
            d.dx === -g.dirX &&
            d.dy === -g.dirY
        ) {
            return false;
        }

        return canMoveTo(
            wrapX(g.x + d.dx),
            g.y + d.dy
        );
    });

    if (validDirs.length === 0) {

        validDirs = dirs.filter((d) => {

            return canMoveTo(
                wrapX(g.x + d.dx),
                g.y + d.dy
            );
        });
    }

    if (validDirs.length === 0) return;

    let chosen = validDirs[
        Math.floor(Math.random() * validDirs.length)
    ];

    if (
        validDirs.length > 1 &&
        Math.random() < 0.7
    ) {

        let bestScore = powerTimerTicks > 0
            ? -99999
            : 99999;

        validDirs.forEach((d) => {

            const nx = wrapX(g.x + d.dx);
            const ny = g.y + d.dy;

            const rawDistX = Math.abs(nx - pac.x);

            const distX = (
                ny === 7 && pac.y === 7
            )
                ? Math.min(rawDistX, GRID_SIZE - rawDistX)
                : rawDistX;

            const dist = distX + Math.abs(ny - pac.y);

            if (powerTimerTicks > 0) {

                if (dist > bestScore) {

                    bestScore = dist;
                    chosen = d;
                }

            } else {

                if (dist < bestScore) {

                    bestScore = dist;
                    chosen = d;
                }
            }
        });
    }

    g.dirX = chosen.dx;
    g.dirY = chosen.dy;

    g.x = wrapX(g.x + g.dirX);
    g.y = g.y + g.dirY;
}


// ==========================================
// COLLISION DETECTION
// ==========================================

function checkCollisions() {

    for (let i = 0; i < ghosts.length; i++) {

        const g = ghosts[i];

        if (
            g.x === pac.x &&
            g.y === pac.y
        ) {

            if (powerTimerTicks > 0) {

                score += 200;

                g.x = 7;
                g.y = 7;

                g.dirX = 0;
                g.dirY = -1;

                updateHeaderUI();

            } else {

                lives--;

                updateHeaderUI();

                stopGameLoop();

                if (lives <= 0) {

                    isGameOver = true;

                    setBanner('GAME OVER - TAP D-PAD');

                } else {

                    setBanner('OUCH! TAP D-PAD');

                    resetPositions();
                }

                return true;
            }
        }
    }

    return false;
}


// ==========================================
// MAIN GAME LOOP
// ==========================================

function stepGame() {

    if (
        !isRunning ||
        isGameOver ||
        !isGameMode
    ) {
        return;
    }

    // ตรวจสอบทิศทางใหม่

    const tryX = wrapX(
        pac.x + pac.nextDirX
    );

    const tryY = pac.y + pac.nextDirY;

    if (
        (pac.nextDirX !== 0 || pac.nextDirY !== 0) &&
        canMoveTo(tryX, tryY)
    ) {

        pac.dirX = pac.nextDirX;
        pac.dirY = pac.nextDirY;
    }

    // เคลื่อนที่ Pac-Man

    const nextX = wrapX(
        pac.x + pac.dirX
    );

    const nextY = pac.y + pac.dirY;

    if (canMoveTo(nextX, nextY)) {

        // Change rotation only when Pac-Man moves

        if (pac.dirX === 1) {
            pacAngle = 0;
        } else if (pac.dirY === 1) {
            pacAngle = 90;
        } else if (pac.dirX === -1) {
            pacAngle = 180;
        } else if (pac.dirY === -1) {
            pacAngle = 270;
        }

        pac.x = nextX;
        pac.y = nextY;

        const cell = mapData[pac.y][pac.x];

        if (cell === 2 || cell === 3) {

            mapData[pac.y][pac.x] = 0;

            totalDots--;

            if (
                dotWidgets[pac.y] &&
                dotWidgets[pac.y][pac.x]
            ) {

                dotWidgets[pac.y][pac.x].setProperty(
                    hmUI.prop.VISIBLE,
                    false
                );
            }

            if (cell === 3) {

                score += 50;

                powerTimerTicks = 32;

                updateGhostAppearance();

            } else {

                score += 10;
            }

            updateHeaderUI();

            // เปลี่ยน Level

            if (totalDots <= 0) {

                level++;

                stopGameLoop();

                loadLevel(false);

                setBanner(
                    `LEVEL ${level}! TAP D-PAD`
                );

                return;
            }
        }

    } else {

        pac.dirX = 0;
        pac.dirY = 0;
    }

    // ตรวจสอบการชนก่อนผีเคลื่อนที่

    if (checkCollisions()) {

        syncEntitiesUI();

        return;
    }

    // ======================================
    // GHOST MOVEMENT - SEPARATE COUNTER
    // ======================================

    ghostMoveCounter++;

    const shouldMoveGhosts = powerTimerTicks > 0
        ? (
            ghostMoveCounter %
            (GHOST_MOVE_INTERVAL * 2) === 0
        )
        : (
            ghostMoveCounter %
            GHOST_MOVE_INTERVAL === 0
        );

    if (shouldMoveGhosts) {

        ghosts.forEach((g) => {
            moveSingleGhost(g);
        });
    }

    // ลดเวลาพลังพิเศษ

    if (powerTimerTicks > 0) {
        powerTimerTicks--;
    }

    // Restore original Ghost images when power ends

    updateGhostAppearance();

    // ตรวจสอบการชนหลังผีเคลื่อนที่

    if (checkCollisions()) {

        syncEntitiesUI();

        return;
    }

    syncEntitiesUI();
}


// ==========================================
// START GAME LOOP
// ==========================================

function startGameLoop() {

    if (isRunning || !isGameMode) return;

    if (isGameOver) {
        loadLevel(true);
    }

    setBanner('');

    isRunning = true;

    if (gameTimer) {
        timer.stopTimer(gameTimer);
        gameTimer = null;
    }

    const myVersion = ++gameTimerVersion;

    const interval = Math.max(
        250,
        400 - (level - 1) * 20
    );

    gameTimer = timer.createTimer(
        0,
        interval,
        () => {

            if (myVersion !== gameTimerVersion) {
                return;
            }

            stepGame();
        }
    );
}


// ==========================================
// STOP GAME LOOP
// ==========================================

function stopGameLoop() {

    isRunning = false;

    // ยกเลิกสิทธิ์ของ callback เก่า
    gameTimerVersion++;

    if (gameTimer) {
        timer.stopTimer(gameTimer);
        gameTimer = null;
    }
}


// ==========================================
// PLAYER DIRECTION
// ==========================================

function setDirection(dx, dy) {

    if (!isGameMode) return;

    pac.nextDirX = dx;
    pac.nextDirY = dy;

    if (!isRunning) {

        startGameLoop();
    }
}


// ==========================================
// SWITCH WATCH MODE / GAME MODE
// ==========================================

function setWatchMode(enableGame) {

    isGameMode = enableGame;

    if (!enableGame) {

        stopGameLoop();
    }

    // แสดง / ซ่อน Widget ของเกมทั้งหมด

    gameGroupWidgets.forEach((w) => {

        w.setProperty(
            hmUI.prop.VISIBLE,
            enableGame
        );
    });

    if (enableGame) {

        for (let y = 0; y < GRID_SIZE; y++) {

            for (let x = 0; x < GRID_SIZE; x++) {

                const w = dotWidgets[y] && dotWidgets[y][x];

                if (w) {

                    const hasDot =
                        mapData[y][x] === 2 ||
                        mapData[y][x] === 3;

                    w.setProperty(
                        hmUI.prop.VISIBLE,
                        hasDot
                    );
                }
            }
        }

        syncEntitiesUI();

        updateHeaderUI();

        if (!isRunning && !isGameOver) {

            setBanner('TAP D-PAD TO PLAY');
        }
    }
}


// ==========================================
// EXIT GAME
// ==========================================

function exitPacmanGame() {
  Button_1.setProperty(hmUI.prop.VISIBLE, true);
  Button_2.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);


    setWatchMode(false);
}


// ==========================================
// BUILD GAME UI
// ==========================================

function buildUI() {

    // ======================================
    // GAME BACKGROUND
    // ======================================

    gameBackground = hmUI.createWidget(
        hmUI.widget.FILL_RECT,
        {
            x: 0,
            y: 0,

            w: SCREEN_W,
            h: SCREEN_H,

            color: 0x000000
        }
    );

    gameGroupWidgets.push(gameBackground);


    // ======================================
    // GAME HEADER
    // ======================================

    gameHeaderText = hmUI.createWidget(hmUI.widget.TEXT, {

        x: 60,
        y: 12,

        w: SCREEN_W - 184,
        h: 32,

        color: 0xfde047,

        text_size: 20,

        align_h: hmUI.align.CENTER_H,

        text: 'LV.1  0  ♥♥♥'
    });

    gameGroupWidgets.push(gameHeaderText);


    // ======================================
    // CREATE MAP WIDGETS
    // ======================================

    dotWidgets = [];

    for (let y = 0; y < GRID_SIZE; y++) {

        dotWidgets[y] = [];

        for (let x = 0; x < GRID_SIZE; x++) {

            const cell = MAP_TEMPLATE[y][x];

            const px = OFFSET_X + x * CELL_SIZE;
            const py = OFFSET_Y + y * CELL_SIZE;

            // WALL

            if (cell === 1) {

                const wall = hmUI.createWidget(
                    hmUI.widget.FILL_RECT,
                    {

                        x: px,
                        y: py,

                        w: CELL_SIZE,
                        h: CELL_SIZE,

                        color: 0x1d4ed8
                    }
                );

                gameGroupWidgets.push(wall);
            }

            // DOT / POWER PELLET

            else if (cell === 2 || cell === 3) {

                const isPower = cell === 3;

                const size = isPower ? 10 : 4;

                const offset = Math.floor(
                    (CELL_SIZE - size) / 2
                );

                const dot = hmUI.createWidget(
                    hmUI.widget.FILL_RECT,
                    {

                        x: px + offset,
                        y: py + offset,

                        w: size,
                        h: size,

                        color: isPower
                            ? 0xfb923c
                            : 0xfef08a
                    }
                );

                dotWidgets[y][x] = dot;

                gameGroupWidgets.push(dot);
            }
        }
    }


    // ======================================
    // PAC-MAN IMAGE WIDGET
    // ======================================

    pacWidget = hmUI.createWidget(
        hmUI.widget.IMG,
        {

            x: OFFSET_X + 7 * CELL_SIZE + 2,
            y: OFFSET_Y + 9 * CELL_SIZE + 2,

            w: CELL_SIZE - 4,
            h: CELL_SIZE - 4,

            src: 'PCman.png',

            angle: pacAngle,

            center_x: (CELL_SIZE - 4) / 2,
            center_y: (CELL_SIZE - 4) / 2
        }
    );

    gameGroupWidgets.push(pacWidget);


    // ======================================
    // GHOST IMAGE WIDGETS
    // ======================================

    ghostWidgets = GHOST_CONFIGS.map((cfg, idx) => {

        const gw = hmUI.createWidget(
            hmUI.widget.IMG,
            {

                x: OFFSET_X + cfg.x * CELL_SIZE + 2,
                y: OFFSET_Y + cfg.y * CELL_SIZE + 2,

                w: CELL_SIZE - 4,
                h: CELL_SIZE - 4,

                src: `Ghost${idx + 1}.png`
            }
        );

        gameGroupWidgets.push(gw);

        return gw;
    });


    // ======================================
    // GAME STATUS BANNER
    // ======================================

    gameStatusBanner = hmUI.createWidget(
        hmUI.widget.TEXT,
        {

            x: 40,

            y: OFFSET_Y +
                Math.floor((GRID_SIZE * CELL_SIZE) / 2) - 16,

            w: SCREEN_W - 80,
            h: 32,

            color: 0xffffff,

            text_size: 20,

            align_h: hmUI.align.CENTER_H,

            text: ''
        }
    );

    gameGroupWidgets.push(gameStatusBanner);


    // ======================================
    // EXIT BUTTON
    // ======================================

    const exitBtn = hmUI.createWidget(
        hmUI.widget.BUTTON,
        {

            x: 42,
            y: 406,

            w: 76,
            h: 44,

            radius: 12,

            text: 'EXIT',

            normal_color: 0x1f2937,
            press_color: 0x374151,

            color: 0x9ca3af,

            text_size: 15,

            click_func: () => {

                exitPacmanGame();
            }
        }
    );

    gameGroupWidgets.push(exitBtn);


    // ======================================
    // RESET BUTTON
    // ======================================

    const resetBtn = hmUI.createWidget(
        hmUI.widget.BUTTON,
        {

            x: SCREEN_W - 108,
            y: 6,

            w: 76,
            h: 44,

            radius: 12,

            text: 'RESET',

            normal_color: 0x1f2937,
            press_color: 0x374151,

            color: 0xf87171,

            text_size: 15,

            click_func: () => {

                stopGameLoop();

                loadLevel(true);

                setBanner('TAP D-PAD TO PLAY');
            }
        }
    );

    gameGroupWidgets.push(resetBtn);


    // ======================================
    // D-PAD BUTTONS
    // ======================================

    const dpadConfigs = [

        {
            label: '◀',
            dx: -1,
            dy: 0,
            x: 141,
            y: 360
        },

        {
            label: '▲',
            dx: 0,
            dy: -1,
            x: 209,
            y: 360
        },

        {
            label: '▼',
            dx: 0,
            dy: 1,
            x: 209,
            y: 410
        },

        {
            label: '▶',
            dx: 1,
            dy: 0,
            x: 276,
            y: 360
        }

    ];

    dpadConfigs.forEach((btn) => {

        const ctrlBtn = hmUI.createWidget(
            hmUI.widget.BUTTON,
            {

                x: btn.x,
                y: btn.y,

                w: 50,
                h: 46,

                radius: 12,

                text: btn.label,

                normal_color: 0x262626,
                press_color: 0xfacc15,

                color: 0xffffff,

                text_size: 20,

                click_func: () => {

                    setDirection(
                        btn.dx,
                        btn.dy
                    );
                }
            }
        );

        gameGroupWidgets.push(ctrlBtn);
    });


    // ======================================
    // INITIAL GAME STATE
    // ======================================

    loadLevel(true);

    setWatchMode(false);
}


// ==========================================
// PUBLIC START FUNCTION
// ==========================================

// ให้ปุ่ม Watch Face เรียก startPacmanGame()

startPacmanGame = function() {

    setWatchMode(true);
};


// ==========================================
// INITIALIZE
// ==========================================

buildUI();


} // END SCREEN TYPE CHECK
            // end user_script_beforeShortcuts.js
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 21,
              y: 242,
              w: 207,
              h: 39,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 23,
              y: 290,
              w: 203,
              h: 44,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 242,
              y: 304,
              w: 119,
              h: 36,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 118,
              y: 354,
              w: 241,
              h: 30,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 245,
              y: 242,
              w: 51,
              h: 50,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 241,
              w: 56,
              h: 49,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 258,
              y: 108,
              w: 80,
              h: 69,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 62,
              y: 111,
              w: 62,
              h: 64,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 14,
              y: 55,
              w: 53,
              h: 51,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 10,
              y: 357,
              w: 59,
              h: 21,
              text: 'START',
              color: 0xFFFFFFFF,
              text_size: 14,
              radius: 11,
              press_color: 0xFFA0A0A0,
              normal_color: 0xFF696969,
              click_func: (button_widget) => {
                Button_1.setProperty(hmUI.prop.VISIBLE, false);
                  Button_2.setProperty(hmUI.prop.VISIBLE, false);
                        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                        normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                        normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                        normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                startPacmanGame()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 366,
              y: 74,
              w: 25,
              h: 95,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 14,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                Applications  : hmApp.startApp({url: 'AppListScreen', native: true }); 
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 366,
              y: 278,
              w: 25,
              h: 95,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 14,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                Workout       : hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 27,
              y: 193,
              w: 347,
              h: 39,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 14,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 191;
                  let start_y_normal_battery = 359;
                  let lenght_ls_normal_battery = 118;
                  let line_width_ls_normal_battery = 11;
                  let color_ls_normal_battery = 0xFF3AD629;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}