﻿    /*
    ** Watch_Face_Editor tool v 17.2
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

        // Start ALL color

        let colornumber_mainALL = 1
        let totalcolors_mainALL = 7
        let namecolor_mainALL = ''
        let FolderA = ''

        function click_All_Color() {
            if(colornumber_mainALL>=totalcolors_mainALL) {
            colornumber_mainALL=1;
                }
            else {
                colornumber_mainALL=colornumber_mainALL+1;
            }

if ( colornumber_mainALL == 1) { 
namecolor_mainALL = "White"
FolderA =''
}
if ( colornumber_mainALL == 2) { 
namecolor_mainALL = "Blue"
FolderA = "Blue/"
}
if ( colornumber_mainALL == 3) { 
namecolor_mainALL = "Green"
FolderA = "Green/"
}
if ( colornumber_mainALL == 4) {
 namecolor_mainALL = "Lemon"
FolderA = "Lemon/"
}
if ( colornumber_mainALL == 5) { 
namecolor_mainALL = "Orange"
FolderA = "Orange/"
}
if ( colornumber_mainALL == 6) {
 namecolor_mainALL = "Red"
FolderA = "Red/"
}
if ( colornumber_mainALL == 7) {
 namecolor_mainALL = "Yellow"
FolderA = "Yellow/"
}

hmUI.showToast({text: namecolor_mainALL });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 251,
              hour_startY: 78,
              hour_array: [FolderA+"Time_0.png",FolderA+"Time_1.png",FolderA+"Time_2.png",FolderA+"Time_3.png",FolderA+"Time_4.png",FolderA+"Time_5.png",FolderA+"Time_6.png",FolderA+"Time_7.png",FolderA+"Time_8.png",FolderA+"Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

         normal_heart_rate_icon_img.setProperty(hmUI.prop.SRC, "Bg_Pulse_" + parseInt(colornumber_mainALL) + ".png");
         normal_battery_icon_img.setProperty(hmUI.prop.SRC, "Bg_Power_" + parseInt(colornumber_mainALL) + ".png");



        }

/////////////////////////////////////////////////////////////////////////////////////////////////


        // Start Hour color

        let colornumber_main = 1
        let totalcolors_main = 7
        let namecolor_main = ''
        let Folder = ''

        function click_Hour_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

if ( colornumber_main == 1) { 
namecolor_main = "White"
Folder =''
}
if ( colornumber_main == 2) { 
namecolor_main = "Blue"
Folder = "Blue/"
}
if ( colornumber_main == 3) { 
namecolor_main = "Green"
Folder = "Green/"
}
if ( colornumber_main == 4) {
 namecolor_main = "Lemon"
Folder = "Lemon/"
}
if ( colornumber_main == 5) { 
namecolor_main = "Orange"
Folder = "Orange/"
}
if ( colornumber_main == 6) {
 namecolor_main = "Red"
Folder = "Red/"
}
if ( colornumber_main == 7) {
 namecolor_main = "Yellow"
Folder = "Yellow/"
}

hmUI.showToast({text: namecolor_main });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 251,
              hour_startY: 78,
              hour_array: [Folder+"Time_0.png",Folder+"Time_1.png",Folder+"Time_2.png",Folder+"Time_3.png",Folder+"Time_4.png",Folder+"Time_5.png",Folder+"Time_6.png",Folder+"Time_7.png",Folder+"Time_8.png",Folder+"Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        }

/////////////////////////////////////////////////////////////////////////////////////////////////
        // Start Power color

        let colornumber_main2 = 1
        let totalcolors_main2 = 8
        let namecolor_main2 = ''
   
        function click_Power_Color() {
            if(colornumber_main2>=totalcolors_main2) {
            colornumber_main2=1;
                }
            else {
                colornumber_main2=colornumber_main2+1;
            }

if ( colornumber_main2 == 1) { 
namecolor_main2 = "White"
}
if ( colornumber_main2 == 2) { 
namecolor_main2 = "Blue"
}
if ( colornumber_main2 == 3) { 
namecolor_main2 = "Green"
}
if ( colornumber_main2 == 4) {
 namecolor_main2 = "Lemon"
}
if ( colornumber_main2 == 5) { 
namecolor_main2 = "Orange"
}
if ( colornumber_main2 == 6) {
 namecolor_main2 = "Red"
}
if ( colornumber_main2 == 7) {
 namecolor_main2 = "Yellow"
}

if ( colornumber_main2 == 8) {
 namecolor_main2 = "Multi Color"
}
hmUI.showToast({text: namecolor_main2 });

         normal_battery_icon_img.setProperty(hmUI.prop.SRC, "Bg_Power_" + parseInt(colornumber_main2) + ".png");
        }

/////////////////////////////////////////////////////////////////////////////////////////////////
        // Start Heart color

        let colornumber_main3 = 1
        let totalcolors_main3 = 7
        let namecolor_main3 = ''
   
        function click_Heart_Color() {
            if(colornumber_main3>=totalcolors_main3) {
            colornumber_main3=1;
                }
            else {
                colornumber_main3=colornumber_main3+1;
            }

if ( colornumber_main3 == 1) { 
namecolor_main3 = "White"
}
if ( colornumber_main3 == 2) { 
namecolor_main3 = "Blue"
}
if ( colornumber_main3 == 3) { 
namecolor_main3 = "Green"
}
if ( colornumber_main3 == 4) {
 namecolor_main3 = "Lemon"
}
if ( colornumber_main3 == 5) { 
namecolor_main3 = "Orange"
}
if ( colornumber_main3 == 6) {
 namecolor_main3 = "Red"
}
if ( colornumber_main3 == 7) {
 namecolor_main3 = "Yellow"
}

hmUI.showToast({text: namecolor_main3 });
         normal_heart_rate_icon_img.setProperty(hmUI.prop.SRC, "Bg_Pulse_" + parseInt(colornumber_main3) + ".png");
        }

/////////////////////////////////////////////////////////////////////////////////////////////////
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_sun_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_background = ''
        let normal_forecast_average_text_img = new Array(3);
        let normal_forecast_image_progress_img_level = new Array(3);
        let normal_forecast_image_array = ['Weather_small_01.png', 'Weather_small_02.png', 'Weather_small_03.png', 'Weather_small_04.png', 'Weather_small_05.png', 'Weather_small_06.png', 'Weather_small_07.png', 'Weather_small_08.png', 'Weather_small_09.png', 'Weather_small_10.png', 'Weather_small_11.png', 'Weather_small_12.png', 'Weather_small_13.png', 'Weather_small_14.png', 'Weather_small_15.png', 'Weather_small_16.png', 'Weather_small_17.png', 'Weather_small_18.png', 'Weather_small_19.png', 'Weather_small_20.png', 'Weather_small_21.png', 'Weather_small_22.png', 'Weather_small_23.png', 'Weather_small_24.png', 'Weather_small_25.png', 'Weather_small_26.png', 'Weather_small_27.png', 'Weather_small_28.png', 'Weather_small_29.png'];
        let normal_forecast_date_week_img = new Array(3);
        let normal_forecast_date_week_img_array = ['WeekF_1.png', 'WeekF_2.png', 'WeekF_3.png', 'WeekF_4.png', 'WeekF_5.png', 'WeekF_6.png', 'WeekF_7.png'];
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_city_name_text = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_sun_current_text_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_battery_icon_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_group_ForecastWeather = ''
        let idle_forecast_background = ''
        let idle_forecast_average_text_img = new Array(3);
        let idle_forecast_image_progress_img_level = new Array(3);
        let idle_forecast_image_array = ['Weather_small_01.png', 'Weather_small_02.png', 'Weather_small_03.png', 'Weather_small_04.png', 'Weather_small_05.png', 'Weather_small_06.png', 'Weather_small_07.png', 'Weather_small_08.png', 'Weather_small_09.png', 'Weather_small_10.png', 'Weather_small_11.png', 'Weather_small_12.png', 'Weather_small_13.png', 'Weather_small_14.png', 'Weather_small_15.png', 'Weather_small_16.png', 'Weather_small_17.png', 'Weather_small_18.png', 'Weather_small_19.png', 'Weather_small_20.png', 'Weather_small_21.png', 'Weather_small_22.png', 'Weather_small_23.png', 'Weather_small_24.png', 'Weather_small_25.png', 'Weather_small_26.png', 'Weather_small_27.png', 'Weather_small_28.png', 'Weather_small_29.png'];
        let idle_forecast_date_week_img = new Array(3);
        let idle_forecast_date_week_img_array = ['WeekF_1.png', 'WeekF_2.png', 'WeekF_3.png', 'WeekF_4.png', 'WeekF_5.png', 'WeekF_6.png', 'WeekF_7.png'];
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 307,
              y: 263,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 258,
              y: 265,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 377,
              day_startY: 379,
              day_sc_array: ["WeatherF_0.png","WeatherF_1.png","WeatherF_2.png","WeatherF_3.png","WeatherF_4.png","WeatherF_5.png","WeatherF_6.png","WeatherF_7.png","WeatherF_8.png","WeatherF_9.png"],
              day_tc_array: ["WeatherF_0.png","WeatherF_1.png","WeatherF_2.png","WeatherF_3.png","WeatherF_4.png","WeatherF_5.png","WeatherF_6.png","WeatherF_7.png","WeatherF_8.png","WeatherF_9.png"],
              day_en_array: ["WeatherF_0.png","WeatherF_1.png","WeatherF_2.png","WeatherF_3.png","WeatherF_4.png","WeatherF_5.png","WeatherF_6.png","WeatherF_7.png","WeatherF_8.png","WeatherF_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 277,
              y: 378,
              week_en: ["WeekD_1.png","WeekD_2.png","WeekD_3.png","WeekD_4.png","WeekD_5.png","WeekD_6.png","WeekD_7.png"],
              week_tc: ["WeekD_1.png","WeekD_2.png","WeekD_3.png","WeekD_4.png","WeekD_5.png","WeekD_6.png","WeekD_7.png"],
              week_sc: ["WeekD_1.png","WeekD_2.png","WeekD_3.png","WeekD_4.png","WeekD_5.png","WeekD_6.png","WeekD_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 101,
              y: 469,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 20,
              y: 367,
              w: 120,
              h: 39,
              text_size: 25,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 153,
              y: 367,
              image_array: ["Weather_small_01.png","Weather_small_02.png","Weather_small_03.png","Weather_small_04.png","Weather_small_05.png","Weather_small_06.png","Weather_small_07.png","Weather_small_08.png","Weather_small_09.png","Weather_small_10.png","Weather_small_11.png","Weather_small_12.png","Weather_small_13.png","Weather_small_14.png","Weather_small_15.png","Weather_small_16.png","Weather_small_17.png","Weather_small_18.png","Weather_small_19.png","Weather_small_20.png","Weather_small_21.png","Weather_small_22.png","Weather_small_23.png","Weather_small_24.png","Weather_small_25.png","Weather_small_26.png","Weather_small_27.png","Weather_small_28.png","Weather_small_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 378,
              font_array: ["WeatherF_0.png","WeatherF_1.png","WeatherF_2.png","WeatherF_3.png","WeatherF_4.png","WeatherF_5.png","WeatherF_6.png","WeatherF_7.png","WeatherF_8.png","WeatherF_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_F_unit.png',
              unit_tc: 'Weather_F_unit.png',
              unit_en: 'Weather_F_unit.png',
              imperial_unit_sc: 'Weather_F_unit.png',
              imperial_unit_tc: 'Weather_F_unit.png',
              imperial_unit_en: 'Weather_F_unit.png',
              negative_image: 'Weather_F_Error.png',
              invalid_image: 'Weather_F_Error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 189,
                y: 378,
                font_array: ["WeatherF_0.png","WeatherF_1.png","WeatherF_2.png","WeatherF_3.png","WeatherF_4.png","WeatherF_5.png","WeatherF_6.png","WeatherF_7.png","WeatherF_8.png","WeatherF_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Weather_F_unit.png',
                unit_tc: 'Weather_F_unit.png',
                unit_en: 'Weather_F_unit.png',
                imperial_unit_sc: 'Weather_F_unit.png',
                imperial_unit_tc: 'Weather_F_unit.png',
                imperial_unit_en: 'Weather_F_unit.png',
                negative_image: 'Weather_F_Error.png',
                invalid_image: 'Weather_F_Error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 428,
              font_array: ["WeatherF_0.png","WeatherF_1.png","WeatherF_2.png","WeatherF_3.png","WeatherF_4.png","WeatherF_5.png","WeatherF_6.png","WeatherF_7.png","WeatherF_8.png","WeatherF_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'SS_Dot.png',
              dot_image: 'SS_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 178,
              y: 417,
              src: 'Bg_Pulse_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 289,
              y: 427,
              font_array: ["Pulse_0.png","Pulse_1.png","Pulse_2.png","Pulse_3.png","Pulse_4.png","Pulse_5.png","Pulse_6.png","Pulse_7.png","Pulse_8.png","Pulse_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 245,
              y: 427,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 334,
              src: 'Bg_Power_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_battery_linear_scale.setAlpha(200);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 79,
              // start_y: 332,
              // color: 0xFF111211,
              // lenght: 322,
              // line_width: 16,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 200,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 9,
              y: 333,
              font_array: ["Dis_Count_0.png","Dis_Count_1.png","Dis_Count_2.png","Dis_Count_3.png","Dis_Count_4.png","Dis_Count_5.png","Dis_Count_6.png","Dis_Count_7.png","Dis_Count_8.png","Dis_Count_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 7,
              // y: 160,
              // ColumnWidth: 76,
              // DaysCount: 3,
              // Background: '0_Empty.png',
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 7,
              y: 160,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              normal_forecast_background = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                src: '0_Empty.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion
            // normal_forecast_average_text_img = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG_Options, {
              // x: -15,
              // y: 112,
              // font_array: ["Step_Count_0.png","Step_Count_1.png","Step_Count_2.png","Step_Count_3.png","Step_Count_4.png","Step_Count_5.png","Step_Count_6.png","Step_Count_7.png","Step_Count_8.png","Step_Count_9.png"],
              // padding: false,
              // h_space: -1,
              // unit_en: 'Weather_F_unit.png',
              // imperial_unit_en: 'Weather_F_unit.png',
              // negative_image: 'Weather_F_Error.png',
              // invalid_image: 'Weather_F_Error.png',
              // dot_image: 'Weather_F_Error.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.forecast_average_text_img,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_average_text_img[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG, {
                  x: -15 + i*76,
                  y: 112,
                  font_array: ["Step_Count_0.png","Step_Count_1.png","Step_Count_2.png","Step_Count_3.png","Step_Count_4.png","Step_Count_5.png","Step_Count_6.png","Step_Count_7.png","Step_Count_8.png","Step_Count_9.png"],
                  padding: false,
                  h_space: -1,
                  unit_sc: 'Weather_F_unit.png',
                  unit_tc: 'Weather_F_unit.png',
                  unit_en: 'Weather_F_unit.png',
                  negative_image: 'Weather_F_Error.png',
                  align_h: hmUI.align.CENTER_H,
                  // type: hmUI.data_type.FORECAST_NUMBER_MAX,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 21,
              // y: 62,
              // image_array: ["Weather_small_01.png","Weather_small_02.png","Weather_small_03.png","Weather_small_04.png","Weather_small_05.png","Weather_small_06.png","Weather_small_07.png","Weather_small_08.png","Weather_small_09.png","Weather_small_10.png","Weather_small_11.png","Weather_small_12.png","Weather_small_13.png","Weather_small_14.png","Weather_small_15.png","Weather_small_16.png","Weather_small_17.png","Weather_small_18.png","Weather_small_19.png","Weather_small_20.png","Weather_small_21.png","Weather_small_22.png","Weather_small_23.png","Weather_small_24.png","Weather_small_25.png","Weather_small_26.png","Weather_small_27.png","Weather_small_28.png","Weather_small_29.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 21 + i*76,
                  y: 62,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            // normal_forecast_date_week_img = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 4,
              // y: 34,
              // image_array: ["WeekF_1.png","WeekF_2.png","WeekF_3.png","WeekF_4.png","WeekF_5.png","WeekF_6.png","WeekF_7.png"],
              // image_length: 7,
              // type: hmUI.data_type.forecast_date_week_img,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_date_week_img[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 4 + i*76,
                  y: 34,
                  src: normal_forecast_date_week_img_array[0],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 94,
              font_array: ["Step_Count_0.png","Step_Count_1.png","Step_Count_2.png","Step_Count_3.png","Step_Count_4.png","Step_Count_5.png","Step_Count_6.png","Step_Count_7.png","Step_Count_8.png","Step_Count_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 14,
              y: 131,
              image_array: ["StepP_01.png","StepP_02.png","StepP_03.png","StepP_04.png","StepP_05.png","StepP_06.png","StepP_07.png","StepP_08.png","StepP_09.png","StepP_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 55,
              font_array: ["Dis_Count_0.png","Dis_Count_1.png","Dis_Count_2.png","Dis_Count_3.png","Dis_Count_4.png","Dis_Count_5.png","Dis_Count_6.png","Dis_Count_7.png","Dis_Count_8.png","Dis_Count_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Dis_Km.png',
              unit_tc: 'Dis_Km.png',
              unit_en: 'Dis_Km.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 33,
              font_array: ["Step_Count_0.png","Step_Count_1.png","Step_Count_2.png","Step_Count_3.png","Step_Count_4.png","Step_Count_5.png","Step_Count_6.png","Step_Count_7.png","Step_Count_8.png","Step_Count_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 198,
              am_y: 43,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 198,
              pm_y: 43,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 348,
              second_startY: 271,
              second_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 253,
              minute_startY: 184,
              minute_array: ["TimeM_0.png","TimeM_1.png","TimeM_2.png","TimeM_3.png","TimeM_4.png","TimeM_5.png","TimeM_6.png","TimeM_7.png","TimeM_8.png","TimeM_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 251,
              hour_startY: 78,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 432,
              h: 514,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 307,
              y: 263,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 258,
              y: 265,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 377,
              day_startY: 379,
              day_sc_array: ["WeatherF_0.png","WeatherF_1.png","WeatherF_2.png","WeatherF_3.png","WeatherF_4.png","WeatherF_5.png","WeatherF_6.png","WeatherF_7.png","WeatherF_8.png","WeatherF_9.png"],
              day_tc_array: ["WeatherF_0.png","WeatherF_1.png","WeatherF_2.png","WeatherF_3.png","WeatherF_4.png","WeatherF_5.png","WeatherF_6.png","WeatherF_7.png","WeatherF_8.png","WeatherF_9.png"],
              day_en_array: ["WeatherF_0.png","WeatherF_1.png","WeatherF_2.png","WeatherF_3.png","WeatherF_4.png","WeatherF_5.png","WeatherF_6.png","WeatherF_7.png","WeatherF_8.png","WeatherF_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 277,
              y: 378,
              week_en: ["WeekD_1.png","WeekD_2.png","WeekD_3.png","WeekD_4.png","WeekD_5.png","WeekD_6.png","WeekD_7.png"],
              week_tc: ["WeekD_1.png","WeekD_2.png","WeekD_3.png","WeekD_4.png","WeekD_5.png","WeekD_6.png","WeekD_7.png"],
              week_sc: ["WeekD_1.png","WeekD_2.png","WeekD_3.png","WeekD_4.png","WeekD_5.png","WeekD_6.png","WeekD_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 101,
              y: 469,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 20,
              y: 367,
              w: 120,
              h: 39,
              text_size: 25,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 153,
              y: 367,
              image_array: ["Weather_small_01.png","Weather_small_02.png","Weather_small_03.png","Weather_small_04.png","Weather_small_05.png","Weather_small_06.png","Weather_small_07.png","Weather_small_08.png","Weather_small_09.png","Weather_small_10.png","Weather_small_11.png","Weather_small_12.png","Weather_small_13.png","Weather_small_14.png","Weather_small_15.png","Weather_small_16.png","Weather_small_17.png","Weather_small_18.png","Weather_small_19.png","Weather_small_20.png","Weather_small_21.png","Weather_small_22.png","Weather_small_23.png","Weather_small_24.png","Weather_small_25.png","Weather_small_26.png","Weather_small_27.png","Weather_small_28.png","Weather_small_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 378,
              font_array: ["WeatherF_0.png","WeatherF_1.png","WeatherF_2.png","WeatherF_3.png","WeatherF_4.png","WeatherF_5.png","WeatherF_6.png","WeatherF_7.png","WeatherF_8.png","WeatherF_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_F_unit.png',
              unit_tc: 'Weather_F_unit.png',
              unit_en: 'Weather_F_unit.png',
              imperial_unit_sc: 'Weather_F_unit.png',
              imperial_unit_tc: 'Weather_F_unit.png',
              imperial_unit_en: 'Weather_F_unit.png',
              negative_image: 'Weather_F_Error.png',
              invalid_image: 'Weather_F_Error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 189,
                y: 378,
                font_array: ["WeatherF_0.png","WeatherF_1.png","WeatherF_2.png","WeatherF_3.png","WeatherF_4.png","WeatherF_5.png","WeatherF_6.png","WeatherF_7.png","WeatherF_8.png","WeatherF_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Weather_F_unit.png',
                unit_tc: 'Weather_F_unit.png',
                unit_en: 'Weather_F_unit.png',
                imperial_unit_sc: 'Weather_F_unit.png',
                imperial_unit_tc: 'Weather_F_unit.png',
                imperial_unit_en: 'Weather_F_unit.png',
                negative_image: 'Weather_F_Error.png',
                invalid_image: 'Weather_F_Error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 428,
              font_array: ["WeatherF_0.png","WeatherF_1.png","WeatherF_2.png","WeatherF_3.png","WeatherF_4.png","WeatherF_5.png","WeatherF_6.png","WeatherF_7.png","WeatherF_8.png","WeatherF_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'SS_Dot.png',
              dot_image: 'SS_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 178,
              y: 417,
              src: 'Bg_Pulse_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 289,
              y: 427,
              font_array: ["Pulse_0.png","Pulse_1.png","Pulse_2.png","Pulse_3.png","Pulse_4.png","Pulse_5.png","Pulse_6.png","Pulse_7.png","Pulse_8.png","Pulse_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 245,
              y: 427,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 334,
              src: 'Bg_Power_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            idle_battery_linear_scale.setAlpha(200);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 79,
              // start_y: 332,
              // color: 0xFF111211,
              // lenght: 322,
              // line_width: 16,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 200,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 9,
              y: 333,
              font_array: ["Dis_Count_0.png","Dis_Count_1.png","Dis_Count_2.png","Dis_Count_3.png","Dis_Count_4.png","Dis_Count_5.png","Dis_Count_6.png","Dis_Count_7.png","Dis_Count_8.png","Dis_Count_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // idle_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 7,
              // y: 160,
              // ColumnWidth: 76,
              // DaysCount: 3,
              // Background: '0_Empty.png',
            // });
            
            idle_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 7,
              y: 160,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region screenType
            if (screenType == hmSetting.screen_type.AOD) {
              idle_forecast_background = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                src: '0_Empty.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion
            // idle_forecast_average_text_img = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG_Options, {
              // x: -15,
              // y: 112,
              // font_array: ["Step_Count_0.png","Step_Count_1.png","Step_Count_2.png","Step_Count_3.png","Step_Count_4.png","Step_Count_5.png","Step_Count_6.png","Step_Count_7.png","Step_Count_8.png","Step_Count_9.png"],
              // padding: false,
              // h_space: -1,
              // unit_en: 'Weather_F_unit.png',
              // imperial_unit_en: 'Weather_F_unit.png',
              // negative_image: 'Weather_F_Error.png',
              // invalid_image: 'Weather_F_Error.png',
              // dot_image: 'Weather_F_Error.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.forecast_average_text_img,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 3; i++) {
                idle_forecast_average_text_img[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG, {
                  x: -15 + i*76,
                  y: 112,
                  font_array: ["Step_Count_0.png","Step_Count_1.png","Step_Count_2.png","Step_Count_3.png","Step_Count_4.png","Step_Count_5.png","Step_Count_6.png","Step_Count_7.png","Step_Count_8.png","Step_Count_9.png"],
                  padding: false,
                  h_space: -1,
                  unit_sc: 'Weather_F_unit.png',
                  unit_tc: 'Weather_F_unit.png',
                  unit_en: 'Weather_F_unit.png',
                  negative_image: 'Weather_F_Error.png',
                  align_h: hmUI.align.CENTER_H,
                  // type: hmUI.data_type.FORECAST_NUMBER_MAX,
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //#endregion

            // idle_forecast_image_progress_img_level = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 21,
              // y: 62,
              // image_array: ["Weather_small_01.png","Weather_small_02.png","Weather_small_03.png","Weather_small_04.png","Weather_small_05.png","Weather_small_06.png","Weather_small_07.png","Weather_small_08.png","Weather_small_09.png","Weather_small_10.png","Weather_small_11.png","Weather_small_12.png","Weather_small_13.png","Weather_small_14.png","Weather_small_15.png","Weather_small_16.png","Weather_small_17.png","Weather_small_18.png","Weather_small_19.png","Weather_small_20.png","Weather_small_21.png","Weather_small_22.png","Weather_small_23.png","Weather_small_24.png","Weather_small_25.png","Weather_small_26.png","Weather_small_27.png","Weather_small_28.png","Weather_small_29.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 3; i++) {
                idle_forecast_image_progress_img_level[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 21 + i*76,
                  y: 62,
                  src: idle_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //#endregion

            // idle_forecast_date_week_img = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 4,
              // y: 34,
              // image_array: ["WeekF_1.png","WeekF_2.png","WeekF_3.png","WeekF_4.png","WeekF_5.png","WeekF_6.png","WeekF_7.png"],
              // image_length: 7,
              // type: hmUI.data_type.forecast_date_week_img,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 3; i++) {
                idle_forecast_date_week_img[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 4 + i*76,
                  y: 34,
                  src: idle_forecast_date_week_img_array[0],
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //#endregion

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 94,
              font_array: ["Step_Count_0.png","Step_Count_1.png","Step_Count_2.png","Step_Count_3.png","Step_Count_4.png","Step_Count_5.png","Step_Count_6.png","Step_Count_7.png","Step_Count_8.png","Step_Count_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 14,
              y: 131,
              image_array: ["StepP_01.png","StepP_02.png","StepP_03.png","StepP_04.png","StepP_05.png","StepP_06.png","StepP_07.png","StepP_08.png","StepP_09.png","StepP_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 55,
              font_array: ["Dis_Count_0.png","Dis_Count_1.png","Dis_Count_2.png","Dis_Count_3.png","Dis_Count_4.png","Dis_Count_5.png","Dis_Count_6.png","Dis_Count_7.png","Dis_Count_8.png","Dis_Count_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Dis_Km.png',
              unit_tc: 'Dis_Km.png',
              unit_en: 'Dis_Km.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 33,
              font_array: ["Step_Count_0.png","Step_Count_1.png","Step_Count_2.png","Step_Count_3.png","Step_Count_4.png","Step_Count_5.png","Step_Count_6.png","Step_Count_7.png","Step_Count_8.png","Step_Count_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 198,
              am_y: 43,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 198,
              pm_y: 43,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 253,
              minute_startY: 184,
              minute_array: ["TimeM_0.png","TimeM_1.png","TimeM_2.png","TimeM_3.png","TimeM_4.png","TimeM_5.png","TimeM_6.png","TimeM_7.png","TimeM_8.png","TimeM_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 270,
              src: 'AOD_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 251,
              hour_startY: 78,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 18,
              y: 85,
              w: 133,
              h: 36,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 428,
              w: 84,
              h: 48,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 261,
              y: 7,
              w: 127,
              h: 51,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 19,
              y: 415,
              w: 73,
              h: 42,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 470,
              w: 133,
              h: 41,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 153,
              y: 362,
              w: 106,
              h: 43,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 237,
              y: 411,
              w: 41,
              h: 53,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 327,
              y: 258,
              w: 71,
              h: 43,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 291,
              y: 184,
              w: 83,
              h: 59,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 254,
              y: 255,
              w: 51,
              h: 48,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 288,
              y: 368,
              w: 136,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 351,
              y: 316,
              w: 79,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 40,
              y: 3,
              w: 132,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 286,
              y: 84,
              w: 128,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // chang Hour color
click_Hour_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 1,
              y: 312,
              w: 142,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //power color
click_Power_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 469,
              w: 73,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // heart color
click_Heart_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 406,
              y: 171,
              w: 30,
              h: 133,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // ALL color
click_All_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region weather_few_days
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 3; i++) {
                // Number_Average
                let averageTemperature = '-';
                if (i < forecastData.count) averageTemperature = parseInt((forecastData.data[i].high + forecastData.data[i].low)/2).toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_average_text_img[i].setProperty(hmUI.prop.TEXT, averageTemperature);
                };
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
                // DOW images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_img[i].setProperty(hmUI.prop.SRC, normal_forecast_date_week_img_array[dowIndex]);
                };
              
                // Number_Average
                if (screenType == hmSetting.screen_type.AOD) {
                  idle_forecast_average_text_img[i].setProperty(hmUI.prop.TEXT, averageTemperature);
                };
                
                // Images
                if (screenType == hmSetting.screen_type.AOD) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  idle_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, idle_forecast_image_array[weatherIndex]);
                };
              
                // DOW images
                if (screenType == hmSetting.screen_type.AOD) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  idle_forecast_date_week_img[i].setProperty(hmUI.prop.SRC, idle_forecast_date_week_img_array[dowIndex]);
                };
              
              };  // end for

            };
            //#endregion

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 401;
                  let start_y_normal_battery = 332;
                  let lenght_ls_normal_battery = -322;
                  let line_width_ls_normal_battery = 16;
                  let color_ls_normal_battery = 0xFF111211;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

              console.log('Weather city name');
              let idle_cityNameStr = weatherData.cityName;
              idle_city_name_text.setProperty(hmUI.prop.TEXT, idle_cityNameStr);

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 401;
                  let start_y_idle_battery = 332;
                  let lenght_ls_idle_battery = -322;
                  let line_width_ls_idle_battery = 16;
                  let color_ls_idle_battery = 0xFF111211;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();

                weather_few_days();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}