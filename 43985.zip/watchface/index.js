﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_image_progress_img_level = ''
        let normal_day_month_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_time_pointer_smooth_second = ''
        let normal_temperature_high_TextRotate = new Array(4);
        let normal_temperature_high_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_high_TextRotate_img_width = 12;
        let normal_temperature_high_TextRotate_dot_width = 12;
        let normal_temperature_high_TextRotate_error_img_width = 12;
        let normal_temperature_low_TextRotate = new Array(4);
        let normal_temperature_low_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_low_TextRotate_img_width = 12;
        let normal_temperature_low_TextRotate_dot_width = 12;
        let normal_temperature_low_TextRotate_error_img_width = 12;
        let normal_temperature_current_TextRotate = new Array(4);
        let normal_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_current_TextRotate_img_width = 16;
        let normal_temperature_current_TextRotate_unit = null;
        let normal_temperature_current_TextRotate_unit_width = 16;
        let normal_temperature_current_TextRotate_dot_width = 16;
        let normal_temperature_current_TextRotate_error_img_width = 16;
        let normal_battery_circle_scale = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 12;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 12;
        let normal_step_circle_scale = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 12;
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 16;
        let normal_heart_rate_TextRotate_error_img_width = 16;
        let idle_background_bg_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SFUIDisplay-Medium.ttf; FontSize: 26
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 354,
              h: 37,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SFUIDisplay-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 95,
              y: 125,
              src: 'SUNMOVEMENT_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 95,
              y: 125,
              image_array: ["SUNMOVEMENT_1.png","SUNMOVEMENT_2.png","SUNMOVEMENT_3.png","SUNMOVEMENT_4.png","SUNMOVEMENT_5.png","SUNMOVEMENT_6.png","SUNMOVEMENT_7.png","SUNMOVEMENT_8.png","SUNMOVEMENT_9.png","SUNMOVEMENT_10.png","SUNMOVEMENT_11.png"],
              image_length: 11,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 254,
              w: 150,
              h: 50,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SFUIDisplay-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND-HR.png',
              // center_x: 195,
              // center_y: 225,
              // x: 15,
              // y: 75,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 15,
              pos_y: 225 - 75,
              center_x: 195,
              center_y: 225,
              src: 'HAND-HR.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND-MIN.png',
              // center_x: 195,
              // center_y: 225,
              // x: 15,
              // y: 117,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 15,
              pos_y: 225 - 117,
              center_x: 195,
              center_y: 225,
              src: 'HAND-MIN.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'HAND-SEC.png',
              // center_x: 195,
              // center_y: 225,
              // x: 18,
              // y: 165,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'HAND-SEC.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 18,
              second_posY: 165,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            // normal_temperature_high_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 371,
              // y: 103,
              // font_array: ["SMALL_0.png","SMALL_1.png","SMALL_2.png","SMALL_3.png","SMALL_4.png","SMALL_5.png","SMALL_6.png","SMALL_7.png","SMALL_8.png","SMALL_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 53,
              // negative_image: 'SMALL_NEGATIVE.png',
              // invalid_image: 'SMALL_NODATA.png',
              // dot_image: 'SMALL_NEGATIVE.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_high_TextRotate_ASCIIARRAY[0] = 'SMALL_0.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[1] = 'SMALL_1.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[2] = 'SMALL_2.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[3] = 'SMALL_3.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[4] = 'SMALL_4.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[5] = 'SMALL_5.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[6] = 'SMALL_6.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[7] = 'SMALL_7.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[8] = 'SMALL_8.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[9] = 'SMALL_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_temperature_high_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 371,
                center_y: 103,
                pos_x: 371,
                pos_y: 103,
                angle: 53,
                src: 'SMALL_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            // normal_temperature_low_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 289,
              // y: 33,
              // font_array: ["SMALL_0.png","SMALL_1.png","SMALL_2.png","SMALL_3.png","SMALL_4.png","SMALL_5.png","SMALL_6.png","SMALL_7.png","SMALL_8.png","SMALL_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 24,
              // negative_image: 'SMALL_NEGATIVE.png',
              // invalid_image: 'SMALL_NODATA.png',
              // dot_image: 'SMALL_NEGATIVE.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_low_TextRotate_ASCIIARRAY[0] = 'SMALL_0.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[1] = 'SMALL_1.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[2] = 'SMALL_2.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[3] = 'SMALL_3.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[4] = 'SMALL_4.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[5] = 'SMALL_5.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[6] = 'SMALL_6.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[7] = 'SMALL_7.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[8] = 'SMALL_8.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[9] = 'SMALL_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_temperature_low_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 289,
                center_y: 33,
                pos_x: 289,
                pos_y: 33,
                angle: 24,
                src: 'SMALL_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 348,
              // y: 35,
              // font_array: ["BIG_0.png","BIG_1.png","BIG_2.png","BIG_3.png","BIG_4.png","BIG_5.png","BIG_6.png","BIG_7.png","BIG_8.png","BIG_9.png"],
              // zero: false,
              // unit_in_alignment: true,
              // h_space: 0,
              // angle: 34,
              // unit_en: 'BIG_DEGREE.png',
              // imperial_unit_en: 'BIG_DEGREE.png',
              // negative_image: 'BIG_NEGATIVE.png',
              // invalid_image: 'BIG_NODATA.png',
              // dot_image: 'BIG_NEGATIVE.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_current_TextRotate_ASCIIARRAY[0] = 'BIG_0.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[1] = 'BIG_1.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[2] = 'BIG_2.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[3] = 'BIG_3.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[4] = 'BIG_4.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[5] = 'BIG_5.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[6] = 'BIG_6.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[7] = 'BIG_7.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[8] = 'BIG_8.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[9] = 'BIG_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 348,
                center_y: 35,
                pos_x: 348,
                pos_y: 35,
                angle: 34,
                src: 'BIG_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 348,
              center_y: 35,
              pos_x: 348,
              pos_y: 35,
              angle: 34,
              src: 'BIG_DEGREE.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            const temperatureUnit = hmSetting.getTemperatureUnit();
            if (temperatureUnit == 1) {
              normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.SRC, 'BIG_DEGREE.png');
            };
            //end of ignored block

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 225,
              // start_angle: 128,
              // end_angle: 157,
              // radius: 211,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFF00B4FF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 225,
              start_angle: 128,
              end_angle: 157,
              radius: 205,
              line_width: 12,
              corner_flag: 0,
              color: 0xFF00B4FF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 224,
              // y: 418,
              // font_array: ["SMALL_0.png","SMALL_1.png","SMALL_2.png","SMALL_3.png","SMALL_4.png","SMALL_5.png","SMALL_6.png","SMALL_7.png","SMALL_8.png","SMALL_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 350,
              // unit_en: 'SMALL_PERCENT.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'SMALL_0.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'SMALL_1.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'SMALL_2.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'SMALL_3.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'SMALL_4.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'SMALL_5.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'SMALL_6.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'SMALL_7.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'SMALL_8.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'SMALL_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 224,
                center_y: 418,
                pos_x: 224,
                pos_y: 418,
                angle: 350,
                src: 'SMALL_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 224,
              center_y: 418,
              pos_x: 224,
              pos_y: 418,
              angle: 350,
              src: 'SMALL_PERCENT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 225,
              // start_angle: -52,
              // end_angle: -23,
              // radius: 212,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFFC0FF00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 225,
              start_angle: -52,
              end_angle: -23,
              radius: 206,
              line_width: 12,
              corner_flag: 0,
              color: 0xFFC0FF00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 118,
              // y: 24,
              // font_array: ["SMALL_0.png","SMALL_1.png","SMALL_2.png","SMALL_3.png","SMALL_4.png","SMALL_5.png","SMALL_6.png","SMALL_7.png","SMALL_8.png","SMALL_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -10,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'SMALL_0.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'SMALL_1.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'SMALL_2.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'SMALL_3.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'SMALL_4.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'SMALL_5.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'SMALL_6.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'SMALL_7.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'SMALL_8.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'SMALL_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 118,
                center_y: 24,
                pos_x: 118,
                pos_y: 24,
                angle: -10,
                src: 'SMALL_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 58,
              // y: 402,
              // font_array: ["BIG_0.png","BIG_1.png","BIG_2.png","BIG_3.png","BIG_4.png","BIG_5.png","BIG_6.png","BIG_7.png","BIG_8.png","BIG_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 36,
              // invalid_image: 'BIG_NODATA.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'BIG_0.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'BIG_1.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'BIG_2.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'BIG_3.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'BIG_4.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'BIG_5.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'BIG_6.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'BIG_7.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'BIG_8.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'BIG_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 58,
                center_y: 402,
                pos_x: 58,
                pos_y: 402,
                angle: 36,
                src: 'BIG_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'AOD-BG.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'AOD-HAND-HR.png',
              // center_x: 195,
              // center_y: 225,
              // x: 15,
              // y: 75,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 15,
              pos_y: 225 - 75,
              center_x: 195,
              center_y: 225,
              src: 'AOD-HAND-HR.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'AOD-HAND-MIN.png',
              // center_x: 195,
              // center_y: 225,
              // x: 15,
              // y: 117,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 15,
              pos_y: 225 - 117,
              center_x: 195,
              center_y: 225,
              src: 'AOD-HAND-MIN.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 290,
              y: 0,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 145,
              y: 128,
              w: 100,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 350,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 145,
              y: 235,
              w: 100,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '/' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '/' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

              if (updateMinute) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              if (updateMinute) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let temperature_high_temp = -100;
              if (forecastData.count > 0) {
                temperature_high_temp = forecastData.data[0].high;
              }; // end forecastData;

              console.log('update text rotate temperature_high_forecastData');
              let temperatureHigh = undefined;
              let normal_temperature_high_rotate_string = undefined;
              if (temperature_high_temp > -100) {
                temperatureHigh = 0;
                normal_temperature_high_rotate_string = String(temperature_high_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && normal_temperature_high_rotate_string.length > 0 && normal_temperature_high_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_temperature_high_TextRotate_posOffset = normal_temperature_high_TextRotate_img_width * normal_temperature_high_rotate_string.length;
                  img_offset -= normal_temperature_high_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_high_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 371 + img_offset);
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_high_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_high_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 371 + img_offset);
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.SRC, 'SMALL_NEGATIVE.png');
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_high_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_temperature_high_TextRotate[0].setProperty(hmUI.prop.POS_X, 371 - normal_temperature_high_TextRotate_error_img_width / 2);
                  normal_temperature_high_TextRotate[0].setProperty(hmUI.prop.SRC, 'SMALL_NODATA.png');
                  normal_temperature_high_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let temperature_low_temp = -100;
              if (forecastData.count > 0) {
                temperature_low_temp = forecastData.data[0].low;
              }; // end forecastData;

              console.log('update text rotate temperature_low_forecastData');
              let temperatureLow = undefined;
              let normal_temperature_low_rotate_string = undefined;
              if (temperature_low_temp > -100) {
                temperatureLow = 0;
                normal_temperature_low_rotate_string = String(temperature_low_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && normal_temperature_low_rotate_string.length > 0 && normal_temperature_low_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_temperature_low_TextRotate_posOffset = normal_temperature_low_TextRotate_img_width * normal_temperature_low_rotate_string.length;
                  img_offset -= normal_temperature_low_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_low_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 289 + img_offset);
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_low_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_low_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 289 + img_offset);
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.SRC, 'SMALL_NEGATIVE.png');
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_low_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_temperature_low_TextRotate[0].setProperty(hmUI.prop.POS_X, 289 - normal_temperature_low_TextRotate_error_img_width / 2);
                  normal_temperature_low_TextRotate[0].setProperty(hmUI.prop.SRC, 'SMALL_NODATA.png');
                  normal_temperature_low_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let temperature_current_temp = -100;
              if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
                temperature_current_temp = weatherSensor.current;
              }; // end currentWeather;

              console.log('update text rotate temperature_current_currentWeather');
              let temperatureCurrent = undefined;
              let normal_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                normal_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && normal_temperature_current_rotate_string.length > 0 && normal_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_img_width * normal_temperature_current_rotate_string.length;
                  normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_posOffset + normal_temperature_current_TextRotate_unit_width + 0;
                  img_offset -= normal_temperature_current_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 348 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 348 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'BIG_NEGATIVE.png');
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 348 + img_offset);
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.POS_X, 348 - normal_temperature_current_TextRotate_error_img_width / 2);
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.SRC, 'BIG_NODATA.png');
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 224 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 224 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 118 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  img_offset -= normal_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 58 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_heart_rate_TextRotate[0].setProperty(hmUI.prop.POS_X, 58 - normal_heart_rate_TextRotate_error_img_width / 2);
                  normal_heart_rate_TextRotate[0].setProperty(hmUI.prop.SRC, 'BIG_NODATA.png');
                  normal_heart_rate_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 225,
                      start_angle: 128,
                      end_angle: 157,
                      radius: 205,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF00B4FF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 225,
                      start_angle: -52,
                      end_angle: -23,
                      radius: 206,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFFC0FF00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}