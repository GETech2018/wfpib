﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['0001_1.png', '0001_2.png', '0001_3.png', '0001_4.png', '0001_5.png'];
        let backgroundToastList = ['Синий', 'Фиолетовый', 'Красный', 'Зелёный', 'Жёлтый'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              vibro(28);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '0001_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 100,
              y: 45,
              src: '1116.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 35,
              y: 45,
              src: '1114.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 288,
              y: 318,
              image_array: ["w_01.png","w_02.png","w_03.png","w_04.png","w_05.png","w_06.png","w_07.png","w_08.png","w_09.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 380,
              font_array: ["0010_00.png","0010_01.png","0010_02.png","0010_03.png","0010_04.png","0010_05.png","0010_06.png","0010_07.png","0010_08.png","0010_09.png"],
              padding: false,
              h_space: 3,
              unit_sc: '0010_11.png',
              unit_tc: '0010_11.png',
              unit_en: '0010_11.png',
              negative_image: '0010_10.png',
              invalid_image: '0010_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 37,
              y: 380,
              font_array: ["0010_00.png","0010_01.png","0010_02.png","0010_03.png","0010_04.png","0010_05.png","0010_06.png","0010_07.png","0010_08.png","0010_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 68,
              y: 335,
              src: '1111.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 161,
              y: 380,
              font_array: ["0010_00.png","0010_01.png","0010_02.png","0010_03.png","0010_04.png","0010_05.png","0010_06.png","0010_07.png","0010_08.png","0010_09.png"],
              padding: false,
              h_space: 3,
              unit_sc: '0010_13.png',
              unit_tc: '0010_13.png',
              unit_en: '0010_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 335,
              src: '1112.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 31,
              y: 260,
              week_en: ["0008_01.png","0008_02.png","0008_03.png","0008_04.png","0008_05.png","0008_06.png","0008_07.png"],
              week_tc: ["0008_01.png","0008_02.png","0008_03.png","0008_04.png","0008_05.png","0008_06.png","0008_07.png"],
              week_sc: ["0008_01.png","0008_02.png","0008_03.png","0008_04.png","0008_05.png","0008_06.png","0008_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 247,
              month_startY: 31,
              month_sc_array: ["0006_01.png","0006_02.png","0006_03.png","0006_04.png","0006_05.png","0006_06.png","0006_07.png","0006_08.png","0006_09.png","0006_10.png","0006_11.png","0006_12.png"],
              month_tc_array: ["0006_01.png","0006_02.png","0006_03.png","0006_04.png","0006_05.png","0006_06.png","0006_07.png","0006_08.png","0006_09.png","0006_10.png","0006_11.png","0006_12.png"],
              month_en_array: ["0006_01.png","0006_02.png","0006_03.png","0006_04.png","0006_05.png","0006_06.png","0006_07.png","0006_08.png","0006_09.png","0006_10.png","0006_11.png","0006_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 167,
              day_startY: 41,
              day_sc_array: ["0004_00.png","0004_01.png","0004_02.png","0004_03.png","0004_04.png","0004_05.png","0004_06.png","0004_07.png","0004_08.png","0004_09.png"],
              day_tc_array: ["0004_00.png","0004_01.png","0004_02.png","0004_03.png","0004_04.png","0004_05.png","0004_06.png","0004_07.png","0004_08.png","0004_09.png"],
              day_en_array: ["0004_00.png","0004_01.png","0004_02.png","0004_03.png","0004_04.png","0004_05.png","0004_06.png","0004_07.png","0004_08.png","0004_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 25,
              hour_startY: 110,
              hour_array: ["0002_00.png","0002_01.png","0002_02.png","0002_03.png","0002_04.png","0002_05.png","0002_06.png","0002_07.png","0002_08.png","0002_09.png"],
              hour_zero: 1,
              hour_space: 13,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 214,
              minute_startY: 110,
              minute_array: ["0002_00.png","0002_01.png","0002_02.png","0002_03.png","0002_04.png","0002_05.png","0002_06.png","0002_07.png","0002_08.png","0002_09.png"],
              minute_zero: 1,
              minute_space: 13,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 110,
              src: '0002_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 100,
              y: 45,
              src: '1116.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 35,
              y: 45,
              src: '1115.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 161,
              y: 380,
              font_array: ["0011_00.png","0011_01.png","0011_02.png","0011_03.png","0011_04.png","0011_05.png","0011_06.png","0011_07.png","0011_08.png","0011_09.png"],
              padding: false,
              h_space: 3,
              unit_sc: '0011_13.png',
              unit_tc: '0011_13.png',
              unit_en: '0011_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 335,
              src: '1113.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 31,
              y: 260,
              week_en: ["0009_01.png","0009_02.png","0009_03.png","0009_04.png","0009_05.png","0009_06.png","0009_07.png"],
              week_tc: ["0009_01.png","0009_02.png","0009_03.png","0009_04.png","0009_05.png","0009_06.png","0009_07.png"],
              week_sc: ["0009_01.png","0009_02.png","0009_03.png","0009_04.png","0009_05.png","0009_06.png","0009_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 247,
              month_startY: 31,
              month_sc_array: ["0007_01.png","0007_02.png","0007_03.png","0007_04.png","0007_05.png","0007_06.png","0007_07.png","0007_08.png","0007_09.png","0007_10.png","0007_11.png","0007_12.png"],
              month_tc_array: ["0007_01.png","0007_02.png","0007_03.png","0007_04.png","0007_05.png","0007_06.png","0007_07.png","0007_08.png","0007_09.png","0007_10.png","0007_11.png","0007_12.png"],
              month_en_array: ["0007_01.png","0007_02.png","0007_03.png","0007_04.png","0007_05.png","0007_06.png","0007_07.png","0007_08.png","0007_09.png","0007_10.png","0007_11.png","0007_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 167,
              day_startY: 41,
              day_sc_array: ["0005_00.png","0005_01.png","0005_02.png","0005_03.png","0005_04.png","0005_05.png","0005_06.png","0005_07.png","0005_08.png","0005_09.png"],
              day_tc_array: ["0005_00.png","0005_01.png","0005_02.png","0005_03.png","0005_04.png","0005_05.png","0005_06.png","0005_07.png","0005_08.png","0005_09.png"],
              day_en_array: ["0005_00.png","0005_01.png","0005_02.png","0005_03.png","0005_04.png","0005_05.png","0005_06.png","0005_07.png","0005_08.png","0005_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 25,
              hour_startY: 110,
              hour_array: ["0003_00.png","0003_01.png","0003_02.png","0003_03.png","0003_04.png","0003_05.png","0003_06.png","0003_07.png","0003_08.png","0003_09.png"],
              hour_zero: 1,
              hour_space: 13,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 214,
              minute_startY: 110,
              minute_array: ["0003_00.png","0003_01.png","0003_02.png","0003_03.png","0003_04.png","0003_05.png","0003_06.png","0003_07.png","0003_08.png","0003_09.png"],
              minute_zero: 1,
              minute_space: 13,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 184,
              y: 110,
              src: '0003_10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth\r\nОТКЛЮЧЕН,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: Bluetooth\r\nПОДКЛЮЧЕН,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth\r\nОТКЛЮЧЕН"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth\r\nПОДКЛЮЧЕН"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 169,
              y: 335,
              w: 50,
              h: 72,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 280,
              y: 320,
              w: 75,
              h: 90,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 25,
              y: 36,
              w: 55,
              h: 55,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 35,
              y: 335,
              w: 90,
              h: 75,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 25,
              press_src: 'NULL.png',
              normal_src: 'NULL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 173,
              y: 40,
              w: 190,
              h: 50,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 25,
              press_src: 'NULL.png',
              normal_src: 'NULL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 31,
              y: 260,
              w: 330,
              h: 50,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 25,
              press_src: 'NULL.png',
              normal_src: 'NULL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 31,
              y: 110,
              w: 330,
              h: 125,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 25,
              press_src: 'NULL.png',
              normal_src: 'NULL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneContactsScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 170,
              // y: 413,
              // w: 50,
              // h: 36,
              // text: '',
              // color: 0xFFFFFFFF,
              // text_size: 25,
              // press_src: '1117.png',
              // normal_src: '1117.png',
              // bg_list: 0001_1|0001_2|0001_3|0001_4|0001_5,
              // toast_list: Синий|Фиолетовый|Красный|Зелёный|Жёлтый,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: True,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 170,
              y: 413,
              w: 50,
              h: 36,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 25,
              press_src: '1117.png',
              normal_src: '1117.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}