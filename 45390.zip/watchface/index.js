/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.2.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_battery_imageset2 = '';
		let normal_week_imageset4 = '';
		let normal_month_imageset5 = '';
		let normal_date_imagecombo6 = '';
		let timeInterval;
		let normal_hour_high_imageset8 = '';
		let normal_hour_high_imageset8_array = ['0043.png','0044.png','0045.png'];
		let normal_hour_low_imageset9 = '';
		let normal_hour_low_imageset9_array = ['0046.png','0047.png','0048.png','0049.png','0050.png','0051.png','0052.png','0053.png','0054.png','0055.png'];
		let normal_minute_high_imageset10 = '';
		let normal_minute_high_imageset10_array = ['0043.png','0044.png','0045.png','0056.png','0057.png','0058.png'];
		let normal_minute_low_imageset11 = '';
		let normal_minute_low_imageset11_array = ['0046.png','0047.png','0048.png','0049.png','0050.png','0051.png','0052.png','0053.png','0054.png','0055.png'];
		let normal_img12 = '';
		let normal_weather_imageset14 = '';
		let normal_temperature_current_imagecombo15 = '';
		let normal_biocharge_imageset17 = '';
		let normal_biocharge_imagecombo18 = '';
		let normal_img19 = '';
		let normal_stress_imageset21 = '';
		let normal_stress_imagecombo22 = '';
		let normal_img23 = '';
		let normal_steps_imageset25 = '';
		let normal_steps_imagecombo26 = '';
		let normal_img27 = '';
		let normal_calories_imagecombo29 = '';
		let normal_calories_imageset30 = '';
		let normal_img31 = '';
		let normal_stress_shortcut34 = '';
		let normal_calories_shortcut35 = '';
		let normal_steps_shortcut36 = '';
		let normal_battery_shortcut37 = '';
		let normal_weather_shortcut38 = '';
		let normal_countdown_shortcut39 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 432,
					h: 514,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imageset2 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 295,
					y: 226,
					image_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
					image_length: 11,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset4 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 47,
					y: 219,
					week_en: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					week_tc: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					week_sc: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset5 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 175,
					month_startY: 219,
					month_sc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					month_tc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					month_en_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo6 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 126,
					day_startY: 217,
					day_sc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					day_tc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					day_en_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.LEFT,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_high_imageset8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 43,
					y: 105,
					w: 43,
					h: 105,
					src: '0045.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_low_imageset9 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 112,
					y: 105,
					w: 112,
					h: 105,
					src: '0055.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_high_imageset10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 219,
					y: 104,
					w: 219,
					h: 104,
					src: '0058.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_low_imageset11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 294,
					y: 104,
					w: 294,
					h: 104,
					src: '0055.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_img12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 182,
					y: 104,
					w: 56,
					h: 110,
					src: '0059.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset14 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 248,
					y: 19,
					image_array: ["0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo15 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 311,
					y: 30,
					font_array: ["0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0100.png"],
					unit_tc: ["0100.png"],
					unit_en: ["0100.png"],
					negative_image: ["0099.png"],
					invalid_image: ["0101.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_biocharge_imageset17 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 0,
					y: 0,
					image_array: ["0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png"],
					image_length: 11,
					type: hmUI.data_type.BIO_CHARGE,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_biocharge_imagecombo18 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 68,
					y: 434,
					font_array: ["0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.BIO_CHARGE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img19 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 38,
					y: 437,
					w: 28,
					h: 37,
					src: '0123.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_imageset21 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 0,
					y: 0,
					image_array: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png"],
					image_length: 11,
					type: hmUI.data_type.STRESS,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_imagecombo22 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 68,
					y: 389,
					font_array: ["0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img23 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 37,
					y: 393,
					w: 30,
					h: 37,
					src: '0145.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imageset25 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 0,
					y: 0,
					image_array: ["0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png"],
					image_length: 11,
					type: hmUI.data_type.STEP,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo26 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 68,
					y: 344,
					font_array: ["0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png","0165.png","0166.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img27 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 30,
					y: 351,
					w: 37,
					h: 32,
					src: '0167.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo29 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 68,
					y: 299,
					font_array: ["0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png","0177.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imageset30 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 0,
					y: 0,
					image_array: ["0178.png","0179.png","0180.png","0181.png","0182.png","0183.png","0184.png","0185.png","0186.png","0187.png","0188.png"],
					image_length: 11,
					type: hmUI.data_type.CAL,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img31 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 30,
					y: 302,
					w: 37,
					h: 37,
					src: '0189.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_shortcut34 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 26,
					y: 389,
					w: 162,
					h: 44,
					src: '',
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_shortcut35 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 26,
					y: 299,
					w: 162,
					h: 44,
					src: '',
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut36 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 26,
					y: 344,
					w: 162,
					h: 44,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_shortcut37 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 266,
					y: 215,
					w: 120,
					h: 53,
					src: '',
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_shortcut38 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 238,
					y: 10,
					w: 163,
					h: 77,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_countdown_shortcut39 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 47,
					y: 0,
					w: 108,
					h: 100,
					src: '',
					type: hmUI.data_type.COUNT_DOWN,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				function updateTime() {
					normal_hour_high_imageset8.setProperty(hmUI.prop.MORE, {
						src: normal_hour_high_imageset8_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					normal_hour_low_imageset9.setProperty(hmUI.prop.MORE, {
						src: normal_hour_low_imageset9_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					normal_minute_high_imageset10.setProperty(hmUI.prop.MORE, {
						src: normal_minute_high_imageset10_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_minute_low_imageset11.setProperty(hmUI.prop.MORE, {
						src: normal_minute_low_imageset11_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}