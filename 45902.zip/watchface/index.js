try{(()=>{var __$$app$$__=__$$hmAppManager$$__.currentApp;var __$$module$$__=__$$app$$__.current;var e=new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__,__$$module$$__),"duo");"use strict";
__$$module$$__.module=DeviceRuntimeCore.WatchFace({
init_view(){
const N=hmUI.show_level.ONLY_NORMAL, AOD=hmUI.show_level.ONLY_AOD, L=hmUI.align.LEFT;
const safe=(f)=>{try{f()}catch(err){console.log(err)}};
safe(()=>hmUI.createWidget(hmUI.widget.IMG,{x:0,y:0,w:390,h:450,src:"0073.png",show_level:N}));
var HRS=["0001.png", "0002.png", "0003.png", "0004.png", "0005.png", "0006.png", "0007.png", "0008.png", "0009.png", "0010.png", "0011.png", "0012.png"], MNS=["0013.png", "0014.png", "0015.png", "0016.png", "0017.png", "0018.png", "0019.png", "0020.png", "0021.png", "0022.png", "0023.png", "0024.png", "0025.png", "0026.png", "0027.png", "0028.png", "0029.png", "0030.png", "0031.png", "0032.png", "0033.png", "0034.png", "0035.png", "0036.png", "0037.png", "0038.png", "0039.png", "0040.png", "0041.png", "0042.png", "0043.png", "0044.png", "0045.png", "0046.png", "0047.png", "0048.png", "0049.png", "0050.png", "0051.png", "0052.png", "0053.png", "0054.png", "0055.png", "0056.png", "0057.png", "0058.png", "0059.png", "0060.png", "0061.png", "0062.png", "0063.png", "0064.png", "0065.png", "0066.png", "0067.png", "0068.png", "0069.png", "0070.png", "0071.png", "0072.png"], tm=null, wh=null, wm=null;
try{tm=hmSensor.createSensor(hmSensor.id.TIME)}catch(err){console.log(err)}
var now=function(){try{if(tm&&typeof tm.hour==="number")return [tm.hour,tm.minute]}catch(err){}var d=new Date();return [d.getHours(),d.getMinutes()]};
var t0=now(), h0=(t0[0]%12)||12;
try{wh=hmUI.createWidget(hmUI.widget.IMG,{x:24,y:28,w:342,h:188,src:HRS[h0-1],show_level:N})}catch(err){console.log(err)}
try{wm=hmUI.createWidget(hmUI.widget.IMG,{x:24,y:232,w:342,h:188,src:MNS[t0[1]],show_level:N})}catch(err){console.log(err)}
var up=function(){try{var t=now(),h=(t[0]%12)||12;wh.setProperty(hmUI.prop.SRC,HRS[h-1]);wm.setProperty(hmUI.prop.SRC,MNS[t[1]])}catch(err){console.log(err)}};
try{tm.addEventListener(hmSensor.event.MINUTEEND,up)}catch(err){console.log(err)}
try{hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE,{resume_call:up})}catch(err){}
// AOD: digitos tenues actualizados por el sistema
safe(()=>hmUI.createWidget(hmUI.widget.IMG,{x:0,y:0,w:390,h:450,src:"0084.png",show_level:AOD}));
safe(()=>hmUI.createWidget(hmUI.widget.IMG_TIME,{
 hour_startX:95,hour_startY:36,hour_array:["0074.png", "0075.png", "0076.png", "0077.png", "0078.png", "0079.png", "0080.png", "0081.png", "0082.png", "0083.png"],hour_zero:1,hour_space:0,hour_align:L,
 minute_startX:95,minute_startY:240,minute_array:["0074.png", "0075.png", "0076.png", "0077.png", "0078.png", "0079.png", "0080.png", "0081.png", "0082.png", "0083.png"],minute_zero:1,minute_space:0,minute_align:L,show_level:AOD}));
},
onInit(){this.init_view()},onReady(){},onShow(){},onHide(){},onDestroy(){}
})})()}catch(e){console.log(e)}
