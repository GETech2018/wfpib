try { (()=>{
const app=__$$hmAppManager$$__.currentApp, module=app.current;
let heartSensor, heartCallback;
module.module=DeviceRuntimeCore.WatchFace({
init_view(){
const N=hmUI.show_level.ONLY_NORMAL,A=hmUI.show_level.ONAL_AOD;
const time=hmSensor.createSensor(hmSensor.id.TIME), battery=hmSensor.createSensor(hmSensor.id.BATTERY);
const tx=(x,y,w,h,text,size,color,level,align=hmUI.align.CENTER_H)=>hmUI.createWidget(hmUI.widget.TEXT,{x,y,w,h,text,text_size:size,color,align_h:align,align_v:hmUI.align.CENTER_V,show_level:level});
const box=(x,y,w,h,level)=>hmUI.createWidget(hmUI.widget.STROKE_RECT,{x,y,w,h,radius:12,line_width:3,color:0x292929,show_level:level});
const white=Array.from({length:10},(_,i)=>`impact_white_${i}.png`);
const grey=Array.from({length:10},(_,i)=>`impact_grey_${i}.png`);
const seconds=Array.from({length:10},(_,i)=>`seconds_${i}.png`);
const digits=Array.from({length:10},(_,i)=>`${String(87+i).padStart(4,'0')}.png`);
function timeWidgets(level){
  hmUI.createWidget(hmUI.widget.IMG_TIME,{hour_startX:32,hour_startY:95,hour_array:white,hour_zero:true,hour_space:0,hour_align:hmUI.align.LEFT,enable:false,show_level:level});
  hmUI.createWidget(hmUI.widget.IMG_TIME,{minute_startX:198,minute_startY:138,minute_array:grey,minute_zero:true,minute_space:0,minute_align:hmUI.align.LEFT,enable:false,show_level:level});
  box(58,312,108,50,level);
  const weekday=tx(66,316,92,42,'THU',35,0x646464,level);
  box(203,85,150,50,level);
  const date=tx(207,90,142,40,'NOV 12',35,0xffffff,level);
  return {weekday,date};
}
const normal=timeWidgets(N),aod=timeWidgets(A);
// Firmware refreshes seconds during the active display; omit them from AOD.
hmUI.createWidget(hmUI.widget.IMG_TIME,{second_startX:278,second_startY:365,second_array:seconds,second_zero:true,second_space:0,second_follow:0,second_align:hmUI.align.LEFT,enable:false,show_level:N});
// Top row: system-bound weather; two digits and icon centred on the hour column.
const weatherImages=Array.from({length:29},(_,i)=>`weather_${String(i).padStart(2,'0')}.png`);
for(const level of [N,A]){
  hmUI.createWidget(hmUI.widget.IMG_LEVEL,{x:72,y:40,image_array:weatherImages,image_length:29,type:hmUI.data_type.WEATHER_CURRENT,show_level:level});
  hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:101,y:41,w:80,h:37,font_array:digits,padding:false,h_space:0,unit_sc:['0098.png'],unit_tc:['0098.png'],unit_en:['0098.png'],negative_image:['0097.png'],invalid_image:['0097.png'],align_h:hmUI.align.LEFT,type:hmUI.data_type.WEATHER_CURRENT,show_level:level});
}
const batteryImages=Array.from({length:10},(_,i)=>`inline_battery_${i}.png`);
// Same size and data-bound percentage as ILK Mono Line; retain the split face centre.
const batteryGroups=[[253,279],[245,271],[237,263]].map(([iconX,valueX])=>({
  icon:hmUI.createWidget(hmUI.widget.IMG_LEVEL,{x:iconX,y:40,image_array:batteryImages,image_length:10,type:hmUI.data_type.BATTERY,show_level:N}),
  value:hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:valueX,y:42,w:64,h:37,font_array:digits,padding:false,h_space:0,unit_sc:['inline_percent.png'],unit_tc:['inline_percent.png'],unit_en:['inline_percent.png'],align_h:hmUI.align.LEFT,type:hmUI.data_type.BATTERY,show_level:N})
}));
// Firmware-bound data remains live; sensor callbacks position the adjacent icons.
const stepIcon=hmUI.createWidget(hmUI.widget.IMG,{x:45,y:390,src:'steps_bip6.png',show_level:N});
hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:64,y:386,w:80,h:37,font_array:digits,padding:false,h_space:0,align_h:hmUI.align.CENTER_H,type:hmUI.data_type.STEP,show_level:N});
// Pre-position all three heart-rate lengths to centre the whole icon/value group.
const heartGroups=[[173,200],[165,192],[157,184]].map(([iconX,textX])=>({
  icon:hmUI.createWidget(hmUI.widget.IMG,{x:iconX,y:391,src:'heart_bip6.png',show_level:N}),
  value:hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:textX,y:386,w:48,h:37,font_array:digits,padding:false,h_space:0,align_h:hmUI.align.LEFT,type:hmUI.data_type.HEART,show_level:N})
}));
let steps;
try { steps=hmSensor.createSensor(hmSensor.id.STEP); } catch(e) {}
try { heartSensor=hmSensor.createSensor(hmSensor.id.HEART); } catch(e) {}
function reading(sensor,prop,method){
  try { const n=sensor && typeof sensor[method]==='function' ? sensor[method]() : sensor && sensor[prop]; return Number.isFinite(Number(n)) && n!==null && n!==undefined ? Math.max(0,Math.floor(Number(n))) : null; } catch(e) { return null; }
}
function alignSteps(){
  const n=reading(steps,'current','getCurrent');
  if(n!==null){const len=Math.min(5,String(n).length);stepIcon.setProperty(hmUI.prop.MORE,{x:64+Math.floor((80-16*len)/2)-21});}
}
function alignHeart(){
  const n=reading(heartSensor,'last','getLast');
  const len=n===null || n===0 ? 2 : Math.min(3,String(n).length);
  heartGroups.forEach((group,i)=>{
    group.icon.setProperty(hmUI.prop.VISIBLE,i===len-1);
    group.value.setProperty(hmUI.prop.VISIBLE,i===len-1);
  });
}
function alignBattery(){
  const n=reading(battery,'current','getCurrent');
  const len=n===null?2:Math.max(1,Math.min(3,String(n).length));
  batteryGroups.forEach((group,i)=>{
    group.icon.setProperty(hmUI.prop.VISIBLE,i===len-1);
    group.value.setProperty(hmUI.prop.VISIBLE,i===len-1);
  });
}
const days=['MON','TUE','WED','THU','FRI','SAT','SUN'],months=['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
function update(){
  const day=days[(time.week+6)%7],date=months[time.month-1]+' '+time.day;
  for(const item of [normal,aod]){item.weekday.setProperty(hmUI.prop.MORE,{text:day});item.date.setProperty(hmUI.prop.MORE,{text:date});}
  try {alignBattery();} catch(e) {}
  try {alignSteps();alignHeart();} catch(e) {}
}
// Transparent native shortcut buttons use the exact asset from Flip Clock.
for(const [x,y,w,h,url] of [[32,95,160,216,'CountdownAppScreen'],[198,138,160,216,'CountdownAppScreen'],[60,30,130,52,'WeatherScreen'],[203,85,150,50,'ScheduleCalScreen'],[58,312,108,50,'ScheduleCalScreen']]){
  hmUI.createWidget(hmUI.widget.BUTTON,{x,y,w,h,text:'',normal_src:'tap_clear.png',press_src:'tap_clear.png',show_level:N,click_func:()=>hmApp.startApp({url,native:true})});
}
// Firmware-resolved destinations, matching the user's original Bip 6 face.
hmUI.createWidget(hmUI.widget.IMG_CLICK,{x:35,y:377,w:110,h:54,src:'',type:hmUI.data_type.STEP,show_level:N});
hmUI.createWidget(hmUI.widget.IMG_CLICK,{x:150,y:377,w:90,h:54,src:'',type:hmUI.data_type.HEART,show_level:N});
time.addEventListener(hmSensor.event.CHANGE,update);
battery.addEventListener(hmSensor.event.CHANGE,update);
try {if(steps)steps.addEventListener(hmSensor.event.CHANGE,alignSteps);} catch(e) {}
try {if(heartSensor && heartSensor.event && heartSensor.event.LAST!==undefined){heartCallback=alignHeart;heartSensor.addEventListener(heartSensor.event.LAST,heartCallback);}} catch(e) {}
hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE,{resume_call(){update()},pause_call(){}});
update();
},onInit(){this.init_view()},onReady(){},onShow(){},onHide(){},onDestroy(){try{if(heartSensor && heartCallback)heartSensor.removeEventListener(heartSensor.event.LAST,heartCallback)}catch(e){}}});
})()} catch(e) {console.log(e)}
