﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_stand_circle_scale = ''
        let normal_temperature_current_text_font = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_step_circle_scale = ''
        let normal_calorie_circle_scale = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_day_text_font = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_background_bg_img = ''
        let idle_stand_circle_scale = ''
        let idle_temperature_current_text_font = ''
        let idle_temperature_high_text_font = ''
        let idle_temperature_low_text_font = ''
        let idle_step_circle_scale = ''
        let idle_calorie_circle_scale = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['KON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let idle_day_text_font = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: sf-pro-rounded.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 534,
              h: 57,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/sf-pro-rounded.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: sf-pro-rounded.ttf; FontSize: 17
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 223,
              h: 24,
              text_size: 17,
              char_space: 0,
              line_space: 0,
              font: 'fonts/sf-pro-rounded.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'IMG_9826.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 323,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 20,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFF2DFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 323,
              start_angle: 0,
              end_angle: 360,
              radius: 16,
              line_width: 9,
              corner_flag: 0,
              color: 0xFF2DFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 81,
              y: 198,
              w: 88,
              h: 41,
              text_size: 40,
              char_space: 0,
              font: 'fonts/sf-pro-rounded.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.WRAP,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 110,
              y: 239,
              w: 70,
              h: 30,
              text_size: 17,
              char_space: 0,
              font: 'fonts/sf-pro-rounded.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 65,
              y: 239,
              w: 74,
              h: 30,
              text_size: 17,
              char_space: 0,
              font: 'fonts/sf-pro-rounded.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 323,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 50,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFFFE0E5B,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 323,
              start_angle: 0,
              end_angle: 360,
              radius: 46,
              line_width: 9,
              corner_flag: 0,
              color: 0xFFFE0E5B,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 323,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 35,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFF93FF26,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 323,
              start_angle: 0,
              end_angle: 360,
              radius: 31,
              line_width: 9,
              corner_flag: 0,
              color: 0xFF93FF26,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 121,
              y: 87,
              w: 150,
              h: 43,
              text_size: 34,
              char_space: 0,
              color: 0xFFFF2F2F,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 124,
              w: 150,
              h: 52,
              text_size: 40,
              char_space: 0,
              font: 'fonts/sf-pro-rounded.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'CHAS.png',
              // center_x: 195,
              // center_y: 225,
              // x: 11,
              // y: 92,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 11,
              pos_y: 225 - 92,
              center_x: 195,
              center_y: 225,
              src: 'CHAS.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'MIN.png',
              // center_x: 195,
              // center_y: 225,
              // x: 9,
              // y: 154,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 9,
              pos_y: 225 - 154,
              center_x: 195,
              center_y: 225,
              src: 'MIN.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'STREL.png',
              // center_x: 195,
              // center_y: 225,
              // x: 10,
              // y: 215,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'STREL.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 10,
              second_posY: 215,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'IMG_9827.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 323,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 20,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFFCFCFCF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 323,
              start_angle: 0,
              end_angle: 360,
              radius: 16,
              line_width: 9,
              corner_flag: 0,
              color: 0xFFCFCFCF,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 81,
              y: 198,
              w: 88,
              h: 41,
              text_size: 40,
              char_space: 0,
              font: 'fonts/sf-pro-rounded.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.WRAP,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 110,
              y: 239,
              w: 70,
              h: 30,
              text_size: 17,
              char_space: 0,
              font: 'fonts/sf-pro-rounded.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 65,
              y: 239,
              w: 74,
              h: 30,
              text_size: 17,
              char_space: 0,
              font: 'fonts/sf-pro-rounded.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 323,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 50,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFFCFCFCF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 323,
              start_angle: 0,
              end_angle: 360,
              radius: 46,
              line_width: 9,
              corner_flag: 0,
              color: 0xFFCFCFCF,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 323,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 35,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFFCFCFCF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 323,
              start_angle: 0,
              end_angle: 360,
              radius: 31,
              line_width: 9,
              corner_flag: 0,
              color: 0xFFCFCFCF,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 121,
              y: 87,
              w: 150,
              h: 43,
              text_size: 34,
              char_space: 0,
              color: 0xFFFF2F2F,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: KON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 124,
              w: 150,
              h: 52,
              text_size: 40,
              char_space: 0,
              font: 'fonts/sf-pro-rounded.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'CHAS.png',
              // center_x: 195,
              // center_y: 225,
              // x: 11,
              // y: 92,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 11,
              pos_y: 225 - 92,
              center_x: 195,
              center_y: 225,
              src: 'CHAS.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'MIN.png',
              // center_x: 195,
              // center_y: 225,
              // x: 9,
              // y: 154,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 9,
              pos_y: 225 - 154,
              center_x: 195,
              center_y: 225,
              src: 'MIN.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            console.log('Watch_Face.Shortcuts');

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 72,
              y: 173,
              w: 100,
              h: 100,
              src: '0057.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 223,
              y: 173,
              w: 100,
              h: 100,
              src: '0057.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 145,
              y: 271,
              w: 100,
              h: 100,
              src: '0057.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 148,
              y: 80,
              w: 100,
              h: 86,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0057.png',
              normal_src: '0057.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 198,
              w: 34,
              h: 61,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0057.png',
              normal_src: '0057.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              if (updateMinute) { // Hour Pointer
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              if (updateMinute) { // Hour Pointer
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*(minute + second/60)/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 323,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 16,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF2DFFFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 323,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 46,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFFFE0E5B,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 323,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 31,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF93FF26,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STAND');
                let progress_cs_idle_stand = progressStand;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_stand * 100);
                  if (idle_stand_circle_scale) {
                    idle_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 323,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 16,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFFCFCFCF,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 323,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 46,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFFCFCFCF,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_calorie * 100);
                  if (idle_calorie_circle_scale) {
                    idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 323,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 31,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFFCFCFCF,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}