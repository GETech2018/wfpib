﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

/// change color 
const W = 390;
const H = 450;

// ===== โหลดค่าสีที่เคยบันทึก =====
let bgColor = hmFS.SysProGetInt("bgColor");
if (bgColor === undefined || bgColor === null) {
  bgColor = 0x003366;
}

// ===== พื้นหลัง =====
let screenType = hmSetting.getScreenType()
let bg = ''
let colorText= ''
if (screenType != hmSetting.screen_type.AOD) {
 bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
  x: 0, y: 0, w: W, h: H, color: bgColor,
});

}

// ===== สร้างสีหลัก 64 สีจาก HSV =====
function hsvToRgb(h) {
  let s = 1, v = 1;
  let c = v * s;
  let x = c * (1 - Math.abs((h / 60) % 2 - 1));
  let m = v - c;

  let r, g, b;
  if (h < 60)      { r = c; g = x; b = 0; }
  else if (h < 120){ r = x; g = c; b = 0; }
  else if (h < 180){ r = 0; g = c; b = x; }
  else if (h < 240){ r = 0; g = x; b = c; }
  else if (h < 300){ r = x; g = 0; b = c; }
  else             { r = c; g = 0; b = x; }

  return [
    Math.floor((r + m) * 255),
    Math.floor((g + m) * 255),
    Math.floor((b + m) * 255),
  ];
}

const baseColors = [];
for (let i = 0; i < 32; i++) {
  const hue = i * (360 / 32);
  baseColors.push(hsvToRgb(hue));
}

// ➕ เพิ่มสีขาวเข้าไป
baseColors.push([255, 255, 255]);

// ===== index (ค่าเริ่มต้นเดิม) =====
let colorIndex = 0;
let levelIndex = 20;

// ===== ไล่ระดับ 40 ขั้น =====
function makeShade(rgb, level) {
  const t = level / 39;
  let r, g, b;

  if (t < 0.5) {
    const k = t * 2;
    r = Math.floor(rgb[0] * k);
    g = Math.floor(rgb[1] * k);
    b = Math.floor(rgb[2] * k);
  } else {
    const k = (t - 0.5) * 2;
    r = Math.floor(rgb[0] + (255 - rgb[0]) * k);
    g = Math.floor(rgb[1] + (255 - rgb[1]) * k);
    b = Math.floor(rgb[2] + (255 - rgb[2]) * k);
  }

  return (r << 16) | (g << 8) | b;
}

// ===== 🔧 Sync colorIndex / levelIndex จาก bgColor ที่โหลดมา =====
function rgbFromInt(c) {
  return [(c >> 16) & 255, (c >> 8) & 255, c & 255];
}

(function syncIndexFromColor() {
  const [R, G, B] = rgbFromInt(bgColor);

  let bestDiff = 1e9;
  let bestColor = 0;
  let bestLevel = 20;

  for (let i = 0; i < baseColors.length; i++) {
    for (let l = 0; l < 40; l++) {
      const c = makeShade(baseColors[i], l);
      const r = (c >> 16) & 255;
      const g = (c >> 8) & 255;
      const b = c & 255;

      const diff =
        (r - R) * (r - R) +
        (g - G) * (g - G) +
        (b - B) * (b - B);

      if (diff < bestDiff) {
        bestDiff = diff;
        bestColor = i;
        bestLevel = l;
      }
    }
  }

  colorIndex = bestColor;
  levelIndex = bestLevel;
})();

function updateColor() {
  const c = makeShade(baseColors[colorIndex], levelIndex);
  bg.setProperty(hmUI.prop.COLOR, c);

  hmFS.SysProSetInt("bgColor", c);   // 👈 จำค่าสี

}


// ===== แสดงสีที่โหลดมา (ไม่ทับ) =====

if (screenType != hmSetting.screen_type.AOD) {
bg.setProperty(hmUI.prop.COLOR, bgColor);
}

//// change color

/// Start 24H /////
let time24 = hmSensor.createSensor(hmSensor.id.TIME);
let normal_24Hcheck =''
let checknum = ''

 function check24h(){
       if (time24.is24Hour){
        checknum = 1
        is24H()
       }

       if (!time24.is24Hour){
       checknum = 2
       isAMPM()
       }
hmFS.SysProSetInt('ampm24h', checknum);
 }

function is24H(){
        normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, true);
}

function isAMPM(){
        normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, false);
}
////////// end 24 icon  /////


///////////////////  weathe animation /////////////////////////////
let weather;
function switchWeatherIconsAnimation() {

// กำหนดค่าตัวแปร weather ให้เก็บข้อมูล เซ็นเซอร์ 
weather = hmSensor.createSensor(hmSensor.id.WEATHER);

// กำหนดค่าตัวแปร curAirIconIndex ให้เก็บค่า ที่ได้จาก  weather.curAirIconIndex ( curAirIconIndex ไม่ใช่ค่าตัวแปร เป็นค่าที่ได้จากsensor )
// ค่านี้จะไม่ทำงานในโปรแกรมจำลอง เมื่อ จำลอง ค่านี้จะเป็น ค่าว่างเปล่า เพราะ โปรแกรมจำลองไม่มี sensor ส่งค่าให้
let curAirIconIndex = weather.curAirIconIndex;

// กำหนด ให้ Folder เก็บค่า folder ของ png ที่จะใช้สร้างเป็น animation 
let Folder = "/W"+parseInt(curAirIconIndex)

if (weather.curAirIconIndex == undefined) { Folder = "/W25"} // ถ้ารับค่าไม่ได้ ให้ Folder เท่ากับ "/W25"

// เนื่องจาก  animation ใช้ more ไม่ได้ จึงต้อง ลบ animation เก่าออกก่อนเพื่อเป็นพื้นว่าง ให้แสดง animation ใหม่ที่จะตามมา
             hmUI.deleteWidget(normal_frame_animation_1);

// element การสร้าง animation 
// เมื่อปิดแล้วสร้างใหม่ widget นี้จะอยู่บนสุด ดังนั้น ถ้าต้องการให้อยู่ต่ำกว่า widget ใด ต้องปิด widget นั้น และเปิดใหม่ หลังจาก  widget animation เปิดแล้ว 

            normal_frame_animation_1= hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 278,
              y: 7,
              anim_path: "animation"+Folder,
              anim_ext: "png",
              anim_prefix: "F",
              anim_fps: 4,
              anim_size: 4,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

// hmUI.showToast({text: "index " + parseInt(curAirIconIndex) });
}

/////////////////// end  Weather animation /////////////////////////////////////

// จากนั้น ประกาศใช้ function switchWeatherIconsAnimation() ใน user_script_end.js และ resume_call.js เพิ่มเปิดใช้งาน และ refresh ทุกครั้งที่หน้าจอปิดและเปิดใหม่



        // Switch activity info.
        let elementnumber_1 = 1
        let total_elemente = 3
        let cc = 0

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

               if(elementnumber_1==3) {
                  UpdateElementeThree();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Steps'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Distance'});
            if(elementnumber_1==3) hmUI.showToast({text: 'Calories'});
        }

        //Steps
        function UpdateElementeOne(){

         normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        }

        //Distance
        function UpdateElementeTwo(){
         normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        }


        //Calorie
        function UpdateElementeThree(){
         normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_TextRotate = new Array(4);
        let normal_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let normal_calorie_TextRotate_img_width = 10;
        let normal_calorie_TextRotate_error_img_width = 10;
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_circle_scale = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 10;
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_frame_animation_1 = ''
        let normal_sun_current_text_img = ''
        let normal_sun_current_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '0_Empty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
            normal_24Hcheck = hmUI.createWidget(hmUI.widget.IMG, {
              x: 42,
              y: 306,
              src: 'Clock_24H.png',
             show_level: hmUI.show_level.ONLY_NORMAL,
            });


//check24h()
            // end user_script.js

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 26,
              month_startY: 69,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 107,
              day_startY: 36,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 33,
              y: 36,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 332,
              // center_y: 310,
              // start_angle: 211,
              // end_angle: 508,
              // radius: 45,
              // line_width: 15,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 181,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 332,
              center_y: 310,
              start_angle: 508,
              end_angle: 211,
              radius: 38,
              line_width: 15,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_circle_scale.setAlpha(181);
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 333,
              // y: 312,
              // font_array: ["ActWhite_0.png","ActWhite_1.png","ActWhite_2.png","ActWhite_3.png","ActWhite_4.png","ActWhite_5.png","ActWhite_6.png","ActWhite_7.png","ActWhite_8.png","ActWhite_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // invalid_image: 'ActWhite_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextRotate_ASCIIARRAY[0] = 'ActWhite_0.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = 'ActWhite_1.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = 'ActWhite_2.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = 'ActWhite_3.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = 'ActWhite_4.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = 'ActWhite_5.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = 'ActWhite_6.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = 'ActWhite_7.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = 'ActWhite_8.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = 'ActWhite_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 333,
                center_y: 312,
                pos_x: 333,
                pos_y: 312,
                angle: 0,
                src: 'ActWhite_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 380,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Cal_unit.png',
              unit_tc: 'Cal_unit.png',
              unit_en: 'Cal_unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 59,
              y: 371,
              src: 'icon_calories.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 380,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 43,
              y: 377,
              src: 'icon_Steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 231,
              // center_y: 310,
              // start_angle: 211,
              // end_angle: 508,
              // radius: 45,
              // line_width: 15,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 181,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 231,
              center_y: 310,
              start_angle: 508,
              end_angle: 211,
              radius: 38,
              line_width: 15,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_circle_scale.setAlpha(181);
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 231,
              // y: 318,
              // font_array: ["ActWhite_0.png","ActWhite_1.png","ActWhite_2.png","ActWhite_3.png","ActWhite_4.png","ActWhite_5.png","ActWhite_6.png","ActWhite_7.png","ActWhite_8.png","ActWhite_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'ActWhite_0.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'ActWhite_1.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'ActWhite_2.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'ActWhite_3.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'ActWhite_4.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'ActWhite_5.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'ActWhite_6.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'ActWhite_7.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'ActWhite_8.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'ActWhite_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 231,
                center_y: 318,
                pos_x: 231,
                pos_y: 318,
                angle: 0,
                src: 'ActWhite_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 138,
              y: 380,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 49,
              y: 376,
              src: 'icon_Steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 336,
              // center_y: 192,
              // start_angle: 211,
              // end_angle: 508,
              // radius: 52,
              // line_width: 15,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 181,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 336,
              center_y: 192,
              start_angle: 508,
              end_angle: 211,
              radius: 45,
              line_width: 15,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale.setAlpha(181);
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 175,
              font_array: ["Power_0.png","Power_1.png","Power_2.png","Power_3.png","Power_4.png","Power_5.png","Power_6.png","Power_7.png","Power_8.png","Power_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 230,
              // center_y: 192,
              // start_angle: 211,
              // end_angle: 508,
              // radius: 52,
              // line_width: 15,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 181,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 230,
              center_y: 192,
              start_angle: 508,
              end_angle: 211,
              radius: 45,
              line_width: 15,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale.setAlpha(181);
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 178,
              font_array: ["Power_0.png","Power_1.png","Power_2.png","Power_3.png","Power_4.png","Power_5.png","Power_6.png","Power_7.png","Power_8.png","Power_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Power_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 203,
              y: 26,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 286,
              y: 102,
              font_array: ["Power_0.png","Power_1.png","Power_2.png","Power_3.png","Power_4.png","Power_5.png","Power_6.png","Power_7.png","Power_8.png","Power_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_Unit.png',
              unit_tc: 'Temp_Unit.png',
              unit_en: 'Temp_Unit.png',
              imperial_unit_sc: 'Temp_Unit.png',
              imperial_unit_tc: 'Temp_Unit.png',
              imperial_unit_en: 'Temp_Unit.png',
              negative_image: 'Temp_minus.png',
              invalid_image: 'Temp_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 286,
                y: 102,
                font_array: ["Power_0.png","Power_1.png","Power_2.png","Power_3.png","Power_4.png","Power_5.png","Power_6.png","Power_7.png","Power_8.png","Power_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Temp_Unit.png',
                unit_tc: 'Temp_Unit.png',
                unit_en: 'Temp_Unit.png',
                imperial_unit_sc: 'Temp_Unit.png',
                imperial_unit_tc: 'Temp_Unit.png',
                imperial_unit_en: 'Temp_Unit.png',
                negative_image: 'Temp_minus.png',
                invalid_image: 'Temp_minus.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 278,
              y: 7,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "F",
              anim_fps: 4,
              anim_size: 4,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 114,
              font_array: ["SS_0.png","SS_1.png","SS_2.png","SS_3.png","SS_4.png","SS_5.png","SS_6.png","SS_7.png","SS_8.png","SS_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'SS_dot.png',
              dot_image: 'SS_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 93,
              src: 'ss_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 42,
              am_y: 306,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 42,
              pm_y: 306,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 19,
              minute_startY: 201,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: -3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 19,
              hour_startY: 99,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: -3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 60,
              y: 330,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 108,
              y: 330,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 246,
              y: 19,
              font_array: ["Power_0.png","Power_1.png","Power_2.png","Power_3.png","Power_4.png","Power_5.png","Power_6.png","Power_7.png","Power_8.png","Power_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'batt_unit.png',
              unit_tc: 'batt_unit.png',
              unit_en: 'batt_unit.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 219,
              minute_startY: 175,
              minute_array: ["AOD_0.png","AOD_1.png","AOD_2.png","AOD_3.png","AOD_4.png","AOD_5.png","AOD_6.png","AOD_7.png","AOD_8.png","AOD_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 155,
              y: 159,
              src: 'AOD_DOT.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 8,
              hour_startY: 175,
              hour_array: ["AOD_0.png","AOD_1.png","AOD_2.png","AOD_3.png","AOD_4.png","AOD_5.png","AOD_6.png","AOD_7.png","AOD_8.png","AOD_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 275,
              w: 58,
              h: 73,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 210,
              y: 216,
              w: 43,
              h: 44,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 290,
              y: 281,
              w: 51,
              h: 70,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 95,
              w: 68,
              h: 41,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 204,
              y: 32,
              w: 53,
              h: 52,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 298,
              y: 93,
              w: 59,
              h: 44,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 153,
              w: 75,
              h: 50,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 43,
              y: 221,
              w: 100,
              h: 56,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 43,
              y: 119,
              w: 100,
              h: 57,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 92,
              y: 320,
              w: 53,
              h: 38,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 3,
              y: 311,
              w: 32,
              h: 54,
              text: '',
              color: 0xFFFF8C00,
              text_size: 18,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //color up
    colorIndex--;
    if (colorIndex < 0) colorIndex = baseColors.length - 1;
    levelIndex = 20;
    updateColor();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 5,
              y: 368,
              w: 31,
              h: 56,
              text: '',
              color: 0xFFFF8C00,
              text_size: 18,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //colordown
    colorIndex++;
    if (colorIndex >= baseColors.length) colorIndex = 0;
    levelIndex = 20;
    updateColor();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 357,
              y: 312,
              w: 33,
              h: 54,
              text: '',
              color: 0xFFFF8C00,
              text_size: 18,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //shade up
    levelIndex++;
    if (levelIndex > 39) levelIndex = 0;
    updateColor();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 358,
              y: 368,
              w: 33,
              h: 54,
              text: '',
              color: 0xFFFF8C00,
              text_size: 18,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //shade down
    levelIndex--;
    if (levelIndex < 0) levelIndex = 39;
    updateColor();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 49,
              y: 375,
              w: 87,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 18,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_elemente()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 309,
              y: 161,
              w: 56,
              h: 59,
              text: '',
              color: 0xFFFF8C00,
              text_size: 18,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 44,
              y: 35,
              w: 98,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 18,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 170,
              y: 383,
              w: 164,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 18,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js



if(hmFS.SysProGetInt('ampm24h') == 1) {
                  is24H();}

if(hmFS.SysProGetInt('ampm24h') == 2) {
                  isAMPM();}


// ประกาศใช้ function switchWeatherIconsAnimation() ใน user_script_end.js และ resume_call.js 
//เพิ่มเปิดใช้งาน และ refresh ทุกครั้งที่หน้าจอปิดและเปิดใหม่
switchWeatherIconsAnimation()


/// one time process 
if ( cc == 0) {
UpdateElementeOne()
cc = 1
}
            // end user_script_end.js

            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_rotate_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_rotate_string.length > 0 && normal_calorie_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_calorie_TextRotate_posOffset = normal_calorie_TextRotate_img_width * normal_calorie_rotate_string.length;
                  img_offset -= normal_calorie_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 333 + img_offset);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, normal_calorie_TextRotate_ASCIIARRAY[charCode]);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_calorie_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_calorie_TextRotate[0].setProperty(hmUI.prop.POS_X, 333 - normal_calorie_TextRotate_error_img_width / 2);
                  normal_calorie_TextRotate[0].setProperty(hmUI.prop.SRC, 'ActWhite_0.png');
                  normal_calorie_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 231 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = 1 - progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 332,
                      center_y: 310,
                      start_angle: 508,
                      end_angle: 211,
                      radius: 38,
                      line_width: 15,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 231,
                      center_y: 310,
                      start_angle: 508,
                      end_angle: 211,
                      radius: 38,
                      line_width: 15,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 336,
                      center_y: 192,
                      start_angle: 508,
                      end_angle: 211,
                      radius: 45,
                      line_width: 15,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 184;
                let progressHeartRate = (valueHeartRate - 30)/(targetHeartRate - 30);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = 1 - progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 230,
                      center_y: 192,
                      start_angle: 508,
                      end_angle: 211,
                      radius: 45,
                      line_width: 15,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

                console.log('resume_call.js');
                // start resume_call.js

// ประกาศใช้ function switchWeatherIconsAnimation() ใน user_script_end.js และ resume_call.js 
//เพิ่มเปิดใช้งาน และ refresh ทุกครั้งที่หน้าจอปิดและเปิดใหม่
switchWeatherIconsAnimation()
// end switch weather

check24h()
	
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

                console.log('pause_call.js');
                // start pause_call.js

// ปิด widget animation เพื่อประหยัดพลังงานเมื่อจดดับลง
hmUI.deleteWidget(normal_frame_animation_1);
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}