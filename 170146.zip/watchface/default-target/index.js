try {
    ((() => {
        const {beforeModuleCreate = () => {
            }, afterModuleCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforeModuleCreate();
        const {beforePageCreate = () => {
            }, afterPageCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforePageCreate();
        const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__;
        !function (context) {
            with (context) {
                const __$$RQR$$__ = __$$R$$__;
                const utils = __$$RQR$$__('@zos/utils');
                const hmUI = __$$RQR$$__('@zos/ui');
                const _interopDefaultCompat = e => e && typeof e === 'object' && 'default' in e ? e : { default: e };
                const hmUI__default = _interopDefaultCompat(hmUI);
                const logger = utils.log.getLogger('watchface');
                __$$module$$__.module = WatchFace({
                    initView() {
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG, {
                            x: 0,
                            y: 0,
                            w: 390,
                            h: 465,
                            src: '2.png',
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG, {
                            x: 0,
                            y: 0,
                            src: '3.png',
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_DATE, {
                            day_startX: 239,
                            day_startY: 337,
                            day_sc_array: [
                                '4.png',
                                '5.png',
                                '6.png',
                                '7.png',
                                '8.png',
                                '9.png',
                                '10.png',
                                '11.png',
                                '12.png',
                                '13.png'
                            ],
                            day_tc_array: [
                                '4.png',
                                '5.png',
                                '6.png',
                                '7.png',
                                '8.png',
                                '9.png',
                                '10.png',
                                '11.png',
                                '12.png',
                                '13.png'
                            ],
                            day_en_array: [
                                '4.png',
                                '5.png',
                                '6.png',
                                '7.png',
                                '8.png',
                                '9.png',
                                '10.png',
                                '11.png',
                                '12.png',
                                '13.png'
                            ],
                            day_align: hmUI__default.default.align.LEFT,
                            day_zero: 1,
                            day_follow: 0,
                            day_space: 0,
                            day_is_character: false,
                            enable: false,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_WEEK, {
                            x: 151,
                            y: 337,
                            week_en: [
                                '14.png',
                                '15.png',
                                '16.png',
                                '17.png',
                                '18.png',
                                '19.png',
                                '20.png'
                            ],
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 319,
                            y: 310,
                            type: hmUI__default.default.data_type.BATTERY,
                            font_array: [
                                '21.png',
                                '22.png',
                                '23.png',
                                '24.png',
                                '25.png',
                                '26.png',
                                '27.png',
                                '28.png',
                                '29.png',
                                '30.png'
                            ],
                            align_h: hmUI__default.default.align.LEFT,
                            h_space: -9,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            unit_sc: '31.png',
                            unit_tc: '31.png',
                            unit_en: '31.png',
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 16,
                            y: 45,
                            w: 112,
                            h: 38,
                            type: hmUI__default.default.data_type.HEART,
                            font_array: [
                                '32.png',
                                '33.png',
                                '34.png',
                                '35.png',
                                '36.png',
                                '37.png',
                                '38.png',
                                '39.png',
                                '40.png',
                                '41.png'
                            ],
                            align_h: hmUI__default.default.align.CENTER_H,
                            h_space: -10,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            invalid_image: '42.png',
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 173,
                            y: 27,
                            type: hmUI__default.default.data_type.BIO_CHARGE,
                            font_array: [
                                '43.png',
                                '44.png',
                                '45.png',
                                '46.png',
                                '47.png',
                                '48.png',
                                '49.png',
                                '50.png',
                                '51.png',
                                '52.png'
                            ],
                            align_h: hmUI__default.default.align.LEFT,
                            h_space: -12,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            invalid_image: '53.png',
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 47,
                            y: 310,
                            type: hmUI__default.default.data_type.WEATHER_CURRENT,
                            font_array: [
                                '32.png',
                                '33.png',
                                '34.png',
                                '35.png',
                                '36.png',
                                '37.png',
                                '38.png',
                                '39.png',
                                '40.png',
                                '41.png'
                            ],
                            align_h: hmUI__default.default.align.LEFT,
                            h_space: -10,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            unit_sc: '55.png',
                            unit_tc: '55.png',
                            unit_en: '55.png',
                            negative_image: '54.png',
                            invalid_image: '42.png',
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 341,
                            y: 45,
                            type: hmUI__default.default.data_type.STRESS,
                            font_array: [
                                '32.png',
                                '33.png',
                                '34.png',
                                '35.png',
                                '36.png',
                                '37.png',
                                '38.png',
                                '39.png',
                                '40.png',
                                '41.png'
                            ],
                            align_h: hmUI__default.default.align.LEFT,
                            h_space: -10,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            invalid_image: '42.png',
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 143,
                            y: 402,
                            w: 145,
                            h: 42,
                            type: hmUI__default.default.data_type.STEP,
                            font_array: [
                                '56.png',
                                '57.png',
                                '58.png',
                                '59.png',
                                '60.png',
                                '61.png',
                                '62.png',
                                '63.png',
                                '64.png',
                                '65.png'
                            ],
                            align_h: hmUI__default.default.align.CENTER_H,
                            h_space: -10,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            invalid_image: '66.png',
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 18,
                            y: 402,
                            type: hmUI__default.default.data_type.DISTANCE,
                            font_array: [
                                '67.png',
                                '68.png',
                                '69.png',
                                '70.png',
                                '71.png',
                                '72.png',
                                '73.png',
                                '74.png',
                                '75.png',
                                '76.png'
                            ],
                            align_h: hmUI__default.default.align.LEFT,
                            h_space: -11,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            unit_sc: '78.png',
                            unit_tc: '78.png',
                            unit_en: '78.png',
                            imperial_unit_sc: '79.png',
                            imperial_unit_tc: '79.png',
                            imperial_unit_en: '79.png',
                            dot_image: '77.png',
                            invalid_image: '66.png',
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 296,
                            y: 402,
                            w: 118,
                            h: 42,
                            type: hmUI__default.default.data_type.CAL,
                            font_array: [
                                '56.png',
                                '57.png',
                                '58.png',
                                '59.png',
                                '60.png',
                                '61.png',
                                '62.png',
                                '63.png',
                                '64.png',
                                '65.png'
                            ],
                            align_h: hmUI__default.default.align.CENTER_H,
                            h_space: -10,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            invalid_image: '66.png',
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_TIME, {
                            hour_zero: 1,
                            hour_startX: 12,
                            hour_startY: 131,
                            hour_array: [
                                '80.png',
                                '81.png',
                                '82.png',
                                '83.png',
                                '84.png',
                                '85.png',
                                '86.png',
                                '87.png',
                                '88.png',
                                '89.png'
                            ],
                            hour_space: -27,
                            hour_align: hmUI__default.default.align.LEFT,
                            minute_zero: 1,
                            minute_startX: 226,
                            minute_startY: 131,
                            minute_array: [
                                '90.png',
                                '91.png',
                                '92.png',
                                '93.png',
                                '94.png',
                                '95.png',
                                '96.png',
                                '97.png',
                                '98.png',
                                '99.png'
                            ],
                            minute_space: -27,
                            minute_align: hmUI__default.default.align.LEFT,
                            minute_follow: 0,
                            second_zero: 1,
                            second_startX: 198,
                            second_startY: 300,
                            second_array: [
                                '100.png',
                                '101.png',
                                '102.png',
                                '103.png',
                                '104.png',
                                '105.png',
                                '106.png',
                                '107.png',
                                '108.png',
                                '109.png'
                            ],
                            second_space: 0,
                            second_align: hmUI__default.default.align.LEFT,
                            second_follow: 0,
                            enable: false,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG, {
                            x: 204,
                            y: 134,
                            w: 22,
                            h: 140,
                            src: '110.png',
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_CLICK, {
                            x: 320,
                            y: 296,
                            w: 88,
                            h: 88,
                            type: hmUI__default.default.data_type.BATTERY,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_CLICK, {
                            x: 22,
                            y: 32,
                            w: 118,
                            h: 80,
                            type: hmUI__default.default.data_type.HEART,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_CLICK, {
                            x: 144,
                            y: 28,
                            w: 144,
                            h: 84,
                            type: hmUI__default.default.data_type.BIO_CHARGE,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_CLICK, {
                            x: 24,
                            y: 296,
                            w: 112,
                            h: 88,
                            type: hmUI__default.default.data_type.WEATHER_CURRENT,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_CLICK, {
                            x: 292,
                            y: 32,
                            w: 118,
                            h: 80,
                            type: hmUI__default.default.data_type.STRESS,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_CLICK, {
                            x: 143,
                            y: 397,
                            w: 149,
                            h: 109,
                            type: hmUI__default.default.data_type.STEP,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_CLICK, {
                            x: 18,
                            y: 397,
                            w: 121,
                            h: 109,
                            type: hmUI__default.default.data_type.DISTANCE,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_CLICK, {
                            x: 296,
                            y: 397,
                            w: 118,
                            h: 109,
                            type: hmUI__default.default.data_type.CAL,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                    },
                    onInit() {
                        logger.log('index page.js on init invoke');
                    },
                    build() {
                        logger.log('index page.js on build invoke');
                        this.initView();
                    },
                    onDestroy() {
                        logger.log('index page.js on destroy invoke');
                    }
                });
                ;
            }
        }.bind(__$$G$$__)(__$$G$$__);
        afterPageCreate();
        afterModuleCreate();
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}