try {
    (() => {
    
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
  
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
  
      /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
    'use strict';
  
    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let weekScArray = []
    let weekEnArray = []
    let img_bg =null
    let dateArray = []
    let numArray = []
    let dataArray = []
    let hourArray = []
    let minArray = []
    let paiArray =[]
    let uviArray =[]
    let weatherArray =[]
    let alexaImg = null
    const  ROOTPATH = "images/"
   
   
    const logger = DeviceRuntimeCore.HmLogger.getLogger("defult");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        
        init_view() {

           
            creatAllArr();
            img_bg = hmUI.createWidget(hmUI.widget.IMG,{
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                src: ROOTPATH + "img/bg.png",
            });  
            let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, {

                hour_zero:1, //是否补零
                hour_startX:97,
                hour_startY:205,
                hour_array:hourArray,
                hour_space:0, //每个数组间的间隔
                //单位
                //hour_unit_sc: ROOTPATH+"hour/colon.png", 
                //hour_unit_tc: ROOTPATH+"hour/colon.png",
                //hour_unit_en: ROOTPATH+"hour/colon.png",
                hour_align:hmUI.align.LEFT,
                hour_follow:0,

                minute_zero:1, //是否补零
                minute_startX:204,
                minute_startY:205,
                minute_array:minArray,
                minute_space:0, //每个数组间的间隔
                minute_align:hmUI.align.LEFT,
                minute_follow:0,
                /*
                am_x:200,
                am_y:100,
                am_sc_path:"img/am.png",
                am_en_path:"img/am_en.png",
                pm_x:200,
                pm_y:100,
                pm_sc_path:"img/pm.png",
                pm_en_path:"img/pm_en.png",
                */
                });
          
            var screenType = hmSetting.getScreenType();
            if(screenType == hmSetting.screen_type.AOD){
                img_bg.setProperty(hmUI.prop.SRC, ROOTPATH + "img/bg_xp.png");   

            }else{ // if(screenType == hmSetting.screen_type.WATCHFACE)     
                let date = hmUI.createWidget(hmUI.widget.IMG_DATE,{
                    year_startX: 125,
                    year_startY: 276 ,
                    year_align: hmUI.align.LEFT,
                    year_space: 0,
                    year_zero: 1,
                    year_unit_sc: ROOTPATH+ "date/line.png", 
                    year_unit_tc: ROOTPATH+"date/line.png", 
                    year_unit_en: ROOTPATH+"date/line.png", 
                  
                    year_en_array: dateArray,
                    year_sc_array: dateArray,
                    year_tc_array: dateArray,
    
                    //month_startX: 270,
                    //month_startY: 226 ,
                    month_align: hmUI.align.LEFT,
                    month_space: 0,
                    month_zero: 1,
                    month_follow: 1,
                   
                    month_en_array: dateArray,
                    month_sc_array: dateArray,
                    month_tc_array: dateArray,
                    month_unit_sc: ROOTPATH+ "date/line.png", 
                    month_unit_tc: ROOTPATH+ "date/line.png", 
                    month_unit_en: ROOTPATH+ "date/line.png", 
                   
                    //day_startX: 345,
                    //day_startY: 199,
                    day_en_array: dateArray,
                    day_sc_array: dateArray,
                    day_tc_array: dateArray,
                    day_space: 0,
                    day_zero: 1,
                    day_follow: 1,
                    day_align: hmUI.align.LEFT,
                    show_level:hmUI.show_level.ONLY_NORMAL,
                });
               let weekLevel=hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 78,
                    y: 144,
                    w:226,
                    h:42,
                    week_sc: weekScArray,
                    week_tc: weekScArray,
                    week_en: weekEnArray,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                
                let heartTxt =hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                    x:46, 
                    y:88,
                    type:hmUI.data_type.HEART,
                    font_array: dataArray ,
                    align_h:hmUI.align.CENTER_H,
                    invalid_image: ROOTPATH + "data/invalid.png",
                    // 无数据时显示的图片
                    padding:false, 
                    show_level:hmUI.show_level.ONLY_NORMAL,
                })
                let heartClick = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
                    x:49,
                    y:45,
                    w:56,
                    h:73,
                    type: hmUI.data_type.HEART, //必写 跳转的action
                });
                let batTxt =hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                    x:286, 
                    y:88,
                    type:hmUI.data_type.BATTERY,
                    font_array: dataArray ,
                    align_h:hmUI.align.CENTER_H,
                    padding:false, 
                    show_level:hmUI.show_level.ONLY_NORMAL,
                })
                let weatherPointer = hmUI.createWidget(hmUI.widget.IMG_POINTER,{
                    x: 12,
                    y: 62,
                    center_x: 196,
                    center_y: 72,
                    start_angle: -155,
                    end_angle: 155,
                    src: ROOTPATH + "img/weatherPointer.png",
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level:hmUI.show_level.ONLY_NORMAL,
                });
                let weatherTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                    x:166, 
                    y:78,
                    type:hmUI.data_type.WEATHER_CURRENT,
                    font_array: dateArray,
                    align_h:hmUI.align.CENTER_H,
                    unit_sc: ROOTPATH + "data/du.png",
                    unit_tc: ROOTPATH + "data/du.png",
                    unit_en: ROOTPATH + "data/du.png",
                    negative_image:  ROOTPATH + "date/line.png", 
                    invalid_image: ROOTPATH + "data/invalid.png",
                    padding:false, 
                    show_level:hmUI.show_level.ONLY_NORMAL,
                });
                let weatherLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL,{
                    x: 175,
                    y: 35,
                    w: 40, 
                    h: 40,
                    image_array: weatherArray,
                    image_length:weatherArray.length,//长度
                    type: hmUI.data_type.WEATHER_CURRENT,
                    shortcut: true, // optional, 默认为false, 表示是否使能快捷跳转功能
                    show_level:hmUI.show_level.ONLY_NORMAL,
                });
               
                let stepTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                    x:32, 
                    y:346,
                    type:hmUI.data_type.STEP,
                    font_array: dataArray ,
                    align_h:hmUI.align.CENTER_H,
                    //invalid_image:"data/invalid.png",
                    // 无数据时显示的图片
                    padding:false, 
                    show_level:hmUI.show_level.ONLY_NORMAL,
                })
                
                let calTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                    x:280, 
                    y:342,
                    type:hmUI.data_type.CAL,
                    font_array: dataArray ,
                    align_h:hmUI.align.CENTER_H,
                    //invalid_image:"data/invalid.png",
                    // 无数据时显示的图片
                    padding:false, 
                    show_level:hmUI.show_level.ONLY_NORMAL,
                })
                let calClick = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
                    x: 290,
                    y: 342,
                    w: 51,
                    h: 76,
                    type:hmUI.data_type.CAL, //必写 跳转的action
                    });
                let uviLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 12,
                    y: 164,
                    w: 10, 
                    h: 148,
                    image_array: uviArray,
                    image_length: uviArray.length,
                    type: hmUI.data_type.UVI,
                    //shortcut: true, 
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                let uviTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                    x:30, 
                    y:244,
                    type:hmUI.data_type.UVI,
                    font_array: dateArray ,
                    align_h:hmUI.align.CENTER_H,
                    invalid_image: ROOTPATH + "little_num/invalid.png",
                    padding:false, 
                    show_level:hmUI.show_level.ONLY_NORMAL,
                })
                let uviClick = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
                    x: 12,
                    y: 165,
                    w: 48,
                    h: 148,
                    type:hmUI.data_type.UVI, //必写 跳转的action
                    });
                let paiLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 368,
                    y: 165,
                    w: 10, 
                    h: 148,
                    image_array: paiArray,
                    image_length: paiArray.length,
                    type: hmUI.data_type.PAI_WEEKLY,
                    //shortcut: true, 
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                let paiTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG,{
                    x: 325, 
                    y: 243,
                    type:hmUI.data_type.PAI_WEEKLY,
                    font_array: dateArray ,
                    align_h:hmUI.align.CENTER_H,
                   // invalid_image:"data/invalid.png",
                    padding:false, 
                    show_level:hmUI.show_level.ONLY_NORMAL,
                })
                let weatherClick = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
                    x:  145,
                    y: 22,
                    w: 100,
                    h: 100,
                    type:hmUI.data_type.WEATHER_CURRENT,
                });
                let batClick = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
                    x: 270,
                    y: 42,
                    w: 103,
                    h: 77,
                    type:hmUI.data_type.BATTERY,
                });
                let stepClick = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
                    x: 36,
                    y: 342,
                    w: 83,
                    h: 77,
                    type:hmUI.data_type.STEP, 
                });
                let paiClick = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
                    x: 330,
                    y: 165,
                    w: 48,
                    h: 148,
                    type:hmUI.data_type.PAI_WEEKLY, 
                });
               
              
                let alexaBtn = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
                        x: 145,
                        y: 328,
                        w: 100,
                        h: 100,
                        type: hmUI.data_type.ALEXA, 
                });

                
            }

  

       
            function creatAllArr()
            {
                for(let n=0; n<=28; n++)
                {
                    weatherArray.push( ROOTPATH + "weather/"+n+".png");
                    if(n<=9)
                    {
                        dataArray.push( ROOTPATH + "data/"+n+".png");
                        dateArray.push( ROOTPATH + "date/"+n+".png");
                        hourArray.push( ROOTPATH + "hour/"+n+".png");
                        minArray.push( ROOTPATH + "min/"+n+".png");
                        paiArray.push( ROOTPATH + "pai_progress/"+n+".png");
                        uviArray.push( ROOTPATH + "uvi_progress/"+n+".png");
                        numArray.push( ROOTPATH + "little_num/"+n+".png");
                    }
                    if(n>=1 && n<=7)
                    {
                        weekScArray.push( ROOTPATH + "week_sc/"+n+".png");
                        weekEnArray.push( ROOTPATH + "week_en/"+n+".png");
                    }
                    
                }
            }
        },

        onInit() {
            console.log('index page.js on init invoke');

            this.init_view();

            
        },

        onReady() {
            console.log('index page.js on ready invoke')
        },

        onShow() {
            console.log('index page.js on show invoke')
        },

        onHide() {
            console.log('index page.js on hide invoke')
        },

        onDestory() {
            console.log('index page.js on destory invoke')
        },
    });
    /*
    * end js
    */
        })()
    } catch (e) {
        console.log(e)
    }