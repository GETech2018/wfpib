﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

        let backgroundImgDark = false
        let clockDigitsLight = ["HOUR_DIGITS_0.png", "HOUR_DIGITS_1.png", "HOUR_DIGITS_2.png", "HOUR_DIGITS_3.png", "HOUR_DIGITS_4.png", "HOUR_DIGITS_5.png", "HOUR_DIGITS_6.png", "HOUR_DIGITS_7.png", "HOUR_DIGITS_8.png", "HOUR_DIGITS_9.png"];
        let clockDigitsDark = ["HOUR_DIGITS_AOD_0.png", "HOUR_DIGITS_AOD_1.png", "HOUR_DIGITS_AOD_2.png", "HOUR_DIGITS_AOD_3.png", "HOUR_DIGITS_AOD_4.png", "HOUR_DIGITS_AOD_5.png", "HOUR_DIGITS_AOD_6.png", "HOUR_DIGITS_AOD_7.png", "HOUR_DIGITS_AOD_8.png", "HOUR_DIGITS_AOD_9.png"];

        function click_Background() {
            if (backgroundImgDark == false) {

                backgroundImgDark = true
                hmUI.showToast({text: "Dark" });
                set_ClockFace(true);
            } else {
                backgroundImgDark = false
                hmUI.showToast({text: "Light" });
                set_ClockFace(false);
            }
        }

        function set_ClockFace(dark = false) {
            hmFS.SysProSetInt('INFO_bg_dark', dark ? 1 : 0);

            normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                hour_startX: 99,
                hour_startY: 106,
                hour_array: dark ? clockDigitsDark : clockDigitsLight,
                hour_zero: 1,
                hour_space: -20,
                hour_angle: 0,
                hour_align: hmUI.align.RIGHT,

                minute_startX: 159,
                minute_startY: 106,
                minute_array: dark ? clockDigitsDark : clockDigitsLight,
                minute_zero: 1,
                minute_space: -20,
                minute_angle: 0,
                minute_follow: 0,
                minute_align: hmUI.align.CENTER_H,

                second_startX: 221,
                second_startY: 106,
                second_array: dark ? clockDigitsDark : clockDigitsLight,
                second_zero: 1,
                second_space: -20,
                second_angle: 0,
                second_follow: 0,
                second_align: hmUI.align.LEFT,

                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.MORE, {
              x: 141,
              y: 101,
              src: dark ? "HOUR_DIGITS_AOD__.png" : "HOUR_DIGITS__.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.MORE, {
              x: 203,
              y: 101,
              src: dark ? "HOUR_DIGITS_AOD__.png" : "HOUR_DIGITS__.png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_background_bg_img.setProperty(hmUI.prop.SRC, dark ? "BG_AOD.png" : "BG.png");
        }

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_uvi_pointer_progress_img_pointer = ''
        let normal_stand_circle_scale = ''
        let normal_calorie_circle_scale = ''
        let normal_step_circle_scale = ''
        let normal_temperature_high_TextRotate = new Array(4);
        let normal_temperature_high_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_high_TextRotate_img_width = 32;
        let normal_temperature_high_TextRotate_unit = null;
        let normal_temperature_high_TextRotate_unit_width = 28;
        let normal_temperature_high_TextRotate_dot_width = 28;
        let normal_temperature_low_TextRotate = new Array(4);
        let normal_temperature_low_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_low_TextRotate_img_width = 32;
        let normal_temperature_low_TextRotate_unit = null;
        let normal_temperature_low_TextRotate_unit_width = 28;
        let normal_temperature_low_TextRotate_dot_width = 28;
        let normal_temperature_current_TextRotate = new Array(4);
        let normal_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_current_TextRotate_img_width = 46;
        let normal_temperature_current_TextRotate_unit = null;
        let normal_temperature_current_TextRotate_unit_width = 29;
        let normal_temperature_current_TextRotate_dot_width = 46;
        let normal_temperature_current_TextRotate_error_img_width = 46;
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 46;
        let normal_battery_circle_scale = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 46;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 45;
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_background_bg_img = ''
        let idle_day_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let idle_uvi_pointer_progress_img_pointer = ''
        let idle_stand_circle_scale = ''
        let idle_calorie_circle_scale = ''
        let idle_step_circle_scale = ''
        let idle_temperature_high_TextRotate = new Array(4);
        let idle_temperature_high_TextRotate_ASCIIARRAY = new Array(10);
        let idle_temperature_high_TextRotate_img_width = 32;
        let idle_temperature_high_TextRotate_unit = null;
        let idle_temperature_high_TextRotate_unit_width = 28;
        let idle_temperature_high_TextRotate_dot_width = 28;
        let idle_temperature_low_TextRotate = new Array(4);
        let idle_temperature_low_TextRotate_ASCIIARRAY = new Array(10);
        let idle_temperature_low_TextRotate_img_width = 32;
        let idle_temperature_low_TextRotate_unit = null;
        let idle_temperature_low_TextRotate_unit_width = 28;
        let idle_temperature_low_TextRotate_dot_width = 28;
        let idle_temperature_current_TextRotate = new Array(4);
        let idle_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let idle_temperature_current_TextRotate_img_width = 46;
        let idle_temperature_current_TextRotate_unit = null;
        let idle_temperature_current_TextRotate_unit_width = 29;
        let idle_temperature_current_TextRotate_dot_width = 46;
        let idle_temperature_current_TextRotate_error_img_width = 46;
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_heart_rate_TextRotate = new Array(3);
        let idle_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextRotate_img_width = 46;
        let idle_battery_circle_scale = ''
        let idle_battery_TextRotate = new Array(3);
        let idle_battery_TextRotate_ASCIIARRAY = new Array(10);
        let idle_battery_TextRotate_img_width = 46;
        let idle_battery_TextRotate_unit = null;
        let idle_battery_TextRotate_unit_width = 45;
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SF-Compact-Rounded-Medium_compressed.ttf; FontSize: 60
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 770,
              h: 85,
              text_size: 60,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF-Compact-Rounded-Medium_compressed.ttf; FontSize: 25; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 30,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
              color: 0xFFF64346,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 308,
              w: 150,
              h: 55,
              text_size: 60,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 121,
              y: 283,
              w: 149,
              h: 30,
              text_size: 25,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
              color: 0xFFF64346,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'rec.png',
              center_x: 191,
              center_y: 224,
              x: -155,
              y: 112,
              start_angle: -223,
              end_angle: -189,
              invalid_visible: false,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 282,
              // center_y: 225,
              // start_angle: 0,
              // end_angle: 359,
              // radius: 24,
              // line_width: 11,
              // line_cap: Rounded,
              // color: 0xFF75F1D9,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 282,
              center_y: 225,
              start_angle: 0,
              end_angle: 359,
              radius: 19,
              line_width: 11,
              corner_flag: 0,
              color: 0xFF75F1D9,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 282,
              // center_y: 225,
              // start_angle: 0,
              // end_angle: 359,
              // radius: 38,
              // line_width: 11,
              // line_cap: Rounded,
              // color: 0xFFBFFD50,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 282,
              center_y: 225,
              start_angle: 0,
              end_angle: 359,
              radius: 33,
              line_width: 11,
              corner_flag: 0,
              color: 0xFFBFFD50,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 282,
              // center_y: 225,
              // start_angle: 0,
              // end_angle: 359,
              // radius: 52,
              // line_width: 11,
              // line_cap: Rounded,
              // color: 0xFFDE385A,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 282,
              center_y: 225,
              start_angle: 0,
              end_angle: 359,
              radius: 47,
              line_width: 11,
              corner_flag: 0,
              color: 0xFFDE385A,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_temperature_high_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 146,
              // y: 396,
              // font_array: ["digits_size_22_orange_0.png","digits_size_22_orange_1.png","digits_size_22_orange_2.png","digits_size_22_orange_3.png","digits_size_22_orange_4.png","digits_size_22_orange_5.png","digits_size_22_orange_6.png","digits_size_22_orange_7.png","digits_size_22_orange_8.png","digits_size_22_orange_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: 2,
              // unit_en: 'simbolos_naranja__.png',
              // dot_image: 'simbolos_naranja_-.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_high_TextRotate_ASCIIARRAY[0] = 'digits_size_22_orange_0.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[1] = 'digits_size_22_orange_1.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[2] = 'digits_size_22_orange_2.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[3] = 'digits_size_22_orange_3.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[4] = 'digits_size_22_orange_4.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[5] = 'digits_size_22_orange_5.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[6] = 'digits_size_22_orange_6.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[7] = 'digits_size_22_orange_7.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[8] = 'digits_size_22_orange_8.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[9] = 'digits_size_22_orange_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_temperature_high_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 146,
                center_y: 396,
                pos_x: 146,
                pos_y: 396,
                angle: 2,
                src: 'digits_size_22_orange_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_high_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 146,
              center_y: 396,
              pos_x: 146,
              pos_y: 396,
              angle: 2,
              src: 'simbolos_naranja__.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            // normal_temperature_low_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 48,
              // y: 321,
              // font_array: ["digits_size_22_0.png","digits_size_22_1.png","digits_size_22_2.png","digits_size_22_3.png","digits_size_22_4.png","digits_size_22_5.png","digits_size_22_6.png","digits_size_22_7.png","digits_size_22_8.png","digits_size_22_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: 63,
              // unit_en: 'simbolos_amarillo__.png',
              // dot_image: 'simbolos_amarillo_-.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_low_TextRotate_ASCIIARRAY[0] = 'digits_size_22_0.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[1] = 'digits_size_22_1.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[2] = 'digits_size_22_2.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[3] = 'digits_size_22_3.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[4] = 'digits_size_22_4.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[5] = 'digits_size_22_5.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[6] = 'digits_size_22_6.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[7] = 'digits_size_22_7.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[8] = 'digits_size_22_8.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[9] = 'digits_size_22_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_temperature_low_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 48,
                center_y: 321,
                pos_x: 48,
                pos_y: 321,
                angle: 63,
                src: 'digits_size_22_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_low_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 48,
              center_y: 321,
              pos_x: 48,
              pos_y: 321,
              angle: 63,
              src: 'simbolos_amarillo__.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            // normal_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 82,
              // y: 379,
              // font_array: ["digits_size_35_0.png","digits_size_35_1.png","digits_size_35_2.png","digits_size_35_3.png","digits_size_35_4.png","digits_size_35_5.png","digits_size_35_6.png","digits_size_35_7.png","digits_size_35_8.png","digits_size_35_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -25,
              // angle: 37,
              // unit_en: 'grade__.png',
              // invalid_image: 'digits_size_35_--.png',
              // dot_image: 'digits_size_35_-.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_current_TextRotate_ASCIIARRAY[0] = 'digits_size_35_0.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[1] = 'digits_size_35_1.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[2] = 'digits_size_35_2.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[3] = 'digits_size_35_3.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[4] = 'digits_size_35_4.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[5] = 'digits_size_35_5.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[6] = 'digits_size_35_6.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[7] = 'digits_size_35_7.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[8] = 'digits_size_35_8.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[9] = 'digits_size_35_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 82,
                center_y: 379,
                pos_x: 82,
                pos_y: 379,
                angle: 37,
                src: 'digits_size_35_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 82,
              center_y: 379,
              pos_x: 82,
              pos_y: 379,
              angle: 37,
              src: 'grade__.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'rec.png',
              center_x: 191,
              center_y: 224,
              x: 193,
              y: 58,
              start_angle: 18,
              end_angle: 58,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 46,
              // y: 25,
              // font_array: ["digits_size_35_0.png","digits_size_35_1.png","digits_size_35_2.png","digits_size_35_3.png","digits_size_35_4.png","digits_size_35_5.png","digits_size_35_6.png","digits_size_35_7.png","digits_size_35_8.png","digits_size_35_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -24,
              // angle: -24,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'digits_size_35_0.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'digits_size_35_1.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'digits_size_35_2.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'digits_size_35_3.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'digits_size_35_4.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'digits_size_35_5.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'digits_size_35_6.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'digits_size_35_7.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'digits_size_35_8.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'digits_size_35_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 46,
                center_y: 25,
                pos_x: 46,
                pos_y: 25,
                angle: -24,
                src: 'digits_size_35_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 226,
              // start_angle: 10,
              // end_angle: 55,
              // radius: 201,
              // line_width: 11,
              // line_cap: Rounded,
              // color: 0xFF5EDD7E,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 226,
              start_angle: 10,
              end_angle: 55,
              radius: 196,
              line_width: 11,
              corner_flag: 0,
              color: 0xFF5EDD7E,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 317,
              // y: 14,
              // font_array: ["digits_size_35_0.png","digits_size_35_1.png","digits_size_35_2.png","digits_size_35_3.png","digits_size_35_4.png","digits_size_35_5.png","digits_size_35_6.png","digits_size_35_7.png","digits_size_35_8.png","digits_size_35_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -24,
              // angle: 31,
              // unit_en: 'digits_size_35___.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'digits_size_35_0.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'digits_size_35_1.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'digits_size_35_2.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'digits_size_35_3.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'digits_size_35_4.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'digits_size_35_5.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'digits_size_35_6.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'digits_size_35_7.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'digits_size_35_8.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'digits_size_35_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 317,
                center_y: 14,
                pos_x: 317,
                pos_y: 14,
                angle: 31,
                src: 'digits_size_35_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 317,
              center_y: 14,
              pos_x: 317,
              pos_y: 14,
              angle: 31,
              src: 'digits_size_35___.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 99,
              hour_startY: 106,
              hour_array: ["HOUR_DIGITS_0.png","HOUR_DIGITS_1.png","HOUR_DIGITS_2.png","HOUR_DIGITS_3.png","HOUR_DIGITS_4.png","HOUR_DIGITS_5.png","HOUR_DIGITS_6.png","HOUR_DIGITS_7.png","HOUR_DIGITS_8.png","HOUR_DIGITS_9.png"],
              hour_zero: 1,
              hour_space: -20,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 159,
              minute_startY: 106,
              minute_array: ["HOUR_DIGITS_0.png","HOUR_DIGITS_1.png","HOUR_DIGITS_2.png","HOUR_DIGITS_3.png","HOUR_DIGITS_4.png","HOUR_DIGITS_5.png","HOUR_DIGITS_6.png","HOUR_DIGITS_7.png","HOUR_DIGITS_8.png","HOUR_DIGITS_9.png"],
              minute_zero: 1,
              minute_space: -20,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 221,
              second_startY: 106,
              second_array: ["HOUR_DIGITS_0.png","HOUR_DIGITS_1.png","HOUR_DIGITS_2.png","HOUR_DIGITS_3.png","HOUR_DIGITS_4.png","HOUR_DIGITS_5.png","HOUR_DIGITS_6.png","HOUR_DIGITS_7.png","HOUR_DIGITS_8.png","HOUR_DIGITS_9.png"],
              second_zero: 1,
              second_space: -20,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 141,
              y: 101,
              src: 'HOUR_DIGITS__.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 101,
              src: 'HOUR_DIGITS__.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'MANECILL_HORA.png',
              // center_x: 195,
              // center_y: 225,
              // x: 19,
              // y: 98,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 19,
              pos_y: 225 - 98,
              center_x: 195,
              center_y: 225,
              src: 'MANECILL_HORA.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'MANECILLA_MIN.png',
              // center_x: 195,
              // center_y: 225,
              // x: 19,
              // y: 171,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 19,
              pos_y: 225 - 171,
              center_x: 195,
              center_y: 225,
              src: 'MANECILLA_MIN.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'STREL.png',
              // center_x: 195,
              // center_y: 225,
              // x: 11,
              // y: 215,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'STREL.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 11,
              second_posY: 215,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 308,
              w: 150,
              h: 55,
              text_size: 60,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 121,
              y: 283,
              w: 149,
              h: 30,
              text_size: 25,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed.ttf',
              color: 0xFFF64346,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'rec.png',
              center_x: 191,
              center_y: 224,
              x: -155,
              y: 112,
              start_angle: -223,
              end_angle: -189,
              invalid_visible: false,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 282,
              // center_y: 225,
              // start_angle: 0,
              // end_angle: 359,
              // radius: 24,
              // line_width: 11,
              // line_cap: Rounded,
              // color: 0xFF75F1D9,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 282,
              center_y: 225,
              start_angle: 0,
              end_angle: 359,
              radius: 19,
              line_width: 11,
              corner_flag: 0,
              color: 0xFF75F1D9,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 282,
              // center_y: 225,
              // start_angle: 0,
              // end_angle: 359,
              // radius: 38,
              // line_width: 11,
              // line_cap: Rounded,
              // color: 0xFFBFFD50,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 282,
              center_y: 225,
              start_angle: 0,
              end_angle: 359,
              radius: 33,
              line_width: 11,
              corner_flag: 0,
              color: 0xFFBFFD50,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 282,
              // center_y: 225,
              // start_angle: 0,
              // end_angle: 359,
              // radius: 52,
              // line_width: 11,
              // line_cap: Rounded,
              // color: 0xFFDE385A,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 282,
              center_y: 225,
              start_angle: 0,
              end_angle: 359,
              radius: 47,
              line_width: 11,
              corner_flag: 0,
              color: 0xFFDE385A,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_temperature_high_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 146,
              // y: 396,
              // font_array: ["digits_size_22_orange_0.png","digits_size_22_orange_1.png","digits_size_22_orange_2.png","digits_size_22_orange_3.png","digits_size_22_orange_4.png","digits_size_22_orange_5.png","digits_size_22_orange_6.png","digits_size_22_orange_7.png","digits_size_22_orange_8.png","digits_size_22_orange_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: 2,
              // unit_en: 'simbolos_naranja__.png',
              // dot_image: 'simbolos_naranja_-.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_temperature_high_TextRotate_ASCIIARRAY[0] = 'digits_size_22_orange_0.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[1] = 'digits_size_22_orange_1.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[2] = 'digits_size_22_orange_2.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[3] = 'digits_size_22_orange_3.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[4] = 'digits_size_22_orange_4.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[5] = 'digits_size_22_orange_5.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[6] = 'digits_size_22_orange_6.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[7] = 'digits_size_22_orange_7.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[8] = 'digits_size_22_orange_8.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[9] = 'digits_size_22_orange_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              idle_temperature_high_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 146,
                center_y: 396,
                pos_x: 146,
                pos_y: 396,
                angle: 2,
                src: 'digits_size_22_orange_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_temperature_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_temperature_high_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 146,
              center_y: 396,
              pos_x: 146,
              pos_y: 396,
              angle: 2,
              src: 'simbolos_naranja__.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            // idle_temperature_low_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 48,
              // y: 321,
              // font_array: ["digits_size_22_0.png","digits_size_22_1.png","digits_size_22_2.png","digits_size_22_3.png","digits_size_22_4.png","digits_size_22_5.png","digits_size_22_6.png","digits_size_22_7.png","digits_size_22_8.png","digits_size_22_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: 63,
              // unit_en: 'simbolos_amarillo__.png',
              // dot_image: 'simbolos_amarillo_-.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_temperature_low_TextRotate_ASCIIARRAY[0] = 'digits_size_22_0.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[1] = 'digits_size_22_1.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[2] = 'digits_size_22_2.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[3] = 'digits_size_22_3.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[4] = 'digits_size_22_4.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[5] = 'digits_size_22_5.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[6] = 'digits_size_22_6.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[7] = 'digits_size_22_7.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[8] = 'digits_size_22_8.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[9] = 'digits_size_22_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              idle_temperature_low_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 48,
                center_y: 321,
                pos_x: 48,
                pos_y: 321,
                angle: 63,
                src: 'digits_size_22_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_temperature_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_temperature_low_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 48,
              center_y: 321,
              pos_x: 48,
              pos_y: 321,
              angle: 63,
              src: 'simbolos_amarillo__.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            // idle_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 82,
              // y: 379,
              // font_array: ["digits_size_35_0.png","digits_size_35_1.png","digits_size_35_2.png","digits_size_35_3.png","digits_size_35_4.png","digits_size_35_5.png","digits_size_35_6.png","digits_size_35_7.png","digits_size_35_8.png","digits_size_35_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -25,
              // angle: 37,
              // unit_en: 'grade__.png',
              // invalid_image: 'digits_size_35_--.png',
              // dot_image: 'digits_size_35_-.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_temperature_current_TextRotate_ASCIIARRAY[0] = 'digits_size_35_0.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[1] = 'digits_size_35_1.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[2] = 'digits_size_35_2.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[3] = 'digits_size_35_3.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[4] = 'digits_size_35_4.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[5] = 'digits_size_35_5.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[6] = 'digits_size_35_6.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[7] = 'digits_size_35_7.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[8] = 'digits_size_35_8.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[9] = 'digits_size_35_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              idle_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 82,
                center_y: 379,
                pos_x: 82,
                pos_y: 379,
                angle: 37,
                src: 'digits_size_35_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_temperature_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 82,
              center_y: 379,
              pos_x: 82,
              pos_y: 379,
              angle: 37,
              src: 'grade__.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'rec.png',
              center_x: 191,
              center_y: 224,
              x: 193,
              y: 58,
              start_angle: 18,
              end_angle: 58,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 46,
              // y: 25,
              // font_array: ["digits_size_35_0.png","digits_size_35_1.png","digits_size_35_2.png","digits_size_35_3.png","digits_size_35_4.png","digits_size_35_5.png","digits_size_35_6.png","digits_size_35_7.png","digits_size_35_8.png","digits_size_35_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -24,
              // angle: -24,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextRotate_ASCIIARRAY[0] = 'digits_size_35_0.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[1] = 'digits_size_35_1.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[2] = 'digits_size_35_2.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[3] = 'digits_size_35_3.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[4] = 'digits_size_35_4.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[5] = 'digits_size_35_5.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[6] = 'digits_size_35_6.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[7] = 'digits_size_35_7.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[8] = 'digits_size_35_8.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[9] = 'digits_size_35_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 46,
                center_y: 25,
                pos_x: 46,
                pos_y: 25,
                angle: -24,
                src: 'digits_size_35_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 226,
              // start_angle: 10,
              // end_angle: 55,
              // radius: 201,
              // line_width: 11,
              // line_cap: Rounded,
              // color: 0xFF5EDD7E,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 226,
              start_angle: 10,
              end_angle: 55,
              radius: 196,
              line_width: 11,
              corner_flag: 0,
              color: 0xFF5EDD7E,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 317,
              // y: 14,
              // font_array: ["digits_size_35_0.png","digits_size_35_1.png","digits_size_35_2.png","digits_size_35_3.png","digits_size_35_4.png","digits_size_35_5.png","digits_size_35_6.png","digits_size_35_7.png","digits_size_35_8.png","digits_size_35_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -24,
              // angle: 31,
              // unit_en: 'digits_size_35___.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextRotate_ASCIIARRAY[0] = 'digits_size_35_0.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[1] = 'digits_size_35_1.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[2] = 'digits_size_35_2.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[3] = 'digits_size_35_3.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[4] = 'digits_size_35_4.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[5] = 'digits_size_35_5.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[6] = 'digits_size_35_6.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[7] = 'digits_size_35_7.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[8] = 'digits_size_35_8.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[9] = 'digits_size_35_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              idle_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 317,
                center_y: 14,
                pos_x: 317,
                pos_y: 14,
                angle: 31,
                src: 'digits_size_35_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 317,
              center_y: 14,
              pos_x: 317,
              pos_y: 14,
              angle: 31,
              src: 'digits_size_35___.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 99,
              hour_startY: 106,
              hour_array: ["HOUR_DIGITS_AOD_0.png","HOUR_DIGITS_AOD_1.png","HOUR_DIGITS_AOD_2.png","HOUR_DIGITS_AOD_3.png","HOUR_DIGITS_AOD_4.png","HOUR_DIGITS_AOD_5.png","HOUR_DIGITS_AOD_6.png","HOUR_DIGITS_AOD_7.png","HOUR_DIGITS_AOD_8.png","HOUR_DIGITS_AOD_9.png"],
              hour_zero: 1,
              hour_space: -20,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 159,
              minute_startY: 106,
              minute_array: ["HOUR_DIGITS_AOD_0.png","HOUR_DIGITS_AOD_1.png","HOUR_DIGITS_AOD_2.png","HOUR_DIGITS_AOD_3.png","HOUR_DIGITS_AOD_4.png","HOUR_DIGITS_AOD_5.png","HOUR_DIGITS_AOD_6.png","HOUR_DIGITS_AOD_7.png","HOUR_DIGITS_AOD_8.png","HOUR_DIGITS_AOD_9.png"],
              minute_zero: 1,
              minute_space: -20,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 221,
              second_startY: 106,
              second_array: ["HOUR_DIGITS_AOD_0.png","HOUR_DIGITS_AOD_1.png","HOUR_DIGITS_AOD_2.png","HOUR_DIGITS_AOD_3.png","HOUR_DIGITS_AOD_4.png","HOUR_DIGITS_AOD_5.png","HOUR_DIGITS_AOD_6.png","HOUR_DIGITS_AOD_7.png","HOUR_DIGITS_AOD_8.png","HOUR_DIGITS_AOD_9.png"],
              second_zero: 1,
              second_space: -20,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 141,
              y: 101,
              src: 'HOUR_DIGITS_AOD__.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 101,
              src: 'HOUR_DIGITS_AOD__.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'MANECILL_HORA.png',
              // center_x: 195,
              // center_y: 225,
              // x: 19,
              // y: 98,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 19,
              pos_y: 225 - 98,
              center_x: 195,
              center_y: 225,
              src: 'MANECILL_HORA.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'MANECILLA_MIN.png',
              // center_x: 195,
              // center_y: 225,
              // x: 19,
              // y: 171,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 19,
              pos_y: 225 - 171,
              center_x: 195,
              center_y: 225,
              src: 'MANECILLA_MIN.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 232,
              y: 173,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 38,
              y: 0,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 266,
              y: 1,
              w: 100,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 33,
              y: 329,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 303,
              y: 360,
              w: 68,
              h: 58,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 223,
              y: 106,
              w: 70,
              h: 57,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 111,
              y: 107,
              w: 104,
              h: 56,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 58,
              y: 175,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 146,
              y: 276,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 168,
              y: 196,
              w: 56,
              h: 56,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                click_Background()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

set_ClockFace(hmFS.SysProGetInt('INFO_bg_dark') == 1);
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              if (updateMinute) { // Hour Pointer
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              if (updateMinute) { // Hour Pointer
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) { // Minute Pointer
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let temperature_high_temp = -100;
              if (forecastData.count > 0) {
                temperature_high_temp = forecastData.data[0].high;
              }; // end forecastData;

              console.log('update text rotate temperature_high_forecastData');
              let temperatureHigh = undefined;
              let normal_temperature_high_rotate_string = undefined;
              if (temperature_high_temp > -100) {
                temperatureHigh = 0;
                normal_temperature_high_rotate_string = String(temperature_high_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && normal_temperature_high_rotate_string.length > 0 && normal_temperature_high_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_temperature_high_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 146 + img_offset);
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_high_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_high_TextRotate_img_width + -20;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 146 + img_offset);
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.SRC, 'simbolos_naranja_-.png');
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_high_TextRotate_dot_width + -20;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.POS_X, 146 + img_offset);
                  normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };
              let temperature_low_temp = -100;
              if (forecastData.count > 0) {
                temperature_low_temp = forecastData.data[0].low;
              }; // end forecastData;

              console.log('update text rotate temperature_low_forecastData');
              let temperatureLow = undefined;
              let normal_temperature_low_rotate_string = undefined;
              if (temperature_low_temp > -100) {
                temperatureLow = 0;
                normal_temperature_low_rotate_string = String(temperature_low_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && normal_temperature_low_rotate_string.length > 0 && normal_temperature_low_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_temperature_low_TextRotate_posOffset = normal_temperature_low_TextRotate_img_width * normal_temperature_low_rotate_string.length;
                  normal_temperature_low_TextRotate_posOffset = normal_temperature_low_TextRotate_posOffset + -20 * (normal_temperature_low_rotate_string.length - 1);
                  img_offset -= normal_temperature_low_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_low_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 48 + img_offset);
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_low_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_low_TextRotate_img_width + -20;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 48 + img_offset);
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.SRC, 'simbolos_amarillo_-.png');
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_low_TextRotate_dot_width + -20;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.POS_X, 48 + img_offset);
                  normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };
              let temperature_current_temp = -100;
              if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
                temperature_current_temp = weatherSensor.current;
              }; // end currentWeather;

              console.log('update text rotate temperature_current_currentWeather');
              let temperatureCurrent = undefined;
              let normal_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                normal_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && normal_temperature_current_rotate_string.length > 0 && normal_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_img_width * normal_temperature_current_rotate_string.length;
                  normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_posOffset + -25 * (normal_temperature_current_rotate_string.length - 1);
                  img_offset -= normal_temperature_current_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 82 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_img_width + -25;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 82 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'digits_size_35_-.png');
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_dot_width + -25;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 82 + img_offset);
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.POS_X, 82 - normal_temperature_current_TextRotate_error_img_width / 2);
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.SRC, 'digits_size_35_--.png');
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 46 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width + -24;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  normal_battery_TextRotate_posOffset = normal_battery_TextRotate_posOffset + -24 * (normal_battery_rotate_string.length - 1);
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 317 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width + -24;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 317 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate temperature_high_forecastData');
              let idle_temperature_high_rotate_string = undefined;
              if (temperature_high_temp > -100) {
                temperatureHigh = 0;
                idle_temperature_high_rotate_string = String(temperature_high_temp)
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_temperature_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && idle_temperature_high_rotate_string.length > 0 && idle_temperature_high_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_temperature_high_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_temperature_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 146 + img_offset);
                      idle_temperature_high_TextRotate[index].setProperty(hmUI.prop.SRC, idle_temperature_high_TextRotate_ASCIIARRAY[charCode]);
                      idle_temperature_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_high_TextRotate_img_width + -20;
                      index++;
                    }  // end if digit
                    else { 
                      idle_temperature_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 146 + img_offset);
                      idle_temperature_high_TextRotate[index].setProperty(hmUI.prop.SRC, 'simbolos_naranja_-.png');
                      idle_temperature_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_high_TextRotate_dot_width + -20;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_temperature_high_TextRotate_unit.setProperty(hmUI.prop.POS_X, 146 + img_offset);
                  idle_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate temperature_low_forecastData');
              let idle_temperature_low_rotate_string = undefined;
              if (temperature_low_temp > -100) {
                temperatureLow = 0;
                idle_temperature_low_rotate_string = String(temperature_low_temp)
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_temperature_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && idle_temperature_low_rotate_string.length > 0 && idle_temperature_low_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let idle_temperature_low_TextRotate_posOffset = idle_temperature_low_TextRotate_img_width * idle_temperature_low_rotate_string.length;
                  idle_temperature_low_TextRotate_posOffset = idle_temperature_low_TextRotate_posOffset + -20 * (idle_temperature_low_rotate_string.length - 1);
                  img_offset -= idle_temperature_low_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_temperature_low_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_temperature_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 48 + img_offset);
                      idle_temperature_low_TextRotate[index].setProperty(hmUI.prop.SRC, idle_temperature_low_TextRotate_ASCIIARRAY[charCode]);
                      idle_temperature_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_low_TextRotate_img_width + -20;
                      index++;
                    }  // end if digit
                    else { 
                      idle_temperature_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 48 + img_offset);
                      idle_temperature_low_TextRotate[index].setProperty(hmUI.prop.SRC, 'simbolos_amarillo_-.png');
                      idle_temperature_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_low_TextRotate_dot_width + -20;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_temperature_low_TextRotate_unit.setProperty(hmUI.prop.POS_X, 48 + img_offset);
                  idle_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate temperature_current_currentWeather');
              let idle_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                idle_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && idle_temperature_current_rotate_string.length > 0 && idle_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_temperature_current_TextRotate_posOffset = idle_temperature_current_TextRotate_img_width * idle_temperature_current_rotate_string.length;
                  idle_temperature_current_TextRotate_posOffset = idle_temperature_current_TextRotate_posOffset + -25 * (idle_temperature_current_rotate_string.length - 1);
                  img_offset -= idle_temperature_current_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 82 + img_offset);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, idle_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_current_TextRotate_img_width + -25;
                      index++;
                    }  // end if digit
                    else { 
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 82 + img_offset);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'digits_size_35_-.png');
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_current_TextRotate_dot_width + -25;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 82 + img_offset);
                  idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_temperature_current_TextRotate[0].setProperty(hmUI.prop.POS_X, 82 - idle_temperature_current_TextRotate_error_img_width / 2);
                  idle_temperature_current_TextRotate[0].setProperty(hmUI.prop.SRC, 'digits_size_35_--.png');
                  idle_temperature_current_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let idle_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_rotate_string.length > 0 && idle_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 46 + img_offset);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_heart_rate_TextRotate_img_width + -24;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let idle_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_rotate_string.length > 0 && idle_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_battery_TextRotate_posOffset = idle_battery_TextRotate_img_width * idle_battery_rotate_string.length;
                  idle_battery_TextRotate_posOffset = idle_battery_TextRotate_posOffset + -24 * (idle_battery_rotate_string.length - 1);
                  img_offset -= idle_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 317 + img_offset);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.SRC, idle_battery_TextRotate_ASCIIARRAY[charCode]);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_battery_TextRotate_img_width + -24;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 317 + img_offset);
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 282,
                      center_y: 225,
                      start_angle: 0,
                      end_angle: 359,
                      radius: 19,
                      line_width: 11,
                      corner_flag: 0,
                      color: 0xFF75F1D9,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 282,
                      center_y: 225,
                      start_angle: 0,
                      end_angle: 359,
                      radius: 33,
                      line_width: 11,
                      corner_flag: 0,
                      color: 0xFFBFFD50,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 282,
                      center_y: 225,
                      start_angle: 0,
                      end_angle: 359,
                      radius: 47,
                      line_width: 11,
                      corner_flag: 0,
                      color: 0xFFDE385A,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 226,
                      start_angle: 10,
                      end_angle: 55,
                      radius: 196,
                      line_width: 11,
                      corner_flag: 0,
                      color: 0xFF5EDD7E,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STAND');
                let progress_cs_idle_stand = progressStand;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_stand * 100);
                  if (idle_stand_circle_scale) {
                    idle_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 282,
                      center_y: 225,
                      start_angle: 0,
                      end_angle: 359,
                      radius: 19,
                      line_width: 11,
                      corner_flag: 0,
                      color: 0xFF75F1D9,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_calorie * 100);
                  if (idle_calorie_circle_scale) {
                    idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 282,
                      center_y: 225,
                      start_angle: 0,
                      end_angle: 359,
                      radius: 33,
                      line_width: 11,
                      corner_flag: 0,
                      color: 0xFFBFFD50,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 282,
                      center_y: 225,
                      start_angle: 0,
                      end_angle: 359,
                      radius: 47,
                      line_width: 11,
                      corner_flag: 0,
                      color: 0xFFDE385A,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 226,
                      start_angle: 10,
                      end_angle: 55,
                      radius: 196,
                      line_width: 11,
                      corner_flag: 0,
                      color: 0xFF5EDD7E,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}