"""Themeable weather icon set for Zepp OS codes 0-28, drawn on a 32x32 grid.
Every condition has one unique cue (sun peeking = showers, flake count = intensity, bolt, hail pellets,
swirls vs dots for sand/dust...) so all 29 stay distinct at ~24-30 px.
Themes swap colours and can switch between 'fill' and 'line' drawing."""
import math

NAMES = ["Cloudy", "Showers", "Snow Showers", "Sunny", "Overcast", "Light Rain", "Light Snow", "Moderate Rain",
         "Moderate Snow", "Heavy Snow", "Heavy Rain", "Sandstorm", "Rain + Snow", "Fog", "Hazy", "T-Storms",
         "Snowstorm", "Floating Dust", "Very Heavy Rainstorm", "Rain + Hail", "T-Storms + Hail", "Heavy Rainstorm",
         "Dust", "Heavy Sandstorm", "Rainstorm", "Unknown", "Cloudy Night", "Showers Night", "Clear Night"]

THEMES = {
    'Color':  dict(mode='fill', sun='#FFC53D', ray='#FFB020', cloud='#EEF1F5', cloud2='#A9B2BE', cloud3='#6F7987',
                   rain='#4DA3FF', rain2='#2B7BFF', snow='#FFFFFF', bolt='#FFD23F', moon='#F3E6BE', star='#F3E6BE',
                   dust='#E0AE62', dust2='#C77F2E', fog='#B9C1CC', hail='#D6F0FF', haze='#FF9F43', bg='#000'),
    'Pastel': dict(mode='fill', sun='#FFD98A', ray='#FFC970', cloud='#F4F1FA', cloud2='#C7C2D9', cloud3='#9A93B3',
                   rain='#8EC5FF', rain2='#6FA8FF', snow='#FFFFFF', bolt='#FFE58A', moon='#FFF1C9', star='#FFE9A8',
                   dust='#EBC28F', dust2='#D9A066', fog='#CFCBDD', hail='#E3F4FF', haze='#FFB98A', bg='#000'),
    'Neon':   dict(mode='line', sun='#FFE600', ray='#FFE600', cloud='#7DF9FF', cloud2='#7DF9FF', cloud3='#B98CFF',
                   rain='#3DA9FF', rain2='#3D7BFF', snow='#FFFFFF', bolt='#FFE600', moon='#FF7CE0', star='#FF7CE0',
                   dust='#FFB347', dust2='#FF8A2A', fog='#7DF9FF', hail='#CFFAFF', haze='#FF9F43', bg='#000', glow=True),
    'Brass':  dict(mode='fill', sun='#E8B04A', ray='#C8922E', cloud='#E9DCC0', cloud2='#B7A27A', cloud3='#8A7550',
                   rain='#8FB3C9', rain2='#6F95AE', snow='#F6EEDC', bolt='#F2C14E', moon='#F2E3BC', star='#E8B04A',
                   dust='#C9965A', dust2='#A8743A', fog='#B7A98C', hail='#E6EEF2', haze='#D98A3A', bg='#000'),
    'Mono':   dict(mode='line', sun='{a}', ray='{a}', cloud='{a}', cloud2='{a}', cloud3='{a}', rain='{a}', rain2='{a}',
                   snow='{a}', bolt='{a}', moon='{a}', star='{a}', dust='{a}', dust2='{a}', fog='{a}', hail='{a}',
                   haze='{a}', bg='#000'),
}
def theme(name, accent='#B8F55C'):
    t = dict(THEMES[name])
    return {k: (v.replace('{a}', accent) if isinstance(v, str) else v) for k, v in t.items()}

CLOUD = 'M9 24.5H23.2A4.8 4.8 0 0 0 23.9 15A7 7 0 0 0 10.6 14.6A5 5 0 0 0 9 24.5Z'

def icon(code, T, size=32):
    line = T['mode'] == 'line'
    sw = 1.9
    out = []
    def cloud(dx=0, dy=0, s=1.0, col='cloud'):
        c = T[col]
        tr = f'translate({dx} {dy}) translate(16 18) scale({s}) translate(-16 -18)'
        if line:
            out.append(f'<path d="{CLOUD}" transform="{tr}" fill="{T["bg"]}" stroke="{c}" stroke-width="{sw / s:.2f}" stroke-linejoin="round"/>')
        else:
            out.append(f'<path d="{CLOUD}" transform="{tr}" fill="{c}"/>')
    def sun(cx, cy, r, rays=True, col='sun', ray_len=3.2):
        if rays:
            for k in range(8):
                a = k * math.pi / 4
                x1, y1 = cx + (r + 1.6) * math.cos(a), cy + (r + 1.6) * math.sin(a)
                x2, y2 = cx + (r + 1.6 + ray_len) * math.cos(a), cy + (r + 1.6 + ray_len) * math.sin(a)
                out.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{T["ray"]}" stroke-width="1.8" stroke-linecap="round"/>')
        if line:
            out.append(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{T["bg"]}" stroke="{T[col]}" stroke-width="{sw}"/>')
        else:
            out.append(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{T[col]}"/>')
    def moon(cx, cy, r, col='moon'):
        d = f'M{cx + r * .35:.1f} {cy - r:.1f}A{r} {r} 0 1 0 {cx + r:.1f} {cy + r * .45:.1f}A{r * .78:.1f} {r * .78:.1f} 0 0 1 {cx + r * .35:.1f} {cy - r:.1f}Z'
        out.append(f'<path d="{d}" fill="{T["bg"] if line else T[col]}" stroke="{T[col] if line else "none"}" stroke-width="{sw}" stroke-linejoin="round"/>')
    def star(cx, cy, r=1.6):
        out.append(f'<path d="M{cx} {cy - r * 1.6}L{cx + r * .45} {cy - r * .45}L{cx + r * 1.6} {cy}L{cx + r * .45} {cy + r * .45}L{cx} {cy + r * 1.6}L{cx - r * .45} {cy + r * .45}L{cx - r * 1.6} {cy}L{cx - r * .45} {cy - r * .45}Z" fill="{T["star"]}"/>')
    def drops(xs, y=24, ln=3.6, col='rain', w=2.1):
        for x in xs:
            out.append(f'<line x1="{x}" y1="{y}" x2="{x - 1.4}" y2="{y + ln}" stroke="{T[col]}" stroke-width="{w}" stroke-linecap="round"/>')
    def flake(cx, cy, r=2.2, col='snow'):
        for k in range(3):
            a = k * math.pi / 3 + math.pi / 2
            out.append(f'<line x1="{cx - r * math.cos(a):.1f}" y1="{cy - r * math.sin(a):.1f}" x2="{cx + r * math.cos(a):.1f}" y2="{cy + r * math.sin(a):.1f}" stroke="{T[col]}" stroke-width="1.5" stroke-linecap="round"/>')
    def hail(cx, cy, r=1.7):
        out.append(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{T["bg"] if line else T["hail"]}" stroke="{T["rain2"]}" stroke-width="1"/>')
    def bolt(dx=0, dy=0, s=1.0):
        out.append(f'<path transform="translate({dx} {dy}) scale({s})" d="M17.5 19 13 25.5h3.2l-1.6 5 5.2-7h-3.3l2-4.5z" fill="{T["bolt"]}" stroke="{T["bg"]}" stroke-width=".8" stroke-linejoin="round"/>')
    def swirl(y, x0=4, x1=21, col='dust', w=2.0, curl=True):
        d = f'M{x0} {y}H{x1}' + (f'a2.6 2.6 0 1 0 -2.6 -2.6' if curl else '')
        out.append(f'<path d="{d}" fill="none" stroke="{T[col]}" stroke-width="{w}" stroke-linecap="round"/>')
    def hlines(ys, x0=6, x1=26, col='fog', w=2.0, offs=None):
        for i, y in enumerate(ys):
            o = (offs or [0] * len(ys))[i]
            out.append(f'<line x1="{x0 + o}" y1="{y}" x2="{x1 - (2 if i % 2 else 0) + o}" y2="{y}" stroke="{T[col]}" stroke-width="{w}" stroke-linecap="round"/>')
    def dots(pts, col='dust', r=1.2):
        for x, y in pts: out.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{T[col]}"/>')

    UP = -4  # cloud lifted when something falls below it
    if code == 3:   sun(16, 16, 6.2, ray_len=3.6)                                        # Sunny
    elif code == 0: sun(11, 11, 5.2, ray_len=2.6); cloud(2, 2)                           # Cloudy (partly)
    elif code == 4: cloud(-4, -5, .78, 'cloud2'); cloud(1, 0, 1, 'cloud')                # Overcast: two clouds
    elif code == 1: sun(10, 7.5, 4.2, ray_len=2.2); cloud(2, UP); drops([14, 19], 23)    # Showers: sun peeks + 2 drops
    elif code == 5: cloud(0, UP); drops([16], 23)                                        # Light rain: 1 drop
    elif code == 7: cloud(0, UP); drops([12, 17, 22], 23)                                # Moderate: 3 drops
    elif code == 10: cloud(0, UP, 1, 'cloud2'); drops([11, 16, 21], 22.5, 5.2, 'rain2', 2.4)   # Heavy: long, darker
    elif code == 24: cloud(0, UP, 1, 'cloud2'); drops([10, 14, 18, 22], 22.5, 5.2, 'rain2', 2.2)  # Rainstorm: 4 long
    elif code == 21: cloud(0, UP, 1, 'cloud3'); drops([10, 14, 18, 22], 22, 4, 'rain2', 2.2); drops([12, 16, 20], 27.5, 3, 'rain2', 2)  # Heavy rainstorm: 2 rows
    elif code == 18: cloud(0, UP, 1, 'cloud3'); drops([9, 12.5, 16, 19.5, 23], 22, 7.5, 'rain2', 2.2)    # Very heavy: curtain
    elif code == 2: sun(10, 7.5, 4.2, ray_len=2.2); cloud(2, UP); flake(14.5, 26); flake(20.5, 26)       # Snow showers: sun + 2 flakes
    elif code == 6: cloud(0, UP); flake(16, 26)                                          # Light snow: 1 flake
    elif code == 8: cloud(0, UP); flake(12.5, 26); flake(19.5, 26)                       # Moderate: 2 flakes
    elif code == 9: cloud(0, UP, 1, 'cloud2'); flake(10.5, 25.5); flake(16, 28.2); flake(21.5, 25.5)     # Heavy: 3 flakes
    elif code == 16: cloud(0, UP, 1, 'cloud3'); flake(11, 25.5); flake(17, 28); swirl(26, 20, 29, 'snow', 1.6, False); swirl(29.5, 21, 27, 'snow', 1.6, False)  # Snowstorm: flakes + wind
    elif code == 12: cloud(0, UP); drops([12.5], 23); flake(19.5, 26)                    # Rain + snow
    elif code == 19: cloud(0, UP); drops([11, 19], 23); hail(15, 26.5); hail(23, 28)     # Rain + hail
    elif code == 15: cloud(0, UP, 1, 'cloud2'); bolt(0, -1); drops([10, 22], 23)         # T-storms
    elif code == 20: cloud(0, UP, 1, 'cloud3'); bolt(0, -1); hail(10, 26); hail(22.5, 26.5)  # T-storms + hail
    elif code == 13: cloud(0, -6, .9); hlines([21, 25, 29], 5, 27)                       # Fog: cloud over bands
    elif code == 14: sun(16, 13, 6, False, 'haze'); hlines([18, 22, 26], 5, 27, 'fog', 2)  # Hazy: dim sun behind bands
    elif code == 11: swirl(12, 4, 20); swirl(18.5, 7, 25); swirl(25, 4, 18); dots([(26, 12), (28, 24)], 'dust2')  # Sandstorm
    elif code == 23: swirl(11, 3, 21, 'dust2', 2.8); swirl(18, 6, 25, 'dust2', 2.8); swirl(25, 3, 19, 'dust2', 2.8); dots([(26, 10), (28, 22), (24, 28), (6, 29)], 'dust2', 1.5)  # Heavy sandstorm: thicker
    elif code == 22: hlines([11, 16, 21, 26], 5, 27, 'dust', 2.2, [0, 3, -1, 2])         # Dust: dusty streaks
    elif code == 17: dots([(8, 9), (15, 7), (23, 10), (11, 15), (19, 15), (26, 17), (7, 21), (15, 22), (22, 24), (11, 27), (19, 28)], 'dust', 1.4)  # Floating dust: specks
    elif code == 25:
        out.append(f'<path d="{CLOUD}" fill="none" stroke="{T["cloud2"]}" stroke-width="1.6" stroke-dasharray="2.6 2.2"/>')
        out.append(f'<text x="16" y="22.5" text-anchor="middle" font-family="Arial" font-weight="900" font-size="10" fill="{T["cloud"]}">?</text>')
    elif code == 28: moon(15, 16, 8.5); star(24.5, 8, 1.4); star(26, 18, 1)              # Clear night
    elif code == 26: moon(19, 10, 6); cloud(-2, 3, .95)                                  # Cloudy night
    elif code == 27: moon(21, 8, 5.2); cloud(-2, UP + 1, .95); drops([12, 18], 24)        # Showers night
    body = ''.join(out)
    glow = f'<defs><filter id="g" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation=".9" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><g filter="url(#g)">{body}</g>' if T.get('glow') else body
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 32 32">{glow}</svg>'
