﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_distance_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 320,
              h: 380,
              src: '0000B.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 28,
              y: 319,
              font_array: ["0200.png","0201.png","0202.png","0203.png","0204.png","0205.png","0206.png","0207.png","0208.png","0209.png"],
              padding: true,
              h_space: -1,
              dot_image: 'punto.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -3,
              y: 282,
              src: 'distancia 25x25.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 74,
              y: 339,
              src: 'KM2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 254,
              // center_y: 66,
              // start_angle: -5,
              // end_angle: 98,
              // radius: 62,
              // line_width: 11,
              // line_cap: Rounded,
              // color: 0xFFA2FF00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 254,
              center_y: 66,
              start_angle: -5,
              end_angle: 98,
              radius: 57,
              line_width: 11,
              corner_flag: 0,
              color: 0xFFA2FF00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 38,
              font_array: ["0300.png","0301.png","0302.png","0303.png","0304.png","0305.png","0306.png","0307.png","0308.png","0309.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 39,
              src: 'percentage.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 248,
              // center_y: 308,
              // start_angle: 90,
              // end_angle: 180,
              // radius: 69,
              // line_width: 11,
              // line_cap: Rounded,
              // color: 0xFF60C1FD,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 248,
              center_y: 308,
              start_angle: 90,
              end_angle: 180,
              radius: 64,
              line_width: 11,
              corner_flag: 0,
              color: 0xFF60C1FD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 319,
              font_array: ["0200.png","0201.png","0202.png","0203.png","0204.png","0205.png","0206.png","0207.png","0208.png","0209.png"],
              padding: true,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 28,
              y: 265,
              src: 'prohibido.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 261,
              src: 'ALARMA2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 19,
              y: 38,
              font_array: ["0300.png","0301.png","0302.png","0303.png","0304.png","0305.png","0306.png","0307.png","0308.png","0309.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'GRADOS CENTIGRADOS1.png',
              unit_tc: 'GRADOS CENTIGRADOS1.png',
              unit_en: 'GRADOS CENTIGRADOS1.png',
              negative_image: '0125.png',
              invalid_image: '226.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 137,
              y: 40,
              image_array: ["201.png","202.png","203.png","204.png","205.png","206.png","207.png","208.png","209.png","210.png","211.png","212.png","213.png","214.png","215.png","216.png","217.png","218.png","219.png","220.png","221.png","222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 124,
              day_startY: 280,
              day_sc_array: ["img_arr_0007_00.png","img_arr_0007_01.png","img_arr_0007_02.png","img_arr_0007_03.png","img_arr_0007_04.png","img_arr_0007_05.png","img_arr_0007_06.png","img_arr_0007_07.png","img_arr_0007_08.png","img_arr_0007_09.png"],
              day_tc_array: ["img_arr_0007_00.png","img_arr_0007_01.png","img_arr_0007_02.png","img_arr_0007_03.png","img_arr_0007_04.png","img_arr_0007_05.png","img_arr_0007_06.png","img_arr_0007_07.png","img_arr_0007_08.png","img_arr_0007_09.png"],
              day_en_array: ["img_arr_0007_00.png","img_arr_0007_01.png","img_arr_0007_02.png","img_arr_0007_03.png","img_arr_0007_04.png","img_arr_0007_05.png","img_arr_0007_06.png","img_arr_0007_07.png","img_arr_0007_08.png","img_arr_0007_09.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 78,
              y: 14,
              week_en: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png"],
              week_tc: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png"],
              week_sc: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 7,
              hour_startY: 97,
              hour_array: ["0350.png","0351.png","0352.png","0353.png","0354.png","0355.png","0356.png","0357.png","0358.png","0359.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_unit_sc: '2_PUNTOS.png',
              hour_unit_tc: '2_PUNTOS.png',
              hour_unit_en: '2_PUNTOS.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["0360.png","0361.png","0362.png","0363.png","0364.png","0365.png","0366.png","0367.png","0368.png","0369.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 7,
              y: 70,
              src: 'temperature-100.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 114,
              y: 18,
              w: 93,
              h: 71,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'botoNCONTAC.png',
              normal_src: 'botoNCONTAC.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 209,
              y: 260,
              w: 103,
              h: 85,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'botoNCONTAC.png',
              normal_src: 'botoNCONTAC.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_displayBrightScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'HmReStartScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 125,
              y: 285,
              w: 65,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'botoNCONTAC.png',
              normal_src: 'botoNCONTAC.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneContactsScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 167,
              y: 92,
              w: 139,
              h: 163,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'botoNCONTAC.png',
              normal_src: 'botoNCONTAC.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneMusicCtrlScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 254,
                      center_y: 66,
                      start_angle: -5,
                      end_angle: 98,
                      radius: 57,
                      line_width: 11,
                      corner_flag: 0,
                      color: 0xFFA2FF00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 248,
                      center_y: 308,
                      start_angle: 90,
                      end_angle: 180,
                      radius: 64,
                      line_width: 11,
                      corner_flag: 0,
                      color: 0xFF60C1FD,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}