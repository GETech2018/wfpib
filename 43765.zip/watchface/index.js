﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_dnd_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'Main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 162,
              y: 363,
              font_array: ["Pls_00.png","Pls_01.png","Pls_02.png","Pls_03.png","Pls_04.png","Pls_05.png","Pls_06.png","Pls_07.png","Pls_08.png","Pls_09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 187,
              day_startY: 160,
              day_sc_array: ["Date_00.png","Date_01.png","Date_02.png","Date_03.png","Date_04.png","Date_05.png","Date_06.png","Date_07.png","Date_08.png","Date_09.png"],
              day_tc_array: ["Date_00.png","Date_01.png","Date_02.png","Date_03.png","Date_04.png","Date_05.png","Date_06.png","Date_07.png","Date_08.png","Date_09.png"],
              day_en_array: ["Date_00.png","Date_01.png","Date_02.png","Date_03.png","Date_04.png","Date_05.png","Date_06.png","Date_07.png","Date_08.png","Date_09.png"],
              day_zero: 0,
              day_space: -2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 262,
              month_startY: 160,
              month_sc_array: ["Date_00.png","Date_01.png","Date_02.png","Date_03.png","Date_04.png","Date_05.png","Date_06.png","Date_07.png","Date_08.png","Date_09.png"],
              month_tc_array: ["Date_00.png","Date_01.png","Date_02.png","Date_03.png","Date_04.png","Date_05.png","Date_06.png","Date_07.png","Date_08.png","Date_09.png"],
              month_en_array: ["Date_00.png","Date_01.png","Date_02.png","Date_03.png","Date_04.png","Date_05.png","Date_06.png","Date_07.png","Date_08.png","Date_09.png"],
              month_zero: 0,
              month_space: -2,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 70,
              y: 161,
              image_array: ["PWR_1.png","PWR_2.png","PWR_3.png","PWR_4.png","PWR_5.png","PWR_6.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 275,
              y: 222,
              src: 'Solar.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 68,
              y: 183,
              src: 'Bell.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 104,
              y: 162,
              week_en: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_tc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_sc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 101,
              am_y: 214,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 68,
              pm_y: 214,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 68,
              hour_startY: 236,
              hour_array: ["Time_00.png","Time_01.png","Time_02.png","Time_03.png","Time_04.png","Time_05.png","Time_06.png","Time_07.png","Time_08.png","Time_09.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 174,
              minute_startY: 236,
              minute_array: ["Time_00.png","Time_01.png","Time_02.png","Time_03.png","Time_04.png","Time_05.png","Time_06.png","Time_07.png","Time_08.png","Time_09.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 265,
              second_startY: 254,
              second_array: ["Sec_00.png","Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}