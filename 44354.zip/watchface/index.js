﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_day_month_year_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_battery_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_sleep_icon_img = ''
        let normal_sleep_score_font = ''
        let normal_wakeup_count_font = ''
        let normal_wakeup_time_font = ''
        let normal_sleep_time_font = ''
        let normal_sleep_duration_total_font = ''
        let normal_sleep_end_font = ''
        let normal_sleep_start_font = ''
        let array_sleep_chart = []
        let normal_sleep_chart_group = ''
        let idle_background_bg_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_day_month_year_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_battery_current_text_font = ''
        let idle_step_current_text_font = ''
        let idle_heart_rate_text_font = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_sleep_icon_img = ''
        let idle_sleep_score_font = ''
        let idle_wakeup_count_font = ''
        let idle_wakeup_time_font = ''
        let idle_sleep_time_font = ''
        let idle_sleep_duration_total_font = ''
        let idle_sleep_end_font = ''
        let idle_sleep_start_font = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let timeSensor = '';
        let sleepSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 174,
              y: 404,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 211,
              y: 406,
              w: 35,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFFD2D2D2,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_day_month_year_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 269,
              y: 50,
              w: 111,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFFE0E0E0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 186,
              y: 236,
              w: 55,
              h: 30,
              text_size: 22,
              char_space: 1,
              color: 0xFFE1E1E1,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 67,
              y: 397,
              w: 104,
              h: 40,
              text_size: 32,
              char_space: 1,
              color: 0xFFE0E0E0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 258,
              y: 397,
              w: 63,
              h: 40,
              text_size: 32,
              char_space: 2,
              color: 0xFFE0E0E0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 220,
              minute_startY: 281,
              minute_array: ["Time_H_0.png","Time_H_1.png","Time_H_2.png","Time_H_3.png","Time_H_4.png","Time_H_5.png","Time_H_6.png","Time_H_7.png","Time_H_8.png","Time_H_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 24,
              hour_startY: 281,
              hour_array: ["Time_H_0.png","Time_H_1.png","Time_H_2.png","Time_H_3.png","Time_H_4.png","Time_H_5.png","Time_H_6.png","Time_H_7.png","Time_H_8.png","Time_H_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 174,
              y: 282,
              src: 'Time_Dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 28,
              y: 28,
              src: 'Weather_29.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_score_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 58,
              y: 234,
              w: 38,
              h: 31,
              text_size: 22,
              char_space: 2,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wakeup_count_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 229,
              y: 236,
              w: 41,
              h: 31,
              text_size: 22,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wakeup_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 259,
              y: 210,
              w: 149,
              h: 27,
              text_size: 20,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_string: ч   м,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -12,
              y: 208,
              w: 128,
              h: 30,
              text_size: 22,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ч   м,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_duration_total_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 112,
              y: 41,
              w: 163,
              h: 32,
              text_size: 25,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ч   м,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_end_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 210,
              y: 160,
              w: 96,
              h: 35,
              text_size: 23,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              // padding: true,
              // unit_end: 2,
              // unit_string: ч  м,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_start_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 89,
              y: 161,
              w: 96,
              h: 35,
              text_size: 23,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              // unit_end: 2,
              // unit_string: ч м,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_chart_group = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 17,
              y: 81,
              w: 363,
              h: 80,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 174,
              y: 404,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 211,
              y: 406,
              w: 35,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFFD2D2D2,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_month_year_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 269,
              y: 50,
              w: 111,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFFE0E0E0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 186,
              y: 236,
              w: 55,
              h: 30,
              text_size: 22,
              char_space: 1,
              color: 0xFFE1E1E1,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 67,
              y: 397,
              w: 104,
              h: 40,
              text_size: 32,
              char_space: 1,
              color: 0xFFE0E0E0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 258,
              y: 397,
              w: 63,
              h: 40,
              text_size: 32,
              char_space: 2,
              color: 0xFFE0E0E0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 220,
              minute_startY: 281,
              minute_array: ["Time_H_0.png","Time_H_1.png","Time_H_2.png","Time_H_3.png","Time_H_4.png","Time_H_5.png","Time_H_6.png","Time_H_7.png","Time_H_8.png","Time_H_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 24,
              hour_startY: 281,
              hour_array: ["Time_H_0.png","Time_H_1.png","Time_H_2.png","Time_H_3.png","Time_H_4.png","Time_H_5.png","Time_H_6.png","Time_H_7.png","Time_H_8.png","Time_H_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 174,
              y: 282,
              src: 'Time_Dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sleep_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 28,
              y: 28,
              src: 'Weather_29.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sleep_score_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 58,
              y: 234,
              w: 38,
              h: 31,
              text_size: 22,
              char_space: 2,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wakeup_count_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 229,
              y: 236,
              w: 41,
              h: 31,
              text_size: 22,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wakeup_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 259,
              y: 210,
              w: 149,
              h: 27,
              text_size: 20,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_string: ч   м,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sleep_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -12,
              y: 208,
              w: 128,
              h: 30,
              text_size: 22,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ч   м,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sleep_duration_total_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 112,
              y: 41,
              w: 163,
              h: 32,
              text_size: 25,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ч   м,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sleep_end_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 210,
              y: 160,
              w: 96,
              h: 35,
              text_size: 23,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              // padding: true,
              // unit_end: 2,
              // unit_string: ч  м,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sleep_start_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 89,
              y: 161,
              w: 96,
              h: 35,
              text_size: 23,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              // unit_end: 2,
              // unit_string: ч м,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 38,
              y: 401,
              w: 120,
              h: 40,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 262,
              y: 400,
              w: 102,
              h: 46,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 172,
              y: 402,
              w: 73,
              h: 39,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 285,
              y: 55,
              w: 100,
              h: 24,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 158,
              y: 242,
              w: 74,
              h: 31,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 11,
              y: 24,
              w: 109,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day/month/year font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                let normal_YearStr = timeSensor.year.toString();
                let normal_DayMonthYearStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0) {
                  normal_DayMonthYearStr = normal_YearStr + '/' + normal_MonthStr + '/' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthYearStr = normal_DayStr + '/' + normal_MonthStr + '/' + normal_YearStr;
                }
                if (dateFormat == 2) {
                  normal_DayMonthYearStr = normal_MonthStr + '/' + normal_DayStr + '/' + normal_YearStr;
                }
                normal_day_month_year_font.setProperty(hmUI.prop.TEXT, normal_DayMonthYearStr );
              };

              console.log('day/month/year font');
              if (updateHour) {
                let idle_DayStr = timeSensor.day.toString();
                let idle_MonthStr = timeSensor.month.toString();
                let idle_YearStr = timeSensor.year.toString();
                let idle_DayMonthYearStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0) {
                  idle_DayMonthYearStr = idle_YearStr + '/' + idle_MonthStr + '/' + idle_DayStr;
                }
                if (dateFormat == 1) {
                  idle_DayMonthYearStr = idle_DayStr + '/' + idle_MonthStr + '/' + idle_YearStr;
                }
                if (dateFormat == 2) {
                  idle_DayMonthYearStr = idle_MonthStr + '/' + idle_DayStr + '/' + idle_YearStr;
                }
                idle_day_month_year_font.setProperty(hmUI.prop.TEXT, idle_DayMonthYearStr );
              };

            };

            //#endregion
            if (!sleepSensor) sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
            //#region sleep_update
            function sleep_update() {
              console.log('sleep_update()');
              let sleepInfo = sleepSensor.getBasicInfo();

              console.log('sleep score');
              let sleepScore = sleepInfo.score;
              if (normal_sleep_score_font) normal_sleep_score_font.setProperty(hmUI.prop.TEXT, String(sleepScore));

              console.log('sleep wakeup count');
              let sleepTime = sleepSensor.getTotalTime();
              const modelData = sleepSensor.getSleepStageModel();
              let sleepStageArray = sleepSensor.getSleepStageData();
              let wakeupTime = 0;
              let wakeupCount = 0;

              for (let i = 0; i < sleepStageArray.length; i++) {
                let data = sleepStageArray[i];
                if (data.model == modelData.WAKE_STAGE) {
                  wakeupTime += data.stop + 1 - data.start;
                  wakeupCount++;
                };
              };
              sleepTime -= wakeupTime;
              if (normal_wakeup_count_font) normal_wakeup_count_font.setProperty(hmUI.prop.TEXT, String(wakeupCount));

              console.log('sleep wakeup time');
              let wakeupTimeHour = Math.floor(wakeupTime / 60);
              let wakeupTimeMin = wakeupTime % 60;

              let normal_wakeupTimeHourStr = wakeupTimeHour.toString();
              normal_wakeupTimeHourStr = normal_wakeupTimeHourStr.padStart(2, '0');
              let normal_wakeupTimeMinStr = wakeupTimeMin.toString().padStart(2, '0');
              let normal_wakeupTimeStr = normal_wakeupTimeHourStr + 'ч   м' + normal_wakeupTimeMinStr;
              if (normal_wakeup_time_font) normal_wakeup_time_font.setProperty(hmUI.prop.TEXT, normal_wakeupTimeStr);

              console.log('sleep duration time');
              let sleepTimeHour = Math.floor(sleepTime / 60);
              let sleepTimeMin = sleepTime % 60;

              let normal_sleepTimeHourStr = sleepTimeHour.toString();
              let normal_sleepTimeMinStr = sleepTimeMin.toString().padStart(2, '0');
              let normal_sleepTimeStr = normal_sleepTimeHourStr + 'ч   м' + normal_sleepTimeMinStr;
              if (normal_sleep_time_font) normal_sleep_time_font.setProperty(hmUI.prop.TEXT, normal_sleepTimeStr);

              console.log('sleep duration total time');
              let sleepDurationTotalTime = sleepSensor.getTotalTime();
              let sleepDurationTotalHour = Math.floor(sleepDurationTotalTime / 60);
              let sleepDurationTotalMin = sleepDurationTotalTime % 60;

              let normal_sleepDurationTotalHourStr = sleepDurationTotalHour.toString();
              let normal_sleepDurationTotalMinStr = sleepDurationTotalMin.toString().padStart(2, '0');
              let normal_SleepDurationStr = normal_sleepDurationTotalHourStr + 'ч   м' + normal_sleepDurationTotalMinStr;
              if (normal_sleep_duration_total_font) normal_sleep_duration_total_font.setProperty(hmUI.prop.TEXT, normal_SleepDurationStr);

              console.log('sleep end time');
              let sleepEndTime = sleepInfo.endTime;
              if (sleepEndTime >= 24*60) sleepEndTime -= 24*60;
              let sleepEndHour = Math.floor(sleepEndTime / 60);
              if (!timeSensor.is24Hour) {
                if (sleepEndHour >= 12) sleepEndHour -= 12;
                if (sleepEndHour == 0) sleepEndHour = 12;
              };
              let sleepEndMin = sleepEndTime % 60;

              let normal_sleepEndHourStr = sleepEndHour.toString();
              normal_sleepEndHourStr = normal_sleepEndHourStr.padStart(2, '0');
              let normal_SleepEndMinStr = sleepEndMin.toString().padStart(2, '0');
              let normal_SleepEndStr = normal_sleepEndHourStr + 'ч  м' + normal_SleepEndMinStr;
              if (normal_sleep_end_font) normal_sleep_end_font.setProperty(hmUI.prop.TEXT, normal_SleepEndStr);

              console.log('sleep start time');
              let sleepStartTime = sleepInfo.startTime;
              if (sleepStartTime >= 24*60) sleepStartTime -= 24*60;
              let sleepStartHour = Math.floor(sleepStartTime / 60);
              if (!timeSensor.is24Hour) {
                if (sleepStartHour >= 12) sleepStartHour -= 12;
                if (sleepStartHour == 0) sleepStartHour = 12;
              };
              let sleepStartMin = sleepStartTime % 60;

              let normal_SleepStartHourStr = sleepStartHour.toString();
              normal_SleepStartHourStr = normal_SleepStartHourStr.padStart(2, '0');
              let normal_SleepStartMinStr = sleepStartMin.toString().padStart(2, '0');
              let normal_SleepStartStr = normal_SleepStartHourStr + 'ч м' + normal_SleepStartMinStr;
              if (normal_sleep_start_font) normal_sleep_start_font.setProperty(hmUI.prop.TEXT, normal_SleepStartStr);

              console.log('sleep chart');
              let normal_sleepColors = [0xFF743ED4, 0xFF6284EF, 0xFF46C536, 0xFFAE433B];
              let normal_sleppChartWidth = 363;
              let normal_sleppChartHeight = 80;
              let normal_sleepScaleX = normal_sleppChartWidth / sleepSensor.getTotalTime();
              let normal_sleepScaleY = normal_sleppChartHeight / 4;
              let sleepChartStartTime = 0;
              if (array_sleep_chart.length > 0) {
                console.log('deleteWidget screen on');
                for (let i = 0; i < array_sleep_chart.length; i++) {
                  if (array_sleep_chart[i]) hmUI.deleteWidget(array_sleep_chart[i]);
                }
                array_sleep_chart = [];
              } // end if

              if (sleepStageArray != undefined && sleepStageArray.length > 0) sleepChartStartTime = sleepStageArray[0].start;
              // console.log('draw normal_sleep_chart');
              if (screenType == hmSetting.screen_type.WATCHFACE) {
                for (let i = 0; i < sleepStageArray.length; i++) { //ONLY_NORMAL
                  let data = sleepStageArray[i];
                  let normal_color = normal_sleepColors[0];
                  let normal_posY = 3 * normal_sleepScaleY;

                  switch (data.model) {
                    case modelData.WAKE_STAGE:
                      normal_color = normal_sleepColors[3];
                      normal_posY = 0;
                      break;
                    case modelData.REM_STAGE:
                      normal_color = normal_sleepColors[2];
                      normal_posY = normal_sleepScaleY; 
                      break;
                    case modelData.LIGHT_STAGE:
                      normal_color = normal_sleepColors[1];
                      normal_posY = 2 * normal_sleepScaleY; 
                      break;
                  };
                  let normal_x = (data.start - sleepChartStartTime) * normal_sleepScaleX;
                  let normal_w = (data.stop + 1 - data.start) * normal_sleepScaleX;
                  const fill_rect = normal_sleep_chart_group.createWidget(hmUI.widget.FILL_RECT, {
                    x: normal_x,
                    y: normal_posY,
                    w: normal_w < 2 ? 2 : normal_w,
                    h: normal_sleepScaleY,
                    radius: 5,
                    color: normal_color,
                  });
                  array_sleep_chart.push(fill_rect);
                }; // for
              }; // end screenType

              console.log('sleep score');
              if (idle_sleep_score_font) idle_sleep_score_font.setProperty(hmUI.prop.TEXT, String(sleepScore));

              console.log('sleep wakeup count');
              if (idle_wakeup_count_font) idle_wakeup_count_font.setProperty(hmUI.prop.TEXT, String(wakeupCount));

              console.log('sleep wakeup time');
              let idle_wakeupTimeHourStr = wakeupTimeHour.toString();
              idle_wakeupTimeHourStr = idle_wakeupTimeHourStr.padStart(2, '0');
              let idle_wakeupTimeMinStr = wakeupTimeMin.toString().padStart(2, '0');
              let idle_wakeupTimeStr = idle_wakeupTimeHourStr + 'ч   м' + idle_wakeupTimeMinStr;
              if (idle_wakeup_time_font) idle_wakeup_time_font.setProperty(hmUI.prop.TEXT, idle_wakeupTimeStr);

              console.log('sleep duration time');
              let idle_sleepTimeHourStr = sleepTimeHour.toString();
              let idle_sleepTimeMinStr = sleepTimeMin.toString().padStart(2, '0');
              let idle_sleepTimeStr = idle_sleepTimeHourStr + 'ч   м' + idle_sleepTimeMinStr;
              if (idle_sleep_time_font) idle_sleep_time_font.setProperty(hmUI.prop.TEXT, idle_sleepTimeStr);

              console.log('sleep duration total time');
              let idle_sleepDurationTotalHourStr = sleepDurationTotalHour.toString();
              let idle_sleepDurationTotalMinStr = sleepDurationTotalMin.toString().padStart(2, '0');
              let idle_SleepDurationStr = idle_sleepDurationTotalHourStr + 'ч   м' + idle_sleepDurationTotalMinStr;
              if (idle_sleep_duration_total_font) idle_sleep_duration_total_font.setProperty(hmUI.prop.TEXT, idle_SleepDurationStr);

              console.log('sleep end time');
              let idle_sleepEndHourStr = sleepEndHour.toString();
              idle_sleepEndHourStr = idle_sleepEndHourStr.padStart(2, '0');
              let idle_SleepEndMinStr = sleepEndMin.toString().padStart(2, '0');
              let idle_SleepEndStr = idle_sleepEndHourStr + 'ч  м' + idle_SleepEndMinStr;
              if (idle_sleep_end_font) idle_sleep_end_font.setProperty(hmUI.prop.TEXT, idle_SleepEndStr);

              console.log('sleep start time');
              let idle_SleepStartHourStr = sleepStartHour.toString();
              idle_SleepStartHourStr = idle_SleepStartHourStr.padStart(2, '0');
              let idle_SleepStartMinStr = sleepStartMin.toString().padStart(2, '0');
              let idle_SleepStartStr = idle_SleepStartHourStr + 'ч м' + idle_SleepStartMinStr;
              if (idle_sleep_start_font) idle_sleep_start_font.setProperty(hmUI.prop.TEXT, idle_SleepStartStr);

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                sleep_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

                if (array_sleep_chart.length > 0) {
                console.log('deleteWidget screen off');
                  for (let i = 0; i < array_sleep_chart.length; i++) {
                    if (array_sleep_chart[i]) hmUI.deleteWidget(array_sleep_chart[i]);
                  }
                  array_sleep_chart = [];
                } // end if
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}