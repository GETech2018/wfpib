﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//////Vibration feedback for buttons
const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
let timer_StopVibrate = null;

function makeVibrate(level = 1) {
  stopVibrate();

  //The values are used as follows: 1 for buttons, 2 for open settings menu, 3 for close settings menu
  const levelToScene = {
    1: 26,
    2: 27,
    3: 29
  };

  let scene = levelToScene[level] || 25;
  let stopDelay = scene > 25 ? 1300 : 50;

  vibrate.scene = scene;
  vibrate.start();

  timer_StopVibrate = timer.createTimer(stopDelay, 0, stopVibrate, {});
}

function stopVibrate() {
  vibrate.stop();
  if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
  timer_StopVibrate = null;
}

//////Watchface Language Sets (Uppercase)
const watchfaceLangs = {
  EN:{
    WEEKDAYS_SHORT: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],

    DATELABEL: "DATE",
    WEATHERLABEL: "WEATHER",
    STEPSLABEL: "STEPS",
    BATTERYLABEL: "BATTERY",
  },

  ES:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MIÉ", "JUE", "VIE", "SÁB", "DOM"],

    DATELABEL: "FECHA",
    WEATHERLABEL: "CLIMA",
    STEPSLABEL: "PASOS",
    BATTERYLABEL: "BATERIA",
  },

  FR:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MER", "JEU", "VEN", "SAM", "DIM"],

    DATELABEL: "DATE",
    WEATHERLABEL: "MÉTÉO",
    STEPSLABEL: "PAS",
    BATTERYLABEL: "BATTERIE",
  },

  PT:{
    WEEKDAYS_SHORT: ["SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM"],

    DATELABEL: "DATA",
    WEATHERLABEL: "CLIMA",
    STEPSLABEL: "PASSOS",
    BATTERYLABEL: "BATERIA",
  },

  IT:{
    WEEKDAYS_SHORT: ["LUN", "MAR", "MER", "GIO", "VEN", "SAB", "DOM"],

    DATELABEL: "DATA",
    WEATHERLABEL: "METEO",
    STEPSLABEL: "PASSI",
    BATTERYLABEL: "BATTERIA",
  },

  DE:{
    WEEKDAYS_SHORT: ["MO", "DI", "MI", "DO", "FR", "SA", "SO"],

    DATELABEL: "DATUM",
    WEATHERLABEL: "WETTER",
    STEPSLABEL: "SCHRITTE",
    BATTERYLABEL: "BATTERIE",
  },
};
let currWatchfaceLang;
let currLangCode;

let colorsSet = 6;
let colorIndex = 1;
let currHourFormat = hmSetting.getTimeFormat(); //Get time format 12h/24h
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_analog_clock_time_pointer_smooth_second = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_widget_text_3 = ''
        let normal_widget_text_4 = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_day_text_font = ''
        let normal_step_current_text_font = ''
        let normal_battery_current_text_font = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_time_second_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SF-Compact-Rounded-Bold.ttf; FontSize: 16
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 273,
              h: 22,
              text_size: 16,
              char_space: 2,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: SF-Compact-Rounded-Semibold.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 373,
              h: 32,
              text_size: 24,
              char_space: 2,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Semibold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

//////Function to detect current language from system
function detectLanguage() {
    const zeppAvailableLangs = [
        "ZH", // 0  Chinese (Simplified)
        "ZH", // 1  Chinese (Traditional)
        "EN", // 2  English
        "ES", // 3  Spanish
        "RU", // 4  Russian
        "KO", // 5  Korean
        "FR", // 6  French
        "DE", // 7  German
        "ID", // 8  Indonesian
        "PL", // 9  Polish
        "IT", // 10 Italian
        "JA", // 11 Japanese
        "TH", // 12 Thai
        "AR", // 13 Arabic
        "VI", // 14 Vietnamese
        "PT", // 15 Portuguese (Portugal)
        "NL", // 16 Dutch
        "TR", // 17 Turkish
        "UK", // 18 Ukrainian
        "HE", // 19 Hebrew
        "PT", // 20 Portuguese (Brazil)
        "RO", // 21 Romanian
        "CS", // 22 Czech
        "EL", // 23 Greek
        "SR", // 24 Serbian
        "CA", // 25 Catalan
        "FI", // 26 Finnish
        "NO", // 27 Norwegian
        "DA", // 28 Danish
        "SV", // 29 Swedish
        "HU", // 30 Hungarian
        "MS", // 31 Malay
        "SK", // 32 Slovak
        "HI"  // 33 Hindi
    ];
    let langCode = zeppAvailableLangs[hmSetting.getLanguage()]; //Get current language on watch

    currLangCode = watchfaceLangs[langCode] ? langCode : "EN";
    currWatchfaceLang = watchfaceLangs[currLangCode];
}
detectLanguage();
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 0,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: MON, TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'CLOCK_HAND_SEC_1.png',
              // center_x: 195,
              // center_y: 225,
              // x: 130,
              // y: 210,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'CLOCK_HAND_SEC_1.png',
              second_centerX: 195,
              second_centerY: 225,
              second_posX: 130,
              second_posY: 210,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'CLOCK_HAND_HRMIN_1.png',
              // center_x: 195,
              // center_y: 225,
              // x: 21,
              // y: 210,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 21,
              pos_y: 225 - 210,
              center_x: 195,
              center_y: 225,
              src: 'CLOCK_HAND_HRMIN_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'CLOCK_HAND_HRMIN_1.png',
              // center_x: 195,
              // center_y: 225,
              // x: 21,
              // y: 210,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 21,
              pos_y: 225 - 210,
              center_x: 195,
              center_y: 225,
              src: 'CLOCK_HAND_HRMIN_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -37,
              y: -7,
              w: 464,
              h: 464,
              text_size: 16,
              char_space: 2,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -30,
              end_angle: 0,
              mode: 0,
              // radius: 232,
              align_h: hmUI.align.LEFT,
              text: 'DATE',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -37,
              y: -7,
              w: 464,
              h: 464,
              text_size: 16,
              char_space: 2,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 39,
              mode: 0,
              // radius: 232,
              align_h: hmUI.align.RIGHT,
              text: 'WEATHER',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -37,
              y: -7,
              w: 464,
              h: 464,
              text_size: 16,
              char_space: 2,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 149,
              end_angle: 170,
              mode: 1,
              // radius: 232,
              align_h: hmUI.align.RIGHT,
              text: 'STEPS',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -37,
              y: -7,
              w: 464,
              h: 464,
              text_size: 16,
              char_space: 2,
              font: 'fonts/SF-Compact-Rounded-Bold.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 180,
              end_angle: 218,
              mode: 1,
              // radius: 232,
              align_h: hmUI.align.LEFT,
              text: 'BATTERY',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 240,
              y: 0,
              image_array: ["WEATHERICON_1.png","WEATHERICON_2.png","WEATHERICON_3.png","WEATHERICON_4.png","WEATHERICON_5.png","WEATHERICON_6.png","WEATHERICON_7.png","WEATHERICON_8.png","WEATHERICON_9.png","WEATHERICON_10.png","WEATHERICON_11.png","WEATHERICON_12.png","WEATHERICON_13.png","WEATHERICON_14.png","WEATHERICON_15.png","WEATHERICON_16.png","WEATHERICON_17.png","WEATHERICON_18.png","WEATHERICON_19.png","WEATHERICON_20.png","WEATHERICON_21.png","WEATHERICON_22.png","WEATHERICON_23.png","WEATHERICON_24.png","WEATHERICON_25.png","WEATHERICON_26.png","WEATHERICON_27.png","WEATHERICON_28.png","WEATHERICON_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -23,
              y: 7,
              w: 436,
              h: 436,
              text_size: 24,
              char_space: 2,
              font: 'fonts/SF-Compact-Rounded-Semibold.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 39,
              end_angle: 60,
              mode: 0,
              // radius: 218,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -23,
              y: 7,
              w: 436,
              h: 436,
              text_size: 24,
              char_space: 2,
              font: 'fonts/SF-Compact-Rounded-Semibold.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -60,
              end_angle: 10,
              mode: 0,
              // radius: 218,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -23,
              y: 7,
              w: 436,
              h: 436,
              text_size: 24,
              char_space: 2,
              font: 'fonts/SF-Compact-Rounded-Semibold.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 120,
              end_angle: 169,
              mode: 1,
              // radius: 218,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -23,
              y: 7,
              w: 436,
              h: 436,
              text_size: 24,
              char_space: 2,
              font: 'fonts/SF-Compact-Rounded-Semibold.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 192,
              end_angle: 246,
              mode: 1,
              // radius: 218,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AODOVERLAY.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 0,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

//////Clock digits
//Normal
let clockDigitMinLow = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'CLOCKWHITE_0.png',
    x: 178,
    y: 190,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockDigitHrHigh = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'CLOCKWHITE_0.png',
    x: 90,
    y: 100,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockDigitHrLow = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'CLOCKWHITE_0.png',
    x: 168,
    y: 100,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

let clockDigitMinHigh = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'CLOCKWHITE_0.png',
    x: 100,
    y: 190,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

//AOD
let clockDigitMinLow_AOD = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'CLOCKWHITE_0.png',
    x: 178,
    y: 190,
    show_level: hmUI.show_level.ONLY_AOD,
});

let clockDigitHrHigh_AOD = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'CLOCKWHITE_0.png',
    x: 90,
    y: 100,
    show_level: hmUI.show_level.ONLY_AOD,
});

let clockDigitHrLow_AOD = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'CLOCKWHITE_0.png',
    x: 168,
    y: 100,
    show_level: hmUI.show_level.ONLY_AOD,
});

let clockDigitMinHigh_AOD = hmUI.createWidget(hmUI.widget.IMG, {
    src: 'CLOCKWHITE_0.png',
    x: 100,
    y: 190,
    show_level: hmUI.show_level.ONLY_AOD,
});

function updateClock(){
    let clockHr = timeSensor.hour;
    let clockMin = timeSensor.minute;

    //Convert clock depending on format... 0 = 12h, 1 = 24h
    if (currHourFormat == 0){
        if (clockHr == 0){
            clockHr = 12;
        }else if (clockHr > 12){
            clockHr -= 12;
        }
    }

    //Add zeros if hr<10
    let clockHrTXT = clockHr.toString().padStart(2, "0");
    let clockMinsTXT = clockMin.toString().padStart(2, "0");

    //Set digits source
    let clockHrHigh_SRC = "CLOCKWHITE_" + clockHrTXT[0] + ".png";
    let clockHrLow_SRC = "CLOCKWHITE_" + clockHrTXT[1] + ".png";
    let clockMinsHigh_SRC = "CLOCKWHITE_" + clockMinsTXT[0] + ".png";
    let clockMinsLow_SRC = "CLOCKWHITE_" + clockMinsTXT[1] + ".png";

    //////Update digits
    //Normal
    clockDigitHrHigh.setProperty(hmUI.prop.SRC, clockHrHigh_SRC);
    clockDigitHrLow.setProperty(hmUI.prop.SRC, clockHrLow_SRC);
    clockDigitMinHigh.setProperty(hmUI.prop.SRC, clockMinsHigh_SRC);
    clockDigitMinLow.setProperty(hmUI.prop.SRC, clockMinsLow_SRC);
    //AOD
    clockDigitHrHigh_AOD.setProperty(hmUI.prop.SRC, clockHrHigh_SRC);
    clockDigitHrLow_AOD.setProperty(hmUI.prop.SRC, clockHrLow_SRC);
    clockDigitMinHigh_AOD.setProperty(hmUI.prop.SRC, clockMinsHigh_SRC);
    clockDigitMinLow_AOD.setProperty(hmUI.prop.SRC, clockMinsLow_SRC);
}
updateClock();

//////Set alpha and current language for modules label
let modulesLabelAlpha = 191;
normal_widget_text_1.setAlpha(modulesLabelAlpha);
normal_widget_text_1.setProperty(hmUI.prop.TEXT, currWatchfaceLang.DATELABEL);
normal_widget_text_2.setAlpha(modulesLabelAlpha);
normal_widget_text_2.setProperty(hmUI.prop.TEXT, currWatchfaceLang.WEATHERLABEL);
normal_widget_text_3.setAlpha(modulesLabelAlpha);
normal_widget_text_3.setProperty(hmUI.prop.TEXT, currWatchfaceLang.STEPSLABEL);
normal_widget_text_4.setAlpha(modulesLabelAlpha);
normal_widget_text_4.setProperty(hmUI.prop.TEXT, currWatchfaceLang.BATTERYLABEL);
            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 25,
              y: 0,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 265,
              y: 0,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 120,
              y: 120,
              w: 150,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 120,
              y: 230,
              w: 150,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 25,
              y: 350,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 265,
              y: 350,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 135,
              y: 0,
              w: 120,
              h: 110,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              longpress_func: (button_widget) => {
                settingsMenu(true)
makeVibrate(2)
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let watchfaceButtons = [ Button_1, Button_2, Button_3, Button_4, Button_5, Button_6 ];

//////Watchface menu
let prevColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 0,
    y: 34,
    w: 134,
    h: 382,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTNPREV_PRESSED.png',
    normal_src: 'settings/BTNPREV_NORMAL.png',
    click_func: (button_widget) => {
    prevColor()
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let nextColorbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 256,
    y: 34,
    w: 134,
    h: 382,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTNNEXT_PRESSED.png',
    normal_src: 'settings/BTNNEXT_NORMAL.png',
    click_func: (button_widget) => {
    nextColor()
    makeVibrate(1)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let Confirmbtn = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 135,
    y: 340,
    w: 120,
    h: 90,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'settings/BTN_CONFIRM_PRESSED.png',
    normal_src: 'settings/BTN_CONFIRM_NORMAL.png',
    click_func: (button_widget) => {
    settingsMenu(false)
    makeVibrate(3)
    }, // end func
    show_level: hmUI.show_level.ONLY_NORMAL,
}); // end button

let settingMenuLayout = [ prevColorbtn, nextColorbtn, Confirmbtn ];

function prevColor(){
    colorIndex = colorIndex - 1;
    if (colorIndex < 1) colorIndex = colorsSet;
    updateWatchface();
}

function nextColor(){
    colorIndex = colorIndex + 1;
    if (colorIndex > colorsSet) colorIndex = 1;
    updateWatchface();
}

function updateWatchface(){
    //Set source for elements
    let currBG_SRC = "BG_" + colorIndex + ".png";
    hmFS.SysProSetInt('AEON_bgIndex', colorIndex);
    let currHANDhr_SRC = "CLOCK_HAND_HRMIN_" + colorIndex + ".png";
    let currHANDmin_SRC = "CLOCK_HAND_HRMIN_" + colorIndex + ".png";
    let currHANDsec_SRC = "CLOCK_HAND_SEC_" + colorIndex + ".png";

    // Get current angles for hour and minute hands
    let currHANDhr_angle = normal_analog_clock_pro_hour_pointer_img.getProperty(hmUI.prop.ANGLE);
    let currHANDmin_angle = normal_analog_clock_pro_minute_pointer_img.getProperty(hmUI.prop.ANGLE);

    //Set background image
    normal_background_bg_img.setProperty(hmUI.prop.SRC, currBG_SRC);

    //Set analog clock hands
    normal_analog_clock_time_pointer_smooth_second.setProperty(hmUI.prop.MORE, {
        second_path: currHANDsec_SRC,
        second_centerX: 195,
        second_centerY: 225,
        second_posX: 130,
        second_posY: 210,
        fresh_frequency: 15,
        fresh_freqency: 15,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.MORE, {
        x: 0,
        y: 0,
        w: deviceInfo.width,
        h: deviceInfo.height,
        pos_x: 195 - 21,
        pos_y: 225 - 210,
        center_x: 195,
        center_y: 225,
        src: currHANDhr_SRC,
        angle: currHANDhr_angle,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
    
    normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.MORE, {
        x: 0,
        y: 0,
        w: deviceInfo.width,
        h: deviceInfo.height,
        pos_x: 195 - 21,
        pos_y: 225 - 210,
        center_x: 195,
        center_y: 225,
        src: currHANDmin_SRC,
        angle: currHANDmin_angle,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
};

function settingsMenu(isVisible){
    watchfaceButtons.forEach(element => element.setProperty(hmUI.prop.VISIBLE, !isVisible));
    settingMenuLayout.forEach(element => element.setProperty(hmUI.prop.VISIBLE, isVisible));
};

settingsMenu(false);
idle_background_bg_img.setProperty(hmUI.prop.SRC, "BG_" + [hmFS.SysProGetInt('AEON_bgIndex') ?? 1] + ".png");
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              updateClock()
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) { // Hour Pointer
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              
                console.log('full date str');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                let normal_DOW_Str = currWatchfaceLang.WEEKDAYS_SHORT[timeSensor.week-1];
                let fullDate_Str = normal_DOW_Str + " " + normal_dayStr;

                normal_day_text_font.setProperty(hmUI.prop.TEXT, fullDate_Str );
              };
            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

                console.log('pause_call.js');
                // start pause_call.js

settingsMenu(false)
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}