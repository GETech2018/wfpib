﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let ptMainWidgets = [];
let ptBagWidgets = [];
function ptPage(main) { ptMainWidgets.forEach(w => w.setProperty(hmUI.prop.VISIBLE, main)); ptBagWidgets.forEach(w => w.setProperty(hmUI.prop.VISIBLE, !main)); }
let image_top_img = ''
        let image_level_text =''
        let normal_background_bag_img = ''
        let normal_pai_day_text_bag_img = ''
        let normal_heart_rate_text_text_bag_img = ''
        let normal_distance_text_text_bag_img = ''
        let normal_calorie_current_text_bag_img = ''
        let normal_step_current_text_bag_img = ''
        let lvlcalc = 1000
        let stepsWidget = ''
        let steps = hmSensor.createSensor(hmSensor.id.STEP)
        let stepsPercent = Math.floor(steps.current / lvlcalc)  
        let lvlstep = Math.floor(stepsPercent -1)
        let colornumber = 1
        let totalcolors = 6
        let Button_bag_5 = ''
        let backgroundpage = 1
        let totalpage = 2
        let cc = 0 
        let normal_date_img_text

// Start background change

                 
        
function click_background() {
            if(backgroundpage>=totalpage) {
            backgroundpage=1;
                backgroundone();
                }
            else {
                backgroundpage=backgroundpage+1;
                if(backgroundpage==2) {
                  backgroundtwo();
                }

            }
            
        }


        function backgroundone(){
   ptPage(true);

   normal_background_bg_img.setProperty(hmUI.prop.VISIBLE, true);  
   normal_sun_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_image_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
   normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
   normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_text.setProperty(hmUI.prop.VISIBLE, true);
   normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_3.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_4.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_5.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_6.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_7.setProperty(hmUI.prop.VISIBLE, true);
   idle_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
   idle_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
   stepsWidget.setProperty(hmUI.prop.VISIBLE, true);
   image_top_img.setProperty(hmUI.prop.VISIBLE, true);
   image_level_text.setProperty(hmUI.prop.VISIBLE, true);
   Button_1.setProperty(hmUI.prop.VISIBLE, true);
   Button_2.setProperty(hmUI.prop.VISIBLE, true);
   Button_3.setProperty(hmUI.prop.VISIBLE, true);
   Button_4.setProperty(hmUI.prop.VISIBLE, true);
   Button_5.setProperty(hmUI.prop.VISIBLE, true);
   normal_background_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   normal_pai_day_text_bag_img.setProperty(hmUI.prop.VISIBLE, false);  
   normal_heart_rate_text_text_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   normal_distance_text_text_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   normal_calorie_current_text_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   normal_step_current_text_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   Button_bag_5.setProperty(hmUI.prop.VISIBLE, false); 

}


         function backgroundtwo(){
   ptPage(false);

   normal_background_bg_img.setProperty(hmUI.prop.VISIBLE, false);  
   normal_sun_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
   normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
   normal_image_img.setProperty(hmUI.prop.VISIBLE, false);
   normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
   normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
   normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
   normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
   normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
   normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, false);
   normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, false);
   normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
   normal_date_img_text.setProperty(hmUI.prop.VISIBLE, false);
   normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
   normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
   normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
   normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
   normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
   normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
   normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
   normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE, false);
   normal_frame_animation_3.setProperty(hmUI.prop.VISIBLE, false);
   normal_frame_animation_4.setProperty(hmUI.prop.VISIBLE, false);
   normal_frame_animation_5.setProperty(hmUI.prop.VISIBLE, false);
   normal_frame_animation_6.setProperty(hmUI.prop.VISIBLE, false);
   normal_frame_animation_7.setProperty(hmUI.prop.VISIBLE, false);
   idle_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
   idle_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
   image_top_img.setProperty(hmUI.prop.VISIBLE, false);
   stepsWidget.setProperty(hmUI.prop.VISIBLE, false);
   image_level_text.setProperty(hmUI.prop.VISIBLE, false);
   Button_1.setProperty(hmUI.prop.VISIBLE, false);
   Button_2.setProperty(hmUI.prop.VISIBLE, false);
   Button_3.setProperty(hmUI.prop.VISIBLE, false);
   Button_4.setProperty(hmUI.prop.VISIBLE, false);
   Button_5.setProperty(hmUI.prop.VISIBLE, false);
   normal_background_bag_img.setProperty(hmUI.prop.VISIBLE, true); 
   normal_pai_day_text_bag_img.setProperty(hmUI.prop.VISIBLE, true);  
   normal_heart_rate_text_text_bag_img.setProperty(hmUI.prop.VISIBLE, true); 
   normal_distance_text_text_bag_img.setProperty(hmUI.prop.VISIBLE, true); 
   normal_calorie_current_text_bag_img.setProperty(hmUI.prop.VISIBLE, true); 
   normal_step_current_text_bag_img.setProperty(hmUI.prop.VISIBLE, true); 
   Button_bag_5.setProperty(hmUI.prop.VISIBLE, true); 




}
 
// Animation hide when done
        
         function hide() {
         normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
         normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE, false);
         normal_frame_animation_3.setProperty(hmUI.prop.VISIBLE, false);
         normal_frame_animation_4.setProperty(hmUI.prop.VISIBLE, false);
         normal_frame_animation_5.setProperty(hmUI.prop.VISIBLE, false);
         normal_frame_animation_6.setProperty(hmUI.prop.VISIBLE, false);
            }

// Run click turn screen of

function click_run() {
const result = hmSetting.setScreenOff()
}

// Change pokémon

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
            hmUI.showToast({text: "Vai, Pikachu!" });
                }
            else {
                colornumber=colornumber+1;       
                } 

         if(colornumber==2) hmUI.showToast({text: 'Vai, Butterfree!'});
         if(colornumber==3) hmUI.showToast({text: 'O que Pidgeot vai fazer?'});
         if(colornumber==4) hmUI.showToast({text: 'Vai, Bulbasaur!'});
         if(colornumber==5) hmUI.showToast({text: 'Vai, Charizard!'});
         if(colornumber==6) hmUI.showToast({text: 'Vai, Squirtle!'});
          normal_image_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");
            
        }

// Start animation
   
       function before_anim() {
           if(colornumber==1) hmUI.showToast({text: "Pikachu usou TROVAO!"});
           if(colornumber==5) hmUI.showToast({text: "Charizard usou LANCA-CHAMAS!"}); 
           if(colornumber==2) hmUI.showToast({text: "Butterfree usou PO DO SONO!"});
           if(colornumber==3) hmUI.showToast({text: "Pidgeot usou RAJADA!"}); 
           if(colornumber==4) hmUI.showToast({text: "Bulbasaur usou FOLHA NAVALHA!"});
           if(colornumber==6) hmUI.showToast({text: "Squirtle usou JATO DE AGUA!"}); 
           setTimeout(click_anim, 2000);

 }


        function click_anim() {
          if(lvlstep<stepsPercent) {
          
          if(colornumber==5) normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START); 
          if(colornumber==5) normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, true);
          if(colornumber==2) normal_frame_animation_3.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START); 
          if(colornumber==2) normal_frame_animation_3.setProperty(hmUI.prop.VISIBLE, true);
          if(colornumber==3) normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START); 
          if(colornumber==3) normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE, true);     
          if(colornumber==4) normal_frame_animation_4.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START); 
          if(colornumber==4) normal_frame_animation_4.setProperty(hmUI.prop.VISIBLE, true);    
          if(colornumber==6) normal_frame_animation_5.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START); 
          if(colornumber==6) normal_frame_animation_5.setProperty(hmUI.prop.VISIBLE, true);
          if(colornumber==1) normal_frame_animation_6.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START); 
          if(colornumber==1) normal_frame_animation_6.setProperty(hmUI.prop.VISIBLE, true);
          lvlstep = Math.floor(lvlstep +0);
          
          
                          }
             else {
               
               if(lvlstep>stepsPercent) {
               lvlstep = 0;
               hmUI.showToast({text: "Mas o ataque falhou!"});

                     }
              else {

         hmUI.showToast({text: "Caminhe mais para atacar!"});
                  
            }
         }              
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_sun_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_image_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_frame_animation_3 = ''
        let normal_frame_animation_4 = ''
        let normal_frame_animation_5 = ''
        let normal_frame_animation_6 = ''
        let normal_frame_animation_7 = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '233.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["231.png","232.png","233.png"],
              image_length: 3,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 204,
              y: 11,
              image_array: ["200.png","201.png","202.png","203.png","204.png","205.png","206.png","207.png","208.png","209.png","210.png","211.png","212.png","213.png","214.png","215.png","216.png","217.png","218.png","219.png","220.png","221.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png","230.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -4,
              y: 155,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 33,
              hour_startY: 329,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: '12.png',
              hour_unit_tc: '12.png',
              hour_unit_en: '12.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 91,
              minute_startY: 329,
              minute_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 2,
              am_y: 327,
              am_sc_path: '23.png',
              am_en_path: '23.png',
              pm_x: 2,
              pm_y: 327,
              pm_sc_path: '24.png',
              pm_en_path: '24.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 271,
              font_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              padding: false,
              h_space: 0,
              unit_sc: '35.png',
              unit_tc: '35.png',
              unit_en: '35.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 339,
              y: 271,
              src: '36.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 268,
              y: 259,
              image_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 73,
              y: 374,
              src: '48.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 105,
              y: 377,
              src: '49.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 57,
              y: 122,
              week_en: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png"],
              week_tc: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png"],
              week_sc: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 231,
              y: 295,
              image_array: ["67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 5,
              y: 349,
              image_array: ["87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 14,
              y: 377,
              font_array: ["148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
              padding: false,
              h_space: 1,
              unit_sc: '161.png',
              unit_tc: '161.png',
              unit_en: '161.png',
              negative_image: '159.png',
              invalid_image: '158.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 13,
              day_startY: 94,
              day_sc_array: ["138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png"],
              day_tc_array: ["138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png"],
              day_en_array: ["138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png"],
              day_unit_sc: '126.png', day_unit_tc: '126.png', day_unit_en: '126.png',
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 57,
              month_startY: 94,
              month_sc_array: ["127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png"],
              month_tc_array: ["127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png"],
              month_en_array: ["127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '137.png',
              month_unit_tc: '137.png',
              month_unit_en: '137.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 101,
              year_startY: 94,
              year_sc_array: ["116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png"],
              year_tc_array: ["116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png"],
              year_en_array: ["116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: -30,
              y: -93,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "fireattack",
              anim_fps: 11,
              anim_size: 14,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: -62,
              y: -18,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "gustattack",
              anim_fps: 13,
              anim_size: 11,
              repeat_count: 1,
              anim_repeat: false,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_3 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: -82,
              y: -43,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "powderattack",
              anim_fps: 10,
              anim_size: 14,
              repeat_count: 1,
              anim_repeat: false,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_4 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: -69,
              y: -53,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "razorleafattack",
              anim_fps: 10,
              anim_size: 9,
              repeat_count: 1,
              anim_repeat: false,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_5 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: -73,
              y: -60,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "watergunattack",
              anim_fps: 10,
              anim_size: 12,
              repeat_count: 1,
              anim_repeat: false,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_6 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: -46,
              y: 38,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "thunderattack",
              anim_fps: 10,
              anim_size: 13,
              repeat_count: 1,
              anim_repeat: false,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_7 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 143,
              y: 309,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "second_anim",
              anim_fps: 1,
              anim_size: 5,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js

normal_date_img_text = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 191,
              y: 230,
              w: 150,
              h: 20,
              week_en: ["pt_week_long_0.png","pt_week_long_1.png","pt_week_long_2.png","pt_week_long_3.png","pt_week_long_4.png","pt_week_long_5.png","pt_week_long_6.png"],
              week_tc: ["pt_week_long_0.png","pt_week_long_1.png","pt_week_long_2.png","pt_week_long_3.png","pt_week_long_4.png","pt_week_long_5.png","pt_week_long_6.png"],
              week_sc: ["pt_week_long_0.png","pt_week_long_1.png","pt_week_long_2.png","pt_week_long_3.png","pt_week_long_4.png","pt_week_long_5.png","pt_week_long_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


             
              stepsWidget = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 339,
              y: 233,
              font_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              text: stepsPercent,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

             steps.addEventListener(hmSensor.event.CHANGE, function stepsUpdate() {

			stepsPercent = Math.floor(steps.current / lvlcalc)
			stepsWidget.setProperty(hmUI.prop.TEXT, `${stepsPercent}`)
		})
            hmUI.createWidget(hmUI.widget.IMG, {x:0,y:0,src:'approved_black.png',show_level:hmUI.show_level.ONLY_AOD});
            // end user_script.js


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 74,
              hour_startY: 70,
              hour_array: ["approved_clock_0.png","approved_clock_1.png","approved_clock_2.png","approved_clock_3.png","approved_clock_4.png","approved_clock_5.png","approved_clock_6.png","approved_clock_7.png","approved_clock_8.png","approved_clock_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: 'approved_colon.png',
              hour_unit_tc: 'approved_colon.png',
              hour_unit_en: 'approved_colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 208,
              minute_startY: 70,
              minute_array: ["approved_clock_0.png","approved_clock_1.png","approved_clock_2.png","approved_clock_3.png","approved_clock_4.png","approved_clock_5.png","approved_clock_6.png","approved_clock_7.png","approved_clock_8.png","approved_clock_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 180,
              am_y: 150,
              am_sc_path: 'approved_am.png',
              am_en_path: 'approved_am.png',
              pm_x: 180,
              pm_y: 150,
              pm_sc_path: 'approved_pm.png',
              pm_en_path: 'approved_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

image_top_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 253,
              font_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              data: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            image_level_text = hmUI.createWidget(hmUI.widget.IMG, {
              x: 359,
              y: 233,
              src: 'pt_level.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
             normal_background_bag_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'background2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_bag_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 222,
              font_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_bag_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 190,
              font_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_bag_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 155,
              font_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              dot_image: 'pt_dot.png',
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_bag_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 123,
              font_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_bag_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 92,
              font_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  
            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 255,
              y: 322,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: 'pt_bag.png',
              normal_src: 'pt_bag.png',
              click_func: (button_widget) => {
                //Bg 
                click_background();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 255,
              y: 356,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: 'pt_run.png',
              normal_src: 'pt_run.png',
              click_func: (button_widget) => {
                //run
                              click_run();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 154,
              y: 323,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: 'pt_attack.png',
              normal_src: 'pt_attack.png',
              click_func: (button_widget) => {
                //before_anim
                before_anim();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 162,
              y: 356,
              w: 106,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: 'pt_pokemon.png',
              normal_src: 'pt_pokemon.png',
              click_func: (button_widget) => {
                //change digital minute colors
                click_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 98,
              y: 371,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 28,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

Button_bag_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 86,
              y: 330,
              w: 220,
              h: 78,
              text: '',
              press_src: 'pt_close.png',
              normal_src: 'pt_close.png',
            click_func: () => {
               click_background();
               hide();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

if (cc == 0 ){

           normal_frame_animation_1.setProperty(hmUI.prop.MORE, {
              x: -30,
              y: -93,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "fireattack",
              anim_fps: 11,
              anim_size: 14,
              repeat_count: 1,
              anim_repeat: false,
           anim_status:hmUI.anim_status.STOP,
           anim_complete_call: hide,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2.setProperty(hmUI.prop.MORE, {
              x: -62,
              y: -18,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "gustattack",
              anim_fps: 13,
              anim_size: 11,
              repeat_count: 1,
              anim_repeat: false,
           anim_status:hmUI.anim_status.STOP,
           anim_complete_call: hide,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_3.setProperty(hmUI.prop.MORE, {
              x: -82,
              y: -43,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "powderattack",
              anim_fps: 10,
              anim_size: 14,
              repeat_count: 1,
              anim_repeat: false,
           anim_status:hmUI.anim_status.STOP,
           anim_complete_call: hide,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_4.setProperty(hmUI.prop.MORE, {
              x: -69,
              y: -53,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "razorleafattack",
              anim_fps: 10,
              anim_size: 9,
              repeat_count: 1,
              anim_repeat: false,
           anim_status:hmUI.anim_status.STOP,
           anim_complete_call: hide,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_5.setProperty(hmUI.prop.MORE, {
              x: -73,
              y: -60,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "watergunattack",
              anim_fps: 10,
              anim_size: 12,
              repeat_count: 1,
              anim_repeat: false,
           anim_status:hmUI.anim_status.STOP,
           anim_complete_call: hide,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_6.setProperty(hmUI.prop.MORE, {
              x: -46,
              y: 38,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "thunderattack",
              anim_fps: 10,
              anim_size: 13,
              repeat_count: 1,
              anim_repeat: false,
           anim_status:hmUI.anim_status.STOP,
           anim_complete_call: hide,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

/*
            normal_frame_animation_7.setProperty(hmUI.prop.MORE, {
              x: 143,
              y: 309,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "second_anim",
              anim_fps: 1,
              anim_size: 5,
              repeat_count: 0,
              anim_repeat: false,
           anim_status:hmUI.anim_status.STOP,
           anim_complete_call: hide,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
*/

cc = 1
   normal_background_bg_img.setProperty(hmUI.prop.VISIBLE, true);  
   normal_sun_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_image_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
   normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
   normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_text.setProperty(hmUI.prop.VISIBLE, true);
   normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
   normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, true);
   normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_3.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_4.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_5.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_6.setProperty(hmUI.prop.VISIBLE, true);
   normal_frame_animation_7.setProperty(hmUI.prop.VISIBLE, true);
   idle_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
   idle_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
   stepsWidget.setProperty(hmUI.prop.VISIBLE, true);
   image_top_img.setProperty(hmUI.prop.VISIBLE, true);
   image_level_text.setProperty(hmUI.prop.VISIBLE, true);
   Button_1.setProperty(hmUI.prop.VISIBLE, true);
   Button_2.setProperty(hmUI.prop.VISIBLE, true);
   Button_3.setProperty(hmUI.prop.VISIBLE, true);
   Button_4.setProperty(hmUI.prop.VISIBLE, true);
   Button_5.setProperty(hmUI.prop.VISIBLE, true);
   
   normal_background_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   normal_pai_day_text_bag_img.setProperty(hmUI.prop.VISIBLE, false);  
   normal_heart_rate_text_text_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   normal_distance_text_text_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   normal_calorie_current_text_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   normal_step_current_text_bag_img.setProperty(hmUI.prop.VISIBLE, false); 
   Button_bag_5.setProperty(hmUI.prop.VISIBLE, false); 

 // Keep the screen awake after loading.
}
            // PT-BR extension: health uses native data binding, without polling timers.
function ptImg(src,x,y,group,level) {
  const w=hmUI.createWidget(hmUI.widget.IMG,{x:x,y:y,src:src,show_level:level || hmUI.show_level.ONLY_NORMAL});
  if(group)group.push(w);return w;
}
function ptRect(x,y,w,h,color,group) {
 const widget=hmUI.createWidget(hmUI.widget.FILL_RECT,{x:x,y:y,w:w,h:h,color:color,show_level:hmUI.show_level.ONLY_NORMAL});
 group.push(widget);return widget;
}
const ptDigits=['pt_stat_0.png','pt_stat_1.png','pt_stat_2.png','pt_stat_3.png','pt_stat_4.png','pt_stat_5.png','pt_stat_6.png','pt_stat_7.png','pt_stat_8.png','pt_stat_9.png'];
ptImg('pt_footer.png',0,411,ptMainWidgets);
[[hmUI.data_type.STEP,33,94],[hmUI.data_type.CAL,155,90],[hmUI.data_type.HEART,269,84]].forEach(function(v) {
 ptMainWidgets.push(hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:v[1],y:425,w:v[2],h:16,font_array:ptDigits,h_space:1,padding:false,align_h:hmUI.align.CENTER_H,type:v[0],invalid_image:'pt_invalid.png',show_level:hmUI.show_level.ONLY_NORMAL}));
});
// Cover the original English labels with small code-native labels; artwork is unchanged.
ptImg('pt_bag_labels.png',166,87,ptBagWidgets);
ptImg('pt_bag_title.png',26,82,ptBagWidgets);
// Approved AOD: sprites, elemental icons, footprints, route and ECG are static art.
// Numeric readings remain automatic native widgets, not painted sample values.
ptImg('approved_scene.png',39,202,null,hmUI.show_level.ONLY_AOD);
const approvedDigits=['approved_num_0.png','approved_num_1.png','approved_num_2.png','approved_num_3.png','approved_num_4.png','approved_num_5.png','approved_num_6.png','approved_num_7.png','approved_num_8.png','approved_num_9.png'];
[[hmUI.data_type.STEP,28,94],[hmUI.data_type.DISTANCE,147,94],[hmUI.data_type.HEART,266,94]].forEach(function(v){hmUI.createWidget(hmUI.widget.TEXT_IMG,{x:v[1],y:374,w:v[2],h:24,font_array:approvedDigits,h_space:1,padding:false,align_h:hmUI.align.CENTER_H,type:v[0],dot_image:'approved_decimal.png',invalid_image:'approved_invalid.png',show_level:hmUI.show_level.ONLY_AOD});});
// Invisible shortcuts: main screen pixels and original button behavior stay intact.
ptMainWidgets.push(hmUI.createWidget(hmUI.widget.BUTTON,{x:33,y:411,w:94,h:39,text:'',normal_src:'0_Empty.png',press_src:'0_Empty.png',click_func:function(){hmApp.startApp({appid:1,url:'SportListScreen',native:true});},show_level:hmUI.show_level.ONLY_NORMAL}));
ptMainWidgets.push(hmUI.createWidget(hmUI.widget.BUTTON,{x:2,y:86,w:174,h:54,text:'',normal_src:'0_Empty.png',press_src:'0_Empty.png',click_func:function(){hmApp.startApp({appid:1,url:'ScheduleCalScreen',native:true});},show_level:hmUI.show_level.ONLY_NORMAL}));
ptMainWidgets.push(hmUI.createWidget(hmUI.widget.IMG_CLICK,{x:22,y:320,w:116,h:52,src:'0_Empty.png',type:hmUI.data_type.COUNT_DOWN,show_level:hmUI.show_level.ONLY_NORMAL}));
ptPage(true);

            // end user_script_end.js

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');


              }),
              pause_call: (function () {
                console.log('pause_call()');


              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}