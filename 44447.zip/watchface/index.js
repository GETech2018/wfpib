﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_digital_clock_img_time = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_sleep_time_font = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let sleepSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: S-Core - CoreSansD37CnRegular-Italic.ttf; FontSize: 33
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 312,
              h: 48,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/S-Core - CoreSansD37CnRegular-Italic.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'BATTERYLEVEL.png',
              center_x: 100,
              center_y: 195,
              x: 62,
              y: 62,
              start_angle: -180,
              end_angle: 160,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 33,
              hour_startY: 8,
              hour_array: ["CLOCK_0.png","CLOCK_1.png","CLOCK_2.png","CLOCK_3.png","CLOCK_4.png","CLOCK_5.png","CLOCK_6.png","CLOCK_7.png","CLOCK_8.png","CLOCK_9.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 153,
              minute_startY: 8,
              minute_array: ["CLOCK_0.png","CLOCK_1.png","CLOCK_2.png","CLOCK_3.png","CLOCK_4.png","CLOCK_5.png","CLOCK_6.png","CLOCK_7.png","CLOCK_8.png","CLOCK_9.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 38,
              font_array: ["NUMBERS_MEDIUM_0.png","NUMBERS_MEDIUM_1.png","NUMBERS_MEDIUM_2.png","NUMBERS_MEDIUM_3.png","NUMBERS_MEDIUM_4.png","NUMBERS_MEDIUM_5.png","NUMBERS_MEDIUM_6.png","NUMBERS_MEDIUM_7.png","NUMBERS_MEDIUM_8.png","NUMBERS_MEDIUM_9.png"],
              padding: false,
              h_space: -8,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 164,
              y: 188,
              font_array: ["NUMBERS_SMALL_0.png","NUMBERS_SMALL_1.png","NUMBERS_SMALL_2.png","NUMBERS_SMALL_3.png","NUMBERS_SMALL_4.png","NUMBERS_SMALL_5.png","NUMBERS_SMALL_6.png","NUMBERS_SMALL_7.png","NUMBERS_SMALL_8.png","NUMBERS_SMALL_9.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 220,
              font_array: ["NUMBERS_SMALL_0.png","NUMBERS_SMALL_1.png","NUMBERS_SMALL_2.png","NUMBERS_SMALL_3.png","NUMBERS_SMALL_4.png","NUMBERS_SMALL_5.png","NUMBERS_SMALL_6.png","NUMBERS_SMALL_7.png","NUMBERS_SMALL_8.png","NUMBERS_SMALL_9.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 248,
              y: 188,
              font_array: ["NUMBERS_SMALL_0.png","NUMBERS_SMALL_1.png","NUMBERS_SMALL_2.png","NUMBERS_SMALL_3.png","NUMBERS_SMALL_4.png","NUMBERS_SMALL_5.png","NUMBERS_SMALL_6.png","NUMBERS_SMALL_7.png","NUMBERS_SMALL_8.png","NUMBERS_SMALL_9.png"],
              padding: false,
              h_space: -8,
              unit_sc: 'ICON_KM.png',
              unit_tc: 'ICON_KM.png',
              unit_en: 'ICON_KM.png',
              dot_image: 'NUMBERS_SMALL_DOT.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 58,
              y: 283,
              week_en: ["DAYS_EN_1.png","DAYS_EN_2.png","DAYS_EN_3.png","DAYS_EN_4.png","DAYS_EN_5.png","DAYS_EN_6.png","DAYS_EN_7.png"],
              week_tc: ["DAYS_EN_1.png","DAYS_EN_2.png","DAYS_EN_3.png","DAYS_EN_4.png","DAYS_EN_5.png","DAYS_EN_6.png","DAYS_EN_7.png"],
              week_sc: ["DAYS_EN_1.png","DAYS_EN_2.png","DAYS_EN_3.png","DAYS_EN_4.png","DAYS_EN_5.png","DAYS_EN_6.png","DAYS_EN_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 289,
              day_startY: 280,
              day_sc_array: ["NUMBERS_BIG_0.png","NUMBERS_BIG_1.png","NUMBERS_BIG_2.png","NUMBERS_BIG_3.png","NUMBERS_BIG_4.png","NUMBERS_BIG_5.png","NUMBERS_BIG_6.png","NUMBERS_BIG_7.png","NUMBERS_BIG_8.png","NUMBERS_BIG_9.png"],
              day_tc_array: ["NUMBERS_BIG_0.png","NUMBERS_BIG_1.png","NUMBERS_BIG_2.png","NUMBERS_BIG_3.png","NUMBERS_BIG_4.png","NUMBERS_BIG_5.png","NUMBERS_BIG_6.png","NUMBERS_BIG_7.png","NUMBERS_BIG_8.png","NUMBERS_BIG_9.png"],
              day_en_array: ["NUMBERS_BIG_0.png","NUMBERS_BIG_1.png","NUMBERS_BIG_2.png","NUMBERS_BIG_3.png","NUMBERS_BIG_4.png","NUMBERS_BIG_5.png","NUMBERS_BIG_6.png","NUMBERS_BIG_7.png","NUMBERS_BIG_8.png","NUMBERS_BIG_9.png"],
              day_zero: 1,
              day_space: -4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 116,
              y: 358,
              image_array: ["WEATHERICON_1.png","WEATHERICON_2.png","WEATHERICON_3.png","WEATHERICON_4.png","WEATHERICON_5.png","WEATHERICON_6.png","WEATHERICON_7.png","WEATHERICON_8.png","WEATHERICON_9.png","WEATHERICON_10.png","WEATHERICON_11.png","WEATHERICON_12.png","WEATHERICON_13.png","WEATHERICON_14.png","WEATHERICON_15.png","WEATHERICON_16.png","WEATHERICON_17.png","WEATHERICON_18.png","WEATHERICON_19.png","WEATHERICON_20.png","WEATHERICON_21.png","WEATHERICON_22.png","WEATHERICON_23.png","WEATHERICON_24.png","WEATHERICON_25.png","WEATHERICON_26.png","WEATHERICON_27.png","WEATHERICON_28.png","WEATHERICON_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 348,
              font_array: ["NUMBERS_MINI_0.png","NUMBERS_MINI_1.png","NUMBERS_MINI_2.png","NUMBERS_MINI_3.png","NUMBERS_MINI_4.png","NUMBERS_MINI_5.png","NUMBERS_MINI_6.png","NUMBERS_MINI_7.png","NUMBERS_MINI_8.png","NUMBERS_MINI_9.png"],
              padding: false,
              h_space: -6,
              negative_image: 'ICON_NEGATIVE_MINI.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 382,
              font_array: ["NUMBERS_MINI_0.png","NUMBERS_MINI_1.png","NUMBERS_MINI_2.png","NUMBERS_MINI_3.png","NUMBERS_MINI_4.png","NUMBERS_MINI_5.png","NUMBERS_MINI_6.png","NUMBERS_MINI_7.png","NUMBERS_MINI_8.png","NUMBERS_MINI_9.png"],
              padding: false,
              h_space: -6,
              negative_image: 'ICON_NEGATIVE_MINI.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 358,
              font_array: ["NUMBERS_MEDIUM_0.png","NUMBERS_MEDIUM_1.png","NUMBERS_MEDIUM_2.png","NUMBERS_MEDIUM_3.png","NUMBERS_MEDIUM_4.png","NUMBERS_MEDIUM_5.png","NUMBERS_MEDIUM_6.png","NUMBERS_MEDIUM_7.png","NUMBERS_MEDIUM_8.png","NUMBERS_MEDIUM_9.png"],
              padding: false,
              h_space: -6,
              unit_sc: 'ICON_TEMP.png',
              unit_tc: 'ICON_TEMP.png',
              unit_en: 'ICON_TEMP.png',
              negative_image: 'ICON_NEGATIVE.png',
              invalid_image: 'NUMBERS_MEDIUM_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 16,
              y: 377,
              w: 100,
              h: 50,
              text_size: 33,
              char_space: 0,
              font: 'fonts/S-Core - CoreSansD37CnRegular-Italic.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: .,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 42,
              y: 25,
              w: 100,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 158,
              y: 25,
              w: 100,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 264,
              y: 25,
              w: 100,
              h: 125,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 168,
              y: 178,
              w: 94,
              h: 42,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 168,
              y: 227,
              w: 94,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportRecordListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 53,
              y: 282,
              w: 300,
              h: 54,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 110,
              y: 353,
              w: 240,
              h: 54,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 32,
              y: 356,
              w: 66,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            if (!sleepSensor) sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
            //#region sleep_update
            function sleep_update() {
              console.log('sleep_update()');

              console.log('sleep duration time');
              let sleepTime = sleepSensor.getTotalTime();
              const modelData = sleepSensor.getSleepStageModel();
              let sleepStageArray = sleepSensor.getSleepStageData();
              let wakeupTime = 0;
              let wakeupCount = 0;

              for (let i = 0; i < sleepStageArray.length; i++) {
                let data = sleepStageArray[i];
                if (data.model == modelData.WAKE_STAGE) {
                  wakeupTime += data.stop + 1 - data.start;
                  wakeupCount++;
                };
              };
              sleepTime -= wakeupTime;
              let sleepTimeHour = Math.floor(sleepTime / 60);
              let sleepTimeMin = sleepTime % 60;

              let normal_sleepTimeHourStr = sleepTimeHour.toString();
              let normal_sleepTimeMinStr = sleepTimeMin.toString().padStart(2, '0');
              let normal_sleepTimeStr = normal_sleepTimeHourStr + '.' + normal_sleepTimeMinStr;
              if (normal_sleep_time_font) normal_sleep_time_font.setProperty(hmUI.prop.TEXT, normal_sleepTimeStr);

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                sleep_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}