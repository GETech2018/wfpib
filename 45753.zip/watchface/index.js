﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '0_fundo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 297,
              y: 273,
              src: '4_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 297,
              y: 251,
              src: '4_mute.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 297,
              y: 207,
              src: '4_blueOFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 297,
              y: 229,
              src: '4_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 297,
              y: 80,
              image_array: ["3_batt1.png","3_batt2.png","3_batt3.png","3_batt4.png","3_batt5.png","3_batt6.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 248,
              y: 325,
              week_en: ["2_week2.png","2_week3.png","2_week4.png","2_week5.png","2_week6.png","2_week7.png","2_week8.png"],
              week_tc: ["2_week2.png","2_week3.png","2_week4.png","2_week5.png","2_week6.png","2_week7.png","2_week8.png"],
              week_sc: ["2_week2.png","2_week3.png","2_week4.png","2_week5.png","2_week6.png","2_week7.png","2_week8.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 172,
              year_startY: 335,
              year_sc_array: ["1_num0.png","1_num1.png","1_num2.png","1_num3.png","1_num4.png","1_num5.png","1_num6.png","1_num7.png","1_num8.png","1_num9.png"],
              year_tc_array: ["1_num0.png","1_num1.png","1_num2.png","1_num3.png","1_num4.png","1_num5.png","1_num6.png","1_num7.png","1_num8.png","1_num9.png"],
              year_en_array: ["1_num0.png","1_num1.png","1_num2.png","1_num3.png","1_num4.png","1_num5.png","1_num6.png","1_num7.png","1_num8.png","1_num9.png"],
              year_zero: 0,
              year_space: 1,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 105,
              month_startY: 335,
              month_sc_array: ["1_num0.png","1_num1.png","1_num2.png","1_num3.png","1_num4.png","1_num5.png","1_num6.png","1_num7.png","1_num8.png","1_num9.png"],
              month_tc_array: ["1_num0.png","1_num1.png","1_num2.png","1_num3.png","1_num4.png","1_num5.png","1_num6.png","1_num7.png","1_num8.png","1_num9.png"],
              month_en_array: ["1_num0.png","1_num1.png","1_num2.png","1_num3.png","1_num4.png","1_num5.png","1_num6.png","1_num7.png","1_num8.png","1_num9.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 38,
              day_startY: 335,
              day_sc_array: ["1_num0.png","1_num1.png","1_num2.png","1_num3.png","1_num4.png","1_num5.png","1_num6.png","1_num7.png","1_num8.png","1_num9.png"],
              day_tc_array: ["1_num0.png","1_num1.png","1_num2.png","1_num3.png","1_num4.png","1_num5.png","1_num6.png","1_num7.png","1_num8.png","1_num9.png"],
              day_en_array: ["1_num0.png","1_num1.png","1_num2.png","1_num3.png","1_num4.png","1_num5.png","1_num6.png","1_num7.png","1_num8.png","1_num9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '5_pointerHRS.png',
              hour_centerX: 147,
              hour_centerY: 181,
              hour_posX: 5,
              hour_posY: 109,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '5_pointerMIN.png',
              minute_centerX: 147,
              minute_centerY: 181,
              minute_posX: 5,
              minute_posY: 109,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '5_pointerSEC.png',
              second_centerX: 147,
              second_centerY: 181,
              second_posX: 5,
              second_posY: 109,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '0_fundo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 297,
              y: 273,
              src: '4_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 297,
              y: 251,
              src: '4_mute.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 297,
              y: 207,
              src: '4_blueOFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 297,
              y: 229,
              src: '4_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 297,
              y: 80,
              image_array: ["3_batt1.png","3_batt2.png","3_batt3.png","3_batt4.png","3_batt5.png","3_batt6.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 248,
              y: 325,
              week_en: ["2_week2.png","2_week3.png","2_week4.png","2_week5.png","2_week6.png","2_week7.png","2_week8.png"],
              week_tc: ["2_week2.png","2_week3.png","2_week4.png","2_week5.png","2_week6.png","2_week7.png","2_week8.png"],
              week_sc: ["2_week2.png","2_week3.png","2_week4.png","2_week5.png","2_week6.png","2_week7.png","2_week8.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 172,
              year_startY: 335,
              year_sc_array: ["1_num0.png","1_num1.png","1_num2.png","1_num3.png","1_num4.png","1_num5.png","1_num6.png","1_num7.png","1_num8.png","1_num9.png"],
              year_tc_array: ["1_num0.png","1_num1.png","1_num2.png","1_num3.png","1_num4.png","1_num5.png","1_num6.png","1_num7.png","1_num8.png","1_num9.png"],
              year_en_array: ["1_num0.png","1_num1.png","1_num2.png","1_num3.png","1_num4.png","1_num5.png","1_num6.png","1_num7.png","1_num8.png","1_num9.png"],
              year_zero: 0,
              year_space: 1,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 105,
              month_startY: 335,
              month_sc_array: ["1_num0.png","1_num1.png","1_num2.png","1_num3.png","1_num4.png","1_num5.png","1_num6.png","1_num7.png","1_num8.png","1_num9.png"],
              month_tc_array: ["1_num0.png","1_num1.png","1_num2.png","1_num3.png","1_num4.png","1_num5.png","1_num6.png","1_num7.png","1_num8.png","1_num9.png"],
              month_en_array: ["1_num0.png","1_num1.png","1_num2.png","1_num3.png","1_num4.png","1_num5.png","1_num6.png","1_num7.png","1_num8.png","1_num9.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 38,
              day_startY: 335,
              day_sc_array: ["1_num0.png","1_num1.png","1_num2.png","1_num3.png","1_num4.png","1_num5.png","1_num6.png","1_num7.png","1_num8.png","1_num9.png"],
              day_tc_array: ["1_num0.png","1_num1.png","1_num2.png","1_num3.png","1_num4.png","1_num5.png","1_num6.png","1_num7.png","1_num8.png","1_num9.png"],
              day_en_array: ["1_num0.png","1_num1.png","1_num2.png","1_num3.png","1_num4.png","1_num5.png","1_num6.png","1_num7.png","1_num8.png","1_num9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '5_pointerHRS.png',
              hour_centerX: 147,
              hour_centerY: 181,
              hour_posX: 5,
              hour_posY: 109,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '5_pointerMIN.png',
              minute_centerX: 147,
              minute_centerY: 181,
              minute_posX: 5,
              minute_posY: 109,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '5_pointerSEC.png',
              second_centerX: 147,
              second_centerY: 181,
              second_posX: 5,
              second_posY: 109,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}