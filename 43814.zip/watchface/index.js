﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Activity select
        let backgroundnumber = 1
        let totalpictures = 5
        let cc = 0

        function click_Background() {
            if(backgroundnumber>=totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }
                if(backgroundnumber==3) {
                  UpdateBackgroundThree();
                }
                if(backgroundnumber==4) {
                  UpdateBackgroundFour();
                }
                if(backgroundnumber==5) {
                  UpdateBackgroundFive();
                }

    

            }
          if(backgroundnumber==1) hmUI.showToast({text: 'Steps'});
          if(backgroundnumber==2) hmUI.showToast({text: 'Calorie'});
          if(backgroundnumber==3) hmUI.showToast({text: 'Distance'});
          if(backgroundnumber==4) hmUI.showToast({text: 'Heart Rate'});
          if(backgroundnumber==5) hmUI.showToast({text: 'Battery'});

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //steps
        function UpdateBackgroundOne(){


         normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);


         normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

       }

//////////////////////////////////////////////////////////////////////////////////////////////////
        //Calories
        function UpdateBackgroundTwo(){


         normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);


         normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
         normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

       }

//////////////////////////////////////////////////////////////////////////////////////////////////
        //Distance
        function UpdateBackgroundThree(){


         normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);


         normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

       }

//////////////////////////////////////////////////////////////////////////////////////////////////
        //Heart Rate
        function UpdateBackgroundFour(){


         normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
         normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);


         normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
         normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
         normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

       }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Battery
        function UpdateBackgroundFive(){


         normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);


         normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

       }

//////////////////////////////////////////////////////////////////////////////////////////////////
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 48,
              y: 230,
              font_array: ["Time_S0.png","Time_S1.png","Time_S2.png","Time_S3.png","Time_S4.png","Time_S5.png","Time_S6.png","Time_S7.png","Time_S8.png","Time_S9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Batt_Unit.png',
              unit_tc: 'Batt_Unit.png',
              unit_en: 'Batt_Unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 227,
              y: 228,
              src: 'icon_power.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 29,
              y: 230,
              font_array: ["Time_S0.png","Time_S1.png","Time_S2.png","Time_S3.png","Time_S4.png","Time_S5.png","Time_S6.png","Time_S7.png","Time_S8.png","Time_S9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Time_S0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 227,
              y: 228,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 151,
              y: 233,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 18,
              y: 230,
              font_array: ["Time_S0.png","Time_S1.png","Time_S2.png","Time_S3.png","Time_S4.png","Time_S5.png","Time_S6.png","Time_S7.png","Time_S8.png","Time_S9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dis_km.png',
              unit_tc: 'dis_km.png',
              unit_en: 'dis_km.png',
              imperial_unit_sc: 'dis_mi.png',
              imperial_unit_tc: 'dis_mi.png',
              imperial_unit_en: 'dis_mi.png',
              dot_image: 'dis_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 227,
              y: 229,
              src: 'icon_dis.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 30,
              y: 230,
              font_array: ["Time_S0.png","Time_S1.png","Time_S2.png","Time_S3.png","Time_S4.png","Time_S5.png","Time_S6.png","Time_S7.png","Time_S8.png","Time_S9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 227,
              y: 229,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 230,
              font_array: ["Time_S0.png","Time_S1.png","Time_S2.png","Time_S3.png","Time_S4.png","Time_S5.png","Time_S6.png","Time_S7.png","Time_S8.png","Time_S9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 227,
              y: 229,
              src: 'icon_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 17,
              y: 83,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 104,
              y: 289,
              week_en: ["Week01.png","Week02.png","Week03.png","Week04.png","Week05.png","Week06.png","Week07.png"],
              week_tc: ["Week01.png","Week02.png","Week03.png","Week04.png","Week05.png","Week06.png","Week07.png"],
              week_sc: ["Week01.png","Week02.png","Week03.png","Week04.png","Week05.png","Week06.png","Week07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 57,
              month_startY: 417,
              month_sc_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_tc_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_en_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 20,
              day_startY: 288,
              day_sc_array: ["Time_S0.png","Time_S1.png","Time_S2.png","Time_S3.png","Time_S4.png","Time_S5.png","Time_S6.png","Time_S7.png","Time_S8.png","Time_S9.png"],
              day_tc_array: ["Time_S0.png","Time_S1.png","Time_S2.png","Time_S3.png","Time_S4.png","Time_S5.png","Time_S6.png","Time_S7.png","Time_S8.png","Time_S9.png"],
              day_en_array: ["Time_S0.png","Time_S1.png","Time_S2.png","Time_S3.png","Time_S4.png","Time_S5.png","Time_S6.png","Time_S7.png","Time_S8.png","Time_S9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 26,
              y: 355,
              font_array: ["Time_S0.png","Time_S1.png","Time_S2.png","Time_S3.png","Time_S4.png","Time_S5.png","Time_S6.png","Time_S7.png","Time_S8.png","Time_S9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              imperial_unit_sc: 'Weather_Symbo1.png',
              imperial_unit_tc: 'Weather_Symbo1.png',
              imperial_unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 26,
                y: 355,
                font_array: ["Time_S0.png","Time_S1.png","Time_S2.png","Time_S3.png","Time_S4.png","Time_S5.png","Time_S6.png","Time_S7.png","Time_S8.png","Time_S9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Weather_Symbo1.png',
                unit_tc: 'Weather_Symbo1.png',
                unit_en: 'Weather_Symbo1.png',
                imperial_unit_sc: 'Weather_Symbo1.png',
                imperial_unit_tc: 'Weather_Symbo1.png',
                imperial_unit_en: 'Weather_Symbo1.png',
                negative_image: 'Weather_Symbo2.png',
                invalid_image: 'Weather_Symbo2.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 126,
              y: 349,
              image_array: ["Weather_icon_BL_01.png","Weather_icon_BL_02.png","Weather_icon_BL_03.png","Weather_icon_BL_04.png","Weather_icon_BL_05.png","Weather_icon_BL_06.png","Weather_icon_BL_07.png","Weather_icon_BL_08.png","Weather_icon_BL_09.png","Weather_icon_BL_10.png","Weather_icon_BL_11.png","Weather_icon_BL_12.png","Weather_icon_BL_13.png","Weather_icon_BL_14.png","Weather_icon_BL_15.png","Weather_icon_BL_16.png","Weather_icon_BL_17.png","Weather_icon_BL_18.png","Weather_icon_BL_19.png","Weather_icon_BL_20.png","Weather_icon_BL_21.png","Weather_icon_BL_22.png","Weather_icon_BL_23.png","Weather_icon_BL_24.png","Weather_icon_BL_25.png","Weather_icon_BL_26.png","Weather_icon_BL_27.png","Weather_icon_BL_28.png","Weather_icon_BL_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 195,
              y: 401,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 342,
              y: 87,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 316,
              am_y: 126,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 316,
              pm_y: 126,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 311,
              second_startY: 171,
              second_array: ["Time_S0.png","Time_S1.png","Time_S2.png","Time_S3.png","Time_S4.png","Time_S5.png","Time_S6.png","Time_S7.png","Time_S8.png","Time_S9.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 169,
              minute_startY: 126,
              minute_array: ["Time0.png","Time1.png","Time2.png","Time3.png","Time4.png","Time5.png","Time6.png","Time7.png","Time8.png","Time9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 126,
              hour_array: ["Time0.png","Time1.png","Time2.png","Time3.png","Time4.png","Time5.png","Time6.png","Time7.png","Time8.png","Time9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 147,
              y: 140,
              w: 34,
              h: 83,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 311,
              y: 179,
              w: 63,
              h: 48,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 332,
              y: 83,
              w: 54,
              h: 48,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 7,
              y: 79,
              w: 61,
              h: 51,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 37,
              y: 366,
              w: 145,
              h: 54,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 22,
              y: 247,
              w: 182,
              h: 41,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 20,
              y: 246,
              w: 89,
              h: 49,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 115,
              y: 244,
              w: 88,
              h: 54,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 30,
              y: 249,
              w: 178,
              h: 41,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 261,
              y: 319,
              w: 68,
              h: 67,
              text: '',
              color: 0xFFFF8C00,
              text_size: 30,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 17,
              y: 305,
              w: 172,
              h: 46,
              text: '',
              color: 0xFFFF8C00,
              text_size: 30,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 224,
              y: 241,
              w: 135,
              h: 33,
              text: '',
              color: 0xFFFF8C00,
              text_size: 30,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Background()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if (cc==0){
         normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);


         normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

cc = 1
}
            // end user_script_end.js


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}