﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_stand_circle_scale = ''
        let normal_calorie_circle_scale = ''
        let normal_fat_burning_circle_scale = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 20;
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 20;
        let normal_temperature_icon_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_TextRotate = new Array(4);
        let normal_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_current_TextRotate_img_width = 20;
        let normal_temperature_current_TextRotate_unit = null;
        let normal_temperature_current_TextRotate_unit_width = 20;
        let normal_temperature_current_TextRotate_dot_width = 20;
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_stand_circle_scale = ''
        let idle_calorie_circle_scale = ''
        let idle_fat_burning_circle_scale = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_step_circle_scale = ''
        let idle_step_TextRotate = new Array(5);
        let idle_step_TextRotate_ASCIIARRAY = new Array(10);
        let idle_step_TextRotate_img_width = 20;
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_TextRotate = new Array(3);
        let idle_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextRotate_img_width = 20;
        let idle_temperature_icon_img = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_TextRotate = new Array(4);
        let idle_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let idle_temperature_current_TextRotate_img_width = 20;
        let idle_temperature_current_TextRotate_unit = null;
        let idle_temperature_current_TextRotate_unit_width = 20;
        let idle_temperature_current_TextRotate_dot_width = 20;
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG_ES.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 276,
              // center_y: 373,
              // start_angle: 3,
              // end_angle: 357,
              // radius: 33,
              // line_width: 16,
              // line_cap: Rounded,
              // color: 0xFF75F1D9,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 276,
              center_y: 373,
              start_angle: 3,
              end_angle: 357,
              radius: 25,
              line_width: 16,
              corner_flag: 0,
              color: 0xFF75F1D9,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 276,
              // center_y: 373,
              // start_angle: 3,
              // end_angle: 358,
              // radius: 53,
              // line_width: 17,
              // line_cap: Rounded,
              // color: 0xFFBFFD50,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 276,
              center_y: 373,
              start_angle: 3,
              end_angle: 358,
              radius: 45,
              line_width: 17,
              corner_flag: 0,
              color: 0xFFBFFD50,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 276,
              // center_y: 373,
              // start_angle: 3,
              // end_angle: 357,
              // radius: 71,
              // line_width: 15,
              // line_cap: Rounded,
              // color: 0xFFDE385A,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 276,
              center_y: 373,
              start_angle: 3,
              end_angle: 357,
              radius: 64,
              line_width: 15,
              corner_flag: 0,
              color: 0xFFDE385A,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'INDICATOR-BATTERY.png',
              center_x: 195,
              center_y: 225,
              x: 102,
              y: 150,
              start_angle: -40,
              end_angle: 3,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 47,
              y: 174,
              font_array: ["img_arr_0008_00.png","img_arr_0008_01.png","img_arr_0008_02.png","img_arr_0008_03.png","img_arr_0008_04.png","img_arr_0008_05.png","img_arr_0008_06.png","img_arr_0008_07.png","img_arr_0008_08.png","img_arr_0008_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 226,
              // start_angle: -42,
              // end_angle: -9,
              // radius: 192,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFFEF9437,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 226,
              start_angle: -42,
              end_angle: -9,
              radius: 186,
              line_width: 12,
              corner_flag: 0,
              color: 0xFFEF9437,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 95,
              // y: 28,
              // font_array: ["img_arr_0005_00.png","img_arr_0005_01.png","img_arr_0005_02.png","img_arr_0005_03.png","img_arr_0005_04.png","img_arr_0005_05.png","img_arr_0005_06.png","img_arr_0005_07.png","img_arr_0005_08.png","img_arr_0005_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -25,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'img_arr_0005_00.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'img_arr_0005_01.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'img_arr_0005_02.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'img_arr_0005_03.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'img_arr_0005_04.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'img_arr_0005_05.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'img_arr_0005_06.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'img_arr_0005_07.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'img_arr_0005_08.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'img_arr_0005_09.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 95,
                center_y: 28,
                pos_x: 95,
                pos_y: 28,
                angle: -25,
                src: 'img_arr_0005_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 104,
              y: 395,
              src: 'img_0012.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 101,
              // y: 409,
              // font_array: ["img_arr_0005_00.png","img_arr_0005_01.png","img_arr_0005_02.png","img_arr_0005_03.png","img_arr_0005_04.png","img_arr_0005_05.png","img_arr_0005_06.png","img_arr_0005_07.png","img_arr_0005_08.png","img_arr_0005_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 26,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'img_arr_0005_00.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'img_arr_0005_01.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'img_arr_0005_02.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'img_arr_0005_03.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'img_arr_0005_04.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'img_arr_0005_05.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'img_arr_0005_06.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'img_arr_0005_07.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'img_arr_0005_08.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'img_arr_0005_09.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 101,
                center_y: 409,
                pos_x: 101,
                pos_y: 409,
                angle: 26,
                src: 'img_arr_0005_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 288,
              y: 59,
              src: 'img_0012.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 99,
              font_array: ["digits_max_0.png","digits_max_1.png","digits_max_2.png","digits_max_3.png","digits_max_4.png","digits_max_5.png","digits_max_6.png","digits_max_7.png","digits_max_8.png","digits_max_9.png"],
              padding: false,
              h_space: -20,
              angle: 54,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 19,
              font_array: ["digits_min_0.png","digits_min_1.png","digits_min_2.png","digits_min_3.png","digits_min_4.png","digits_min_5.png","digits_min_6.png","digits_min_7.png","digits_min_8.png","digits_min_9.png"],
              padding: false,
              h_space: -20,
              angle: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 313,
              // y: 36,
              // font_array: ["img_arr_0005_00.png","img_arr_0005_01.png","img_arr_0005_02.png","img_arr_0005_03.png","img_arr_0005_04.png","img_arr_0005_05.png","img_arr_0005_06.png","img_arr_0005_07.png","img_arr_0005_08.png","img_arr_0005_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 30,
              // unit_en: 'img_0013.png',
              // negative_image: 'img_arr_0004_10.png',
              // dot_image: 'img_arr_0004_10.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_current_TextRotate_ASCIIARRAY[0] = 'img_arr_0005_00.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[1] = 'img_arr_0005_01.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[2] = 'img_arr_0005_02.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[3] = 'img_arr_0005_03.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[4] = 'img_arr_0005_04.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[5] = 'img_arr_0005_05.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[6] = 'img_arr_0005_06.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[7] = 'img_arr_0005_07.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[8] = 'img_arr_0005_08.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[9] = 'img_arr_0005_09.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 313,
                center_y: 36,
                pos_x: 313,
                pos_y: 36,
                angle: 30,
                src: 'img_arr_0005_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 313,
              center_y: 36,
              pos_x: 313,
              pos_y: 36,
              angle: 30,
              src: 'img_0013.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 179,
              day_startY: 131,
              day_sc_array: ["img_arr_0003_00.png","img_arr_0003_01.png","img_arr_0003_02.png","img_arr_0003_03.png","img_arr_0003_04.png","img_arr_0003_05.png","img_arr_0003_06.png","img_arr_0003_07.png","img_arr_0003_08.png","img_arr_0003_09.png"],
              day_tc_array: ["img_arr_0003_00.png","img_arr_0003_01.png","img_arr_0003_02.png","img_arr_0003_03.png","img_arr_0003_04.png","img_arr_0003_05.png","img_arr_0003_06.png","img_arr_0003_07.png","img_arr_0003_08.png","img_arr_0003_09.png"],
              day_en_array: ["img_arr_0003_00.png","img_arr_0003_01.png","img_arr_0003_02.png","img_arr_0003_03.png","img_arr_0003_04.png","img_arr_0003_05.png","img_arr_0003_06.png","img_arr_0003_07.png","img_arr_0003_08.png","img_arr_0003_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 167,
              y: 151,
              week_en: ["DAYS_ES_1.png","DAYS_ES_2.png","DAYS_ES_3.png","DAYS_ES_4.png","DAYS_ES_5.png","DAYS_ES_6.png","DAYS_ES_7.png"],
              week_tc: ["DAYS_ES_1.png","DAYS_ES_2.png","DAYS_ES_3.png","DAYS_ES_4.png","DAYS_ES_5.png","DAYS_ES_6.png","DAYS_ES_7.png"],
              week_sc: ["DAYS_ES_1.png","DAYS_ES_2.png","DAYS_ES_3.png","DAYS_ES_4.png","DAYS_ES_5.png","DAYS_ES_6.png","DAYS_ES_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 85,
              hour_startY: 169,
              hour_array: ["img_arr_0000_00.png","img_arr_0000_01.png","img_arr_0000_02.png","img_arr_0000_03.png","img_arr_0000_04.png","img_arr_0000_05.png","img_arr_0000_06.png","img_arr_0000_07.png","img_arr_0000_08.png","img_arr_0000_09.png"],
              hour_zero: 1,
              hour_space: -3,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 199,
              minute_startY: 169,
              minute_array: ["img_arr_0000_00.png","img_arr_0000_01.png","img_arr_0000_02.png","img_arr_0000_03.png","img_arr_0000_04.png","img_arr_0000_05.png","img_arr_0000_06.png","img_arr_0000_07.png","img_arr_0000_08.png","img_arr_0000_09.png"],
              minute_zero: 1,
              minute_space: -3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 183,
              y: 180,
              src: 'img_0011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG_ES.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 276,
              // center_y: 373,
              // start_angle: 3,
              // end_angle: 357,
              // radius: 33,
              // line_width: 16,
              // line_cap: Rounded,
              // color: 0xFF75F1D9,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 276,
              center_y: 373,
              start_angle: 3,
              end_angle: 357,
              radius: 25,
              line_width: 16,
              corner_flag: 0,
              color: 0xFF75F1D9,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 276,
              // center_y: 373,
              // start_angle: 3,
              // end_angle: 358,
              // radius: 53,
              // line_width: 17,
              // line_cap: Rounded,
              // color: 0xFFBFFD50,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 276,
              center_y: 373,
              start_angle: 3,
              end_angle: 358,
              radius: 45,
              line_width: 17,
              corner_flag: 0,
              color: 0xFFBFFD50,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 276,
              // center_y: 373,
              // start_angle: 3,
              // end_angle: 357,
              // radius: 71,
              // line_width: 15,
              // line_cap: Rounded,
              // color: 0xFFDE385A,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_fat_burning_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 276,
              center_y: 373,
              start_angle: 3,
              end_angle: 357,
              radius: 64,
              line_width: 15,
              corner_flag: 0,
              color: 0xFFDE385A,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'INDICATOR-BATTERY.png',
              center_x: 195,
              center_y: 225,
              x: 102,
              y: 150,
              start_angle: -40,
              end_angle: 3,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 47,
              y: 174,
              font_array: ["img_arr_0008_00.png","img_arr_0008_01.png","img_arr_0008_02.png","img_arr_0008_03.png","img_arr_0008_04.png","img_arr_0008_05.png","img_arr_0008_06.png","img_arr_0008_07.png","img_arr_0008_08.png","img_arr_0008_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 226,
              // start_angle: -42,
              // end_angle: -9,
              // radius: 192,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFFEF9437,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 226,
              start_angle: -42,
              end_angle: -9,
              radius: 186,
              line_width: 12,
              corner_flag: 0,
              color: 0xFFEF9437,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 95,
              // y: 28,
              // font_array: ["img_arr_0005_00.png","img_arr_0005_01.png","img_arr_0005_02.png","img_arr_0005_03.png","img_arr_0005_04.png","img_arr_0005_05.png","img_arr_0005_06.png","img_arr_0005_07.png","img_arr_0005_08.png","img_arr_0005_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -25,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextRotate_ASCIIARRAY[0] = 'img_arr_0005_00.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[1] = 'img_arr_0005_01.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[2] = 'img_arr_0005_02.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[3] = 'img_arr_0005_03.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[4] = 'img_arr_0005_04.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[5] = 'img_arr_0005_05.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[6] = 'img_arr_0005_06.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[7] = 'img_arr_0005_07.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[8] = 'img_arr_0005_08.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[9] = 'img_arr_0005_09.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              idle_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 95,
                center_y: 28,
                pos_x: 95,
                pos_y: 28,
                angle: -25,
                src: 'img_arr_0005_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 104,
              y: 395,
              src: 'img_0012.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 101,
              // y: 409,
              // font_array: ["img_arr_0005_00.png","img_arr_0005_01.png","img_arr_0005_02.png","img_arr_0005_03.png","img_arr_0005_04.png","img_arr_0005_05.png","img_arr_0005_06.png","img_arr_0005_07.png","img_arr_0005_08.png","img_arr_0005_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 26,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextRotate_ASCIIARRAY[0] = 'img_arr_0005_00.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[1] = 'img_arr_0005_01.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[2] = 'img_arr_0005_02.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[3] = 'img_arr_0005_03.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[4] = 'img_arr_0005_04.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[5] = 'img_arr_0005_05.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[6] = 'img_arr_0005_06.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[7] = 'img_arr_0005_07.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[8] = 'img_arr_0005_08.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[9] = 'img_arr_0005_09.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 101,
                center_y: 409,
                pos_x: 101,
                pos_y: 409,
                angle: 26,
                src: 'img_arr_0005_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 288,
              y: 59,
              src: 'img_0012.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 99,
              font_array: ["digits_max_0.png","digits_max_1.png","digits_max_2.png","digits_max_3.png","digits_max_4.png","digits_max_5.png","digits_max_6.png","digits_max_7.png","digits_max_8.png","digits_max_9.png"],
              padding: false,
              h_space: -20,
              angle: 54,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 19,
              font_array: ["digits_min_0.png","digits_min_1.png","digits_min_2.png","digits_min_3.png","digits_min_4.png","digits_min_5.png","digits_min_6.png","digits_min_7.png","digits_min_8.png","digits_min_9.png"],
              padding: false,
              h_space: -20,
              angle: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 313,
              // y: 36,
              // font_array: ["img_arr_0005_00.png","img_arr_0005_01.png","img_arr_0005_02.png","img_arr_0005_03.png","img_arr_0005_04.png","img_arr_0005_05.png","img_arr_0005_06.png","img_arr_0005_07.png","img_arr_0005_08.png","img_arr_0005_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 30,
              // unit_en: 'img_0013.png',
              // negative_image: 'img_arr_0004_10.png',
              // dot_image: 'img_arr_0004_10.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_temperature_current_TextRotate_ASCIIARRAY[0] = 'img_arr_0005_00.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[1] = 'img_arr_0005_01.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[2] = 'img_arr_0005_02.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[3] = 'img_arr_0005_03.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[4] = 'img_arr_0005_04.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[5] = 'img_arr_0005_05.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[6] = 'img_arr_0005_06.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[7] = 'img_arr_0005_07.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[8] = 'img_arr_0005_08.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[9] = 'img_arr_0005_09.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              idle_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 313,
                center_y: 36,
                pos_x: 313,
                pos_y: 36,
                angle: 30,
                src: 'img_arr_0005_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_temperature_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 313,
              center_y: 36,
              pos_x: 313,
              pos_y: 36,
              angle: 30,
              src: 'img_0013.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 196,
              day_startY: 152,
              day_sc_array: ["img_arr_0003_00.png","img_arr_0003_01.png","img_arr_0003_02.png","img_arr_0003_03.png","img_arr_0003_04.png","img_arr_0003_05.png","img_arr_0003_06.png","img_arr_0003_07.png","img_arr_0003_08.png","img_arr_0003_09.png"],
              day_tc_array: ["img_arr_0003_00.png","img_arr_0003_01.png","img_arr_0003_02.png","img_arr_0003_03.png","img_arr_0003_04.png","img_arr_0003_05.png","img_arr_0003_06.png","img_arr_0003_07.png","img_arr_0003_08.png","img_arr_0003_09.png"],
              day_en_array: ["img_arr_0003_00.png","img_arr_0003_01.png","img_arr_0003_02.png","img_arr_0003_03.png","img_arr_0003_04.png","img_arr_0003_05.png","img_arr_0003_06.png","img_arr_0003_07.png","img_arr_0003_08.png","img_arr_0003_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 139,
              y: 147,
              week_en: ["DAYS_ES_1.png","DAYS_ES_2.png","DAYS_ES_3.png","DAYS_ES_4.png","DAYS_ES_5.png","DAYS_ES_6.png","DAYS_ES_7.png"],
              week_tc: ["DAYS_ES_1.png","DAYS_ES_2.png","DAYS_ES_3.png","DAYS_ES_4.png","DAYS_ES_5.png","DAYS_ES_6.png","DAYS_ES_7.png"],
              week_sc: ["DAYS_ES_1.png","DAYS_ES_2.png","DAYS_ES_3.png","DAYS_ES_4.png","DAYS_ES_5.png","DAYS_ES_6.png","DAYS_ES_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 85,
              hour_startY: 169,
              hour_array: ["img_arr_0000_00.png","img_arr_0000_01.png","img_arr_0000_02.png","img_arr_0000_03.png","img_arr_0000_04.png","img_arr_0000_05.png","img_arr_0000_06.png","img_arr_0000_07.png","img_arr_0000_08.png","img_arr_0000_09.png"],
              hour_zero: 1,
              hour_space: -3,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 199,
              minute_startY: 169,
              minute_array: ["img_arr_0000_00.png","img_arr_0000_01.png","img_arr_0000_02.png","img_arr_0000_03.png","img_arr_0000_04.png","img_arr_0000_05.png","img_arr_0000_06.png","img_arr_0000_07.png","img_arr_0000_08.png","img_arr_0000_09.png"],
              minute_zero: 1,
              minute_space: -3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 183,
              y: 180,
              src: 'img_0011.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 55,
              y: 25,
              w: 108,
              h: 45,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 43,
              y: 384,
              w: 124,
              h: 49,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 36,
              y: 158,
              w: 44,
              h: 70,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 214,
              y: 25,
              w: 141,
              h: 48,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 111,
              y: 343,
              w: 30,
              h: 30,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 207,
              y: 183,
              w: 100,
              h: 85,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 292,
              y: 122,
              w: 30,
              h: 30,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 138,
              y: 149,
              w: 100,
              h: 31,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 202,
              y: 77,
              w: 30,
              h: 31,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_dndScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 48,
              y: 274,
              w: 30,
              h: 31,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 206,
              y: 299,
              w: 140,
              h: 150,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 87,
              y: 183,
              w: 100,
              h: 84,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 95 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  img_offset -= normal_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 101 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };
              let weatherData = weatherSensor.getForecastWeather();
              let temperature_current_temp = -100;
              if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
                temperature_current_temp = weatherSensor.current;
              }; // end currentWeather;

              console.log('update text rotate temperature_current_currentWeather');
              let temperatureCurrent = undefined;
              let normal_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                normal_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && normal_temperature_current_rotate_string.length > 0 && normal_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_img_width * normal_temperature_current_rotate_string.length;
                  img_offset -= normal_temperature_current_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 313 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 313 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'img_arr_0004_10.png');
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 313 + img_offset);
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let idle_step_rotate_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_rotate_string.length > 0 && idle_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_step_TextRotate_posOffset = idle_step_TextRotate_img_width * idle_step_rotate_string.length;
                  img_offset -= idle_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 95 + img_offset);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.SRC, idle_step_TextRotate_ASCIIARRAY[charCode]);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let idle_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_rotate_string.length > 0 && idle_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_img_width * idle_heart_rate_rotate_string.length;
                  img_offset -= idle_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 101 + img_offset);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_heart_rate_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate temperature_current_currentWeather');
              let idle_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                idle_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && idle_temperature_current_rotate_string.length > 0 && idle_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_temperature_current_TextRotate_posOffset = idle_temperature_current_TextRotate_img_width * idle_temperature_current_rotate_string.length;
                  img_offset -= idle_temperature_current_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 313 + img_offset);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, idle_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_current_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 313 + img_offset);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'img_arr_0004_10.png');
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_current_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 313 + img_offset);
                  idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 276,
                      center_y: 373,
                      start_angle: 3,
                      end_angle: 357,
                      radius: 25,
                      line_width: 16,
                      corner_flag: 0,
                      color: 0xFF75F1D9,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 276,
                      center_y: 373,
                      start_angle: 3,
                      end_angle: 358,
                      radius: 45,
                      line_width: 17,
                      corner_flag: 0,
                      color: 0xFFBFFD50,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales FAT_BURNING');
                
                let valueFatBurning = fat_burning.current;
                let targetFatBurning = fat_burning.target;
                let progressFatBurning = valueFatBurning/targetFatBurning;
                if (progressFatBurning > 1) progressFatBurning = 1;
                let progress_cs_normal_fat_burning = progressFatBurning;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_fat_burning_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_fat_burning * 100);
                  if (normal_fat_burning_circle_scale) {
                    normal_fat_burning_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 276,
                      center_y: 373,
                      start_angle: 3,
                      end_angle: 357,
                      radius: 64,
                      line_width: 15,
                      corner_flag: 0,
                      color: 0xFFDE385A,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 226,
                      start_angle: -42,
                      end_angle: -9,
                      radius: 186,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFFEF9437,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STAND');
                let progress_cs_idle_stand = progressStand;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_stand * 100);
                  if (idle_stand_circle_scale) {
                    idle_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 276,
                      center_y: 373,
                      start_angle: 3,
                      end_angle: 357,
                      radius: 25,
                      line_width: 16,
                      corner_flag: 0,
                      color: 0xFF75F1D9,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_calorie * 100);
                  if (idle_calorie_circle_scale) {
                    idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 276,
                      center_y: 373,
                      start_angle: 3,
                      end_angle: 358,
                      radius: 45,
                      line_width: 17,
                      corner_flag: 0,
                      color: 0xFFBFFD50,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales FAT_BURNING');
                let progress_cs_idle_fat_burning = progressFatBurning;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_fat_burning_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_fat_burning * 100);
                  if (idle_fat_burning_circle_scale) {
                    idle_fat_burning_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 276,
                      center_y: 373,
                      start_angle: 3,
                      end_angle: 357,
                      radius: 64,
                      line_width: 15,
                      corner_flag: 0,
                      color: 0xFFDE385A,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 226,
                      start_angle: -42,
                      end_angle: -9,
                      radius: 186,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFFEF9437,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}