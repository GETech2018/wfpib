try {
  ;(() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp

    var __$$module$$__ = __$$app$$__.current
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      'drink'
    )

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     */
    ;('use strict')

    console.log('----->>>current')
    console.log(__$$hmAppManager$$__.currentApp.pid)
    console.log(__$$hmAppManager$$__.currentApp.current)

    const logger = DeviceRuntimeCore.HmLogger.getLogger('defult')
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        let rootPath = 'images/'
        let batteryPath = rootPath + 'battery/'
        let bgPath = rootPath + 'bg/'
        let powerPath = rootPath + 'power/'
        let stepPath = rootPath + 'step/'
        let timePath = rootPath + 'time/'
        let xpPath = rootPath + 'xp/'
        let battery_array = []
        let power_array = []
        let step_array = []
        let time_array = []
        let xp_array = []

        for (let i = 0; i < 10; i++) {
          battery_array.push(batteryPath + i + '.png')
          power_array.push(powerPath + i + '.png')
          step_array.push(stepPath + i + '.png')
          time_array.push(timePath + i + '.png')
          xp_array.push(xpPath + i + '.png')
        }

        //背景图片配置
        let obj_bg = {
          x: 0,
          y: 0,
          w: 390,
          h: 450,
          src: bgPath + 'bg.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        //背景动画配置
        let obj_anim = {
          x: 0,
          y: 0,
          anim_path: rootPath + 'bg',
          anim_prefix: 'a',
          anim_ext: 'png',
          anim_fps: 15,
          anim_size: 80,
          repeat_count: 1,
          anim_repeat: true,
          display_on_restart: true,
          anim_status: hmUI.anim_status.START,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        //电量进度配置
        let obj_battery_progress = {
          x: 134,
          y: 17,
          image_array: battery_array,
          image_length: battery_array.length,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        // 电量数值文本配置
        let obj_battery_text = {
          x: 182,
          y: 19,
          type: hmUI.data_type.BATTERY,
          font_array: power_array,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
          unit_sc: powerPath + 'baifen.png',
          unit_tc: powerPath + 'baifen.png',
          unit_en: powerPath + 'baifen.png',
        }

        // 时间文本配置
        let obj_time = {
          hour_zero: 1,
          hour_startX: 56,
          hour_startY: 60,
          hour_array: time_array,
          hour_space: 0,
          hour_unit_sc: timePath + 'maohao.png',
          hour_unit_tc: timePath + 'maohao.png',
          hour_unit_en: timePath + 'maohao.png',
          minute_zero: 1,
          minute_startX: 202,
          minute_startY: 60,
          minute_array: time_array,
          minute_space: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        // 步数文本配置
        let obj_step_text = {
          x: 179,
          y: 412,
          type: hmUI.data_type.STEP,
          font_array: step_array,
          h_space: 0,
          align_h: hmUI.align.LEFT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        }

        // 息屏时间配置
        let obj_time_xp = {
          hour_zero: 1,
          hour_startX: 56,
          hour_startY: 60,
          hour_array: xp_array,
          hour_space: 0,
          hour_unit_sc: xpPath + 'maohao.png',
          hour_unit_tc: xpPath + 'maohao.png',
          hour_unit_en: xpPath + 'maohao.png',
          minute_zero: 1,
          minute_startX: 202,
          minute_startY: 60,
          minute_array: xp_array,
          minute_space: 0,
          show_level: hmUI.show_level.ONAL_AOD,
        }

        // 背景
        let bg_img = hmUI.createWidget(hmUI.widget.IMG, obj_bg)

        // 动画
        let anim = hmUI.createWidget(hmUI.widget.IMG_ANIM, obj_anim)

        // 电量进度
        let battery_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, obj_battery_progress)

        // 电量数值
        let battery_text = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_battery_text)

        // 时间文本
        let time_text = hmUI.createWidget(hmUI.widget.IMG_TIME, obj_time)

        // 步数文本
        let step_ext = hmUI.createWidget(hmUI.widget.TEXT_IMG, obj_step_text)

        // 息屏时间
        let time_text_xp = hmUI.createWidget(hmUI.widget.IMG_TIME, obj_time_xp)

        // 步数热区跳转
        let step_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 149,
          y: 408,
          w: 120,
          h: 30,
          type: hmUI.data_type.STEP,
        })
      },

      onInit() {
        console.log('index page.js on init invoke')

        this.init_view()
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    })
    /*
     * end js
     */
  })()
} catch (e) {
  console.log(e)
}
