﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_stand_current_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_background_bg = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 262,
              y: 302,
              font_array: ["nn0.png","nn1.png","nn2.png","nn3.png","nn4.png","nn5.png","nn6.png","nn7.png","nn8.png","nn9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 257,
              y: 407,
              font_array: ["nn0.png","nn1.png","nn2.png","nn3.png","nn4.png","nn5.png","nn6.png","nn7.png","nn8.png","nn9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 257,
              y: 354,
              font_array: ["nn0.png","nn1.png","nn2.png","nn3.png","nn4.png","nn5.png","nn6.png","nn7.png","nn8.png","nn9.png"],
              padding: false,
              h_space: 2,
              dot_image: 'Act_Dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 40,
              y: 405,
              font_array: ["nn0.png","nn1.png","nn2.png","nn3.png","nn4.png","nn5.png","nn6.png","nn7.png","nn8.png","nn9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 350,
              y: 86,
              src: 'lock_closed.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 17,
              y: 83,
              src: 'dnd_on.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 342,
              y: 125,
              src: 'btoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 19,
              y: 136,
              src: 'alarm_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 13,
              y: 354,
              font_array: ["nn0.png","nn1.png","nn2.png","nn3.png","nn4.png","nn5.png","nn6.png","nn7.png","nn8.png","nn9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 302,
              font_array: ["nn0.png","nn1.png","nn2.png","nn3.png","nn4.png","nn5.png","nn6.png","nn7.png","nn8.png","nn9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 40,
              font_array: ["nn0.png","nn1.png","nn2.png","nn3.png","nn4.png","nn5.png","nn6.png","nn7.png","nn8.png","nn9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 37,
              y: 40,
              font_array: ["nn0.png","nn1.png","nn2.png","nn3.png","nn4.png","nn5.png","nn6.png","nn7.png","nn8.png","nn9.png"],
              padding: false,
              h_space: 4,
              unit_sc: '0086.png',
              unit_tc: '0086.png',
              unit_en: '0086.png',
              negative_image: '0087.png',
              invalid_image: '0087.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 153,
              y: 15,
              image_array: ["WET_0.png","WET_1.png","WET_2.png","WET_3.png","WET_4.png","WET_5.png","WET_6.png","WET_7.png","WET_8.png","WET_9.png","WET_10.png","WET_11.png","WET_12.png","WET_13.png","WET_14.png","WET_15.png","WET_16.png","WET_17.png","WET_18.png","WET_19.png","WET_20.png","WET_21.png","WET_22.png","WET_23.png","WET_24.png","WET_25.png","WET_26.png","WET_27.png","WET_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 171,
              month_startY: 98,
              month_sc_array: ["bb0.png","bb1.png","bb2.png","bb3.png","bb4.png","bb5.png","bb6.png","bb7.png","bb8.png","bb9.png"],
              month_tc_array: ["bb0.png","bb1.png","bb2.png","bb3.png","bb4.png","bb5.png","bb6.png","bb7.png","bb8.png","bb9.png"],
              month_en_array: ["bb0.png","bb1.png","bb2.png","bb3.png","bb4.png","bb5.png","bb6.png","bb7.png","bb8.png","bb9.png"],
              month_zero: 1,
              month_space: 4,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 242,
              year_startY: 98,
              year_sc_array: ["nn0.png","nn1.png","nn2.png","nn3.png","nn4.png","nn5.png","nn6.png","nn7.png","nn8.png","nn9.png"],
              year_tc_array: ["nn0.png","nn1.png","nn2.png","nn3.png","nn4.png","nn5.png","nn6.png","nn7.png","nn8.png","nn9.png"],
              year_en_array: ["nn0.png","nn1.png","nn2.png","nn3.png","nn4.png","nn5.png","nn6.png","nn7.png","nn8.png","nn9.png"],
              year_zero: 0,
              year_space: 4,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 102,
              day_startY: 98,
              day_sc_array: ["nn0.png","nn1.png","nn2.png","nn3.png","nn4.png","nn5.png","nn6.png","nn7.png","nn8.png","nn9.png"],
              day_tc_array: ["nn0.png","nn1.png","nn2.png","nn3.png","nn4.png","nn5.png","nn6.png","nn7.png","nn8.png","nn9.png"],
              day_en_array: ["nn0.png","nn1.png","nn2.png","nn3.png","nn4.png","nn5.png","nn6.png","nn7.png","nn8.png","nn9.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 108,
              y: 121,
              week_en: ["SEM2_1.png","SEM2_2.png","SEM2_3.png","SEM2_4.png","SEM2_5.png","SEM2_6.png","SEM2_7.png"],
              week_tc: ["SEM2_1.png","SEM2_2.png","SEM2_3.png","SEM2_4.png","SEM2_5.png","SEM2_6.png","SEM2_7.png"],
              week_sc: ["SEM2_1.png","SEM2_2.png","SEM2_3.png","SEM2_4.png","SEM2_5.png","SEM2_6.png","SEM2_7.png"],
              // alpha: 190,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img.setAlpha(190);

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 224,
              minute_startY: 192,
              minute_array: ["MIN0.png","MIN1.png","MIN2.png","MIN3.png","MIN4.png","MIN5.png","MIN6.png","MIN7.png","MIN8.png","MIN9.png"],
              minute_zero: 1,
              minute_space: 19,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 153,
              second_startY: 192,
              second_array: ["S0.png","S1.png","S2.png","S3.png","S4.png","S5.png","S6.png","S7.png","S8.png","S9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 11,
              hour_startY: 181,
              hour_array: ["h0.png","h1.png","h2.png","h3.png","h4.png","h5.png","h6.png","h7.png","h8.png","h9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 350,
              y: 86,
              src: 'lock_closed.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 17,
              y: 83,
              src: 'dnd_on.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 342,
              y: 125,
              src: 'btoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 19,
              y: 136,
              src: 'alarm_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 224,
              minute_startY: 192,
              minute_array: ["MIN0.png","MIN1.png","MIN2.png","MIN3.png","MIN4.png","MIN5.png","MIN6.png","MIN7.png","MIN8.png","MIN9.png"],
              minute_zero: 1,
              minute_space: 19,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 11,
              hour_startY: 181,
              hour_array: ["h0.png","h1.png","h2.png","h3.png","h4.png","h5.png","h6.png","h7.png","h8.png","h9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Desconectado,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: Conectado,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Desconectado"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Conectado"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 266,
              y: 340,
              w: 100,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 18,
              y: 286,
              w: 100,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 236,
              y: 402,
              w: 100,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 270,
              y: 17,
              w: 100,
              h: 60,
              src: '0_Empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 239,
              y: 278,
              w: 100,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 258,
              y: 183,
              w: 100,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 138,
              y: 101,
              w: 120,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 58,
              y: 184,
              w: 100,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 293,
              y: 107,
              w: 80,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 150,
              y: 23,
              w: 80,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 63,
              y: 386,
              w: 130,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 12,
              y: 103,
              w: 100,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 36,
              y: 22,
              w: 100,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'MusicCommonScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}