﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;
        let normal_rotate_animation_img_2 = '';
        let normal_rotate_animation_param_2 = null;
        let normal_rotate_animation_lastTime_2 = 0;
        let timer_anim_rotate_2;
        let normal_rotate_animation_count_2 = 0;
        let normal_rotate_animation_img_3 = '';
        let normal_rotate_animation_param_3 = null;
        let normal_rotate_animation_lastTime_3 = 0;
        let timer_anim_rotate_3;
        let normal_rotate_animation_count_3 = 0;
        let normal_rotate_animation_img_4 = '';
        let normal_rotate_animation_param_4 = null;
        let normal_rotate_animation_lastTime_4 = 0;
        let timer_anim_rotate_4;
        let normal_rotate_animation_count_4 = 0;
        let normal_rotate_animation_img_5 = '';
        let normal_rotate_animation_param_5 = null;
        let normal_rotate_animation_lastTime_5 = 0;
        let timer_anim_rotate_5;
        let normal_rotate_animation_count_5 = 0;
        let normal_rotate_animation_img_6 = '';
        let normal_rotate_animation_param_6 = null;
        let normal_rotate_animation_lastTime_6 = 0;
        let timer_anim_rotate_6;
        let normal_rotate_animation_count_6 = 0;
        let normal_rotate_animation_img_7 = '';
        let normal_rotate_animation_param_7 = null;
        let normal_rotate_animation_lastTime_7 = 0;
        let timer_anim_rotate_7;
        let normal_rotate_animation_count_7 = 0;
        let normal_rotate_animation_img_8 = '';
        let normal_rotate_animation_param_8 = null;
        let normal_rotate_animation_lastTime_8 = 0;
        let timer_anim_rotate_8;
        let normal_rotate_animation_count_8 = 0;
        let normal_rotate_animation_img_9 = '';
        let normal_rotate_animation_param_9 = null;
        let normal_rotate_animation_lastTime_9 = 0;
        let timer_anim_rotate_9;
        let normal_rotate_animation_count_9 = 0;
        let normal_rotate_animation_img_10 = '';
        let normal_rotate_animation_param_10 = null;
        let normal_rotate_animation_lastTime_10 = 0;
        let timer_anim_rotate_10;
        let normal_rotate_animation_count_10 = 0;
        let normal_motion_animation_img_1 = '';
        let normal_motion_animation_paramX_1 = null;
        let normal_motion_animation_paramY_1 = null;
        let normal_motion_animation_lastTime_1 = 0;
        let timer_anim_motion_1;
        let timer_anim_motion_1_mirror = false;
        let normal_motion_animation_paramX_1_mirror = null;
        let normal_motion_animation_paramY_1_mirror = null;
        let normal_motion_animation_count_1 = 0;
        let normal_image_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_humidity_text_text_img = ''
        let idle_humidity_text_separator_img = ''
        let idle_spo2_text_text_img = ''
        let idle_spo2_text_separator_img = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_pai_weekly_text_img = ''
        let idle_pai_weekly_separator_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 141,
              y: 179,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "Sun",
              anim_fps: 11,
              anim_size: 17,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 391,
              h: 451,
              pos_x: 190,
              pos_y: 181,
              center_x: 195,
              center_y: 232,
              angle: 0,
              src: 'animation/star_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 10000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
              normal_rotate_animation_lastTime_1 = now.utc;
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 5,
              // pos_y: 51,
              // center_x: 195,
              // center_y: 232,
              // src: 'star_01.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 391,
              h: 451,
              pos_x: 189,
              pos_y: 166,
              center_x: 195,
              center_y: 232,
              angle: 0,
              src: 'animation/star_02.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_2 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 15000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            function anim_rotate_2_complete_call() {
              normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_2);
              normal_rotate_animation_lastTime_2 = now.utc;
              normal_rotate_animation_count_2 = normal_rotate_animation_count_2 - 1;
              if(normal_rotate_animation_count_2 < -1) normal_rotate_animation_count_2 = - 1;
              if(normal_rotate_animation_count_2 == 0) stop_anim_rotate_2();
            }; // end animation callback function
            
            function stop_anim_rotate_2() {
              if (timer_anim_rotate_2) {
                timer.stopTimer(timer_anim_rotate_2);
                timer_anim_rotate_2 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_2 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 6,
              // pos_y: 66,
              // center_x: 195,
              // center_y: 232,
              // src: 'star_02.png',
              // anim_fps: 15,
              // anim_duration: 15000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_3 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 391,
              h: 451,
              pos_x: 186,
              pos_y: 148,
              center_x: 195,
              center_y: 232,
              angle: 0,
              src: 'animation/star_03.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_3 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 24000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            function anim_rotate_3_complete_call() {
              normal_rotate_animation_img_3.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_3);
              normal_rotate_animation_lastTime_3 = now.utc;
              normal_rotate_animation_count_3 = normal_rotate_animation_count_3 - 1;
              if(normal_rotate_animation_count_3 < -1) normal_rotate_animation_count_3 = - 1;
              if(normal_rotate_animation_count_3 == 0) stop_anim_rotate_3();
            }; // end animation callback function
            
            function stop_anim_rotate_3() {
              if (timer_anim_rotate_3) {
                timer.stopTimer(timer_anim_rotate_3);
                timer_anim_rotate_3 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_3 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 9,
              // pos_y: 84,
              // center_x: 195,
              // center_y: 232,
              // src: 'star_03.png',
              // anim_fps: 15,
              // anim_duration: 24000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_4 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 391,
              h: 451,
              pos_x: 190,
              pos_y: 136,
              center_x: 195,
              center_y: 232,
              angle: 0,
              src: 'animation/star_04.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_4 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 30000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            function anim_rotate_4_complete_call() {
              normal_rotate_animation_img_4.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_4);
              normal_rotate_animation_lastTime_4 = now.utc;
              normal_rotate_animation_count_4 = normal_rotate_animation_count_4 - 1;
              if(normal_rotate_animation_count_4 < -1) normal_rotate_animation_count_4 = - 1;
              if(normal_rotate_animation_count_4 == 0) stop_anim_rotate_4();
            }; // end animation callback function
            
            function stop_anim_rotate_4() {
              if (timer_anim_rotate_4) {
                timer.stopTimer(timer_anim_rotate_4);
                timer_anim_rotate_4 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_4 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 5,
              // pos_y: 96,
              // center_x: 195,
              // center_y: 232,
              // src: 'star_04.png',
              // anim_fps: 15,
              // anim_duration: 30000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_5 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 391,
              h: 451,
              pos_x: 178,
              pos_y: 98,
              center_x: 195,
              center_y: 232,
              angle: 0,
              src: 'animation/star_05.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_5 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 36000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            function anim_rotate_5_complete_call() {
              normal_rotate_animation_img_5.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_5);
              normal_rotate_animation_lastTime_5 = now.utc;
              normal_rotate_animation_count_5 = normal_rotate_animation_count_5 - 1;
              if(normal_rotate_animation_count_5 < -1) normal_rotate_animation_count_5 = - 1;
              if(normal_rotate_animation_count_5 == 0) stop_anim_rotate_5();
            }; // end animation callback function
            
            function stop_anim_rotate_5() {
              if (timer_anim_rotate_5) {
                timer.stopTimer(timer_anim_rotate_5);
                timer_anim_rotate_5 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_5 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 17,
              // pos_y: 134,
              // center_x: 195,
              // center_y: 232,
              // src: 'star_05.png',
              // anim_fps: 15,
              // anim_duration: 36000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_6 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 391,
              h: 451,
              pos_x: 172,
              pos_y: 58,
              center_x: 195,
              center_y: 232,
              angle: 0,
              src: 'animation/star_06.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_6 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 45000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            function anim_rotate_6_complete_call() {
              normal_rotate_animation_img_6.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_6);
              normal_rotate_animation_lastTime_6 = now.utc;
              normal_rotate_animation_count_6 = normal_rotate_animation_count_6 - 1;
              if(normal_rotate_animation_count_6 < -1) normal_rotate_animation_count_6 = - 1;
              if(normal_rotate_animation_count_6 == 0) stop_anim_rotate_6();
            }; // end animation callback function
            
            function stop_anim_rotate_6() {
              if (timer_anim_rotate_6) {
                timer.stopTimer(timer_anim_rotate_6);
                timer_anim_rotate_6 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_6 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 23,
              // pos_y: 174,
              // center_x: 195,
              // center_y: 232,
              // src: 'star_06.png',
              // anim_fps: 15,
              // anim_duration: 45000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_7 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 391,
              h: 451,
              pos_x: 183,
              pos_y: 42,
              center_x: 195,
              center_y: 232,
              angle: 0,
              src: 'animation/star_07.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_7 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 54000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            function anim_rotate_7_complete_call() {
              normal_rotate_animation_img_7.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_7);
              normal_rotate_animation_lastTime_7 = now.utc;
              normal_rotate_animation_count_7 = normal_rotate_animation_count_7 - 1;
              if(normal_rotate_animation_count_7 < -1) normal_rotate_animation_count_7 = - 1;
              if(normal_rotate_animation_count_7 == 0) stop_anim_rotate_7();
            }; // end animation callback function
            
            function stop_anim_rotate_7() {
              if (timer_anim_rotate_7) {
                timer.stopTimer(timer_anim_rotate_7);
                timer_anim_rotate_7 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_7 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 12,
              // pos_y: 190,
              // center_x: 195,
              // center_y: 232,
              // src: 'star_07.png',
              // anim_fps: 15,
              // anim_duration: 54000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_8 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 391,
              h: 451,
              pos_x: 189,
              pos_y: 28,
              center_x: 195,
              center_y: 232,
              angle: 0,
              src: 'animation/star_08.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_8 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 63000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            function anim_rotate_8_complete_call() {
              normal_rotate_animation_img_8.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_8);
              normal_rotate_animation_lastTime_8 = now.utc;
              normal_rotate_animation_count_8 = normal_rotate_animation_count_8 - 1;
              if(normal_rotate_animation_count_8 < -1) normal_rotate_animation_count_8 = - 1;
              if(normal_rotate_animation_count_8 == 0) stop_anim_rotate_8();
            }; // end animation callback function
            
            function stop_anim_rotate_8() {
              if (timer_anim_rotate_8) {
                timer.stopTimer(timer_anim_rotate_8);
                timer_anim_rotate_8 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_8 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 6,
              // pos_y: 204,
              // center_x: 195,
              // center_y: 232,
              // src: 'star_08.png',
              // anim_fps: 15,
              // anim_duration: 63000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_9 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 391,
              h: 451,
              pos_x: 189,
              pos_y: 15,
              center_x: 195,
              center_y: 232,
              angle: 0,
              src: 'animation/star_09.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_9 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 40000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            function anim_rotate_9_complete_call() {
              normal_rotate_animation_img_9.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_9);
              normal_rotate_animation_lastTime_9 = now.utc;
              normal_rotate_animation_count_9 = normal_rotate_animation_count_9 - 1;
              if(normal_rotate_animation_count_9 < -1) normal_rotate_animation_count_9 = - 1;
              if(normal_rotate_animation_count_9 == 0) stop_anim_rotate_9();
            }; // end animation callback function
            
            function stop_anim_rotate_9() {
              if (timer_anim_rotate_9) {
                timer.stopTimer(timer_anim_rotate_9);
                timer_anim_rotate_9 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_9 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 6,
              // pos_y: 217,
              // center_x: 195,
              // center_y: 232,
              // src: 'star_09.png',
              // anim_fps: 15,
              // anim_duration: 40000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_10 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 391,
              h: 451,
              pos_x: 0,
              pos_y: 0,
              center_x: 195,
              center_y: 232,
              angle: 30,
              src: 'animation/main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_10 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 90000,
                anim_from: 30,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            function anim_rotate_10_complete_call() {
              normal_rotate_animation_img_10.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_10);
              normal_rotate_animation_lastTime_10 = now.utc;
              normal_rotate_animation_count_10 = normal_rotate_animation_count_10 - 1;
              if(normal_rotate_animation_count_10 < -1) normal_rotate_animation_count_10 = - 1;
              if(normal_rotate_animation_count_10 == 0) stop_anim_rotate_10();
            }; // end animation callback function
            
            function stop_anim_rotate_10() {
              if (timer_anim_rotate_10) {
                timer.stopTimer(timer_anim_rotate_10);
                timer_anim_rotate_10 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_10 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 30,
              // end_angle: 360,
              // pos_x: 195,
              // pos_y: 232,
              // center_x: 195,
              // center_y: 232,
              // src: 'main.png',
              // anim_fps: 15,
              // anim_duration: 90000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_motion_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 389,
              h: 449,
              pos_x: 174,
              pos_y: 300,
              src: 'animation/rocket_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 10000,
                anim_from: 174,
                anim_to: 161,
                anim_key: "pos_x",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            normal_motion_animation_paramY_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 10000,
                anim_from: 300,
                anim_to: 293,
                anim_key: "pos_y",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            normal_motion_animation_paramX_1_mirror = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 10000,
                anim_from: 161,
                anim_to: 174,
                anim_key: "pos_x",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            normal_motion_animation_paramY_1_mirror = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 10000,
                anim_from: 293,
                anim_to: 300,
                anim_key: "pos_y",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            function anim_motion_1_mirror() {
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_1_mirror);
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_1_mirror);
              normal_motion_animation_lastTime_1 = now.utc;
              normal_motion_animation_count_1 = normal_motion_animation_count_1 - 1;
              if(normal_motion_animation_count_1 < -1) normal_motion_animation_count_1 = - 1;
              if(normal_motion_animation_count_1 == 0) stop_anim_motion_1();
            }; // end animation_mirror callback function

            function anim_motion_1_complete_call() {
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_1);
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_1);
                normal_motion_animation_lastTime_1 = now.utc;
            }; // end animation callback function
            
            function stop_anim_motion_1() {
              if (timer_anim_motion_1) {
                timer.stopTimer(timer_anim_motion_1);
                timer_anim_motion_1 = undefined;
              };
            }; // end stop_anim_motion function

            // normal_motion_anime_1 = hmUI.createWidget(hmUI.widget.Motion_Animation, {
              // x_start: 174,
              // y_start: 300,
              // x_end: 161,
              // y_end: 293,
              // src: 'rocket_0.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 137,
              y: 211,
              src: 'amazfitlogo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 336,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'batt_symbo.png',
              unit_tc: 'batt_symbo.png',
              unit_en: 'batt_symbo.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 347,
              src: 'icon_hum.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 289,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'batt_symbo.png',
              unit_tc: 'batt_symbo.png',
              unit_en: 'batt_symbo.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 340,
              y: 274,
              src: 'icon_O2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 90,
              y: 345,
              w: 200,
              h: 45,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 20,
              y: 358,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_Symbo_01.png',
              unit_tc: 'Weather_Symbo_01.png',
              unit_en: 'Weather_Symbo_01.png',
              negative_image: 'Weather_Symbo_02.png',
              invalid_image: 'Weather_Symbo_02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 30,
              y: 303,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 59,
              y: 260,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 9,
              y: 249,
              src: 'icon_PAI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 33,
              y: 393,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 300,
              y: 396,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 394,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 130,
              y: 416,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'batt_symbo.png',
              unit_tc: 'batt_symbo.png',
              unit_en: 'batt_symbo.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 85,
              y: 395,
              src: 'icon_Batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 95,
              y: 410,
              image_array: ["Batt_icon_1.png","Batt_icon_2.png","Batt_icon_3.png","Batt_icon_4.png","Batt_icon_5.png","Batt_icon_6.png","Batt_icon_7.png","Batt_icon_8.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 168,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 335,
              y: 149,
              src: 'icon_Dis.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 279,
              y: 213,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 346,
              y: 206,
              src: 'icon_heartrate.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 324,
              y: 244,
              image_array: ["Zone_1.png","Zone_2.png","Zone_3.png","Zone_4.png","Zone_5.png","Zone_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 59,
              y: 210,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 12,
              y: 197,
              src: 'icon_Cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 167,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 7,
              y: 145,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 55,
              day_startY: 18,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 106,
              y: 23,
              week_en: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_tc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_sc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 204,
              month_startY: 24,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 34,
              hour_startY: 55,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 12,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 219,
              minute_startY: 55,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 12,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 177,
              second_startY: 113,
              second_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 188,
              y: 43,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 173,
              am_y: 139,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 174,
              pm_y: 139,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 137,
              y: 211,
              src: 'amazfitlogo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 336,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'batt_symbo.png',
              unit_tc: 'batt_symbo.png',
              unit_en: 'batt_symbo.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 347,
              src: 'icon_hum.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 289,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'batt_symbo.png',
              unit_tc: 'batt_symbo.png',
              unit_en: 'batt_symbo.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 340,
              y: 274,
              src: 'icon_O2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 90,
              y: 345,
              w: 200,
              h: 45,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 20,
              y: 358,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_Symbo_01.png',
              unit_tc: 'Weather_Symbo_01.png',
              unit_en: 'Weather_Symbo_01.png',
              negative_image: 'Weather_Symbo_02.png',
              invalid_image: 'Weather_Symbo_02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 30,
              y: 303,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 59,
              y: 260,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 9,
              y: 249,
              src: 'icon_PAI.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 29,
              y: 403,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 300,
              y: 410,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 222,
              y: 407,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 130,
              y: 425,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'batt_symbo.png',
              unit_tc: 'batt_symbo.png',
              unit_en: 'batt_symbo.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 85,
              y: 401,
              src: 'icon_Batt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 95,
              y: 417,
              image_array: ["Batt_icon_1.png","Batt_icon_2.png","Batt_icon_3.png","Batt_icon_4.png","Batt_icon_5.png","Batt_icon_6.png","Batt_icon_7.png","Batt_icon_8.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 168,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 335,
              y: 149,
              src: 'icon_Dis.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 279,
              y: 213,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 346,
              y: 206,
              src: 'icon_heartrate.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 324,
              y: 244,
              image_array: ["Zone_1.png","Zone_2.png","Zone_3.png","Zone_4.png","Zone_5.png","Zone_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 59,
              y: 210,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 12,
              y: 197,
              src: 'icon_Cal.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 167,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 7,
              y: 145,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 55,
              day_startY: 18,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 106,
              y: 23,
              week_en: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_tc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_sc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 204,
              month_startY: 24,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 34,
              hour_startY: 55,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 12,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 219,
              minute_startY: 55,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 12,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 177,
              second_startY: 113,
              second_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 188,
              y: 43,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 173,
              am_y: 139,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 174,
              pm_y: 139,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 254,
              y: 63,
              w: 68,
              h: 68,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 179,
              y: 60,
              w: 37,
              h: 77,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 221,
              y: 401,
              w: 49,
              h: 61,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 11,
              y: 405,
              w: 60,
              h: 52,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 18,
              y: 319,
              w: 59,
              h: 68,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 9,
              y: 251,
              w: 112,
              h: 40,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 283,
              y: 279,
              w: 100,
              h: 40,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 279,
              y: 215,
              w: 106,
              h: 48,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 13,
              y: 161,
              w: 145,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 82,
              y: 410,
              w: 115,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 30,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 46,
              y: 5,
              w: 54,
              h: 54,
              text: '',
              color: 0xFFFF8C00,
              text_size: 30,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 10000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    anim_rotate_1_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_2 = 0;
                let repeat_anim_rotate_2 = 15000;
                delay_anim_rotate_2 = repeat_anim_rotate_2 - (nawAnimationTime - normal_rotate_animation_lastTime_2);
                if(delay_anim_rotate_2 < 0) delay_anim_rotate_2 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_2) > repeat_anim_rotate_2) {
                  normal_rotate_animation_count_2 = 0;
                  timer_anim_rotate_2_mirror = false;
                };

                if (!timer_anim_rotate_2) {
                  timer_anim_rotate_2 = timer.createTimer(delay_anim_rotate_2, repeat_anim_rotate_2, (function (option) {
                    anim_rotate_2_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_3 = 0;
                let repeat_anim_rotate_3 = 24000;
                delay_anim_rotate_3 = repeat_anim_rotate_3 - (nawAnimationTime - normal_rotate_animation_lastTime_3);
                if(delay_anim_rotate_3 < 0) delay_anim_rotate_3 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_3) > repeat_anim_rotate_3) {
                  normal_rotate_animation_count_3 = 0;
                  timer_anim_rotate_3_mirror = false;
                };

                if (!timer_anim_rotate_3) {
                  timer_anim_rotate_3 = timer.createTimer(delay_anim_rotate_3, repeat_anim_rotate_3, (function (option) {
                    anim_rotate_3_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_4 = 0;
                let repeat_anim_rotate_4 = 30000;
                delay_anim_rotate_4 = repeat_anim_rotate_4 - (nawAnimationTime - normal_rotate_animation_lastTime_4);
                if(delay_anim_rotate_4 < 0) delay_anim_rotate_4 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_4) > repeat_anim_rotate_4) {
                  normal_rotate_animation_count_4 = 0;
                  timer_anim_rotate_4_mirror = false;
                };

                if (!timer_anim_rotate_4) {
                  timer_anim_rotate_4 = timer.createTimer(delay_anim_rotate_4, repeat_anim_rotate_4, (function (option) {
                    anim_rotate_4_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_5 = 0;
                let repeat_anim_rotate_5 = 36000;
                delay_anim_rotate_5 = repeat_anim_rotate_5 - (nawAnimationTime - normal_rotate_animation_lastTime_5);
                if(delay_anim_rotate_5 < 0) delay_anim_rotate_5 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_5) > repeat_anim_rotate_5) {
                  normal_rotate_animation_count_5 = 0;
                  timer_anim_rotate_5_mirror = false;
                };

                if (!timer_anim_rotate_5) {
                  timer_anim_rotate_5 = timer.createTimer(delay_anim_rotate_5, repeat_anim_rotate_5, (function (option) {
                    anim_rotate_5_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_6 = 0;
                let repeat_anim_rotate_6 = 45000;
                delay_anim_rotate_6 = repeat_anim_rotate_6 - (nawAnimationTime - normal_rotate_animation_lastTime_6);
                if(delay_anim_rotate_6 < 0) delay_anim_rotate_6 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_6) > repeat_anim_rotate_6) {
                  normal_rotate_animation_count_6 = 0;
                  timer_anim_rotate_6_mirror = false;
                };

                if (!timer_anim_rotate_6) {
                  timer_anim_rotate_6 = timer.createTimer(delay_anim_rotate_6, repeat_anim_rotate_6, (function (option) {
                    anim_rotate_6_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_7 = 0;
                let repeat_anim_rotate_7 = 54000;
                delay_anim_rotate_7 = repeat_anim_rotate_7 - (nawAnimationTime - normal_rotate_animation_lastTime_7);
                if(delay_anim_rotate_7 < 0) delay_anim_rotate_7 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_7) > repeat_anim_rotate_7) {
                  normal_rotate_animation_count_7 = 0;
                  timer_anim_rotate_7_mirror = false;
                };

                if (!timer_anim_rotate_7) {
                  timer_anim_rotate_7 = timer.createTimer(delay_anim_rotate_7, repeat_anim_rotate_7, (function (option) {
                    anim_rotate_7_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_8 = 0;
                let repeat_anim_rotate_8 = 63000;
                delay_anim_rotate_8 = repeat_anim_rotate_8 - (nawAnimationTime - normal_rotate_animation_lastTime_8);
                if(delay_anim_rotate_8 < 0) delay_anim_rotate_8 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_8) > repeat_anim_rotate_8) {
                  normal_rotate_animation_count_8 = 0;
                  timer_anim_rotate_8_mirror = false;
                };

                if (!timer_anim_rotate_8) {
                  timer_anim_rotate_8 = timer.createTimer(delay_anim_rotate_8, repeat_anim_rotate_8, (function (option) {
                    anim_rotate_8_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_9 = 0;
                let repeat_anim_rotate_9 = 40000;
                delay_anim_rotate_9 = repeat_anim_rotate_9 - (nawAnimationTime - normal_rotate_animation_lastTime_9);
                if(delay_anim_rotate_9 < 0) delay_anim_rotate_9 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_9) > repeat_anim_rotate_9) {
                  normal_rotate_animation_count_9 = 0;
                  timer_anim_rotate_9_mirror = false;
                };

                if (!timer_anim_rotate_9) {
                  timer_anim_rotate_9 = timer.createTimer(delay_anim_rotate_9, repeat_anim_rotate_9, (function (option) {
                    anim_rotate_9_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_10 = 0;
                let repeat_anim_rotate_10 = 90000;
                delay_anim_rotate_10 = repeat_anim_rotate_10 - (nawAnimationTime - normal_rotate_animation_lastTime_10);
                if(delay_anim_rotate_10 < 0) delay_anim_rotate_10 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_10) > repeat_anim_rotate_10) {
                  normal_rotate_animation_count_10 = 0;
                  timer_anim_rotate_10_mirror = false;
                };

                if (!timer_anim_rotate_10) {
                  timer_anim_rotate_10 = timer.createTimer(delay_anim_rotate_10, repeat_anim_rotate_10, (function (option) {
                    anim_rotate_10_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_motion_1 = 0;
                let repeat_anim_motion_1 = 10000;
                delay_anim_motion_1 = repeat_anim_motion_1 - (nawAnimationTime - normal_motion_animation_lastTime_1);
                if(delay_anim_motion_1 < 0) delay_anim_motion_1 = 0; 
                if((nawAnimationTime - normal_motion_animation_lastTime_1) > repeat_anim_motion_1*2) {
                  normal_motion_animation_count_1 = 0;
                  timer_anim_motion_1_mirror = false;
                };

                if (!timer_anim_motion_1) {
                  timer_anim_motion_1 = timer.createTimer(delay_anim_motion_1, repeat_anim_motion_1, (function (option) {
                    if(timer_anim_motion_1_mirror) {
                      anim_motion_1_mirror()
                    } else {
                      anim_motion_1_complete_call()
                    };
                    timer_anim_motion_1_mirror = !timer_anim_motion_1_mirror;
                  })); // end timer create
                };

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                stop_anim_rotate_1();
                stop_anim_rotate_2();
                stop_anim_rotate_3();
                stop_anim_rotate_4();
                stop_anim_rotate_5();
                stop_anim_rotate_6();
                stop_anim_rotate_7();
                stop_anim_rotate_8();
                stop_anim_rotate_9();
                stop_anim_rotate_10();
                stop_anim_motion_1();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}