﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_font = ''
        let normal_stand_circle_scale = ''
        let normal_calorie_circle_scale = ''
        let normal_step_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_temperature_icon_img = ''
        let idle_temperature_current_text_font = ''
        let idle_stand_circle_scale = ''
        let idle_calorie_circle_scale = ''
        let idle_step_circle_scale = ''
        let idle_battery_icon_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: SF-Compact-Rounded-Medium_compressed (1).ttf; FontSize: 42
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 552,
              h: 61,
              text_size: 42,
              char_space: 0,
              line_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed (1).ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 1,
              y: 152,
              src: 'HR_ES_EN__lt__medici_n_.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 152,
              font_array: ["NUM_HR_SIZE_35_0.png","NUM_HR_SIZE_35_1.png","NUM_HR_SIZE_35_2.png","NUM_HR_SIZE_35_3.png","NUM_HR_SIZE_35_4.png","NUM_HR_SIZE_35_5.png","NUM_HR_SIZE_35_6.png","NUM_HR_SIZE_35_7.png","NUM_HR_SIZE_35_8.png","NUM_HR_SIZE_35_9.png"],
              padding: false,
              h_space: -21,
              unit_sc: 'LPM_BPP_TAM_35_lpm.png',
              unit_tc: 'LPM_BPP_TAM_35_lpm.png',
              unit_en: 'LPM_BPP_TAM_35_lpm.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 11,
              y: 286,
              src: 'MAX_MIN_min.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 2,
              y: 81,
              w: 150,
              h: 44,
              text_size: 42,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed (1).ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 75,
              // center_y: 387,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 23,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFF3E88AD,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 75,
              center_y: 387,
              start_angle: 0,
              end_angle: 360,
              radius: 19,
              line_width: 9,
              corner_flag: 0,
              color: 0xFF3E88AD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 75,
              // center_y: 387,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 35,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFF3E88AD,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 75,
              center_y: 387,
              start_angle: 0,
              end_angle: 360,
              radius: 31,
              line_width: 9,
              corner_flag: 0,
              color: 0xFF3E88AD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 75,
              // center_y: 387,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 47,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFF3E88AD,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 75,
              center_y: 387,
              start_angle: 0,
              end_angle: 360,
              radius: 43,
              line_width: 9,
              corner_flag: 0,
              color: 0xFF3E88AD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 5,
              y: 190,
              src: 'MAX_MIN_max.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 319,
              // center_y: 385,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 47,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFF37C371,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 319,
              center_y: 385,
              start_angle: 0,
              end_angle: 360,
              radius: 43,
              line_width: 8,
              corner_flag: 0,
              color: 0xFF37C371,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 355,
              font_array: ["TAM_45_CENTER_0.png","TAM_45_CENTER_1.png","TAM_45_CENTER_2.png","TAM_45_CENTER_3.png","TAM_45_CENTER_4.png","TAM_45_CENTER_5.png","TAM_45_CENTER_6.png","TAM_45_CENTER_7.png","TAM_45_CENTER_8.png","TAM_45_CENTER_9.png"],
              padding: false,
              h_space: -22,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 200,
              y: 14,
              week_en: ["DAYS_ES_1.png","DAYS_ES_2.png","DAYS_ES_3.png","DAYS_ES_4.png","DAYS_ES_5.png","DAYS_ES_6.png","DAYS_ES_7.png"],
              week_tc: ["DAYS_ES_1.png","DAYS_ES_2.png","DAYS_ES_3.png","DAYS_ES_4.png","DAYS_ES_5.png","DAYS_ES_6.png","DAYS_ES_7.png"],
              week_sc: ["DAYS_ES_1.png","DAYS_ES_2.png","DAYS_ES_3.png","DAYS_ES_4.png","DAYS_ES_5.png","DAYS_ES_6.png","DAYS_ES_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 290,
              day_startY: 12,
              day_sc_array: ["NUM_TAM_45_0.png","NUM_TAM_45_1.png","NUM_TAM_45_2.png","NUM_TAM_45_3.png","NUM_TAM_45_4.png","NUM_TAM_45_5.png","NUM_TAM_45_6.png","NUM_TAM_45_7.png","NUM_TAM_45_8.png","NUM_TAM_45_9.png"],
              day_tc_array: ["NUM_TAM_45_0.png","NUM_TAM_45_1.png","NUM_TAM_45_2.png","NUM_TAM_45_3.png","NUM_TAM_45_4.png","NUM_TAM_45_5.png","NUM_TAM_45_6.png","NUM_TAM_45_7.png","NUM_TAM_45_8.png","NUM_TAM_45_9.png"],
              day_en_array: ["NUM_TAM_45_0.png","NUM_TAM_45_1.png","NUM_TAM_45_2.png","NUM_TAM_45_3.png","NUM_TAM_45_4.png","NUM_TAM_45_5.png","NUM_TAM_45_6.png","NUM_TAM_45_7.png","NUM_TAM_45_8.png","NUM_TAM_45_9.png"],
              day_zero: 1,
              day_space: -21,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 120,
              hour_startY: 47,
              hour_array: ["NUM_HR_0.png","NUM_HR_1.png","NUM_HR_2.png","NUM_HR_3.png","NUM_HR_4.png","NUM_HR_5.png","NUM_HR_6.png","NUM_HR_7.png","NUM_HR_8.png","NUM_HR_9.png"],
              hour_zero: 1,
              hour_space: -21,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 244,
              minute_startY: 47,
              minute_array: ["NUM_MIN_0.png","NUM_MIN_1.png","NUM_MIN_2.png","NUM_MIN_3.png","NUM_MIN_4.png","NUM_MIN_5.png","NUM_MIN_6.png","NUM_MIN_7.png","NUM_MIN_8.png","NUM_MIN_9.png"],
              minute_zero: 1,
              minute_space: -21,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 192,
              y: 38,
              src: 'NUM_HR__.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 30,
              y: 152,
              src: 'ultima_medicion_last_measure__lt__medici_n_.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 152,
              font_array: ["HR_NUM_0.png","HR_NUM_1.png","HR_NUM_2.png","HR_NUM_3.png","HR_NUM_4.png","HR_NUM_5.png","HR_NUM_6.png","HR_NUM_7.png","HR_NUM_8.png","HR_NUM_9.png"],
              padding: false,
              h_space: -21,
              unit_sc: 'BPP_LPM_lpm.png',
              unit_tc: 'BPP_LPM_lpm.png',
              unit_en: 'BPP_LPM_lpm.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 11,
              y: 286,
              src: 'MAX_MIN_min.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 2,
              y: 81,
              w: 150,
              h: 44,
              text_size: 42,
              char_space: 0,
              font: 'fonts/SF-Compact-Rounded-Medium_compressed (1).ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 75,
              // center_y: 387,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 23,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFF3E88AD,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 75,
              center_y: 387,
              start_angle: 0,
              end_angle: 360,
              radius: 19,
              line_width: 9,
              corner_flag: 0,
              color: 0xFF3E88AD,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 75,
              // center_y: 387,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 35,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFF3E88AD,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 75,
              center_y: 387,
              start_angle: 0,
              end_angle: 360,
              radius: 31,
              line_width: 9,
              corner_flag: 0,
              color: 0xFF3E88AD,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 75,
              // center_y: 387,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 47,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFF3E88AD,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 75,
              center_y: 387,
              start_angle: 0,
              end_angle: 360,
              radius: 43,
              line_width: 9,
              corner_flag: 0,
              color: 0xFF3E88AD,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 5,
              y: 190,
              src: 'MAX_MIN_max.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 319,
              // center_y: 385,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 47,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFF37C371,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 319,
              center_y: 385,
              start_angle: 0,
              end_angle: 360,
              radius: 43,
              line_width: 8,
              corner_flag: 0,
              color: 0xFF37C371,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 355,
              font_array: ["TAM_45_CENTER_0.png","TAM_45_CENTER_1.png","TAM_45_CENTER_2.png","TAM_45_CENTER_3.png","TAM_45_CENTER_4.png","TAM_45_CENTER_5.png","TAM_45_CENTER_6.png","TAM_45_CENTER_7.png","TAM_45_CENTER_8.png","TAM_45_CENTER_9.png"],
              padding: false,
              h_space: -22,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 200,
              y: 14,
              week_en: ["DAYS_ES_1.png","DAYS_ES_2.png","DAYS_ES_3.png","DAYS_ES_4.png","DAYS_ES_5.png","DAYS_ES_6.png","DAYS_ES_7.png"],
              week_tc: ["DAYS_ES_1.png","DAYS_ES_2.png","DAYS_ES_3.png","DAYS_ES_4.png","DAYS_ES_5.png","DAYS_ES_6.png","DAYS_ES_7.png"],
              week_sc: ["DAYS_ES_1.png","DAYS_ES_2.png","DAYS_ES_3.png","DAYS_ES_4.png","DAYS_ES_5.png","DAYS_ES_6.png","DAYS_ES_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 290,
              day_startY: 12,
              day_sc_array: ["NUM_TAM_45_0.png","NUM_TAM_45_1.png","NUM_TAM_45_2.png","NUM_TAM_45_3.png","NUM_TAM_45_4.png","NUM_TAM_45_5.png","NUM_TAM_45_6.png","NUM_TAM_45_7.png","NUM_TAM_45_8.png","NUM_TAM_45_9.png"],
              day_tc_array: ["NUM_TAM_45_0.png","NUM_TAM_45_1.png","NUM_TAM_45_2.png","NUM_TAM_45_3.png","NUM_TAM_45_4.png","NUM_TAM_45_5.png","NUM_TAM_45_6.png","NUM_TAM_45_7.png","NUM_TAM_45_8.png","NUM_TAM_45_9.png"],
              day_en_array: ["NUM_TAM_45_0.png","NUM_TAM_45_1.png","NUM_TAM_45_2.png","NUM_TAM_45_3.png","NUM_TAM_45_4.png","NUM_TAM_45_5.png","NUM_TAM_45_6.png","NUM_TAM_45_7.png","NUM_TAM_45_8.png","NUM_TAM_45_9.png"],
              day_zero: 1,
              day_space: -21,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 120,
              hour_startY: 47,
              hour_array: ["NUM_HR_0.png","NUM_HR_1.png","NUM_HR_2.png","NUM_HR_3.png","NUM_HR_4.png","NUM_HR_5.png","NUM_HR_6.png","NUM_HR_7.png","NUM_HR_8.png","NUM_HR_9.png"],
              hour_zero: 1,
              hour_space: -21,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 244,
              minute_startY: 47,
              minute_array: ["NUM_MIN_0.png","NUM_MIN_1.png","NUM_MIN_2.png","NUM_MIN_3.png","NUM_MIN_4.png","NUM_MIN_5.png","NUM_MIN_6.png","NUM_MIN_7.png","NUM_MIN_8.png","NUM_MIN_9.png"],
              minute_zero: 1,
              minute_space: -21,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 192,
              y: 38,
              src: 'NUM_HR__.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 28,
              y: 335,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 10,
              y: 151,
              w: 365,
              h: 175,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 267,
              y: 335,
              w: 100,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 21,
              y: 44,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 146,
              y: 335,
              w: 100,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 253,
              y: 68,
              w: 109,
              h: 69,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 138,
              y: 68,
              w: 105,
              h: 69,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 208,
              y: 23,
              w: 154,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 75,
                      center_y: 387,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 19,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF3E88AD,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 75,
                      center_y: 387,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 31,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF3E88AD,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 75,
                      center_y: 387,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 43,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF3E88AD,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 319,
                      center_y: 385,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 43,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF37C371,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STAND');
                let progress_cs_idle_stand = progressStand;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_stand * 100);
                  if (idle_stand_circle_scale) {
                    idle_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 75,
                      center_y: 387,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 19,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF3E88AD,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_calorie * 100);
                  if (idle_calorie_circle_scale) {
                    idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 75,
                      center_y: 387,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 31,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF3E88AD,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 75,
                      center_y: 387,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 43,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF3E88AD,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 319,
                      center_y: 385,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 43,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF37C371,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}