﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// Change color BG

        let colornumber_main = 1
        let totalcolors_main = 6
        let namecolor_main = ''

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

if ( colornumber_main == 1) { namecolor_main = "BLUE"}
if ( colornumber_main == 2) { namecolor_main = "YELLOW"}
if ( colornumber_main == 3) { namecolor_main = "ORANGE"}
if ( colornumber_main == 4) { namecolor_main = "RED"}
if ( colornumber_main == 5) { namecolor_main = "GREEN"}
if ( colornumber_main == 6) { namecolor_main = "BLACK"}
hmUI.showToast({text: namecolor_main });

             normal_image_img.setProperty(hmUI.prop.SRC, "Top" + parseInt(colornumber_main) + ".png");             
        }

/////////////////////////////////////////////////////////////////////////////////////////////////

        // Time Circle ON / OFF
        let elementnumber_1 = 1
        let total_elemente = 2

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'CIRCLE TIME ON'});
            if(elementnumber_1==2) hmUI.showToast({text: 'CIRCLE TIME OFF'});
        }

        //CIRCLE TIME ON 
        function UpdateElementeOne(){
        normal_hour_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
        normal_minute_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
        normal_second_circle_scale.setProperty(hmUI.prop.VISIBLE, true);

        }

        //CIRCLE TIME OFF
        function UpdateElementeTwo(){
        normal_hour_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_minute_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_second_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_image_img = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 16;
        let normal_heart_rate_TextCircle_img_height = 15;
        let normal_heart_rate_TextCircle_error_img_width = 16;
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 16;
        let normal_calorie_TextCircle_img_height = 15;
        let normal_calorie_TextCircle_error_img_width = 16;
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 16;
        let normal_step_TextCircle_img_height = 15;
        let normal_step_TextCircle_error_img_width = 16;
        let normal_distance_TextCircle = new Array(5);
        let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
        let normal_distance_TextCircle_img_width = 16;
        let normal_distance_TextCircle_img_height = 15;
        let normal_distance_TextCircle_unit = null;
        let normal_distance_TextCircle_unit_width = 24;
        let normal_distance_TextCircle_dot_width = 4;
        let normal_distance_TextCircle_error_img_width = 16;
        let normal_battery_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_hour_circle_scale = ''
        let normal_minute_circle_scale = ''
        let normal_timerUpdateSec = undefined;
        let normal_second_circle_scale = ''
        let normal_timerUpdateSecCircle = undefined;
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_background_bg_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_image_img = ''
        let idle_heart_rate_TextCircle = new Array(3);
        let idle_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextCircle_img_width = 16;
        let idle_heart_rate_TextCircle_img_height = 15;
        let idle_heart_rate_TextCircle_error_img_width = 16;
        let idle_calorie_TextCircle = new Array(4);
        let idle_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let idle_calorie_TextCircle_img_width = 16;
        let idle_calorie_TextCircle_img_height = 15;
        let idle_calorie_TextCircle_error_img_width = 16;
        let idle_step_TextCircle = new Array(5);
        let idle_step_TextCircle_ASCIIARRAY = new Array(10);
        let idle_step_TextCircle_img_width = 16;
        let idle_step_TextCircle_img_height = 15;
        let idle_step_TextCircle_error_img_width = 16;
        let idle_distance_TextCircle = new Array(5);
        let idle_distance_TextCircle_ASCIIARRAY = new Array(10);
        let idle_distance_TextCircle_img_width = 16;
        let idle_distance_TextCircle_img_height = 15;
        let idle_distance_TextCircle_unit = null;
        let idle_distance_TextCircle_unit_width = 24;
        let idle_distance_TextCircle_dot_width = 4;
        let idle_distance_TextCircle_error_img_width = 16;
        let idle_battery_text_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSecSmooth = undefined;
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 67,
              y: 298,
              image_array: ["Weather_image_01.png","Weather_image_02.png","Weather_image_03.png","Weather_image_04.png","Weather_image_05.png","Weather_image_06.png","Weather_image_07.png","Weather_image_08.png","Weather_image_09.png","Weather_image_10.png","Weather_image_11.png","Weather_image_12.png","Weather_image_13.png","Weather_image_14.png","Weather_image_15.png","Weather_image_16.png","Weather_image_17.png","Weather_image_18.png","Weather_image_19.png","Weather_image_20.png","Weather_image_21.png","Weather_image_22.png","Weather_image_23.png","Weather_image_24.png","Weather_image_25.png","Weather_image_26.png","Weather_image_27.png","Weather_image_28.png","Weather_image_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 275,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_Unit.png',
              unit_tc: 'Temp_Unit.png',
              unit_en: 'Temp_Unit.png',
              imperial_unit_sc: 'Temp_Unit.png',
              imperial_unit_tc: 'Temp_Unit.png',
              imperial_unit_en: 'Temp_Unit.png',
              negative_image: 'Temp_error.png',
              invalid_image: 'Temp_error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 115,
                y: 275,
                font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Temp_Unit.png',
                unit_tc: 'Temp_Unit.png',
                unit_en: 'Temp_Unit.png',
                imperial_unit_sc: 'Temp_Unit.png',
                imperial_unit_tc: 'Temp_Unit.png',
                imperial_unit_en: 'Temp_Unit.png',
                negative_image: 'Temp_error.png',
                invalid_image: 'Temp_error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 29,
              src: 'Top1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 195,
              // circle_center_Y: 225,
              // font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              // radius: 224,
              // angle: 141,
              // char_space_angle: 1,
              // error_image: 'Day_0.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'Day_0.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'Day_1.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'Day_2.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'Day_3.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'Day_4.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'Day_5.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'Day_6.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'Day_7.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'Day_8.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'Day_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 195,
                center_y: 225,
                pos_x: 195 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 225 + 209,
                src: 'Day_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 195,
              // circle_center_Y: 225,
              // font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              // radius: 221,
              // angle: 220,
              // char_space_angle: 1,
              // error_image: 'Day_0.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = 'Day_0.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = 'Day_1.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = 'Day_2.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = 'Day_3.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = 'Day_4.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = 'Day_5.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = 'Day_6.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = 'Day_7.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = 'Day_8.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = 'Day_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 195,
                center_y: 225,
                pos_x: 195 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 225 + 206,
                src: 'Day_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 195,
              // circle_center_Y: 225,
              // font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              // radius: 205,
              // angle: 319,
              // char_space_angle: 0,
              // error_image: 'Day_0.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'Day_0.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'Day_1.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'Day_2.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'Day_3.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'Day_4.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'Day_5.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'Day_6.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'Day_7.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'Day_8.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'Day_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 195,
                center_y: 225,
                pos_x: 195 - normal_step_TextCircle_img_width / 2,
                pos_y: 225 - 220,
                src: 'Day_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 195,
              // circle_center_Y: 225,
              // font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              // radius: 205,
              // angle: 42,
              // char_space_angle: 0,
              // unit: 'Dis_KM.png',
              // imperial_unit: 'Dis_Mi.png',
              // dot_image: 'Dis_dot.png',
              // error_image: 'Day_0.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextCircle_ASCIIARRAY[0] = 'Day_0.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = 'Day_1.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = 'Day_2.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = 'Day_3.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = 'Day_4.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = 'Day_5.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = 'Day_6.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = 'Day_7.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = 'Day_8.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = 'Day_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 195,
                center_y: 225,
                pos_x: 195 - normal_distance_TextCircle_img_width / 2,
                pos_y: 225 - 220,
                src: 'Day_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 195,
              center_y: 225,
              pos_x: 195 - normal_distance_TextCircle_unit_width / 2,
              pos_y: 225 - 220,
              src: 'Dis_KM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextCircle_unit.setProperty(hmUI.prop.SRC, 'Dis_Mi.png');
            };
            //#endregion
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 281,
              y: 295,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 267,
              y: 326,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 221,
              y: 348,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 180,
              day_startY: 345,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 139,
              month_startY: 348,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 264,
              y: 417,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 107,
              y: 420,
              src: 'Alarm_icon.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 233,
              am_y: 274,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 233,
              pm_y: 274,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 182,
              second_startY: 288,
              second_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 168,
              minute_startY: 228,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 167,
              hour_startY: 191,
              hour_array: ["Time_E_0.png","Time_E_1.png","Time_E_2.png","Time_E_3.png","Time_E_4.png","Time_E_5.png","Time_E_6.png","Time_E_7.png","Time_E_8.png","Time_E_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_hour_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 196,
              // center_y: 224,
              // start_angle: 251,
              // end_angle: 469,
              // radius: 99,
              // line_width: 44,
              // line_cap: Flat,
              // color: 0xFF1EA6FF,
              // mirror: False,
              // inversion: False,
              // alpha: 99,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_hour_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 196,
              center_y: 224,
              start_angle: 251,
              end_angle: 469,
              radius: 77,
              line_width: 44,
              corner_flag: 3,
              color: 0xFF1EA6FF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hour_circle_scale.setAlpha(99);

            // normal_minute_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 196,
              // center_y: 224,
              // start_angle: 251,
              // end_angle: 469,
              // radius: 143,
              // line_width: 29,
              // line_cap: Flat,
              // color: 0xFFFF0508,
              // mirror: False,
              // inversion: False,
              // alpha: 99,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_minute_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 196,
              center_y: 224,
              start_angle: 251,
              end_angle: 469,
              radius: 129,
              line_width: 29,
              corner_flag: 3,
              color: 0xFFFF0508,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_minute_circle_scale.setAlpha(99);

            let screenType = hmSetting.getScreenType();
            // normal_second_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 196,
              // center_y: 224,
              // start_angle: 252,
              // end_angle: 471,
              // radius: 173,
              // line_width: 30,
              // line_cap: Flat,
              // color: 0xFFFF9007,
              // mirror: False,
              // inversion: False,
              // alpha: 99,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_second_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 196,
              center_y: 224,
              start_angle: 252,
              end_angle: 471,
              radius: 158,
              line_width: 30,
              corner_flag: 3,
              color: 0xFFFF9007,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_second_circle_scale.setAlpha(99);

            // normal_time_circle_options = hmUI.createWidget(hmUI.widget.TIME_CIRCLE_OPTIONS, {
              // smooth: true,
              // format24h: false,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            const deviceInfo = hmSetting.getDeviceInfo();
            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_H1.png',
              // center_x: 195,
              // center_y: 225,
              // x: 7,
              // y: 119,
              // start_angle: 253,
              // end_angle: 467,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 7,
              pos_y: 225 - 119,
              center_x: 195,
              center_y: 225,
              src: 'Hand_H1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_M1.png',
              // center_x: 195,
              // center_y: 225,
              // x: 7,
              // y: 179,
              // start_angle: 252,
              // end_angle: 469,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 7,
              pos_y: 225 - 179,
              center_x: 195,
              center_y: 225,
              src: 'Hand_M1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_S1.png',
              // center_x: 195,
              // center_y: 225,
              // x: 7,
              // y: 179,
              // start_angle: 252,
              // end_angle: 469,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 7,
              pos_y: 225 - 179,
              center_x: 195,
              center_y: 225,
              src: 'Hand_S1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 67,
              y: 298,
              image_array: ["Weather_image_01.png","Weather_image_02.png","Weather_image_03.png","Weather_image_04.png","Weather_image_05.png","Weather_image_06.png","Weather_image_07.png","Weather_image_08.png","Weather_image_09.png","Weather_image_10.png","Weather_image_11.png","Weather_image_12.png","Weather_image_13.png","Weather_image_14.png","Weather_image_15.png","Weather_image_16.png","Weather_image_17.png","Weather_image_18.png","Weather_image_19.png","Weather_image_20.png","Weather_image_21.png","Weather_image_22.png","Weather_image_23.png","Weather_image_24.png","Weather_image_25.png","Weather_image_26.png","Weather_image_27.png","Weather_image_28.png","Weather_image_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 275,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_Unit.png',
              unit_tc: 'Temp_Unit.png',
              unit_en: 'Temp_Unit.png',
              imperial_unit_sc: 'Temp_Unit.png',
              imperial_unit_tc: 'Temp_Unit.png',
              imperial_unit_en: 'Temp_Unit.png',
              negative_image: 'Temp_error.png',
              invalid_image: 'Temp_error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 115,
                y: 275,
                font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Temp_Unit.png',
                unit_tc: 'Temp_Unit.png',
                unit_en: 'Temp_Unit.png',
                imperial_unit_sc: 'Temp_Unit.png',
                imperial_unit_tc: 'Temp_Unit.png',
                imperial_unit_en: 'Temp_Unit.png',
                negative_image: 'Temp_error.png',
                invalid_image: 'Temp_error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 29,
              src: 'Top6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 195,
              // circle_center_Y: 225,
              // font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              // radius: 224,
              // angle: 141,
              // char_space_angle: 1,
              // error_image: 'Day_0.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextCircle_ASCIIARRAY[0] = 'Day_0.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[1] = 'Day_1.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[2] = 'Day_2.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[3] = 'Day_3.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[4] = 'Day_4.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[5] = 'Day_5.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[6] = 'Day_6.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[7] = 'Day_7.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[8] = 'Day_8.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[9] = 'Day_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 195,
                center_y: 225,
                pos_x: 195 - idle_heart_rate_TextCircle_img_width / 2,
                pos_y: 225 + 209,
                src: 'Day_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 195,
              // circle_center_Y: 225,
              // font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              // radius: 221,
              // angle: 220,
              // char_space_angle: 1,
              // error_image: 'Day_0.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_TextCircle_ASCIIARRAY[0] = 'Day_0.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[1] = 'Day_1.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[2] = 'Day_2.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[3] = 'Day_3.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[4] = 'Day_4.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[5] = 'Day_5.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[6] = 'Day_6.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[7] = 'Day_7.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[8] = 'Day_8.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[9] = 'Day_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 4; i++) {
              idle_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 195,
                center_y: 225,
                pos_x: 195 - idle_calorie_TextCircle_img_width / 2,
                pos_y: 225 + 206,
                src: 'Day_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 195,
              // circle_center_Y: 225,
              // font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              // radius: 205,
              // angle: 319,
              // char_space_angle: 0,
              // error_image: 'Day_0.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextCircle_ASCIIARRAY[0] = 'Day_0.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[1] = 'Day_1.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[2] = 'Day_2.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[3] = 'Day_3.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[4] = 'Day_4.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[5] = 'Day_5.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[6] = 'Day_6.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[7] = 'Day_7.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[8] = 'Day_8.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[9] = 'Day_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              idle_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 195,
                center_y: 225,
                pos_x: 195 - idle_step_TextCircle_img_width / 2,
                pos_y: 225 - 220,
                src: 'Day_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 195,
              // circle_center_Y: 225,
              // font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              // radius: 205,
              // angle: 42,
              // char_space_angle: 0,
              // unit: 'Dis_KM.png',
              // imperial_unit: 'Dis_Mi.png',
              // dot_image: 'Dis_dot.png',
              // error_image: 'Day_0.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_distance_TextCircle_ASCIIARRAY[0] = 'Day_0.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[1] = 'Day_1.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[2] = 'Day_2.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[3] = 'Day_3.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[4] = 'Day_4.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[5] = 'Day_5.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[6] = 'Day_6.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[7] = 'Day_7.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[8] = 'Day_8.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[9] = 'Day_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              idle_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                center_x: 195,
                center_y: 225,
                pos_x: 195 - idle_distance_TextCircle_img_width / 2,
                pos_y: 225 - 220,
                src: 'Day_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_distance_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              center_x: 195,
              center_y: 225,
              pos_x: 195 - idle_distance_TextCircle_unit_width / 2,
              pos_y: 225 - 220,
              src: 'Dis_KM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (mileageUnit == 1) {
              idle_distance_TextCircle_unit.setProperty(hmUI.prop.SRC, 'Dis_Mi.png');
            };
            //#endregion

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 281,
              y: 295,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 267,
              y: 326,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 221,
              y: 348,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 180,
              day_startY: 345,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 139,
              month_startY: 348,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 264,
              y: 417,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 107,
              y: 420,
              src: 'Alarm_icon.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 233,
              am_y: 274,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 233,
              pm_y: 274,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 168,
              minute_startY: 228,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 177,
              y: 289,
              src: 'icon_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 167,
              hour_startY: 191,
              hour_array: ["Time_E_0.png","Time_E_1.png","Time_E_2.png","Time_E_3.png","Time_E_4.png","Time_E_5.png","Time_E_6.png","Time_E_7.png","Time_E_8.png","Time_E_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_H1.png',
              // center_x: 195,
              // center_y: 225,
              // x: 7,
              // y: 119,
              // start_angle: 253,
              // end_angle: 467,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 7,
              pos_y: 225 - 119,
              center_x: 195,
              center_y: 225,
              src: 'Hand_H1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_M1.png',
              // center_x: 195,
              // center_y: 225,
              // x: 7,
              // y: 179,
              // start_angle: 252,
              // end_angle: 469,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 7,
              pos_y: 225 - 179,
              center_x: 195,
              center_y: 225,
              src: 'Hand_M1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_S1.png',
              // center_x: 195,
              // center_y: 225,
              // x: 7,
              // y: 179,
              // start_angle: 252,
              // end_angle: 469,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 195 - 7,
              pos_y: 225 - 179,
              center_x: 195,
              center_y: 225,
              src: 'Hand_S1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 1,
              w: 83,
              h: 84,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 299,
              y: 366,
              w: 88,
              h: 84,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 2,
              y: 365,
              w: 89,
              h: 83,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 61,
              y: 298,
              w: 49,
              h: 50,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 269,
              y: 326,
              w: 33,
              h: 35,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 116,
              y: 256,
              w: 48,
              h: 52,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 179,
              y: 278,
              w: 40,
              h: 45,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 175,
              y: 203,
              w: 41,
              h: 45,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 98,
              y: 410,
              w: 34,
              h: 35,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 288,
              y: 275,
              w: 55,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 134,
              y: 339,
              w: 123,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 293,
              y: 4,
              w: 96,
              h: 98,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 138,
              y: 410,
              w: 110,
              h: 39,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //CHANGE COLOR
                click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 122,
              y: 1,
              w: 151,
              h: 59,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_elemente()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) { // Hour Circle
                let normal_circle_scale_hour = hour;
                if (normal_circle_scale_hour > 11) normal_circle_scale_hour -= 12;
                let normal_hourCircleProgress = normal_circle_scale_hour/12 + (minute/60)/12;
                normal_hourCircleProgress = normal_hourCircleProgress * 100;
                if (normal_hour_circle_scale) normal_hour_circle_scale.setProperty(hmUI.prop.LEVEL, normal_hourCircleProgress );
              };

              if (updateMinute) { // Minute Circle
                let normal_minuteCircleProgress = minute/60 +(second / 60) / 60;
                normal_minuteCircleProgress = normal_minuteCircleProgress * 100;
                if (normal_minute_circle_scale) normal_minute_circle_scale.setProperty(hmUI.prop.LEVEL, normal_minuteCircleProgress );
              };

              // Second Circle
              let normal_secondCircleProgress = 100 * (second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_second_circle_scale) normal_second_circle_scale.setProperty(hmUI.prop.LEVEL, normal_secondCircleProgress );

              if (updateMinute) { // Hour Pointer
                let normal_hour = hour;
                let normal_fullAngle_hour = 214;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 253 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 217;
                let normal_angle_minute = 252 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              // Second Pointer
              let normal_fullAngle_second = 217;
              let normal_angle_second = 252 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              if (updateMinute) { // Hour Pointer
                let idle_hour = hour;
                let idle_fullAngle_hour = 214;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 253 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

                let idle_fullAngle_minute = 217;
                let idle_angle_minute = 252 + idle_fullAngle_minute*(minute + second/60)/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              // Second Pointer
              let idle_fullAngle_second = 217;
              let idle_angle_second = 252 + idle_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 321;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 224));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_angleOffset + 1 * (normal_heart_rate_circle_string.length - 1) / 2;
                  normal_heart_rate_TextCircle_angleOffset = -normal_heart_rate_TextCircle_angleOffset;
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_heart_rate_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.POS_X, 195 - normal_heart_rate_TextCircle_error_img_width / 2);
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.SRC, 'Day_0.png');
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 400;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 221));
                  // alignment = CENTER_H
                  let normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_img_angle * (normal_calorie_circle_string.length - 1);
                  normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_angleOffset + 1 * (normal_calorie_circle_string.length - 1) / 2;
                  normal_calorie_TextCircle_angleOffset = -normal_calorie_TextCircle_angleOffset;
                  char_Angle -= normal_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_calorie_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.POS_X, 195 - normal_calorie_TextCircle_error_img_width / 2);
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.SRC, 'Day_0.png');
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 319;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 205));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_step_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_step_TextCircle[0].setProperty(hmUI.prop.POS_X, 195 - normal_step_TextCircle_error_img_width / 2);
                  normal_step_TextCircle[0].setProperty(hmUI.prop.SRC, 'Day_0.png');
                  normal_step_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);
              if (mileageUnit == 1) normal_distance_circle_string = (0.621371 * distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 42;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_distance_TextCircle_img_angle = 0;
                  let normal_distance_TextCircle_dot_img_angle = 0;
                  let normal_distance_TextCircle_unit_angle = 0;
                  normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width/2, 205));
                  normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width/2, 205));
                  normal_distance_TextCircle_unit_angle = toDegree(Math.atan2(normal_distance_TextCircle_unit_width/2, 205));
                  // alignment = CENTER_H
                  let normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_img_angle * (normal_distance_circle_string.length - 1);
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset - normal_distance_TextCircle_img_angle + normal_distance_TextCircle_dot_img_angle;
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset + (normal_distance_TextCircle_img_angle + normal_distance_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= normal_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - normal_distance_TextCircle_img_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - normal_distance_TextCircle_dot_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'Dis_dot.png');
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_distance_TextCircle_unit_angle;
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.POS_X, 195 - normal_distance_TextCircle_error_img_width / 2);
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.SRC, 'Day_0.png');
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let idle_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 321;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_circle_string.length > 0 && idle_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let idle_heart_rate_TextCircle_img_angle = 0;
                  let idle_heart_rate_TextCircle_dot_img_angle = 0;
                  idle_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(idle_heart_rate_TextCircle_img_width/2, 224));
                  // alignment = CENTER_H
                  let idle_heart_rate_TextCircle_angleOffset = idle_heart_rate_TextCircle_img_angle * (idle_heart_rate_circle_string.length - 1);
                  idle_heart_rate_TextCircle_angleOffset = idle_heart_rate_TextCircle_angleOffset + 1 * (idle_heart_rate_circle_string.length - 1) / 2;
                  idle_heart_rate_TextCircle_angleOffset = -idle_heart_rate_TextCircle_angleOffset;
                  char_Angle -= idle_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - idle_heart_rate_TextCircle_img_width / 2);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_heart_rate_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_heart_rate_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_heart_rate_TextCircle[0].setProperty(hmUI.prop.POS_X, 195 - idle_heart_rate_TextCircle_error_img_width / 2);
                  idle_heart_rate_TextCircle[0].setProperty(hmUI.prop.SRC, 'Day_0.png');
                  idle_heart_rate_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let idle_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 400;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && idle_calorie_circle_string.length > 0 && idle_calorie_circle_string.length <= 4) {  // display data if it was possible to get it
                  let idle_calorie_TextCircle_img_angle = 0;
                  let idle_calorie_TextCircle_dot_img_angle = 0;
                  idle_calorie_TextCircle_img_angle = toDegree(Math.atan2(idle_calorie_TextCircle_img_width/2, 221));
                  // alignment = CENTER_H
                  let idle_calorie_TextCircle_angleOffset = idle_calorie_TextCircle_img_angle * (idle_calorie_circle_string.length - 1);
                  idle_calorie_TextCircle_angleOffset = idle_calorie_TextCircle_angleOffset + 1 * (idle_calorie_circle_string.length - 1) / 2;
                  idle_calorie_TextCircle_angleOffset = -idle_calorie_TextCircle_angleOffset;
                  char_Angle -= idle_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - idle_calorie_TextCircle_img_width / 2);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, idle_calorie_TextCircle_ASCIIARRAY[charCode]);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_calorie_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_calorie_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_calorie_TextCircle[0].setProperty(hmUI.prop.POS_X, 195 - idle_calorie_TextCircle_error_img_width / 2);
                  idle_calorie_TextCircle[0].setProperty(hmUI.prop.SRC, 'Day_0.png');
                  idle_calorie_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle step_STEP');
              let idle_step_circle_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 319;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_circle_string.length > 0 && idle_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let idle_step_TextCircle_img_angle = 0;
                  let idle_step_TextCircle_dot_img_angle = 0;
                  idle_step_TextCircle_img_angle = toDegree(Math.atan2(idle_step_TextCircle_img_width/2, 205));
                  // alignment = CENTER_H
                  let idle_step_TextCircle_angleOffset = idle_step_TextCircle_img_angle * (idle_step_circle_string.length - 1);
                  char_Angle -= idle_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_step_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - idle_step_TextCircle_img_width / 2);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.SRC, idle_step_TextCircle_ASCIIARRAY[charCode]);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_step_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_step_TextCircle[0].setProperty(hmUI.prop.POS_X, 195 - idle_step_TextCircle_error_img_width / 2);
                  idle_step_TextCircle[0].setProperty(hmUI.prop.SRC, 'Day_0.png');
                  idle_step_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle DISTANCE');
              let idle_distance_circle_string = (distanceCurrent / 1000).toFixed(2);
              if (mileageUnit == 1) idle_distance_circle_string = (0.621371 * distanceCurrent / 1000).toFixed(2);

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 42;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && idle_distance_circle_string.length > 0 && idle_distance_circle_string.length <= 5) {  // display data if it was possible to get it
                  let idle_distance_TextCircle_img_angle = 0;
                  let idle_distance_TextCircle_dot_img_angle = 0;
                  let idle_distance_TextCircle_unit_angle = 0;
                  idle_distance_TextCircle_img_angle = toDegree(Math.atan2(idle_distance_TextCircle_img_width/2, 205));
                  idle_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_distance_TextCircle_dot_width/2, 205));
                  idle_distance_TextCircle_unit_angle = toDegree(Math.atan2(idle_distance_TextCircle_unit_width/2, 205));
                  // alignment = CENTER_H
                  let idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_img_angle * (idle_distance_circle_string.length - 1);
                  idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_angleOffset - idle_distance_TextCircle_img_angle + idle_distance_TextCircle_dot_img_angle;
                  idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_angleOffset + (idle_distance_TextCircle_img_angle + idle_distance_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= idle_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - idle_distance_TextCircle_img_width / 2);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.SRC, idle_distance_TextCircle_ASCIIARRAY[charCode]);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_distance_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += idle_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 195 - idle_distance_TextCircle_dot_width / 2);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'Dis_dot.png');
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_distance_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += idle_distance_TextCircle_unit_angle;
                  idle_distance_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.POS_X, 195 - idle_distance_TextCircle_error_img_width / 2);
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.SRC, 'Day_0.png');
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecCircle) {
                    let animDelay = 0;
                    let animRepeat = 1000/12;
                    normal_timerUpdateSecCircle = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    idle_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecCircle) {
                  timer.stopTimer(normal_timerUpdateSecCircle);
                  normal_timerUpdateSecCircle = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }
                if (idle_timerUpdateSecSmooth) {
                  timer.stopTimer(idle_timerUpdateSecSmooth);
                  idle_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}