try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_11225a098db64efda00c5b9cd2179d5c = '';
        let normal$_$text_10004cb6451f43f89d3d05d6839e0daa = '';
        let normal$_$text_bd11bcdf6d4642b5aa4b1920de0a2b66 = '';
        let normal$_$text_fc88bd5bc01247fba687909e94efcd5c = '';
        let normal$_$text_df58a5003ee6464e8c5f84b73b4581a5 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let timeSensor = '';
        let heartSensor = '';
        let stepSensor = '';
        let batterySensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 320,
                    h: 380,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_11225a098db64efda00c5b9cd2179d5c = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 0,
                    y: 32,
                    w: 320,
                    h: 70,
                    text: '[HOUR_24_Z]:[MIN_Z]:[SEC_Z]',
                    color: '0xFF000000',
                    text_size: 60,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_10004cb6451f43f89d3d05d6839e0daa = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 101,
                    y: 232,
                    w: 200,
                    h: 53,
                    text: '[HR]',
                    color: '0xFF000000',
                    text_size: 50,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_bd11bcdf6d4642b5aa4b1920de0a2b66 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 101,
                    y: 165,
                    w: 200,
                    h: 53,
                    text: '[SC]',
                    color: '0xFF000000',
                    text_size: 50,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_fc88bd5bc01247fba687909e94efcd5c = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 102,
                    y: 298,
                    w: 200,
                    h: 53,
                    text: '[BATT_PER]',
                    color: '0xFF000000',
                    text_size: 50,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_df58a5003ee6464e8c5f84b73b4581a5 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 0,
                    y: 90,
                    w: 320,
                    h: 53,
                    text: '[DAY].[MON_Z].[YEAR]',
                    color: '0xFF000000',
                    text_size: 30,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
                    normal$_$text_11225a098db64efda00c5b9cd2179d5c.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_10004cb6451f43f89d3d05d6839e0daa.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                }), stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_bd11bcdf6d4642b5aa4b1920de0a2b66.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_fc88bd5bc01247fba687909e94efcd5c.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }` });
                }), timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_df58a5003ee6464e8c5f84b73b4581a5.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }.${ String(timeSensor.month).padStart(2, '0') }.${ timeSensor.day }` });
                        },
                        () => {
                            normal$_$text_df58a5003ee6464e8c5f84b73b4581a5.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }.${ String(timeSensor.month).padStart(2, '0') }.${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_df58a5003ee6464e8c5f84b73b4581a5.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }.${ timeSensor.day }.${ timeSensor.year }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                });
                normal$_$text_11225a098db64efda00c5b9cd2179d5c.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                timer.createTimer(0, 1000, function (timeSensor2) {
                    normal$_$text_11225a098db64efda00c5b9cd2179d5c.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor2.hour).padStart(2, '0') }:${ String(timeSensor2.minute).padStart(2, '0') }:${ String(timeSensor2.second).padStart(2, '0') }` });
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 10,
                    y: 220,
                    w: 300,
                    h: 158,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 10,
                    y: 0,
                    w: 300,
                    h: 160,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_11225a098db64efda00c5b9cd2179d5c.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                        normal$_$text_10004cb6451f43f89d3d05d6839e0daa.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                        normal$_$text_bd11bcdf6d4642b5aa4b1920de0a2b66.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        normal$_$text_fc88bd5bc01247fba687909e94efcd5c.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_df58a5003ee6464e8c5f84b73b4581a5.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }.${ String(timeSensor.month).padStart(2, '0') }.${ timeSensor.day }` });
                            },
                            () => {
                                normal$_$text_df58a5003ee6464e8c5f84b73b4581a5.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }.${ String(timeSensor.month).padStart(2, '0') }.${ timeSensor.year }` });
                            },
                            () => {
                                normal$_$text_df58a5003ee6464e8c5f84b73b4581a5.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }.${ timeSensor.day }.${ timeSensor.year }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}