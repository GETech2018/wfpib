try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_03df237cc21a47e5adc01698ebd5331b = '';
        let normal$_$text_0e1277ef8aaa4d69af6996d96ebe7d73 = '';
        let normal$_$text_405b0048c1c6465f8c5470368439415b = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_69a28fbcc8224b5d8e6d2fe8db3e9c37 = '';
        const WEEK_EN_S = function (val) {
            const valueMap = {
                '1': 'Mon',
                '2': 'Tue',
                '3': 'Wed',
                '4': 'Thu',
                '5': 'Fri',
                '6': 'Sat',
                '7': 'Sun'
            };
            return valueMap[val];
        };
        let batterySensor = '';
        let timeSensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 432,
                    h: 514,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_03df237cc21a47e5adc01698ebd5331b = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 183,
                    y: 309,
                    w: 69,
                    h: 34,
                    text: '[BATT_PER]%',
                    color: '0xFF470b0b',
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_0e1277ef8aaa4d69af6996d96ebe7d73 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 223,
                    y: 239,
                    w: 100,
                    h: 40,
                    text: '[HOUR_24_Z]:[MIN_Z]',
                    color: '0xFF470b0b',
                    text_size: 23,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_405b0048c1c6465f8c5470368439415b = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 118,
                    y: 239,
                    w: 100,
                    h: 22,
                    text: '[DAY_Z]/[HOUR_24_Z]',
                    color: '0xFF470b0b',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_69a28fbcc8224b5d8e6d2fe8db3e9c37 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 118,
                    y: 257,
                    w: 100,
                    h: 40,
                    text: '[WEEK_EN_S]',
                    color: '0xFF470b0b',
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.TOP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 218,
                    hour_centerY: 259,
                    hour_posX: 32,
                    hour_posY: 208,
                    hour_path: '3.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 218,
                    minute_centerY: 259,
                    minute_posX: 32,
                    minute_posY: 208,
                    minute_path: '4.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 218,
                    second_centerY: 259,
                    second_posX: 32,
                    second_posY: 208,
                    second_path: '5.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_03df237cc21a47e5adc01698ebd5331b.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                }), timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
                    normal$_$text_0e1277ef8aaa4d69af6996d96ebe7d73.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_405b0048c1c6465f8c5470368439415b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.hour).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_405b0048c1c6465f8c5470368439415b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.hour).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_405b0048c1c6465f8c5470368439415b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.hour).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                }), timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_405b0048c1c6465f8c5470368439415b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.hour).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_405b0048c1c6465f8c5470368439415b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.hour).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_405b0048c1c6465f8c5470368439415b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.hour).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    normal$_$text_69a28fbcc8224b5d8e6d2fe8db3e9c37.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                });
                normal$_$text_0e1277ef8aaa4d69af6996d96ebe7d73.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                timer.createTimer(0, 1000, function (timeSensor2) {
                    normal$_$text_0e1277ef8aaa4d69af6996d96ebe7d73.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor2.hour).padStart(2, '0') }:${ String(timeSensor2.minute).padStart(2, '0') }` });
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_03df237cc21a47e5adc01698ebd5331b.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                        normal$_$text_0e1277ef8aaa4d69af6996d96ebe7d73.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }:${ String(timeSensor.minute).padStart(2, '0') }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_405b0048c1c6465f8c5470368439415b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.hour).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_405b0048c1c6465f8c5470368439415b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.hour).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_405b0048c1c6465f8c5470368439415b.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.hour).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_69a28fbcc8224b5d8e6d2fe8db3e9c37.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_S(timeSensor.week) }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}