﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 320,
              h: 380,
              src: 'rendition1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 51,
              y: 174,
              src: 'bat_larH.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 81,
              y: 165,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 222,
              month_startY: 42,
              month_sc_array: ["mes_01.png","mes_02.png","mes_03.png","mes_04.png","mes_05.png","mes_06.png","mes_07.png","mes_08.png","mes_09.png","mes_10.png","mes_11.png","mes_12.png"],
              month_tc_array: ["mes_01.png","mes_02.png","mes_03.png","mes_04.png","mes_05.png","mes_06.png","mes_07.png","mes_08.png","mes_09.png","mes_10.png","mes_11.png","mes_12.png"],
              month_en_array: ["mes_01.png","mes_02.png","mes_03.png","mes_04.png","mes_05.png","mes_06.png","mes_07.png","mes_08.png","mes_09.png","mes_10.png","mes_11.png","mes_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 220,
              day_startY: 69,
              day_sc_array: ["day_num_0.png","day_num_1.png","day_num_2.png","day_num_3.png","day_num_4.png","day_num_5.png","day_num_6.png","day_num_7.png","day_num_8.png","day_num_9.png"],
              day_tc_array: ["day_num_0.png","day_num_1.png","day_num_2.png","day_num_3.png","day_num_4.png","day_num_5.png","day_num_6.png","day_num_7.png","day_num_8.png","day_num_9.png"],
              day_en_array: ["day_num_0.png","day_num_1.png","day_num_2.png","day_num_3.png","day_num_4.png","day_num_5.png","day_num_6.png","day_num_7.png","day_num_8.png","day_num_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 192,
              hour_startY: 112,
              hour_array: ["sec_num_0.png","sec_num_1.png","sec_num_2.png","sec_num_3.png","sec_num_4.png","sec_num_5.png","sec_num_6.png","sec_num_7.png","sec_num_8.png","sec_num_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 186,
              minute_startY: 213,
              minute_array: ["sec_num_0.png","sec_num_1.png","sec_num_2.png","sec_num_3.png","sec_num_4.png","sec_num_5.png","sec_num_6.png","sec_num_7.png","sec_num_8.png","sec_num_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 192,
              y: 184,
              src: 'sec_num_colon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}