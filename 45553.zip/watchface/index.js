﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let normal_date_img_date_day = ''
        let normal_temperature_current_text_img = ''
        let normal_bio_charge_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_hour = ''
        let idle_background_bg_img = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let idle_date_img_date_day = ''
        let idle_bio_charge_image_progress_img_level = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_hour = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Oswald-Medium.ttf; FontSize: 28; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 33,
              h: 33,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'background_1c3e96b5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 133,
              y: 56,
              image_array: ["set_29_124x125_fv_img_level_1.png","set_29_124x125_fv_img_level_2.png","set_29_124x125_fv_img_level_3.png","set_29_124x125_fv_img_level_4.png","set_29_124x125_fv_img_level_5.png","set_29_124x125_fv_img_level_6.png","set_29_124x125_fv_img_level_7.png","set_29_124x125_fv_img_level_8.png","set_29_124x125_fv_img_level_9.png","set_29_124x125_fv_img_level_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 157,
              y: 93,
              font_array: ["chars_2778334C_000.png","chars_2778334C_001.png","chars_2778334C_002.png","chars_2778334C_003.png","chars_2778334C_004.png","chars_2778334C_005.png","chars_2778334C_006.png","chars_2778334C_007.png","chars_2778334C_008.png","chars_2778334C_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 133,
              y: 267,
              image_array: ["set_29_124x125_img_level_1.png","set_29_124x125_img_level_2.png","set_29_124x125_img_level_3.png","set_29_124x125_img_level_4.png","set_29_124x125_img_level_5.png","set_29_124x125_img_level_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 157,
              y: 311,
              font_array: ["chars_2778334C_000.png","chars_2778334C_001.png","chars_2778334C_002.png","chars_2778334C_003.png","chars_2778334C_004.png","chars_2778334C_005.png","chars_2778334C_006.png","chars_2778334C_007.png","chars_2778334C_008.png","chars_2778334C_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 37,
              y: 148,
              image_array: ["set_22_38x160_r90_fh_fv_img_level_1.png","set_22_38x160_r90_fh_fv_img_level_2.png","set_22_38x160_r90_fh_fv_img_level_3.png","set_22_38x160_r90_fh_fv_img_level_4.png","set_22_38x160_r90_fh_fv_img_level_5.png","set_22_38x160_r90_fh_fv_img_level_6.png","set_22_38x160_r90_fh_fv_img_level_7.png","set_22_38x160_r90_fh_fv_img_level_8.png"],
              image_length: 8,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 266,
              y: 205,
              w: 150,
              h: 36,
              text_size: 28,
              char_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: ПНД,ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 333,
              day_startY: 212,
              day_sc_array: ["chars_7644B0AD_000.png","chars_7644B0AD_001.png","chars_7644B0AD_002.png","chars_7644B0AD_003.png","chars_7644B0AD_004.png","chars_7644B0AD_005.png","chars_7644B0AD_006.png","chars_7644B0AD_007.png","chars_7644B0AD_008.png","chars_7644B0AD_009.png"],
              day_tc_array: ["chars_7644B0AD_000.png","chars_7644B0AD_001.png","chars_7644B0AD_002.png","chars_7644B0AD_003.png","chars_7644B0AD_004.png","chars_7644B0AD_005.png","chars_7644B0AD_006.png","chars_7644B0AD_007.png","chars_7644B0AD_008.png","chars_7644B0AD_009.png"],
              day_en_array: ["chars_7644B0AD_000.png","chars_7644B0AD_001.png","chars_7644B0AD_002.png","chars_7644B0AD_003.png","chars_7644B0AD_004.png","chars_7644B0AD_005.png","chars_7644B0AD_006.png","chars_7644B0AD_007.png","chars_7644B0AD_008.png","chars_7644B0AD_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 57,
              font_array: ["chars_7775B23D_000.png","chars_7775B23D_001.png","chars_7775B23D_002.png","chars_7775B23D_003.png","chars_7775B23D_004.png","chars_7775B23D_005.png","chars_7775B23D_006.png","chars_7775B23D_007.png","chars_7775B23D_008.png","chars_7775B23D_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_7775B23D_011.png',
              unit_tc: 'chars_7775B23D_011.png',
              unit_en: 'chars_7775B23D_011.png',
              negative_image: 'chars_7775B23D_010.png',
              invalid_image: 'chars_7775B23D_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 155,
              y: 185,
              image_array: ["set_27_80x80_h211s200b98_img_level_1.png","set_27_80x80_h211s200b98_img_level_2.png","set_27_80x80_h211s200b98_img_level_3.png","set_27_80x80_h211s200b98_img_level_4.png","set_27_80x80_h211s200b98_img_level_5.png","set_27_80x80_h211s200b98_img_level_6.png","set_27_80x80_h211s200b98_img_level_7.png","set_27_80x80_h211s200b98_img_level_8.png","set_27_80x80_h211s200b98_img_level_9.png","set_27_80x80_h211s200b98_img_level_10.png"],
              image_length: 10,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'pointers_minute_set_27_m_AE08FBC4.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 25,
              minute_posY: 209,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'pointers_hour_set_27_h_A233B386.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 25,
              hour_posY: 230,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 266,
              y: 205,
              w: 150,
              h: 36,
              text_size: 28,
              char_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: ПНД,ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 333,
              day_startY: 212,
              day_sc_array: ["chars_7644B0AD_000.png","chars_7644B0AD_001.png","chars_7644B0AD_002.png","chars_7644B0AD_003.png","chars_7644B0AD_004.png","chars_7644B0AD_005.png","chars_7644B0AD_006.png","chars_7644B0AD_007.png","chars_7644B0AD_008.png","chars_7644B0AD_009.png"],
              day_tc_array: ["chars_7644B0AD_000.png","chars_7644B0AD_001.png","chars_7644B0AD_002.png","chars_7644B0AD_003.png","chars_7644B0AD_004.png","chars_7644B0AD_005.png","chars_7644B0AD_006.png","chars_7644B0AD_007.png","chars_7644B0AD_008.png","chars_7644B0AD_009.png"],
              day_en_array: ["chars_7644B0AD_000.png","chars_7644B0AD_001.png","chars_7644B0AD_002.png","chars_7644B0AD_003.png","chars_7644B0AD_004.png","chars_7644B0AD_005.png","chars_7644B0AD_006.png","chars_7644B0AD_007.png","chars_7644B0AD_008.png","chars_7644B0AD_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 155,
              y: 185,
              image_array: ["set_27_80x80_h211s200b98_img_level_1.png","set_27_80x80_h211s200b98_img_level_2.png","set_27_80x80_h211s200b98_img_level_3.png","set_27_80x80_h211s200b98_img_level_4.png","set_27_80x80_h211s200b98_img_level_5.png","set_27_80x80_h211s200b98_img_level_6.png","set_27_80x80_h211s200b98_img_level_7.png","set_27_80x80_h211s200b98_img_level_8.png","set_27_80x80_h211s200b98_img_level_9.png","set_27_80x80_h211s200b98_img_level_10.png"],
              image_length: 10,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'pointers_minute_set_27_m_AE08FBC4.png',
              minute_centerX: 195,
              minute_centerY: 225,
              minute_posX: 25,
              minute_posY: 209,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'pointers_hour_set_27_h_A233B386.png',
              hour_centerX: 195,
              hour_centerY: 225,
              hour_posX: 25,
              hour_posY: 230,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 142,
              y: 61,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 144,
              y: 179,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 143,
              y: 287,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 254,
              y: 192,
              w: 126,
              h: 74,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({ appid: 1057409, url: 'page/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}